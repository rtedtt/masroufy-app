/*
 * Self-contained Offline ISO/IEC 18004 QR Code Encoder (Byte Mode, ECC Level H, Versions 1..20)
 * + Artistic Canvas Renderer for Masroufy Developer Signature Card
 */
(function (global) {
  'use strict';

  // GF(256) with primitive polynomial 0x11D
  const EXP = new Uint8Array(512);
  const LOG = new Uint8Array(256);
  (function initGF() {
    let x = 1;
    for (let i = 0; i < 255; i++) {
      EXP[i] = x;
      LOG[x] = i;
      x <<= 1;
      if (x & 0x100) x ^= 0x11d;
    }
    for (let i = 255; i < 512; i++) {
      EXP[i] = EXP[i - 255];
    }
  })();

  function gfMul(a, b) {
    if (a === 0 || b === 0) return 0;
    return EXP[LOG[a] + LOG[b]];
  }

  function rsGeneratorPoly(degree) {
    let poly = [1];
    for (let i = 0; i < degree; i++) {
      const next = new Array(poly.length + 1).fill(0);
      const factor = EXP[i];
      for (let j = 0; j < poly.length; j++) {
        next[j] ^= poly[j];
        next[j + 1] ^= gfMul(poly[j], factor);
      }
      poly = next;
    }
    return poly;
  }

  function rsComputeEC(data, ecCount) {
    const gen = rsGeneratorPoly(ecCount);
    const res = new Uint8Array(ecCount);
    for (let i = 0; i < data.length; i++) {
      const factor = data[i] ^ res[0];
      for (let j = 0; j < ecCount - 1; j++) {
        res[j] = res[j + 1] ^ gfMul(gen[j + 1], factor);
      }
      res[ecCount - 1] = gfMul(gen[ecCount], factor);
    }
    return res;
  }

  // ISO 18004 ECC Level H (Error Correction Level = 10 binary, max ~30% recovery)
  // Format per version (1..20): [ecPerBlock, g1Blocks, g1Data, g2Blocks, g2Data]
  const ECC_H_TABLE = {
    1:  [17, 1, 9,  0, 0],
    2:  [28, 1, 16, 0, 0],
    3:  [22, 2, 13, 0, 0],
    4:  [16, 4, 9,  0, 0],
    5:  [22, 2, 11, 2, 12],
    6:  [28, 4, 15, 0, 0],
    7:  [26, 4, 13, 1, 14],
    8:  [26, 4, 14, 2, 15],
    9:  [24, 4, 12, 4, 13],
    10: [28, 6, 15, 2, 16],
    11: [24, 3, 12, 8, 13],
    12: [28, 7, 14, 4, 15],
    13: [22, 12, 11, 4, 12],
    14: [24, 11, 12, 5, 13],
    15: [24, 11, 12, 7, 13],
    16: [30, 3, 15, 13, 16],
    17: [28, 2, 14, 17, 15],
    18: [28, 2, 14, 19, 15],
    19: [26, 9, 13, 16, 14],
    20: [28, 15, 15, 10, 16]
  };

  const ALIGNMENT_COORDS = {
    1: [],
    2: [6, 18],
    3: [6, 22],
    4: [6, 26],
    5: [6, 30],
    6: [6, 34],
    7: [6, 22, 38],
    8: [6, 24, 42],
    9: [6, 26, 46],
    10: [6, 28, 50],
    11: [6, 30, 54],
    12: [6, 32, 58],
    13: [6, 34, 62],
    14: [6, 26, 46, 66],
    15: [6, 26, 48, 70],
    16: [6, 26, 50, 74],
    17: [6, 30, 54, 78],
    18: [6, 30, 56, 82],
    19: [6, 30, 58, 86],
    20: [6, 34, 62, 90]
  };

  // Precomputed 15-bit format info for ECC Level H (indicator = 10 -> 2) & mask 0..7
  // Verified against ISO 18004 Annex C
  const FORMAT_INFO_H = [
    0x1689, // mask 0
    0x13BE, // mask 1
    0x1CE7, // mask 2
    0x19D0, // mask 3
    0x0762, // mask 4
    0x0255, // mask 5
    0x0D0C, // mask 6
    0x083B  // mask 7
  ];

  function encodeUtf8Bytes(text) {
    if (typeof TextEncoder !== 'undefined') {
      return Array.from(new TextEncoder().encode(text));
    }
    const encoded = unescape(encodeURIComponent(text));
    const out = [];
    for (let i = 0; i < encoded.length; i++) out.push(encoded.charCodeAt(i));
    return out;
  }

  function selectVersionForBytes(byteLen) {
    for (let v = 1; v <= 20; v++) {
      const spec = ECC_H_TABLE[v];
      const totalData = spec[1] * spec[2] + spec[3] * spec[4];
      const countBits = v < 10 ? 8 : 16;
      const totalDataBits = totalData * 8;
      const neededBits = 4 + countBits + byteLen * 8;
      if (neededBits <= totalDataBits) {
        return v;
      }
    }
    throw new Error('QR payload too large');
  }

  function buildCodewords(bytes, version) {
    const spec = ECC_H_TABLE[version];
    const [ecPerBlock, g1Blocks, g1Data, g2Blocks, g2Data] = spec;
    const totalData = g1Blocks * g1Data + g2Blocks * g2Data;
    const totalDataBits = totalData * 8;

    const bits = [];
    function pushBits(val, len) {
      for (let i = len - 1; i >= 0; i--) {
        bits.push((val >> i) & 1);
      }
    }

    // Mode: Byte (0100)
    pushBits(0b0100, 4);
    // Character count
    pushBits(bytes.length, version < 10 ? 8 : 16);
    // Data bytes
    for (let i = 0; i < bytes.length; i++) {
      pushBits(bytes[i], 8);
    }
    // Terminator (up to 4 zeros)
    const term = Math.min(4, totalDataBits - bits.length);
    for (let i = 0; i < term; i++) bits.push(0);
    // Pad to byte boundary
    while (bits.length % 8 !== 0) bits.push(0);

    const dataBytes = [];
    for (let i = 0; i < bits.length; i += 8) {
      let b = 0;
      for (let j = 0; j < 8; j++) b = (b << 1) | bits[i + j];
      dataBytes.push(b);
    }

    // Pad codewords 0xEC, 0x11
    let padToggle = 0;
    while (dataBytes.length < totalData) {
      dataBytes.push(padToggle % 2 === 0 ? 0xec : 0x11);
      padToggle++;
    }

    // Split into blocks and compute RS EC codewords
    const dataBlocks = [];
    const ecBlocks = [];
    let offset = 0;

    for (let i = 0; i < g1Blocks; i++) {
      const blk = dataBytes.slice(offset, offset + g1Data);
      offset += g1Data;
      dataBlocks.push(blk);
      ecBlocks.push(rsComputeEC(blk, ecPerBlock));
    }
    for (let i = 0; i < g2Blocks; i++) {
      const blk = dataBytes.slice(offset, offset + g2Data);
      offset += g2Data;
      dataBlocks.push(blk);
      ecBlocks.push(rsComputeEC(blk, ecPerBlock));
    }

    // Interleave data codewords
    const finalBytes = [];
    const maxDataLen = Math.max(g1Data, g2Data);
    for (let i = 0; i < maxDataLen; i++) {
      for (let b = 0; b < dataBlocks.length; b++) {
        if (i < dataBlocks[b].length) finalBytes.push(dataBlocks[b][i]);
      }
    }
    // Interleave EC codewords
    for (let i = 0; i < ecPerBlock; i++) {
      for (let b = 0; b < ecBlocks.length; b++) {
        finalBytes.push(ecBlocks[b][i]);
      }
    }

    return finalBytes;
  }

  function createMatrix(size) {
    const modules = Array.from({ length: size }, () => new Uint8Array(size));
    const reserved = Array.from({ length: size }, () => new Uint8Array(size));
    return { size, modules, reserved };
  }

  function setFunctionModule(mat, r, c, dark) {
    if (r < 0 || r >= mat.size || c < 0 || c >= mat.size) return;
    mat.modules[r][c] = dark ? 1 : 0;
    mat.reserved[r][c] = 1;
  }

  function drawFinderAndSeparator(mat, topR, leftC) {
    for (let dr = -1; dr <= 7; dr++) {
      for (let dc = -1; dc <= 7; dc++) {
        const r = topR + dr;
        const c = leftC + dc;
        if (r < 0 || r >= mat.size || c < 0 || c >= mat.size) continue;
        let dark = false;
        if (dr >= 0 && dr <= 6 && dc >= 0 && dc <= 6) {
          const isBorder = dr === 0 || dr === 6 || dc === 0 || dc === 6;
          const isCenter = dr >= 2 && dr <= 4 && dc >= 2 && dc <= 4;
          dark = isBorder || isCenter;
        }
        setFunctionModule(mat, r, c, dark);
      }
    }
  }

  function drawAlignmentPattern(mat, centerR, centerC) {
    for (let dr = -2; dr <= 2; dr++) {
      for (let dc = -2; dc <= 2; dc++) {
        const dark = Math.max(Math.abs(dr), Math.abs(dc)) !== 1;
        setFunctionModule(mat, centerR + dr, centerC + dc, dark);
      }
    }
  }

  function computeVersionBCH(version) {
    let d = version << 12;
    const gen = 0x1f25;
    for (let i = 17; i >= 12; i--) {
      if ((d >> i) & 1) {
        d ^= gen << (i - 12);
      }
    }
    return (version << 12) | d;
  }

  function populateFunctionPatterns(mat, version) {
    const n = mat.size;
    drawFinderAndSeparator(mat, 0, 0);
    drawFinderAndSeparator(mat, 0, n - 7);
    drawFinderAndSeparator(mat, n - 7, 0);

    // Timing patterns
    for (let i = 8; i < n - 8; i++) {
      const dark = i % 2 === 0;
      setFunctionModule(mat, 6, i, dark);
      setFunctionModule(mat, i, 6, dark);
    }

    // Dark module
    setFunctionModule(mat, 4 * version + 9, 8, true);

    // Alignment patterns (skip only the 3 finder corners, NOT timing overlaps)
    const coords = ALIGNMENT_COORDS[version] || [];
    for (let i = 0; i < coords.length; i++) {
      for (let j = 0; j < coords.length; j++) {
        const isTopLeft = i === 0 && j === 0;
        const isTopRight = i === 0 && j === coords.length - 1;
        const isBottomLeft = i === coords.length - 1 && j === 0;
        if (isTopLeft || isTopRight || isBottomLeft) continue;
        drawAlignmentPattern(mat, coords[i], coords[j]);
      }
    }

    // Reserve Format Info areas
    for (let i = 0; i <= 8; i++) {
      if (i !== 6) {
        mat.reserved[8][i] = 1;
        mat.reserved[i][8] = 1;
      }
    }
    for (let i = 0; i < 8; i++) {
      mat.reserved[8][n - 1 - i] = 1;
    }
    for (let i = 0; i < 7; i++) {
      mat.reserved[n - 1 - i][8] = 1;
    }

    // Version Info (>= 7)
    if (version >= 7) {
      const vBits = computeVersionBCH(version);
      for (let i = 0; i < 18; i++) {
        const dark = ((vBits >> i) & 1) === 1;
        const r = Math.floor(i / 3);
        const c = (n - 11) + (i % 3);
        setFunctionModule(mat, r, c, dark);
        setFunctionModule(mat, c, r, dark);
      }
    }
  }

  function placeDataBits(mat, codewords) {
    const n = mat.size;
    let bitIdx = 0;
    const totalBits = codewords.length * 8;
    let upward = true;

    for (let col = n - 1; col > 0; col -= 2) {
      if (col === 6) col--;
      for (let i = 0; i < n; i++) {
        const r = upward ? n - 1 - i : i;
        for (let dc = 0; dc < 2; dc++) {
          const c = col - dc;
          if (!mat.reserved[r][c]) {
            let dark = false;
            if (bitIdx < totalBits) {
              const byteVal = codewords[bitIdx >> 3];
              dark = ((byteVal >> (7 - (bitIdx & 7))) & 1) === 1;
              bitIdx++;
            }
            mat.modules[r][c] = dark ? 1 : 0;
          }
        }
      }
      upward = !upward;
    }
  }

  function maskCondition(mask, r, c) {
    switch (mask) {
      case 0: return (r + c) % 2 === 0;
      case 1: return r % 2 === 0;
      case 2: return c % 3 === 0;
      case 3: return (r + c) % 3 === 0;
      case 4: return (Math.floor(r / 2) + Math.floor(c / 3)) % 2 === 0;
      case 5: return ((r * c) % 2) + ((r * c) % 3) === 0;
      case 6: return (((r * c) % 2) + ((r * c) % 3)) % 2 === 0;
      case 7: return (((r + c) % 2) + ((r * c) % 3)) % 2 === 0;
      default: return false;
    }
  }

  function writeFormatInfo(mat, mask) {
    const n = mat.size;
    const bits = FORMAT_INFO_H[mask];
    for (let i = 0; i < 15; i++) {
      const dark = ((bits >> i) & 1) === 1 ? 1 : 0;
      // Vertical copy (top-left then bottom-left)
      if (i < 6) mat.modules[i][8] = dark;
      else if (i < 8) mat.modules[i + 1][8] = dark;
      else mat.modules[n - 15 + i][8] = dark;

      // Horizontal copy (top-right then top-left)
      if (i < 8) mat.modules[8][n - 1 - i] = dark;
      else if (i === 8) mat.modules[8][7] = dark;
      else mat.modules[8][14 - i] = dark;
    }
  }

  function evaluatePenalty(modules, n) {
    let penalty = 0;

    // Rule 1: 5+ consecutive same color in rows and cols
    for (let r = 0; r < n; r++) {
      let runColor = modules[r][0];
      let runLen = 1;
      for (let c = 1; c < n; c++) {
        if (modules[r][c] === runColor) {
          runLen++;
        } else {
          if (runLen >= 5) penalty += 3 + (runLen - 5);
          runColor = modules[r][c];
          runLen = 1;
        }
      }
      if (runLen >= 5) penalty += 3 + (runLen - 5);
    }
    for (let c = 0; c < n; c++) {
      let runColor = modules[0][c];
      let runLen = 1;
      for (let r = 1; r < n; r++) {
        if (modules[r][c] === runColor) {
          runLen++;
        } else {
          if (runLen >= 5) penalty += 3 + (runLen - 5);
          runColor = modules[r][c];
          runLen = 1;
        }
      }
      if (runLen >= 5) penalty += 3 + (runLen - 5);
    }

    // Rule 2: 2x2 blocks of same color
    for (let r = 0; r < n - 1; r++) {
      for (let c = 0; c < n - 1; c++) {
        const v = modules[r][c];
        if (modules[r][c + 1] === v && modules[r + 1][c] === v && modules[r + 1][c + 1] === v) {
          penalty += 3;
        }
      }
    }

    // Rule 3: 10111010000 or 00001011101
    function hasPattern(arr) {
      let count = 0;
      for (let i = 0; i <= arr.length - 11; i++) {
        const p1 = arr[i] === 1 && arr[i + 1] === 0 && arr[i + 2] === 1 && arr[i + 3] === 1 &&
          arr[i + 4] === 1 && arr[i + 5] === 0 && arr[i + 6] === 1 &&
          arr[i + 7] === 0 && arr[i + 8] === 0 && arr[i + 9] === 0 && arr[i + 10] === 0;
        const p2 = arr[i] === 0 && arr[i + 1] === 0 && arr[i + 2] === 0 && arr[i + 3] === 0 &&
          arr[i + 4] === 1 && arr[i + 5] === 0 && arr[i + 6] === 1 &&
          arr[i + 7] === 1 && arr[i + 8] === 1 && arr[i + 9] === 0 && arr[i + 10] === 1;
        if (p1 || p2) count++;
      }
      return count;
    }
    for (let r = 0; r < n; r++) {
      penalty += hasPattern(modules[r]) * 40;
    }
    const colArr = new Uint8Array(n);
    for (let c = 0; c < n; c++) {
      for (let r = 0; r < n; r++) colArr[r] = modules[r][c];
      penalty += hasPattern(colArr) * 40;
    }

    // Rule 4: Dark proportion balance
    let darkCount = 0;
    for (let r = 0; r < n; r++) {
      for (let c = 0; c < n; c++) {
        if (modules[r][c] === 1) darkCount++;
      }
    }
    const pct = (darkCount * 100) / (n * n);
    const prev5 = Math.floor(pct / 5) * 5;
    const next5 = prev5 + 5;
    penalty += Math.min(Math.abs(prev5 - 50) / 5, Math.abs(next5 - 50) / 5) * 10;

    return penalty;
  }

  function generateQRMatrix(text) {
    const bytes = encodeUtf8Bytes(String(text || ''));
    const version = selectVersionForBytes(bytes.length);
    const size = version * 4 + 17;
    const codewords = buildCodewords(bytes, version);

    const baseMat = createMatrix(size);
    populateFunctionPatterns(baseMat, version);
    placeDataBits(baseMat, codewords);

    let bestMask = 0;
    let bestPenalty = Infinity;
    let bestModules = null;

    for (let mask = 0; mask < 8; mask++) {
      const cand = {
        size,
        modules: baseMat.modules.map((row) => new Uint8Array(row)),
        reserved: baseMat.reserved
      };
      for (let r = 0; r < size; r++) {
        for (let c = 0; c < size; c++) {
          if (!cand.reserved[r][c] && maskCondition(mask, r, c)) {
            cand.modules[r][c] ^= 1;
          }
        }
      }
      writeFormatInfo(cand, mask);
      const pen = evaluatePenalty(cand.modules, size);
      if (pen < bestPenalty) {
        bestPenalty = pen;
        bestMask = mask;
        bestModules = cand.modules;
      }
    }

    return { version, size, mask: bestMask, modules: bestModules };
  }

  function isFinderZone(r, c, n) {
    if (r < 7 && c < 7) return true;
    if (r < 7 && c >= n - 7) return true;
    if (r >= n - 7 && c < 7) return true;
    return false;
  }

  function drawRoundedRectPath(ctx, x, y, w, h, r) {
    const radius = Math.min(r, w / 2, h / 2);
    ctx.beginPath();
    ctx.moveTo(x + radius, y);
    ctx.lineTo(x + w - radius, y);
    ctx.quadraticCurveTo(x + w, y, x + w, y + radius);
    ctx.lineTo(x + w, y + h - radius);
    ctx.quadraticCurveTo(x + w, y + h, x + w - radius, y + h);
    ctx.lineTo(x + radius, y + h);
    ctx.quadraticCurveTo(x, y + h, x, y + h - radius);
    ctx.lineTo(x, y + radius);
    ctx.quadraticCurveTo(x, y, x + radius, y);
    ctx.closePath();
  }

  function renderArtisticQR(canvas, text, options = {}) {
    if (!canvas) return null;
    const qr = generateQRMatrix(text);
    const n = qr.size;
    const dpr = Math.min(4, Math.max(2, Number(global.devicePixelRatio) || 2));
    const displaySize = options.displaySize || 220;
    const canvasSize = options.canvasSize || Math.max(660, Math.round(displaySize * dpr));
    const quietModules = options.quietModules || 3;
    const totalModules = n + quietModules * 2;
    const modSize = canvasSize / totalModules;
    const origin = quietModules * modSize;
    const qrPixelSize = n * modSize;

    canvas.width = canvasSize;
    canvas.height = canvasSize;
    canvas.style.width = `${displaySize}px`;
    canvas.style.height = `${displaySize}px`;
    const ctx = canvas.getContext('2d');
    if (!ctx) return qr;

    ctx.clearRect(0, 0, canvasSize, canvasSize);

    // Crisp white quiet-zone card so cameras scan reliably in both Dark & Light modes
    drawRoundedRectPath(ctx, 0, 0, canvasSize, canvasSize, 42);
    ctx.fillStyle = '#FFFFFF';
    ctx.fill();

    // Subtle decorative border around QR canvas
    drawRoundedRectPath(ctx, 4, 4, canvasSize - 8, canvasSize - 8, 38);
    ctx.lineWidth = 4;
    const borderGrad = ctx.createLinearGradient(0, 0, canvasSize, canvasSize);
    borderGrad.addColorStop(0, 'rgba(16, 185, 129, 0.35)');
    borderGrad.addColorStop(1, 'rgba(245, 158, 11, 0.45)');
    ctx.strokeStyle = borderGrad;
    ctx.stroke();

    // Emerald-to-Gold rich gradient (#10B981 -> #F59E0B)
    const dotGrad = ctx.createLinearGradient(origin, origin, origin + qrPixelSize, origin + qrPixelSize);
    dotGrad.addColorStop(0, '#10B981');
    dotGrad.addColorStop(0.5, '#0D9488');
    dotGrad.addColorStop(1, '#F59E0B');

    // Center monogram badge exclusion radius (safely well inside ECC-H 30% tolerance)
    const centerPx = canvasSize / 2;
    const badgeRadius = qrPixelSize * 0.128;
    const clearRadius = badgeRadius + modSize * 0.9;

    // 1. Draw smooth rounded circular dots for all non-finder dark modules
    ctx.fillStyle = dotGrad;
    const dotRadius = modSize * 0.43;
    for (let r = 0; r < n; r++) {
      for (let c = 0; c < n; c++) {
        if (qr.modules[r][c] !== 1) continue;
        if (isFinderZone(r, c, n)) continue;

        const cx = origin + (c + 0.5) * modSize;
        const cy = origin + (r + 0.5) * modSize;
        const dist = Math.hypot(cx - centerPx, cy - centerPx);
        if (dist < clearRadius) continue;

        ctx.beginPath();
        ctx.arc(cx, cy, dotRadius, 0, Math.PI * 2);
        ctx.fill();
      }
    }

    // 2. Draw custom rounded finder eyes (Top-Left, Top-Right, Bottom-Left)
    const finderCoords = [
      [0, 0],
      [0, n - 7],
      [n - 7, 0]
    ];
    finderCoords.forEach(([fr, fc]) => {
      const fx = origin + fc * modSize;
      const fy = origin + fr * modSize;
      const fSize = 7 * modSize;

      // Outer 7x7 rounded ring
      drawRoundedRectPath(ctx, fx, fy, fSize, fSize, modSize * 1.9);
      ctx.fillStyle = dotGrad;
      ctx.fill();

      // Inner 5x5 white cutout
      drawRoundedRectPath(ctx, fx + modSize, fy + modSize, 5 * modSize, 5 * modSize, modSize * 1.25);
      ctx.fillStyle = '#FFFFFF';
      ctx.fill();

      // Center 3x3 rounded pupil
      drawRoundedRectPath(ctx, fx + 2 * modSize, fy + 2 * modSize, 3 * modSize, 3 * modSize, modSize * 0.95);
      ctx.fillStyle = dotGrad;
      ctx.fill();
    });

    // 3. Draw clean circular center badge displaying monogram "B"
    // Outer white halo
    ctx.beginPath();
    ctx.arc(centerPx, centerPx, badgeRadius + modSize * 0.55, 0, Math.PI * 2);
    ctx.fillStyle = '#FFFFFF';
    ctx.fill();

    // Gradient badge circle
    const badgeGrad = ctx.createLinearGradient(
      centerPx - badgeRadius,
      centerPx - badgeRadius,
      centerPx + badgeRadius,
      centerPx + badgeRadius
    );
    badgeGrad.addColorStop(0, '#10B981');
    badgeGrad.addColorStop(1, '#F59E0B');

    ctx.beginPath();
    ctx.arc(centerPx, centerPx, badgeRadius, 0, Math.PI * 2);
    ctx.fillStyle = badgeGrad;
    ctx.fill();

    // Inner deep slate ring for high-contrast crisp monogram
    ctx.beginPath();
    ctx.arc(centerPx, centerPx, badgeRadius * 0.84, 0, Math.PI * 2);
    ctx.fillStyle = '#0F172A';
    ctx.fill();

    // Monogram "B"
    ctx.fillStyle = '#FFFFFF';
    ctx.font = `800 ${Math.round(badgeRadius * 1.16)}px "Cairo", system-ui, -apple-system, sans-serif`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('B', centerPx, centerPx + badgeRadius * 0.05);

    return qr;
  }

  global.MasroufyQR = {
    generateQRMatrix,
    renderArtisticQR
  };
})(window);
