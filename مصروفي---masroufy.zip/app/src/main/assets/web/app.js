(() => {
  'use strict';

  const STORAGE_KEY = 'masroufy_state_v1';
  const RATES_CACHE_KEY = 'masroufy_rates_cache_v1';
  const AI_CHATS_KEY = 'masroufy_ai_chats_v1';
  const AI_WORKER_URL = 'https://masroufy-ai.r47278128.workers.dev';
  const CURRENCY_PRIMARY_URL = 'https://cdn.jsdelivr.net/npm/@fawazahmed0/currency-api@latest/v1/currencies/egp.json';
  const CURRENCY_FALLBACK_URL = 'https://latest.currency-api.pages.dev/v1/currencies/egp.json';
  const FRANKFURTER_URL = 'https://api.frankfurter.app/latest?from=USD&to=EUR,GBP';
  const TROY_OUNCE_GRAMS = 31.1034768;

  const BASE_CATEGORIES = [
    { id: 'food', name: 'أكل وشرب', icon: '🍽️', color: '#10B981', type: 'expense' },
    { id: 'transport', name: 'مواصلات وبنزين', icon: '🚗', color: '#38BDF8', type: 'expense' },
    { id: 'bills', name: 'فواتير وباقات نت', icon: '📱', color: '#8B5CF6', type: 'expense' },
    { id: 'shopping', name: 'تسوق وملابس', icon: '🛍️', color: '#EC4899', type: 'expense' },
    { id: 'health', name: 'صحة وأدوية', icon: '💊', color: '#EF4444', type: 'expense' },
    { id: 'education', name: 'تعليم وكورسات', icon: '📚', color: '#6366F1', type: 'expense' },
    { id: 'entertainment', name: 'ترفيه وخروجات', icon: '☕', color: '#F59E0B', type: 'expense' },
    { id: 'installments', name: 'أقساط وجمعيات', icon: '🤝', color: '#14B8A6', type: 'expense' },
    { id: 'salary', name: 'مرتب', icon: '💼', color: '#10B981', type: 'income' },
    { id: 'freelance', name: 'عمل حر', icon: '💻', color: '#0EA5E9', type: 'income' },
    { id: 'other', name: 'أخرى', icon: '📌', color: '#94A3B8', type: 'both' }
  ];

  const WALLET_TYPE_LABELS = {
    cash: 'كاش / المحفظة',
    bank: 'حساب بنكي / انستا باي',
    mobile: 'محفظة إلكترونية',
    credit: 'كارت مشتريات'
  };

  const DEFAULT_TEMPLATES = [
    { id: 'tpl_1', title: 'مواصلات', amount: 20, categoryId: 'transport', icon: '🚕' },
    { id: 'tpl_2', title: 'فطار/قهوة', amount: 40, categoryId: 'entertainment', icon: '☕' },
    { id: 'tpl_3', title: 'باقة/رصيد', amount: 50, categoryId: 'bills', icon: '📱' }
  ];

  const CURRENCY_LABELS = {
    EGP: 'ج.م',
    USD: 'USD',
    SAR: 'SAR',
    EUR: 'EUR'
  };

  function todayIso(offsetDays = 0) {
    const d = new Date();
    d.setDate(d.getDate() + offsetDays);
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${y}-${m}-${day}`;
  }

  function currentMonthKey() {
    const d = new Date();
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
  }

  function prevMonthKey() {
    const d = new Date();
    d.setMonth(d.getMonth() - 1);
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
  }

  function uid(prefix = 'id') {
    return `${prefix}_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 7)}`;
  }

  function formatTimeAr(ts) {
    if (!ts) return '';
    try {
      const d = new Date(ts);
      if (Number.isNaN(d.getTime())) return '';
      return d.toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' });
    } catch (_) {
      return '';
    }
  }

  const DEFAULT_RATES = {
    usd: 49.50,
    eur: 52.30,
    sar: 13.20,
    aed: 13.48,
    kwd: 161.10,
    gold24: 4250,
    gold21: 3718.75,
    gold18: 3187.50,
    silverGram: 51.40,
    updatedAt: null,
    sourceLabel: 'أسعار مرجعية أولية (اضغط تحديث للأسعار الحية)',
    frankfurterVerified: false,
    isCached: true
  };

  function normalizeRatesState(raw) {
    const src = raw && typeof raw === 'object' ? raw : {};
    const pos = (v, fb) => {
      const n = Number(v);
      return Number.isFinite(n) && n > 0 ? n : fb;
    };
    const gold24 = pos(src.gold24, DEFAULT_RATES.gold24);
    return {
      usd: pos(src.usd, DEFAULT_RATES.usd),
      eur: pos(src.eur, DEFAULT_RATES.eur),
      sar: pos(src.sar, DEFAULT_RATES.sar),
      aed: pos(src.aed, DEFAULT_RATES.aed),
      kwd: pos(src.kwd, DEFAULT_RATES.kwd),
      gold24,
      gold21: pos(src.gold21, (gold24 * 21) / 24),
      gold18: pos(src.gold18, (gold24 * 18) / 24),
      silverGram: pos(src.silverGram, DEFAULT_RATES.silverGram),
      updatedAt: src.updatedAt || null,
      sourceLabel: String(src.sourceLabel || DEFAULT_RATES.sourceLabel),
      frankfurterVerified: Boolean(src.frankfurterVerified),
      isCached: src.isCached !== false
    };
  }

  function sanitizeAiChats(raw) {
    if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return {};
    const clean = {};
    Object.keys(raw).forEach((key) => {
      const list = raw[key];
      if (!Array.isArray(list)) {
        clean[key] = [];
        return;
      }
      clean[key] = list
        .filter((m) => m && typeof m === 'object' && typeof m.content === 'string')
        .map((m) => ({
          role: m.role === 'user' ? 'user' : 'assistant',
          content: String(m.content),
          provider: m.provider ? String(m.provider) : undefined,
          ts: Number.isFinite(Number(m.ts)) ? Number(m.ts) : Date.now()
        }));
    });
    return clean;
  }

  function createSeedState() {
    return {
      version: 2,
      initialized: true,
      settings: {
        theme: 'dark',
        privacyMode: false,
        pinCode: '',
        geminiApiKey: '',
        groqApiKey: ''
      },
      wallets: [
        { id: 'w_cash', name: 'كاش / المحفظة', type: 'cash', currency: 'EGP', balance: 2450, icon: '💵' },
        { id: 'w_bank', name: 'البنك / انستا باي', type: 'bank', currency: 'EGP', balance: 14800, icon: '🏦' },
        { id: 'w_vf', name: 'فودافون كاش', type: 'mobile', currency: 'EGP', balance: 1850, icon: '📲' },
        { id: 'w_usd', name: 'حساب دولار', type: 'bank', currency: 'USD', balance: 250, icon: '💲' }
      ],
      transactions: [
        { id: 'tx_1', type: 'income', amount: 18500, categoryId: 'salary', walletId: 'w_bank', toWalletId: null, note: 'مرتب الشهر الأساسي #شغل', date: todayIso(-12) },
        { id: 'tx_2', type: 'income', amount: 3800, categoryId: 'freelance', walletId: 'w_vf', toWalletId: null, note: 'مشروع تصميم واجهة #فريلانس', date: todayIso(-7) },
        { id: 'tx_3', type: 'expense', amount: 2200, categoryId: 'food', walletId: 'w_cash', toWalletId: null, note: 'طلبات البيت وسوبر ماركت #البيت', date: todayIso(-6) },
        { id: 'tx_4', type: 'expense', amount: 850, categoryId: 'bills', walletId: 'w_vf', toWalletId: null, note: 'باقة النت المنزلي والموبايل #فواتير', date: todayIso(-5) },
        { id: 'tx_5', type: 'expense', amount: 420, categoryId: 'transport', walletId: 'w_cash', toWalletId: null, note: 'بنزين ومشاوير أوبر', date: todayIso(-3) },
        { id: 'tx_6', type: 'expense', amount: 1500, categoryId: 'installments', walletId: 'w_bank', toWalletId: null, note: 'قسط جمعية الشغل #جمعية', date: todayIso(-2) },
        { id: 'tx_7', type: 'expense', amount: 740, categoryId: 'entertainment', walletId: 'w_cash', toWalletId: null, note: 'قهوة وخروجة مع الأصحاب #خروجة', date: todayIso(-1) },
        { id: 'tx_8', type: 'expense', amount: 680, categoryId: 'food', walletId: 'w_bank', toWalletId: null, note: 'عزومة غداء #خروجة', date: todayIso(0) }
      ],
      budgets: {
        food: 3500,
        transport: 1500,
        bills: 1000,
        shopping: 1500,
        health: 800,
        entertainment: 900,
        installments: 2000
      },
      goals: [
        { id: 'g_1', title: 'صندوق الطوارئ (3 شهور)', target: 30000, saved: 12500, icon: '🛡️' },
        { id: 'g_2', title: 'شراء سبيكة ذهب 5 جرام', target: 22000, saved: 9500, icon: '🪙' }
      ],
      gam3eyas: [
        { id: 'gm_1', title: 'جمعية الشغل', monthlyAmount: 1500, payoutAmount: 15000, totalMembers: 10, paidMonths: 4, payoutMonthLabel: 'شهر أغسطس', lastPaidMonth: currentMonthKey(), walletId: 'w_bank' }
      ],
      debts: [
        { id: 'db_1', person: 'أحمد محمود', type: 'owed_to_me', totalAmount: 1200, remainingAmount: 800, note: 'سلفة خروجة الساحل', date: todayIso(-10) },
        { id: 'db_2', person: 'محمد علي', type: 'i_owe', totalAmount: 500, remainingAmount: 500, note: 'حجز التذاكر', date: todayIso(-4) }
      ],
      recurringBills: [
        { id: 'rb_1', title: 'باقة الإنترنت المنزلي', amount: 410, dueDay: 15, categoryId: 'bills', walletId: 'w_vf', lastPaidMonth: currentMonthKey() },
        { id: 'rb_2', title: 'فاتورة الكهرباء والمياه', amount: 480, dueDay: 22, categoryId: 'bills', walletId: 'w_bank', lastPaidMonth: '' }
      ],
      commitments: [],
      customCategories: [],
      quickTemplates: DEFAULT_TEMPLATES.map((t) => ({ ...t }))
    };
  }

  function createEmptyZeroState(currentSettings) {
    return {
      version: 2,
      initialized: true,
      settings: {
        theme: currentSettings?.theme || 'dark',
        privacyMode: Boolean(currentSettings?.privacyMode),
        pinCode: currentSettings?.pinCode || '',
        geminiApiKey: currentSettings?.geminiApiKey || '',
        groqApiKey: currentSettings?.groqApiKey || ''
      },
      wallets: [
        { id: 'w_cash', name: 'كاش / المحفظة', type: 'cash', currency: 'EGP', balance: 0, icon: '💵' },
        { id: 'w_bank', name: 'البنك / انستا باي', type: 'bank', currency: 'EGP', balance: 0, icon: '🏦' },
        { id: 'w_vf', name: 'محفظة إلكترونية', type: 'mobile', currency: 'EGP', balance: 0, icon: '📲' }
      ],
      transactions: [],
      budgets: {},
      goals: [],
      gam3eyas: [],
      debts: [],
      recurringBills: [],
      commitments: [],
      customCategories: [],
      quickTemplates: DEFAULT_TEMPLATES.map((t) => ({ ...t }))
    };
  }

  function normalizeAppState(parsed) {
    const base = createEmptyZeroState(parsed?.settings);
    const wallets = (Array.isArray(parsed?.wallets) ? parsed.wallets : [])
      .filter((w) => w && typeof w === 'object')
      .map((w) => ({
        id: String(w.id || uid('w')),
        name: String(w.name || 'محفظة'),
        type: String(w.type || 'cash'),
        currency: String(w.currency || 'EGP'),
        balance: Number.isFinite(Number(w.balance)) ? Number(w.balance) : 0,
        icon: String(w.icon || '💳')
      }));
    if (!wallets.length) {
      wallets.push(...base.wallets);
    }

    const transactions = (Array.isArray(parsed?.transactions) ? parsed.transactions : [])
      .filter((t) => t && typeof t === 'object')
      .map((t) => ({
        ...t,
        id: String(t.id || uid('tx')),
        type: t.type === 'income' || t.type === 'transfer' ? t.type : 'expense',
        amount: Math.max(0, Number.isFinite(Number(t.amount)) ? Number(t.amount) : 0),
        categoryId: String(t.categoryId || 'other'),
        walletId: String(t.walletId || wallets[0].id),
        toWalletId: t.toWalletId ? String(t.toWalletId) : null,
        date: /^\d{4}-\d{2}-\d{2}/.test(String(t.date || '')) ? String(t.date).slice(0, 10) : todayIso(),
        note: String(t.note || '')
      }));

    const goals = (Array.isArray(parsed?.goals) ? parsed.goals : [])
      .filter((g) => g && typeof g === 'object')
      .map((g) => ({
        ...g,
        id: String(g.id || uid('goal')),
        title: String(g.title || 'هدف'),
        target: Math.max(1, Number.isFinite(Number(g.target)) ? Number(g.target) : 1),
        saved: Math.max(0, Number.isFinite(Number(g.saved)) ? Number(g.saved) : 0)
      }));

    const gam3eyas = (Array.isArray(parsed?.gam3eyas) ? parsed.gam3eyas : []).filter((x) => x && typeof x === 'object');
    const debts = (Array.isArray(parsed?.debts) ? parsed.debts : []).filter((x) => x && typeof x === 'object');
    const recurringBills = (Array.isArray(parsed?.recurringBills) ? parsed.recurringBills : []).filter((x) => x && typeof x === 'object');
    const commitments = (Array.isArray(parsed?.commitments) ? parsed.commitments : []).filter((x) => x && typeof x === 'object');
    const customCategories = (Array.isArray(parsed?.customCategories) ? parsed.customCategories : []).filter((x) => x && typeof x === 'object');
    const tags = Array.isArray(parsed?.tags) ? parsed.tags.filter((x) => typeof x === 'string') : [];
    const quickTemplates = Array.isArray(parsed?.quickTemplates) && parsed.quickTemplates.length
      ? parsed.quickTemplates.filter((x) => x && typeof x === 'object')
      : DEFAULT_TEMPLATES.map((t) => ({ ...t }));

    const budgets = parsed?.budgets && typeof parsed.budgets === 'object' && !Array.isArray(parsed.budgets)
      ? parsed.budgets
      : {};

    const normalized = {
      version: 2,
      initialized: true,
      settings: base.settings,
      wallets,
      transactions,
      budgets,
      goals,
      gam3eyas,
      debts,
      recurringBills,
      commitments,
      customCategories,
      tags,
      quickTemplates
    };

    if (normalized.commitments.length && !normalized.gam3eyas.length) {
      normalized.gam3eyas = normalized.commitments.map((c) => ({
        id: c.id || uid('gm'),
        title: String(c.title || 'جمعية'),
        monthlyAmount: Number(c.amount) || 0,
        payoutAmount: (Number(c.amount) || 0) * 10,
        totalMembers: 10,
        paidMonths: c.paidMonth === currentMonthKey() ? 1 : 0,
        payoutMonthLabel: `يوم ${c.dueDay || 1}`,
        lastPaidMonth: c.paidMonth || '',
        walletId: c.walletId || wallets[0]?.id
      }));
      normalized.commitments = [];
      saveState(normalized);
    }

    return normalized;
  }

  function loadState() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (parsed && Array.isArray(parsed.wallets) && Array.isArray(parsed.transactions)) {
          return normalizeAppState(parsed);
        }
      }
    } catch (_) {}
    const seeded = createSeedState();
    saveState(seeded);
    return seeded;
  }

  function saveState(nextState) {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(nextState));
    } catch (_) {}
  }

  function loadRatesCache() {
    try {
      const raw = localStorage.getItem(RATES_CACHE_KEY);
      if (raw) {
        return normalizeRatesState(JSON.parse(raw));
      }
    } catch (_) {}
    return null;
  }

  function saveRatesCache(cacheObj) {
    try {
      localStorage.setItem(RATES_CACHE_KEY, JSON.stringify(cacheObj));
    } catch (_) {}
  }

  function loadAiChats() {
    try {
      const raw = localStorage.getItem(AI_CHATS_KEY);
      if (raw) return sanitizeAiChats(JSON.parse(raw));
    } catch (_) {}
    return {};
  }

  function saveAiChats(chatsObj) {
    try {
      localStorage.setItem(AI_CHATS_KEY, JSON.stringify(chatsObj));
    } catch (_) {}
  }

  // Runtime State
  let appState = loadState();
  let ratesState = loadRatesCache() || { ...DEFAULT_RATES };
  let ratesLoading = false;
  let aiChats = loadAiChats();
  let activeTab = 'dashboard';
  const dirtyTabs = new Set(['dashboard', 'transactions', 'budgets', 'advisor', 'rates', 'settings']);
  let activeBudgetsSubTab = 'all';
  let activeAdvisorChatId = null; // null = Screen 1 (List), personaId = Screen 2 (Fullscreen Chat)
  let aiLoading = false;
  let aiQuotaBannerVisible = false;
  let voiceListening = false;
  let speechRecInstance = null;
  let modalOpen = false;
  let isPinLocked = Boolean(appState.settings.pinCode && appState.settings.pinCode.length === 4);
  let pinEntryBuffer = '';
  let devQrMode = 'vcard'; // 'vcard' | 'whatsapp'
  let devApiGuideOpen = false;

  const DEV_PROFILE = {
    nameAr: 'بلال محمد سليمان',
    nameEn: 'Belal Mohamed Sleman',
    roleAr: 'مطور تطبيق مصروفي (Masroufy)',
    roleEn: 'Masroufy App Developer',
    phone: '+201271425089',
    whatsappUrl: 'https://wa.me/201271425089',
    githubUrl: 'https://github.com/rtedtt',
    email: 'belalbelalmoh@gmail.com'
  };

  function buildDeveloperVCard() {
    return [
      'BEGIN:VCARD',
      'VERSION:3.0',
      `FN:${DEV_PROFILE.nameAr} (${DEV_PROFILE.nameEn})`,
      'N:Sleman;Belal;Mohamed;;',
      `TITLE:${DEV_PROFILE.roleEn}`,
      `TEL;TYPE=CELL:${DEV_PROFILE.phone}`,
      `EMAIL:${DEV_PROFILE.email}`,
      `URL:${DEV_PROFILE.githubUrl}`,
      'END:VCARD'
    ].join('\n');
  }

  function getDeveloperQrPayload() {
    return devQrMode === 'whatsapp' ? DEV_PROFILE.whatsappUrl : buildDeveloperVCard();
  }

  function renderDeveloperQrCanvas() {
    const canvas = document.getElementById('devQrCanvas');
    if (!canvas || !window.MasroufyQR || typeof window.MasroufyQR.renderArtisticQR !== 'function') return;
    try {
      window.MasroufyQR.renderArtisticQR(canvas, getDeveloperQrPayload(), { canvasSize: 640, quietModules: 3 });
    } catch (_) {}
  }

  const txFilters = {
    search: '',
    type: 'all',
    categoryId: 'all',
    walletId: 'all',
    period: 'this_month',
    customDate: '',
    hashtag: ''
  };

  const converterState = { amount: '1000', from: 'EGP', to: 'USD' };
  const zakatState = { cash: '50000', gold21: '0', gold24: '0', silver: '0' };
  const splitState = { total: '600', friends: '3', tipPct: '10', walletId: '', note: 'خروجة مع الأصدقاء' };

  // Helpers
  function escapeHtml(str) {
    return String(str ?? '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  function getAllCategories() {
    return [...BASE_CATEGORIES, ...(appState.customCategories || [])];
  }

  function getCategory(id) {
    const all = getAllCategories();
    return all.find((c) => c.id === id) || BASE_CATEGORIES[BASE_CATEGORIES.length - 1];
  }

  function getWallet(id) {
    return appState.wallets.find((w) => w.id === id) || null;
  }

  function normalizeArabicDigits(str) {
    const arabicDigits = '٠١٢٣٤٥٦٧٨٩';
    const persianDigits = '۰۱۲۳۴۵۶۷۸۹';
    return String(str ?? '')
      .replace(/[٠-٩]/g, (d) => String(arabicDigits.indexOf(d)))
      .replace(/[۰-۹]/g, (d) => String(persianDigits.indexOf(d)))
      .replace(/٬/g, ',')
      .replace(/٫/g, '.');
  }

  function parseLocaleNumber(val, fallback = NaN) {
    if (typeof val === 'number') return Number.isFinite(val) ? val : fallback;
    const cleaned = normalizeArabicDigits(val).replace(/,/g, '').trim();
    if (!cleaned) return fallback;
    const n = Number(cleaned);
    return Number.isFinite(n) ? n : fallback;
  }

  function safeDiv(num, den, fallback = 0) {
    const a = Number(num);
    const b = Number(den);
    if (!Number.isFinite(a) || !Number.isFinite(b) || b === 0) return fallback;
    const res = a / b;
    return Number.isFinite(res) ? res : fallback;
  }

  function getUnitRateInEgp(code) {
    const pos = (v, fb) => (Number.isFinite(Number(v)) && Number(v) > 0 ? Number(v) : fb);
    switch (code) {
      case 'EGP': return 1;
      case 'USD': return pos(ratesState.usd, DEFAULT_RATES.usd);
      case 'EUR': return pos(ratesState.eur, DEFAULT_RATES.eur);
      case 'SAR': return pos(ratesState.sar, DEFAULT_RATES.sar);
      case 'AED': return pos(ratesState.aed, DEFAULT_RATES.aed);
      case 'KWD': return pos(ratesState.kwd, DEFAULT_RATES.kwd);
      case 'GOLD_24': return pos(ratesState.gold24, DEFAULT_RATES.gold24);
      case 'GOLD_21': return pos(ratesState.gold21, DEFAULT_RATES.gold21);
      case 'GOLD_18': return pos(ratesState.gold18, DEFAULT_RATES.gold18);
      case 'SILVER': return pos(ratesState.silverGram, DEFAULT_RATES.silverGram);
      default: return 1;
    }
  }

  function toEgp(amount, currency = 'EGP') {
    const num = parseLocaleNumber(amount, 0);
    return num * getUnitRateInEgp(currency || 'EGP');
  }

  function fmtNum(val, decimals = 2) {
    const n = Number(val);
    const num = Number.isFinite(n) ? n : 0;
    return num.toLocaleString('en-US', {
      minimumFractionDigits: decimals,
      maximumFractionDigits: decimals
    });
  }

  function fmtCurrency(val, currency = 'EGP', decimals = 0, ignorePrivacy = false) {
    const symbol = CURRENCY_LABELS[currency] || currency;
    if (!ignorePrivacy && appState.settings.privacyMode) {
      return `<span class="num-ltr">••••</span> ${symbol}`;
    }
    return `<span class="num-ltr">${fmtNum(val, decimals)}</span> ${symbol}`;
  }

  function fmtEgp(val, decimals = 0, ignorePrivacy = false) {
    return fmtCurrency(val, 'EGP', decimals, ignorePrivacy);
  }

  function extractHashtags(text) {
    if (!text) return [];
    const matches = String(text).match(/#[\p{L}\p{N}_]+/gu) || [];
    return [...new Set(matches)];
  }

  function showToast(msg) {
    const el = document.getElementById('toastEl');
    if (!el) return;
    el.textContent = msg;
    el.classList.add('show');
    clearTimeout(showToast._timer);
    showToast._timer = setTimeout(() => el.classList.remove('show'), 2800);
  }

  function applyThemeAndChrome() {
    const isLight = appState.settings.theme === 'light';
    document.body.classList.toggle('theme-light', isLight);
    const themeIcon = document.getElementById('themeToggleIcon');
    if (themeIcon) themeIcon.textContent = isLight ? '🌙' : '☀️';

    const privIcon = document.getElementById('privacyToggleIcon');
    if (privIcon) privIcon.textContent = appState.settings.privacyMode ? '🙈' : '👁️';
    document.getElementById('privacyToggleBtn')?.classList.toggle('active-btn', appState.settings.privacyMode);
    document.getElementById('openRatesBtn')?.classList.toggle('active-btn', activeTab === 'rates');
    document.getElementById('openSettingsBtn')?.classList.toggle('active-btn', activeTab === 'settings');

    const metaTheme = document.querySelector('meta[name="theme-color"]');
    if (metaTheme) metaTheme.setAttribute('content', isLight ? '#F8FAFC' : '#0F172A');

    document.body.classList.toggle('chat-fullscreen', activeTab === 'advisor' && Boolean(activeAdvisorChatId));
  }

  // PIN Lock Renderer
  function renderPinLock() {
    const overlay = document.getElementById('pinLockOverlay');
    if (!overlay) return;
    if (!isPinLocked) {
      overlay.classList.remove('open');
      overlay.innerHTML = '';
      return;
    }
    overlay.classList.add('open');
    const dots = [0, 1, 2, 3].map((i) => `<span class="pin-dot ${i < pinEntryBuffer.length ? 'filled' : ''}"></span>`).join('');
    const keys = ['1', '2', '3', '4', '5', '6', '7', '8', '9', 'مسح', '0', '⌫'];

    overlay.innerHTML = `
      <img src="./icon.svg" alt="مصروفي" style="width:64px;height:64px;border-radius:18px" />
      <div style="text-align:center">
        <h2 style="margin:0 0 4px;font-size:1.15rem">تطبيق مصروفي مقفل</h2>
        <span style="font-size:0.82rem;color:var(--text-muted)">أدخل رمز الحماية المكون من 4 أرقام</span>
      </div>
      <div class="pin-dots">${dots}</div>
      <div class="pin-keypad">
        ${keys.map((k) => `<button class="pin-key" data-pin-key="${k}" type="button" style="font-size:${k === 'مسح' ? '0.82rem' : '1.25rem'}">${k}</button>`).join('')}
      </div>
    `;
  }

  // Metrics & Health Score Engine
  function getMonthTransactions(monthKey = currentMonthKey()) {
    return appState.transactions.filter((tx) => String(tx.date || '').startsWith(monthKey));
  }

  function computeDashboardMetrics() {
    const totalBalance = appState.wallets.reduce((sum, w) => sum + toEgp(w.balance, w.currency), 0);
    const monthTxs = getMonthTransactions(currentMonthKey());

    const txEgp = (tx) => {
      const w = getWallet(tx.walletId);
      return toEgp(tx.amount, w?.currency || 'EGP');
    };

    const monthIncome = monthTxs.filter((t) => t.type === 'income').reduce((s, t) => s + txEgp(t), 0);
    const monthExpense = monthTxs.filter((t) => t.type === 'expense').reduce((s, t) => s + txEgp(t), 0);
    const netSurplus = monthIncome - monthExpense;
    const savingsRate = monthIncome > 0 ? Math.max(0, Math.round((netSurplus / monthIncome) * 100)) : 0;

    const catTotalsMap = {};
    monthTxs.filter((t) => t.type === 'expense').forEach((t) => {
      catTotalsMap[t.categoryId] = (catTotalsMap[t.categoryId] || 0) + txEgp(t);
    });

    const categoryBreakdown = Object.entries(catTotalsMap)
      .map(([catId, total]) => {
        const cat = getCategory(catId);
        const pct = monthExpense > 0 ? (total / monthExpense) * 100 : 0;
        return { category: cat, total, pct };
      })
      .sort((a, b) => b.total - a.total);

    // Daily Safe-to-Spend
    const now = new Date();
    const daysInMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0).getDate();
    const remainingDays = Math.max(1, daysInMonth - now.getDate() + 1);
    const totalBudgetsSet = Object.values(appState.budgets).reduce((s, v) => s + (Number(v) || 0), 0);
    const monthlyBudgetPool = totalBudgetsSet > 0 ? totalBudgetsSet : Math.max(monthIncome, totalBalance * 0.5, 3000);
    const remainingMonthlyBudget = Math.max(0, monthlyBudgetPool - monthExpense);
    const dailySafeToSpend = remainingMonthlyBudget / remainingDays;

    const todayStr = todayIso();
    const todaySpent = monthTxs
      .filter((t) => t.type === 'expense' && t.date === todayStr)
      .reduce((s, t) => s + txEgp(t), 0);

    // Budget Streak (consecutive days up to today staying within dailySafeToSpend)
    const dailyBaseline = Math.max(dailySafeToSpend, monthlyBudgetPool / daysInMonth);
    let streak = 0;
    for (let offset = 0; offset < 30; offset++) {
      const dStr = todayIso(-offset);
      if (!dStr.startsWith(currentMonthKey())) break;
      const daySpend = monthTxs
        .filter((t) => t.type === 'expense' && t.date === dStr)
        .reduce((s, t) => s + txEgp(t), 0);
      if (daySpend <= dailyBaseline) {
        streak++;
      } else {
        break;
      }
    }

    // Overspending Alerts (>= 80%)
    const overspendingAlerts = Object.entries(appState.budgets)
      .filter(([, limit]) => Number(limit) > 0)
      .map(([catId, limit]) => {
        const cat = getCategory(catId);
        const spent = catTotalsMap[catId] || 0;
        const pct = Math.round((spent / limit) * 100);
        return { cat, spent, limit, pct };
      })
      .filter((item) => item.pct >= 80)
      .sort((a, b) => b.pct - a.pct);

    // Financial Health Score (0-100)
    const savingsPts = monthIncome > 0
      ? Math.min(35, Math.max(0, Math.round((Math.max(0, netSurplus) / monthIncome) * 140)))
      : (totalBalance > 0 ? 18 : 10);
    const activeBudgets = Object.entries(appState.budgets).filter(([, l]) => Number(l) > 0);
    const withinBudgetCount = activeBudgets.filter(([catId, l]) => (catTotalsMap[catId] || 0) <= l).length;
    const budgetPts = activeBudgets.length > 0
      ? Math.round((withinBudgetCount / activeBudgets.length) * 35)
      : 22;
    const dailyPts = todaySpent <= dailySafeToSpend ? 15 : 5;
    const streakPts = Math.min(15, streak * 2);
    const healthScore = Math.min(100, Math.max(5, savingsPts + budgetPts + dailyPts + streakPts));
    const healthLabel = healthScore >= 80 ? 'ممتاز 🌟' : healthScore >= 60 ? 'جيد جداً 👍' : healthScore >= 40 ? 'متوسط ⚖️' : 'تحت الضغط 🛡️';

    return {
      totalBalance,
      monthIncome,
      monthExpense,
      netSurplus,
      savingsRate,
      categoryBreakdown,
      dailySafeToSpend,
      todaySpent,
      remainingDays,
      remainingMonthlyBudget,
      streak,
      overspendingAlerts,
      healthScore,
      healthLabel
    };
  }

  // Wallet Balance Engine
  function applyTxWalletEffect(tx, direction = 1) {
    if (!tx) return;
    const amt = (parseLocaleNumber(tx.amount, 0)) * direction;
    const w = getWallet(tx.walletId);
    if (tx.type === 'expense') {
      if (w) w.balance = Number(((Number(w.balance) || 0) - amt).toFixed(2));
    } else if (tx.type === 'income') {
      if (w) w.balance = Number(((Number(w.balance) || 0) + amt).toFixed(2));
    } else if (tx.type === 'transfer') {
      if (w) w.balance = Number(((Number(w.balance) || 0) - amt).toFixed(2));
      const toW = getWallet(tx.toWalletId);
      if (toW) {
        let convertedAmt;
        if (direction < 0 && Number.isFinite(Number(tx.convertedToAmount))) {
          convertedAmt = -Number(tx.convertedToAmount);
        } else if (w && w.currency !== toW.currency) {
          convertedAmt = safeDiv(toEgp(amt, w.currency), getUnitRateInEgp(toW.currency), amt);
        } else {
          convertedAmt = amt;
        }
        if (direction > 0) tx.convertedToAmount = Number(convertedAmt.toFixed(2));
        toW.balance = Number(((Number(toW.balance) || 0) + convertedAmt).toFixed(2));
      }
    }
  }

  function saveTransactionRecord(payload) {
    const amount = parseLocaleNumber(payload.amount);
    if (!Number.isFinite(amount) || amount <= 0) {
      showToast('من فضلك أدخل مبلغاً صحيحاً أكبر من صفر');
      return false;
    }
    if (!payload.walletId || !getWallet(payload.walletId)) {
      showToast('اختر المحفظة أولاً');
      return false;
    }
    if (payload.type === 'transfer' && (!payload.toWalletId || !getWallet(payload.toWalletId) || payload.toWalletId === payload.walletId)) {
      showToast('اختر محفظة مستلمة مختلفة للتحويل');
      return false;
    }

    const safeDate = /^\d{4}-\d{2}-\d{2}/.test(String(payload.date || '')) ? String(payload.date).slice(0, 10) : todayIso();

    if (payload.id) {
      const idx = appState.transactions.findIndex((t) => t.id === payload.id);
      if (idx !== -1) {
        const oldTx = appState.transactions[idx];
        applyTxWalletEffect(oldTx, -1);
        const updated = {
          ...oldTx,
          type: payload.type,
          amount,
          categoryId: payload.type === 'transfer' ? 'other' : payload.categoryId,
          walletId: payload.walletId,
          toWalletId: payload.type === 'transfer' ? payload.toWalletId : null,
          convertedToAmount: undefined,
          date: safeDate,
          note: (payload.note || '').trim()
        };
        applyTxWalletEffect(updated, 1);
        appState.transactions[idx] = updated;
        showToast('تم تعديل المعاملة وتحديث الرصيد ✅');
      }
    } else {
      const created = {
        id: uid('tx'),
        type: payload.type,
        amount,
        categoryId: payload.type === 'transfer' ? 'other' : payload.categoryId,
        walletId: payload.walletId,
        toWalletId: payload.type === 'transfer' ? payload.toWalletId : null,
        date: safeDate,
        note: (payload.note || '').trim()
      };
      applyTxWalletEffect(created, 1);
      appState.transactions.unshift(created);
      showToast('تم تسجيل المعاملة وتحديث المحفظة ✅');
    }

    appState.transactions.sort((a, b) => String(b.date || '').localeCompare(String(a.date || '')));
    saveState(appState);
    renderAll();
    return true;
  }

  function deleteTransactionById(txId) {
    const idx = appState.transactions.findIndex((t) => t.id === txId);
    if (idx === -1) return;
    const old = appState.transactions[idx];
    applyTxWalletEffect(old, -1);
    appState.transactions.splice(idx, 1);
    saveState(appState);
    showToast('تم حذف المعاملة وإرجاع المبلغ للمحفظة');
    renderAll();
  }

  // Egyptian SMS / InstaPay Parser (Supports mixed Arabic/English & comma numbers)
  function parseEgyptianSms(rawText) {
    const normalized = normalizeArabicDigits(rawText).trim();
    if (!normalized) return null;

    // Strip trailing available balance phrases so we don't accidentally extract account balance as tx amount
    const txSection = normalized.split(/(?:الرصيد المتاح|رصيدك الحالي|الرصيد الحالى|available balance|current balance|bal[:\s])/i)[0] || normalized;

    const amtMatch =
      txSection.match(/(?:مبلغ(?:\s+وقدره)?|قيمة|بمبلغ|egp|l\.?e\.?|ج\.م)\s*[:\-]?\s*([0-9][0-9,]*(?:\.[0-9]+)?)/i) ||
      txSection.match(/([0-9][0-9,]*(?:\.[0-9]+)?)\s*(?:egp|l\.?e\.?|ج\.م|جنيه|جم|ج(?=\s|$))/i) ||
      txSection.match(/(?:خصم|سحب|دفع|شراء|تحويل|استلام|إيداع|ايداع|debited|credited|spent|paid|received)\s+(?:مبلغ\s+)?([0-9][0-9,]*(?:\.[0-9]+)?)/i) ||
      txSection.match(/([0-9][0-9,]*(?:\.[0-9]+)?)/);

    const amount = amtMatch ? parseLocaleNumber(amtMatch[1]) : null;
    if (!amount || !Number.isFinite(amount) || amount <= 0) return null;

    const lower = normalized.toLowerCase();
    const isIncome = /(استلام|وصلتك|تحويل وارد|إلى حسابك|تم ايداع|إيداع|ايداع|تم تحويل.*إليك|تم تحويل.*لك|كاش باك|received|credited|deposit|refund|cashback|مرتب)/.test(lower);
    const type = isIncome ? 'income' : 'expense';

    let suggestedWalletId = appState.wallets[0]?.id || '';
    if (/(فودافون|vodafone|اتصالات|اورانج|orange|etisalat|محفظة)/.test(lower)) {
      suggestedWalletId = appState.wallets.find((w) => w.type === 'mobile')?.id || suggestedWalletId;
    } else if (/(انستا|instapay|بنك|cib|الأهلي|مصر|qnb|hsbc|nbe|banque|حساب)/.test(lower)) {
      suggestedWalletId = appState.wallets.find((w) => w.type === 'bank')?.id || suggestedWalletId;
    } else if (/(بطاقة|كارت|فيزا|ماستر|visa|mastercard|card)/.test(lower)) {
      suggestedWalletId = appState.wallets.find((w) => w.type === 'credit')?.id || suggestedWalletId;
    }

    let suggestedCategoryId = type === 'income' ? 'salary' : 'other';
    if (type === 'expense') {
      if (/(مطعم|طلبات|اكل|أكل|سوبر|ماركت|كارفور|كافيه|talabat|mcdonald|starbucks)/.test(lower)) suggestedCategoryId = 'food';
      else if (/(أوبر|اوبر|كريم|بنزين|مواصلات|uber|careem|indriver)/.test(lower)) suggestedCategoryId = 'transport';
      else if (/(فوري|فاتورة|نت|شحن|رصيد|كهرباء|مياه|غاز|fawry|telecom|we )/.test(lower)) suggestedCategoryId = 'bills';
      else if (/(صيدلية|علاج|مستشفى|دكتور|pharmacy|hospital)/.test(lower)) suggestedCategoryId = 'health';
      else if (/(أمازون|امازون|ملابس|نون|شراء|amazon|noon)/.test(lower)) suggestedCategoryId = 'shopping';
    }

    return {
      amount,
      type,
      walletId: suggestedWalletId,
      categoryId: suggestedCategoryId,
      note: rawText.trim().slice(0, 65)
    };
  }

  // Charts & Shared Renderers
  function buildDonutChartSvg(breakdown, totalExpense) {
    const radius = 48;
    const circumference = 2 * Math.PI * radius;
    if (!breakdown.length || totalExpense <= 0) {
      return `<svg viewBox="0 0 130 130" width="138" height="138"><circle cx="65" cy="65" r="${radius}" fill="none" stroke="var(--bg-soft)" stroke-width="16"/></svg>`;
    }
    let offset = 0;
    const slices = breakdown.slice(0, 6).map((item) => {
      const fraction = item.total / totalExpense;
      const dash = fraction * circumference;
      const c = `<circle cx="65" cy="65" r="${radius}" fill="none" stroke="${item.category.color}" stroke-width="16" stroke-dasharray="${dash.toFixed(2)} ${circumference.toFixed(2)}" stroke-dashoffset="${(-offset).toFixed(2)}" transform="rotate(-90 65 65)"/>`;
      offset += dash;
      return c;
    }).join('');
    return `<svg viewBox="0 0 130 130" width="138" height="138"><circle cx="65" cy="65" r="${radius}" fill="none" stroke="var(--bg-soft)" stroke-width="16"/>${slices}</svg>`;
  }

  function buildHealthGaugeSvg(score) {
    const radius = 25;
    const circ = 2 * Math.PI * radius;
    const pct = Math.min(100, Math.max(0, score)) / 100;
    const dash = pct * circ;
    const color = score >= 75 ? '#10B981' : score >= 50 ? '#F59E0B' : '#EF4444';
    return `
      <svg class="health-gauge-svg" viewBox="0 0 64 64">
        <circle cx="32" cy="32" r="${radius}" fill="none" stroke="var(--bg-soft)" stroke-width="6"/>
        <circle cx="32" cy="32" r="${radius}" fill="none" stroke="${color}" stroke-width="6" stroke-linecap="round" stroke-dasharray="${dash.toFixed(1)} ${circ.toFixed(1)}" transform="rotate(-90 32 32)"/>
        <text x="32" y="36" text-anchor="middle" fill="var(--text)" font-size="14" font-weight="800">${score}</text>
      </svg>
    `;
  }

  function renderTransactionRow(tx, showActions = false) {
    const cat = getCategory(tx.categoryId);
    const w = getWallet(tx.walletId);
    const toW = tx.toWalletId ? getWallet(tx.toWalletId) : null;
    const walletCurr = w?.currency || 'EGP';
    const title = tx.type === 'transfer'
      ? `تحويل: ${w ? w.name : ''} ← ${toW ? toW.name : ''}`
      : (tx.note || cat.name);
    const sign = tx.type === 'expense' ? '-' : tx.type === 'income' ? '+' : '⇄';
    const icon = tx.type === 'transfer' ? '⇄' : cat.icon;
    const iconBg = tx.type === 'transfer' ? 'var(--blue-soft)' : `${cat.color}24`;
    const tags = extractHashtags(tx.note);

    return `
      <div class="tx-item">
        <div class="tx-main">
          <div class="tx-icon" style="background:${iconBg}">${icon}</div>
          <div class="tx-info">
            <div class="tx-title">${escapeHtml(title)}</div>
            <div class="tx-meta">
              <span>${escapeHtml(tx.type === 'transfer' ? 'تحويل' : cat.name)}</span>
              <span>•</span>
              <span>${escapeHtml(w ? w.name : 'محفظة')}</span>
              <span>•</span>
              <span class="num-ltr">${escapeHtml(tx.date)}</span>
              ${tags.map((tag) => `<button class="tag-pill" data-filter-tag="${escapeHtml(tag)}" type="button">${escapeHtml(tag)}</button>`).join('')}
            </div>
          </div>
        </div>
        <div class="tx-right">
          <div class="tx-amount ${tx.type}">
            ${sign} ${fmtCurrency(tx.amount, walletCurr, walletCurr === 'EGP' ? 0 : 2)}
          </div>
          ${showActions ? `
            <div class="tx-actions">
              <button class="mini-action-btn" data-edit-tx="${tx.id}" type="button">تعديل</button>
              <button class="mini-action-btn danger" data-del-tx="${tx.id}" type="button">حذف</button>
            </div>
          ` : ''}
        </div>
      </div>
    `;
  }

  // 1. Render Dashboard
  function renderDashboard() {
    const container = document.getElementById('tab-dashboard');
    if (!container) return;
    const m = computeDashboardMetrics();

    const alertsHtml = m.overspendingAlerts.slice(0, 2).map((al) => `
      <div class="alert-banner ${al.pct >= 100 ? 'danger' : 'warn'}" data-jump-tab="budgets" style="cursor:pointer">
        <span>${al.cat.icon} تنبيه ميزانية «${escapeHtml(al.cat.name)}»: وصلت <span class="num-ltr">${al.pct}%</span> (${fmtEgp(al.spent)} / ${fmtEgp(al.limit)})</span>
        <span>←</span>
      </div>
    `).join('');

    const walletsHtml = appState.wallets.map((w) => `
      <div class="wallet-chip">
        <div class="wallet-chip-top">
          <span>${escapeHtml(w.name)}</span>
          <span>${w.icon || '💳'}</span>
        </div>
        <div class="wallet-chip-bal">${fmtCurrency(w.balance, w.currency, w.currency === 'EGP' ? 0 : 2)}</div>
        ${w.currency !== 'EGP' ? `<div class="wallet-chip-eq">≈ ${fmtEgp(toEgp(w.balance, w.currency))}</div>` : ''}
      </div>
    `).join('');

    const totalFlow = Math.max(1, m.monthIncome + m.monthExpense);
    const incPct = Math.round((m.monthIncome / totalFlow) * 100);
    const expPct = 100 - incPct;
    const legendHtml = m.categoryBreakdown.slice(0, 5).map((item) => `
      <div class="legend-item">
        <div class="legend-left">
          <span class="legend-dot" style="background:${item.category.color}"></span>
          <span class="legend-name">${item.category.icon} ${escapeHtml(item.category.name)}</span>
        </div>
        <span class="num-ltr" style="font-weight:700">${Math.round(item.pct)}%</span>
      </div>
    `).join('');

    const latestTxs = appState.transactions.slice(0, 5);

    container.innerHTML = `
      <div class="card hero-card">
        <div class="hero-label">إجمالي صافي الثروة (مقوّم بالجنيه المصري)</div>
        <div class="hero-amount">${fmtEgp(m.totalBalance)}</div>
        <div class="hero-metrics">
          <div class="metric-box">
            <span class="m-label">دخل الشهر</span>
            <span class="m-val val-income">${fmtEgp(m.monthIncome)}</span>
          </div>
          <div class="metric-box">
            <span class="m-label">مصاريف الشهر</span>
            <span class="m-val val-expense">${fmtEgp(m.monthExpense)}</span>
          </div>
          <div class="metric-box">
            <span class="m-label">معدل الادخار</span>
            <span class="m-val val-gold"><span class="num-ltr">${m.savingsRate}%</span></span>
          </div>
        </div>
      </div>

      ${alertsHtml}

      <div class="smart-widgets-grid">
        <div class="widget-card">
          <div>
            <span class="card-subtitle">الحد اليومي الآمن</span>
            <div style="font-size:1.12rem;font-weight:800;color:${m.todaySpent > m.dailySafeToSpend ? 'var(--red)' : 'var(--emerald)'};margin-top:2px">
              ${fmtEgp(m.dailySafeToSpend)}
            </div>
          </div>
          <div style="font-size:0.74rem;color:var(--text-muted)">
            مصروف اليوم: <strong>${fmtEgp(m.todaySpent)}</strong><br/>
            متبقي <span class="num-ltr">${m.remainingDays}</span> يوم في الشهر
          </div>
        </div>

        <div class="widget-card">
          <div class="health-gauge-wrap">
            ${buildHealthGaugeSvg(m.healthScore)}
            <div>
              <span class="card-subtitle">صحتك المالية</span>
              <strong style="display:block;font-size:0.86rem">${m.healthLabel}</strong>
              <span class="badge badge-amber" style="margin-top:4px">🔥 التزام <span class="num-ltr">${m.streak}</span> يوم</span>
            </div>
          </div>
        </div>
      </div>

      <div class="h-scroll">${walletsHtml}</div>

      <div class="card">
        <div class="card-header">
          <h2 class="card-title">💱 الدولار والذهب الآن</h2>
          <button class="link-btn" data-jump-tab="rates" type="button">كل الأسعار والحاسبات ←</button>
        </div>
        <div class="rates-glance-grid">
          <div class="glance-rate-box" data-jump-tab="rates" style="cursor:pointer">
            <div>
              <span class="glance-rate-name">الدولار (USD)</span>
              <span class="glance-rate-val">${fmtEgp(ratesState.usd, 2, true)}</span>
            </div>
            <span style="font-size:1.25rem">💵</span>
          </div>
          <div class="glance-rate-box" data-jump-tab="rates" style="cursor:pointer;border-color:rgba(245,158,11,0.4)">
            <div>
              <span class="glance-rate-name">ذهب عيار 21</span>
              <span class="glance-rate-val" style="color:var(--gold)">${fmtEgp(ratesState.gold21, 0, true)}</span>
            </div>
            <span style="font-size:1.25rem">🪙</span>
          </div>
        </div>
      </div>

      <div class="card">
        <div class="card-header">
          <h2 class="card-title">📊 توزيع مصاريف الشهر</h2>
          <span class="card-subtitle">${m.netSurplus >= 0 ? `فائض ${fmtEgp(m.netSurplus)}` : `عجز ${fmtEgp(Math.abs(m.netSurplus))}`}</span>
        </div>
        <div class="chart-wrap">
          <div class="donut-box">
            ${buildDonutChartSvg(m.categoryBreakdown, m.monthExpense)}
            <div class="donut-center">
              <span>إجمالي الصرف</span>
              <strong>${appState.settings.privacyMode ? '••••' : fmtNum(m.monthExpense, 0)} ج.م</strong>
            </div>
          </div>
          <div class="chart-legend">
            ${legendHtml || '<div class="empty-state" style="padding:8px">لا توجد مصاريف هذا الشهر</div>'}
          </div>
        </div>
        <div class="compare-bar-wrap">
          <div class="compare-labels">
            <span style="color:var(--emerald)">الدخل (<span class="num-ltr">${incPct}%</span>)</span>
            <span style="color:var(--red)">المصروفات (<span class="num-ltr">${expPct}%</span>)</span>
          </div>
          <div class="compare-track">
            <div class="compare-income" style="width:${incPct}%"></div>
            <div class="compare-expense" style="width:${expPct}%"></div>
          </div>
        </div>
      </div>

      <div class="card">
        <div class="card-header">
          <h2 class="card-title">🧾 أحدث المعاملات</h2>
          <button class="link-btn" data-jump-tab="transactions" type="button">السجل الكامل ←</button>
        </div>
        <div class="tx-list">
          ${latestTxs.length ? latestTxs.map((tx) => renderTransactionRow(tx, false)).join('') : '<div class="empty-state">لا توجد معاملات مسجلة — اضغط زر + بالأسفل للبدء.</div>'}
        </div>
      </div>
    `;
  }

  // 2. Render Transactions (with #hashtags filtering)
  function getFilteredTransactions() {
    const q = txFilters.search.trim().toLowerCase();
    const thisMonth = currentMonthKey();
    const lastMonth = prevMonthKey();
    return appState.transactions.filter((tx) => {
      if (txFilters.type !== 'all' && tx.type !== txFilters.type) return false;
      if (txFilters.categoryId !== 'all' && tx.categoryId !== txFilters.categoryId) return false;
      if (txFilters.walletId !== 'all' && tx.walletId !== txFilters.walletId && tx.toWalletId !== txFilters.walletId) return false;
      if (txFilters.period === 'this_month' && !String(tx.date).startsWith(thisMonth)) return false;
      if (txFilters.period === 'last_month' && !String(tx.date).startsWith(lastMonth)) return false;
      if (txFilters.period === 'custom' && txFilters.customDate && tx.date !== txFilters.customDate) return false;
      if (txFilters.hashtag && !extractHashtags(tx.note).includes(txFilters.hashtag)) return false;
      if (q) {
        const cat = getCategory(tx.categoryId).name.toLowerCase();
        const w = (getWallet(tx.walletId)?.name || '').toLowerCase();
        const note = (tx.note || '').toLowerCase();
        const amtStr = String(tx.amount);
        if (!cat.includes(q) && !w.includes(q) && !note.includes(q) && !amtStr.includes(q)) return false;
      }
      return true;
    });
  }

  function renderTransactions() {
    const container = document.getElementById('tab-transactions');
    if (!container) return;
    const filtered = getFilteredTransactions();
    const allCats = getAllCategories();
    const allHashtags = [...new Set(appState.transactions.flatMap((t) => extractHashtags(t.note)))];
    const totalOut = filtered.filter((t) => t.type === 'expense').reduce((s, t) => s + toEgp(t.amount, getWallet(t.walletId)?.currency || 'EGP'), 0);
    const totalIn = filtered.filter((t) => t.type === 'income').reduce((s, t) => s + toEgp(t.amount, getWallet(t.walletId)?.currency || 'EGP'), 0);

    container.innerHTML = `
      <div class="card filters-card">
        <div class="card-header" style="margin-bottom:4px">
          <h2 class="card-title">📋 سجل المعاملات</h2>
          <span class="badge badge-green"><span class="num-ltr">${filtered.length}</span> معاملة</span>
        </div>

        <input id="txSearchInput" class="input-field" type="search" placeholder="ابحث بالملاحظة، #الوسم، الفئة، المحفظة أو المبلغ..." value="${escapeHtml(txFilters.search)}" />

        <div class="filter-pills">
          <button class="pill-btn ${txFilters.type === 'all' ? 'active' : ''}" data-tx-type="all" type="button">الكل</button>
          <button class="pill-btn ${txFilters.type === 'expense' ? 'active' : ''}" data-tx-type="expense" type="button">مصاريف</button>
          <button class="pill-btn ${txFilters.type === 'income' ? 'active' : ''}" data-tx-type="income" type="button">دخل</button>
          <button class="pill-btn ${txFilters.type === 'transfer' ? 'active' : ''}" data-tx-type="transfer" type="button">تحويلات</button>
        </div>

        ${allHashtags.length ? `
          <div class="suggestions-row">
            <button class="pill-btn ${txFilters.hashtag === '' ? 'active' : ''}" data-filter-tag="" type="button"># كل الوسوم</button>
            ${allHashtags.map((tag) => `<button class="pill-btn ${txFilters.hashtag === tag ? 'active' : ''}" data-filter-tag="${escapeHtml(tag)}" type="button">${escapeHtml(tag)}</button>`).join('')}
          </div>
        ` : ''}

        <div class="grid-2">
          <select id="txCatFilter" class="select-field">
            <option value="all">كل الفئات</option>
            ${allCats.map((c) => `<option value="${c.id}" ${txFilters.categoryId === c.id ? 'selected' : ''}>${c.icon} ${escapeHtml(c.name)}</option>`).join('')}
          </select>
          <select id="txWalletFilter" class="select-field">
            <option value="all">كل المحافظ</option>
            ${appState.wallets.map((w) => `<option value="${w.id}" ${txFilters.walletId === w.id ? 'selected' : ''}>${w.icon || '💳'} ${escapeHtml(w.name)}</option>`).join('')}
          </select>
        </div>

        <div class="grid-2">
          <select id="txPeriodFilter" class="select-field">
            <option value="this_month" ${txFilters.period === 'this_month' ? 'selected' : ''}>هذا الشهر</option>
            <option value="last_month" ${txFilters.period === 'last_month' ? 'selected' : ''}>الشهر الماضي</option>
            <option value="all" ${txFilters.period === 'all' ? 'selected' : ''}>كل الأوقات</option>
            <option value="custom" ${txFilters.period === 'custom' ? 'selected' : ''}>تاريخ محدد</option>
          </select>
          ${txFilters.period === 'custom'
            ? `<input id="txCustomDate" class="input-field" type="date" value="${escapeHtml(txFilters.customDate || todayIso())}" />`
            : `<div class="budget-item" style="justify-content:center;padding:6px 10px;font-size:0.74rem">
                 <div>دخل: <strong style="color:var(--emerald)">${fmtEgp(totalIn)}</strong></div>
                 <div>صرف: <strong style="color:var(--red)">${fmtEgp(totalOut)}</strong></div>
               </div>`
          }
        </div>
      </div>

      <div class="tx-list">
        ${filtered.length
          ? filtered.map((tx) => renderTransactionRow(tx, true)).join('')
          : '<div class="card empty-state">لا توجد معاملات مطابقة للبحث أو الفلتر الحالي.</div>'}
      </div>
    `;
  }

  // 3. Render Budgets, Goals, Gam3eya, Debts & Recurring Bills
  function renderBudgets() {
    const container = document.getElementById('tab-budgets');
    if (!container) return;
    const m = computeDashboardMetrics();
    const expenseCategories = getAllCategories().filter((c) => c.type === 'expense' || c.type === 'both');
    const curMonth = currentMonthKey();
    const todayDay = new Date().getDate();

    const subTabs = [
      { id: 'all', label: 'الكل' },
      { id: 'limits', label: 'الميزانيات' },
      { id: 'goals', label: 'الأهداف' },
      { id: 'gam3eya', label: 'الجمعية' },
      { id: 'debts', label: 'الديون والسلف' },
      { id: 'bills', label: 'الفواتير الثابتة' }
    ];

    const showSec = (sec) => activeBudgetsSubTab === 'all' || activeBudgetsSubTab === sec;

    const budgetsHtml = expenseCategories.map((cat) => {
      const limit = Number(appState.budgets[cat.id]) || 0;
      const spent = m.categoryBreakdown.find((b) => b.category.id === cat.id)?.total || 0;
      const pct = limit > 0 ? Math.round((spent / limit) * 100) : 0;
      let fillCls = 'fill-green';
      let badgeCls = 'badge-green';
      let statusTxt = 'ضمن الحد';
      if (limit === 0) {
        badgeCls = 'badge-blue';
        statusTxt = 'بدون حد';
      } else if (pct >= 100) {
        fillCls = 'fill-red';
        badgeCls = 'badge-red';
        statusTxt = `تجاوزت الحد (${pct}%)`;
      } else if (pct >= 75) {
        fillCls = 'fill-amber';
        badgeCls = 'badge-amber';
        statusTxt = `اقتربت (${pct}%)`;
      } else {
        statusTxt = `آمن (${pct}%)`;
      }
      return `
        <div class="budget-item">
          <div class="budget-top">
            <div>${cat.icon} <strong>${escapeHtml(cat.name)}</strong></div>
            <div style="display:flex;align-items:center;gap:6px">
              <span class="badge ${badgeCls}">${statusTxt}</span>
              <button class="mini-action-btn" data-edit-budget="${cat.id}" type="button">${limit > 0 ? 'تعديل' : 'تعيين حد'}</button>
            </div>
          </div>
          <div class="budget-top" style="font-size:0.77rem;color:var(--text-muted)">
            <span>المصروف: ${fmtEgp(spent)}</span>
            <span>${limit > 0 ? `الحد: ${fmtEgp(limit)}` : 'اضغط لتحديد ميزانية'}</span>
          </div>
          ${limit > 0 ? `<div class="progress-track"><div class="progress-fill ${fillCls}" style="width:${Math.min(100, pct)}%"></div></div>` : ''}
        </div>
      `;
    }).join('');

    const goalsHtml = appState.goals.length
      ? appState.goals.map((g) => {
          const pct = g.target > 0 ? Math.min(100, Math.round((g.saved / g.target) * 100)) : 0;
          return `
            <div class="budget-item">
              <div class="budget-top">
                <div>${g.icon || '🎯'} <strong>${escapeHtml(g.title)}</strong></div>
                <span class="badge badge-green num-ltr">${pct}%</span>
              </div>
              <div class="budget-top" style="font-size:0.78rem;color:var(--text-muted)">
                <span>المدخر: ${fmtEgp(g.saved)}</span>
                <span>الهدف: ${fmtEgp(g.target)}</span>
              </div>
              <div class="progress-track"><div class="progress-fill fill-green" style="width:${pct}%"></div></div>
              <div style="display:flex;gap:8px;margin-top:3px">
                <button class="mini-action-btn emerald" style="flex:1" data-deposit-goal="${g.id}" type="button">+ إيداع للهدف</button>
                <button class="mini-action-btn danger" data-del-goal="${g.id}" type="button">حذف</button>
              </div>
            </div>
          `;
        }).join('')
      : '<div class="empty-state">لا توجد أهداف ادخار حالياً — أضف هدفك الأول!</div>';

    const gam3eyaHtml = appState.gam3eyas.length
      ? appState.gam3eyas.map((gm) => {
          const paidThisMonth = gm.lastPaidMonth === curMonth;
          const pct = gm.totalMembers > 0 ? Math.min(100, Math.round((gm.paidMonths / gm.totalMembers) * 100)) : 0;
          const w = getWallet(gm.walletId);
          return `
            <div class="budget-item">
              <div class="budget-top">
                <div>🤝 <strong>${escapeHtml(gm.title)}</strong></div>
                <span class="badge ${paidThisMonth ? 'badge-green' : 'badge-amber'}">${paidThisMonth ? 'تم سداد الشهر ✓' : 'قسط الشهر متبقي'}</span>
              </div>
              <div class="budget-top" style="font-size:0.77rem;color:var(--text-muted)">
                <span>القسط: <strong>${fmtEgp(gm.monthlyAmount)}</strong></span>
                <span>القبض: <strong style="color:var(--gold)">${fmtEgp(gm.payoutAmount)}</strong> (${escapeHtml(gm.payoutMonthLabel)})</span>
              </div>
              <div class="progress-track"><div class="progress-fill fill-green" style="width:${pct}%"></div></div>
              <div class="budget-top" style="font-size:0.72rem;color:var(--text-muted)">
                <span>الأشهر المدفوعة: <span class="num-ltr">${gm.paidMonths} / ${gm.totalMembers}</span></span>
                <span>${escapeHtml(w ? w.name : '')}</span>
              </div>
              <div style="display:flex;gap:8px;margin-top:2px">
                ${paidThisMonth
                  ? '<span class="mini-action-btn" style="flex:1;text-align:center;opacity:0.7">قسط هذا الشهر مسدد</span>'
                  : `<button class="mini-action-btn emerald" style="flex:1" data-pay-gam3eya="${gm.id}" type="button">سداد قسط الشهر (${fmtNum(gm.monthlyAmount, 0)} ج.م)</button>`}
                <button class="mini-action-btn danger" data-del-gam3eya="${gm.id}" type="button">حذف</button>
              </div>
            </div>
          `;
        }).join('')
      : '<div class="empty-state">لا توجد جمعيات مسجلة بعد — أضف جمعيتك لمتابعة الأقساط وموعد القبض.</div>';

    const owedToMeTotal = appState.debts.filter((d) => d.type === 'owed_to_me' && d.remainingAmount > 0).reduce((s, d) => s + d.remainingAmount, 0);
    const iOweTotal = appState.debts.filter((d) => d.type === 'i_owe' && d.remainingAmount > 0).reduce((s, d) => s + d.remainingAmount, 0);
    const debtsHtml = appState.debts.length
      ? appState.debts.map((d) => {
          const settled = d.remainingAmount <= 0;
          const isOwedToMe = d.type === 'owed_to_me';
          return `
            <div class="budget-item">
              <div class="budget-top">
                <div><strong>${escapeHtml(d.person)}</strong> <span class="badge ${isOwedToMe ? 'badge-green' : 'badge-red'}">${isOwedToMe ? 'فلوس ليك بره' : 'فلوس عليك'}</span></div>
                <span class="badge ${settled ? 'badge-blue' : 'badge-amber'}">${settled ? 'تمت التسوية ✓' : fmtEgp(d.remainingAmount)}</span>
              </div>
              <div class="budget-top" style="font-size:0.75rem;color:var(--text-muted)">
                <span>${escapeHtml(d.note || 'بدون ملاحظة')}</span>
                <span>الأصل: ${fmtEgp(d.totalAmount)}</span>
              </div>
              <div style="display:flex;gap:8px;margin-top:2px">
                ${settled ? '' : `<button class="mini-action-btn emerald" style="flex:1" data-settle-debt="${d.id}" type="button">${isOwedToMe ? 'تسجيل تحصيل' : 'تسجيل سداد'}</button>`}
                <button class="mini-action-btn danger" data-del-debt="${d.id}" type="button">حذف</button>
              </div>
            </div>
          `;
        }).join('')
      : '<div class="empty-state">لا توجد ديون أو سلف مسجلة.</div>';

    const billsHtml = appState.recurringBills.length
      ? appState.recurringBills.map((rb) => {
          const paid = rb.lastPaidMonth === curMonth;
          const overdue = !paid && todayDay > (rb.dueDay || 1);
          const dueSoon = !paid && !overdue && (rb.dueDay - todayDay) <= 3;
          const w = getWallet(rb.walletId);
          return `
            <div class="budget-item">
              <div class="budget-top">
                <div>📄 <strong>${escapeHtml(rb.title)}</strong></div>
                <span class="badge ${paid ? 'badge-green' : overdue ? 'badge-red' : dueSoon ? 'badge-amber' : 'badge-blue'}">
                  ${paid ? 'مدفوعة هذا الشهر ✓' : overdue ? `متأخرة (يوم ${rb.dueDay})` : `استحقاق يوم ${rb.dueDay}`}
                </span>
              </div>
              <div class="budget-top" style="font-size:0.78rem;color:var(--text-muted)">
                <span>القيمة: <strong style="color:var(--text)">${fmtEgp(rb.amount)}</strong></span>
                <span>${escapeHtml(w ? w.name : '')}</span>
              </div>
              <div style="display:flex;gap:8px;margin-top:2px">
                ${paid
                  ? '<span class="mini-action-btn" style="flex:1;text-align:center;opacity:0.7">تم الدفع لهذا الشهر</span>'
                  : `<button class="mini-action-btn emerald" style="flex:1" data-pay-bill="${rb.id}" type="button">دفع الفاتورة الآن</button>`}
                <button class="mini-action-btn danger" data-del-bill="${rb.id}" type="button">حذف</button>
              </div>
            </div>
          `;
        }).join('')
      : '<div class="empty-state">لا توجد فواتير أو اشتراكات ثابتة مسجلة.</div>';

    container.innerHTML = `
      <div class="budget-subtabs">
        ${subTabs.map((st) => `<button class="pill-btn ${activeBudgetsSubTab === st.id ? 'active' : ''}" data-budget-subtab="${st.id}" type="button">${st.label}</button>`).join('')}
      </div>

      ${showSec('limits') ? `
        <div class="card">
          <div class="card-header">
            <h2 class="card-title">📊 حدود الإنفاق الشهرية</h2>
            <span class="card-subtitle">أخضر &lt;75% • برتقالي 75-99% • أحمر ≥100%</span>
          </div>
          <div class="tx-list">${budgetsHtml}</div>
        </div>
      ` : ''}

      ${showSec('gam3eya') ? `
        <div class="card">
          <div class="card-header">
            <h2 class="card-title">🤝 متابع الجمعية (Gam3eya)</h2>
            <button id="addGam3eyaBtn" class="link-btn" type="button">+ جمعية جديدة</button>
          </div>
          <div class="tx-list">${gam3eyaHtml}</div>
        </div>
      ` : ''}

      ${showSec('goals') ? `
        <div class="card">
          <div class="card-header">
            <h2 class="card-title">🏆 أهداف الادخار</h2>
            <button id="addGoalBtn" class="link-btn" type="button">+ هدف جديد</button>
          </div>
          <div class="tx-list">${goalsHtml}</div>
        </div>
      ` : ''}

      ${showSec('debts') ? `
        <div class="card">
          <div class="card-header">
            <div>
              <h2 class="card-title">📒 الديون والسلف</h2>
              <span class="card-subtitle">ليك: ${fmtEgp(owedToMeTotal)} • عليك: ${fmtEgp(iOweTotal)}</span>
            </div>
            <button id="addDebtBtn" class="link-btn" type="button">+ دين / سلفة</button>
          </div>
          <div class="tx-list">${debtsHtml}</div>
        </div>
      ` : ''}

      ${showSec('bills') ? `
        <div class="card">
          <div class="card-header">
            <h2 class="card-title">🔁 الفواتير والاشتراكات الثابتة</h2>
            <button id="addBillBtn" class="link-btn" type="button">+ فاتورة جديدة</button>
          </div>
          <div class="tx-list">${billsHtml}</div>
        </div>
      ` : ''}
    `;
  }

  // 4. WhatsApp-Style Two-Screen AI Advisor + Voice-to-Text (ar-EG) + Safe Error Boundary
  function resolveAdvisor(advisorOrId) {
    const personas = window.PERSONAS && typeof window.PERSONAS === 'object' ? window.PERSONAS : {};
    if (!advisorOrId) return null;
    if (typeof advisorOrId === 'string') return personas[advisorOrId] || null;
    if (typeof advisorOrId === 'object' && advisorOrId.id) return personas[advisorOrId.id] || advisorOrId;
    return null;
  }

  function getPersonaHistory(personaId) {
    if (!aiChats || typeof aiChats !== 'object' || Array.isArray(aiChats)) aiChats = {};
    const list = aiChats[personaId];
    if (!Array.isArray(list)) {
      aiChats[personaId] = [];
      return aiChats[personaId];
    }
    aiChats[personaId] = list.filter((m) => m && typeof m === 'object' && typeof m.content === 'string');
    return aiChats[personaId];
  }

  function formatAiMessageHtml(rawText) {
    const safe = escapeHtml(rawText || '');
    const lines = safe.split(/\r?\n/);
    const blocks = lines.map((line) => {
      let formatted = line
        .replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>')
        .replace(/`([^`]+)`/g, '<code class="ai-md-code">$1</code>');
      if (/^#{1,4}\s+/.test(formatted)) {
        return `<div class="ai-md-h">${formatted.replace(/^#{1,4}\s+/, '')}</div>`;
      }
      if (/^\s*[-*•]\s+/.test(formatted)) {
        return `<div class="ai-md-li">${formatted.replace(/^\s*[-*•]\s+/, '')}</div>`;
      }
      if (!formatted.trim()) return '<div style="height:3px"></div>';
      return `<p class="ai-md-p">${formatted}</p>`;
    });
    return `<div class="ai-md-body">${blocks.join('')}</div>`;
  }

  function stopChatVoiceInput(shouldRender = false) {
    voiceListening = false;
    if (speechRecInstance) {
      try { speechRecInstance.onresult = null; speechRecInstance.onerror = null; speechRecInstance.onend = null; speechRecInstance.stop(); } catch (_) {}
      speechRecInstance = null;
    }
    if (shouldRender && activeTab === 'advisor' && activeAdvisorChatId) {
      updateVoiceUiState();
    }
  }

  function updateVoiceUiState() {
    const micBtn = document.getElementById('aiVoiceBtn');
    const pill = document.getElementById('voiceListeningPill');
    if (micBtn) {
      micBtn.classList.toggle('recording', voiceListening);
      micBtn.setAttribute('aria-label', voiceListening ? 'إيقاف التسجيل الصوتي' : 'تحدث بالمايكروفون');
    }
    if (pill) {
      pill.style.display = voiceListening ? 'inline-flex' : 'none';
    }
  }

  function startChatVoiceInput() {
    if (aiLoading) return;
    if (voiceListening) {
      stopChatVoiceInput(true);
      return;
    }

    const SpeechRec = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (SpeechRec) {
      try {
        const rec = new SpeechRec();
        rec.lang = 'ar-EG';
        rec.interimResults = true;
        rec.maxAlternatives = 1;
        speechRecInstance = rec;
        voiceListening = true;
        updateVoiceUiState();

        const baseVal = (document.getElementById('aiChatInput')?.value || '').trim();
        rec.onresult = (event) => {
          let transcript = '';
          for (let i = 0; i < event.results.length; i++) {
            transcript += (event.results[i]?.[0]?.transcript || '') + ' ';
          }
          const input = document.getElementById('aiChatInput');
          if (input) {
            const combined = [baseVal, transcript.trim()].filter(Boolean).join(' ');
            input.value = combined;
          }
        };
        rec.onerror = (ev) => {
          const errCode = ev?.error || '';
          stopChatVoiceInput(true);
          if (errCode === 'not-allowed' || errCode === 'service-not-allowed') {
            showToast('تم رفض إذن الميكروفون — اسمح بالصوت أو استخدم مايك لوحة المفاتيح');
          } else if (errCode !== 'aborted') {
            showToast('التسجيل الصوتي غير مدعوم في هذا المتصفح، استخدم مايك لوحة المفاتيح');
          }
        };
        rec.onend = () => {
          stopChatVoiceInput(true);
          document.getElementById('aiChatInput')?.focus();
        };
        rec.start();
        return;
      } catch (_) {
        stopChatVoiceInput(true);
      }
    }

    if (window.MasroufyAndroidBridge && typeof window.MasroufyAndroidBridge.startVoiceRecognition === 'function') {
      try {
        voiceListening = true;
        updateVoiceUiState();
        window.MasroufyAndroidBridge.startVoiceRecognition('ar-EG');
        return;
      } catch (_) {
        voiceListening = false;
        updateVoiceUiState();
      }
    }

    showToast('التسجيل الصوتي غير مدعوم في هذا المتصفح، استخدم مايك لوحة المفاتيح');
  }

  window.masroufyOnVoiceResult = function (text) {
    voiceListening = false;
    updateVoiceUiState();
    const spoken = String(text || '').trim();
    if (!spoken) return;
    const input = document.getElementById('aiChatInput');
    if (input) {
      const prev = input.value.trim();
      input.value = prev ? `${prev} ${spoken}` : spoken;
      input.focus();
    }
  };

  window.masroufyOnVoiceError = function (msg) {
    voiceListening = false;
    updateVoiceUiState();
    if (msg) showToast(String(msg));
  };

  function buildLiveFinancialContext(persona) {
    const p = resolveAdvisor(persona) || {};
    const m = computeDashboardMetrics();
    const walletsLines = (appState.wallets || []).map((w) => `- ${w?.name || 'محفظة'} (${w?.currency || 'EGP'}): ${fmtNum(w?.balance, w?.currency === 'EGP' ? 0 : 2)}`).join('\n');
    const topCatsLines = (m.categoryBreakdown || []).slice(0, 3).map((c) => `- ${c?.category?.name || 'أخرى'}: ${fmtNum(c.total, 0)} ج.م (${Math.round(c.pct)}%)`).join('\n') || '- لا توجد مصاريف هذا الشهر.';
    const budgetAlerts = (m.overspendingAlerts || []).map((b) => `- ${b?.cat?.name || ''}: ${fmtNum(b.spent, 0)} / ${fmtNum(b.limit, 0)} ج.م (${b.pct}%)`).join('\n') || '- جميع الميزانيات المحددة في النطاق الآمن.';
    const goalsLines = (appState.goals || []).map((g) => `- ${g?.title || 'هدف'}: ${fmtNum(g?.saved, 0)} / ${fmtNum(g?.target, 0)} ج.م`).join('\n') || '- لا توجد أهداف.';
    const latest5 = (appState.transactions || []).slice(0, 5).map((tx) => `- [${tx?.date || ''}] ${tx?.type || 'expense'}: ${fmtNum(tx?.amount, 0)} (${getCategory(tx?.categoryId)?.name || 'أخرى'}${tx?.note ? ' - ' + tx.note : ''})`).join('\n') || '- لا توجد معاملات.';

    return `${p?.systemInstruction || 'أنت مستشار مالي مصري خبير داخل تطبيق مصروفي.'}

قواعد الإجابة:
- اعتمد على البيانات المالية الحية التالية للمستخدم بعملة الجنيه المصري (ج.م).
- قدّم إجابات عملية مختصرة ومنظمة في نقاط قصيرة واضحة.

=== السياق المالي الحي (${todayIso()}) ===
صافي الثروة بالجنيه: ${fmtNum(m.totalBalance, 0)} ج.م
الحد اليومي الآمن: ${fmtNum(m.dailySafeToSpend, 0)} ج.م (مصروف اليوم: ${fmtNum(m.todaySpent, 0)} ج.م)
درجة الصحة المالية: ${m.healthScore}/100 (سلسلة الالتزام: ${m.streak} يوم)
المحافظ:
${walletsLines}

الشهر الحالي (${currentMonthKey()}): دخل ${fmtNum(m.monthIncome, 0)} ج.م | مصاريف ${fmtNum(m.monthExpense, 0)} ج.م | صافي ${fmtNum(m.netSurplus, 0)} ج.م (ادخار ${m.savingsRate}%)
أعلى 3 فئات صرف:
${topCatsLines}
تنبيهات الميزانيات:
${budgetAlerts}
الأهداف:
${goalsLines}
آخر 5 معاملات:
${latest5}
الأسعار الحية المحفوظة: دولار ${fmtNum(ratesState.usd, 2)} ج.م | ذهب عيار 21: ${fmtNum(ratesState.gold21, 0)} ج.م | ذهب عيار 24: ${fmtNum(ratesState.gold24, 0)} ج.م`;
  }

  function buildDynamicSmartSuggestions(persona) {
    const p = resolveAdvisor(persona);
    const m = computeDashboardMetrics();
    const list = [];
    const over30 = (m.categoryBreakdown || []).find((c) => c.pct > 30);
    if (over30) list.push(`إزاي أقلل مصاريف ${over30.category?.name || 'الفئة دي'} الشهر ده؟`);
    if (m.netSurplus > 500) list.push('أحفظ الفائض بتاعي في ذهب عيار 21 ولا دولار دلوقتي؟');
    if ((m.overspendingAlerts || []).length) list.push(`ميزانية ${m.overspendingAlerts[0]?.cat?.name || ''} قربت تخلص، أتصرف إزاي؟`);
    list.push('حلل وضعي المالي الشهر ده');
    list.push('اعمل لي خطة توفير لآخر الشهر');
    list.push('عايز أشتري حاجة بـ 2000 جنيه، ينفع؟');
    if (Array.isArray(p?.sampleQuestions)) {
      p.sampleQuestions.forEach((q) => { if (q && !list.includes(q)) list.push(q); });
    }
    return list.slice(0, 6);
  }

  function renderAdvisor() {
    const container = document.getElementById('tab-advisor');
    if (!container) return;
    const personas = window.PERSONAS && typeof window.PERSONAS === 'object' ? window.PERSONAS : {};
    const persona = resolveAdvisor(activeAdvisorChatId);

    // Screen 1: WhatsApp-style Advisors List
    if (!persona) {
      if (activeAdvisorChatId) {
        activeAdvisorChatId = null;
        applyThemeAndChrome();
      }
      const personaList = Object.values(personas).filter((p) => p && typeof p === 'object' && p.id);
      const listHtml = personaList.length ? personaList.map((p) => {
        const hist = getPersonaHistory(p.id);
        const lastMsg = hist.length ? hist[hist.length - 1] : null;
        const preview = lastMsg?.content || p?.welcomeMessage || 'اضغط لبدء المحادثة المالية';
        const timeStr = lastMsg?.ts ? formatTimeAr(lastMsg.ts) : 'متصل';
        return `
          <button class="wa-contact-row" data-open-advisor="${escapeHtml(p.id)}" type="button">
            <div class="wa-avatar-wrap">
              ${p?.avatarSvg || '<svg viewBox="0 0 64 64"><circle cx="32" cy="32" r="30" fill="#10B981"/></svg>'}
              <span class="wa-online-dot"></span>
            </div>
            <div class="wa-contact-info">
              <div class="wa-contact-top">
                <span class="wa-contact-name">${escapeHtml(p?.name || 'مستشار مصروفي')}</span>
                <span class="wa-contact-time">${escapeHtml(timeStr)}</span>
              </div>
              <div class="wa-contact-role" style="color:${p?.themeColor || '#10B981'}">${escapeHtml(p?.title || 'مستشار مالي ذكي')}</div>
              <div class="wa-contact-preview">${escapeHtml(preview)}</div>
            </div>
          </button>
        `;
      }).join('') : '<div class="card empty-state">جاري تحميل قائمة المستشارين...</div>';

      container.innerHTML = `
        <div class="wa-list-header">
          <div>
            <h2 class="card-title">💬 قائمة المستشارين</h2>
            <span class="card-subtitle">اختر المستشار المناسب — كل مستشار يقرأ بياناتك المالية الحية</span>
          </div>
        </div>
        <div class="wa-contact-list">${listHtml}</div>
      `;
      return;
    }

    // Screen 2: Dedicated Full-Screen WhatsApp Chat View (100dvh, hides bottom nav)
    const history = getPersonaHistory(persona.id);
    const suggestions = buildDynamicSmartSuggestions(persona);
    const welcomeText = persona?.welcomeMessage || 'أهلاً بك! اسألني عن وضعك المالي وسأساعدك فوراً.';
    const themeColor = persona?.themeColor || '#10B981';

    const messagesHtml = [
      `
        <div class="chat-msg assistant" style="border-color:${themeColor}55">
          ${formatAiMessageHtml(welcomeText)}
          <div class="chat-msg-footer">
            <span>${escapeHtml(persona?.name || 'المستشار')}</span>
            <span>${escapeHtml(persona?.badge || 'ذكي')}</span>
          </div>
        </div>
      `,
      ...history.map((m) => `
        <div class="chat-msg ${m?.role === 'user' ? 'user' : 'assistant'}">
          ${m?.role === 'user' ? escapeHtml(m?.content || '') : formatAiMessageHtml(m?.content || '')}
          <div class="chat-msg-footer">
            <span>${m?.provider ? escapeHtml(m.provider) : (m?.role === 'user' ? 'أنت ✓✓' : escapeHtml(persona?.name || 'المستشار'))}</span>
            <span>${escapeHtml(formatTimeAr(m?.ts) || '')}</span>
          </div>
        </div>
      `)
    ];

    if (aiLoading) {
      messagesHtml.push(`<div class="chat-msg assistant">يكتب الآن... ⏳</div>`);
    }

    const existingDraft = document.getElementById('aiChatInput')?.value || '';

    container.innerHTML = `
      <div class="wa-chat-screen">
        <header class="wa-chat-header">
          <div class="wa-chat-header-right">
            <button id="advisorBackBtn" class="wa-back-btn" type="button" aria-label="رجوع لقائمة المستشارين">→</button>
            <div class="wa-avatar-wrap" style="width:40px;height:40px">
              ${persona?.avatarSvg || '<svg viewBox="0 0 64 64"><circle cx="32" cy="32" r="30" fill="#10B981"/></svg>'}
              <span class="wa-online-dot" style="width:10px;height:10px"></span>
            </div>
            <div style="min-width:0">
              <strong style="display:block;font-size:0.92rem;line-height:1.2">${escapeHtml(persona?.name || 'المستشار')}</strong>
              <span style="display:block;font-size:0.7rem;color:var(--emerald-text)">${aiLoading ? 'يكتب الآن...' : 'متصل الآن • يرى بياناتك المالية'}</span>
            </div>
          </div>
          <button id="clearPersonaChatBtn" class="icon-btn" type="button" aria-label="مسح المحادثة" title="مسح المحادثة">🗑️</button>
        </header>

        <div id="aiChatBox" class="wa-chat-feed">
          ${messagesHtml.join('')}
          ${aiQuotaBannerVisible ? `
            <div class="quota-alert">
              <strong>⚡ انتهت الباقة اليومية المشتركة أو تعذر الاتصال</strong>
              <span>أضف مفتاح Gemini API أو Groq API مجاني للاستمرار فوراً من متصفحك.</span>
              <div style="display:flex;gap:8px">
                <button id="openAiKeySetupBtn" class="mini-action-btn" style="background:var(--emerald);color:#fff;border:none;padding:6px 12px" type="button">إضافة مفتاح الآن</button>
                <button id="dismissQuotaAlertBtn" class="mini-action-btn" type="button">إخفاء</button>
              </div>
            </div>
          ` : ''}
        </div>

        <footer class="wa-chat-footer">
          <div id="voiceListeningPill" class="voice-listening-pill" style="display:${voiceListening ? 'inline-flex' : 'none'}">
            <span>🔴</span>
            <span>جاري الاستماع... تحدث باللهجة المصرية</span>
          </div>
          <div class="suggestions-row">
            ${suggestions.map((q) => `<button class="suggestion-chip" data-ai-suggestion="${escapeHtml(q)}" type="button" ${aiLoading ? 'disabled' : ''}>${escapeHtml(q)}</button>`).join('')}
          </div>
          <form id="aiChatForm" class="chat-composer">
            <button id="aiVoiceBtn" class="mic-circle-btn ${voiceListening ? 'recording' : ''}" type="button" ${aiLoading ? 'disabled' : ''} aria-label="تحدث بالمايكروفون" title="إملاء صوتي باللهجة المصرية">🎤</button>
            <input id="aiChatInput" class="input-field" type="text" placeholder="اكتب رسالتك لـ ${escapeHtml(persona?.name || 'المستشار')}..." value="${escapeHtml(existingDraft)}" ${aiLoading ? 'disabled' : ''} />
            <button class="send-circle-btn" type="submit" ${aiLoading ? 'disabled' : ''} aria-label="إرسال">➤</button>
          </form>
        </footer>
      </div>
    `;

    requestAnimationFrame(() => {
      const box = document.getElementById('aiChatBox');
      if (box) box.scrollTop = box.scrollHeight;
    });
  }

  async function callPersonalGeminiFallback(systemPrompt, messages, apiKey) {
    const contents = messages.map((m) => ({
      role: m.role === 'assistant' ? 'model' : 'user',
      parts: [{ text: m.content }]
    }));
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 16000);
    const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${encodeURIComponent(apiKey)}`;
    try {
      const res = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          system_instruction: { parts: [{ text: systemPrompt }] },
          contents,
          generationConfig: { temperature: 0.65, maxOutputTokens: 700 }
        }),
        signal: controller.signal
      });
      if (!res.ok) throw new Error(`Gemini HTTP ${res.status}`);
      const data = await res.json();
      const text = data?.candidates?.[0]?.content?.parts?.[0]?.text;
      if (!text) throw new Error('Empty Gemini reply');
      return { reply: text.trim(), provider: 'Gemini (مفتاحك الشخصي)' };
    } finally {
      clearTimeout(timer);
    }
  }

  async function callPersonalGroqFallback(systemPrompt, messages, apiKey) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 16000);
    try {
      const res = await fetch('https://api.groq.com/openai/v1/chat/completions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${apiKey}` },
        body: JSON.stringify({
          model: 'llama-3.3-70b-versatile',
          messages: [{ role: 'system', content: systemPrompt }, ...messages],
          temperature: 0.65,
          max_tokens: 700
        }),
        signal: controller.signal
      });
      if (!res.ok) throw new Error(`Groq HTTP ${res.status}`);
      const data = await res.json();
      const text = data?.choices?.[0]?.message?.content;
      if (!text) throw new Error('Empty Groq reply');
      return { reply: text.trim(), provider: 'Groq (مفتاحك الشخصي)' };
    } finally {
      clearTimeout(timer);
    }
  }

  async function sendAiAdvisorMessage(rawText) {
    const text = String(rawText || '').trim();
    if (!text || aiLoading || !activeAdvisorChatId) return;
    const persona = resolveAdvisor(activeAdvisorChatId);
    if (!persona) return;
    stopChatVoiceInput(false);

    const history = getPersonaHistory(persona.id);
    history.push({ role: 'user', content: text, ts: Date.now() });
    saveAiChats(aiChats);
    aiQuotaBannerVisible = false;
    aiLoading = true;
    const draftEl = document.getElementById('aiChatInput');
    if (draftEl) draftEl.value = '';
    safeRender('tab-advisor', renderAdvisor);

    const systemPrompt = buildLiveFinancialContext(persona);
    const payloadMessages = history.slice(-10).map((m) => ({
      role: m.role === 'assistant' ? 'assistant' : 'user',
      content: m.content
    }));

    let result = null;
    let needsPersonalFallback = false;

    try {
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), 16000);
      try {
        const res = await fetch(AI_WORKER_URL, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ systemPrompt, messages: payloadMessages }),
          signal: controller.signal
        });
        if (!res.ok) {
          needsPersonalFallback = true;
        } else {
          const data = await res.json();
          if (data && data.reply) {
            result = { reply: String(data.reply).trim(), provider: data.provider || 'Masroufy AI' };
          } else {
            needsPersonalFallback = true;
          }
        }
      } finally {
        clearTimeout(timer);
      }
    } catch (_) {
      needsPersonalFallback = true;
    }

    if (!result && needsPersonalFallback) {
      const geminiKey = (appState.settings.geminiApiKey || '').trim();
      const groqKey = (appState.settings.groqApiKey || '').trim();
      if (geminiKey) {
        try { result = await callPersonalGeminiFallback(systemPrompt, payloadMessages, geminiKey); } catch (_) {}
      }
      if (!result && groqKey) {
        try { result = await callPersonalGroqFallback(systemPrompt, payloadMessages, groqKey); } catch (_) {}
      }
    }

    if (result) {
      history.push({ role: 'assistant', content: result.reply, provider: result.provider, ts: Date.now() });
      aiQuotaBannerVisible = false;
    } else {
      aiQuotaBannerVisible = true;
      history.push({
        role: 'assistant',
        content: 'عذراً، انتهت الباقة اليومية المشتركة أو لا يوجد اتصال بالإنترنت حالياً. أضف مفتاح Gemini أو Groq مجاني في الإعدادات للاستمرار بدون حدود.',
        provider: 'تنبيه الباقة',
        ts: Date.now()
      });
    }

    saveAiChats(aiChats);
    aiLoading = false;
    safeRender('tab-advisor', renderAdvisor);
  }

  async function fetchWithTimeout(url, options = {}, timeoutMs = 10000) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    try {
      return await fetch(url, { ...options, signal: controller.signal });
    } finally {
      clearTimeout(timer);
    }
  }

  // 5. Live Rates, Converter, Zakat Calculator & Split Bill Calculator
  async function fetchLiveRates(manual = false) {
    if (ratesLoading) return;
    ratesLoading = true;
    if (activeTab === 'rates') safeRender('tab-rates', renderRates);

    let egpData = null;
    let sourceLabel = '';

    try {
      const res = await fetchWithTimeout(CURRENCY_PRIMARY_URL, { cache: 'no-store' }, 9000);
      if (res.ok) {
        egpData = await res.json();
        sourceLabel = 'Fawazahmed0 API';
      }
    } catch (_) {}

    if (!egpData) {
      try {
        const res = await fetchWithTimeout(CURRENCY_FALLBACK_URL, { cache: 'no-store' }, 9000);
        if (res.ok) {
          egpData = await res.json();
          sourceLabel = 'Fawazahmed0 API (احتياطي)';
        }
      } catch (_) {}
    }

    let frankfurterVerified = false;
    try {
      const fRes = await fetchWithTimeout(FRANKFURTER_URL, { cache: 'no-store' }, 8000);
      if (fRes.ok) {
        const fJson = await fRes.json();
        if (fJson?.rates?.EUR && fJson?.rates?.GBP) frankfurterVerified = true;
      }
    } catch (_) {}

    if (egpData && egpData.egp) {
      const r = egpData.egp;
      const toEgpRate = (c) => (Number(r[c]) > 0 ? 1 / Number(r[c]) : 0);
      const usd = toEgpRate('usd') || ratesState.usd;
      const eur = toEgpRate('eur') || ratesState.eur;
      const sar = toEgpRate('sar') || ratesState.sar;
      const aed = toEgpRate('aed') || ratesState.aed;
      const kwd = toEgpRate('kwd') || ratesState.kwd;
      const xauOz = toEgpRate('xau');
      const gold24 = xauOz > 0 ? xauOz / TROY_OUNCE_GRAMS : ratesState.gold24;
      const gold21 = (gold24 * 21) / 24;
      const gold18 = (gold24 * 18) / 24;
      const xagOz = toEgpRate('xag');
      const silverGram = xagOz > 0 ? xagOz / TROY_OUNCE_GRAMS : ratesState.silverGram;

      ratesState = normalizeRatesState({
        usd, eur, sar, aed, kwd, gold24, gold21, gold18, silverGram,
        updatedAt: new Date().toLocaleString('ar-EG', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }),
        sourceLabel,
        frankfurterVerified,
        isCached: false
      });
      saveRatesCache(ratesState);
      if (manual) showToast('تم تحديث أسعار العملات والذهب بنجاح ✅');
    } else {
      ratesState.isCached = true;
      if (manual) showToast('تعذر الاتصال — يتم عرض آخر أسعار محفوظة');
    }

    ratesLoading = false;
    renderAll();
  }

  function getUnitLabel(code) {
    const map = {
      EGP: 'جنيه مصري (EGP)', USD: 'دولار (USD)', EUR: 'يورو (EUR)',
      SAR: 'ريال سعودي (SAR)', AED: 'درهم إماراتي (AED)', KWD: 'دينار كويتي (KWD)',
      GOLD_24: 'جرام ذهب عيار 24', GOLD_21: 'جرام ذهب عيار 21', GOLD_18: 'جرام ذهب عيار 18', SILVER: 'جرام فضة'
    };
    return map[code] || code;
  }

  function computeConverterOutput() {
    const amt = Math.max(0, parseLocaleNumber(converterState.amount, 0));
    return safeDiv(amt * getUnitRateInEgp(converterState.from), getUnitRateInEgp(converterState.to), 0);
  }

  function computeZakatSummary() {
    const g24 = getUnitRateInEgp('GOLD_24');
    const g21 = getUnitRateInEgp('GOLD_21');
    const silver = getUnitRateInEgp('SILVER');
    const nisabEgp = 85 * g24;
    const cash = Math.max(0, parseLocaleNumber(zakatState.cash, 0));
    const g21Val = Math.max(0, parseLocaleNumber(zakatState.gold21, 0)) * g21;
    const g24Val = Math.max(0, parseLocaleNumber(zakatState.gold24, 0)) * g24;
    const silverVal = Math.max(0, parseLocaleNumber(zakatState.silver, 0)) * silver;
    const totalWealth = cash + g21Val + g24Val + silverVal;
    const eligible = totalWealth >= nisabEgp;
    const zakatDue = eligible ? totalWealth * 0.025 : 0;
    return { nisabEgp, totalWealth, eligible, zakatDue };
  }

  function computeSplitSummary() {
    const total = Math.max(0, parseLocaleNumber(splitState.total, 0));
    const friends = Math.max(1, Math.round(parseLocaleNumber(splitState.friends, 1)));
    const tipPct = Math.max(0, parseLocaleNumber(splitState.tipPct, 0));
    const grandTotal = total * (1 + tipPct / 100);
    const perPerson = safeDiv(grandTotal, friends, 0);
    return { grandTotal, perPerson, friends };
  }

  function renderRates() {
    const container = document.getElementById('tab-rates');
    if (!container) return;
    const unitOptions = ['EGP', 'USD', 'EUR', 'SAR', 'AED', 'KWD', 'GOLD_21', 'GOLD_24', 'GOLD_18', 'SILVER'];
    const convertedVal = computeConverterOutput();
    const zakat = computeZakatSummary();
    const split = computeSplitSummary();
    if (!splitState.walletId && appState.wallets.length) splitState.walletId = appState.wallets[0].id;

    container.innerHTML = `
      <div class="card">
        <div class="card-header">
          <div>
            <h2 class="card-title">🪙 أسعار الذهب والفضة والعملات</h2>
            <span class="card-subtitle">${ratesState.updatedAt ? `آخر تحديث: ${escapeHtml(ratesState.updatedAt)}` : escapeHtml(ratesState.sourceLabel)}</span>
          </div>
          <button id="refreshRatesBtn" class="mini-action-btn emerald" type="button" ${ratesLoading ? 'disabled' : ''}>
            ${ratesLoading ? '⏳' : '🔄'} تحديث
          </button>
        </div>

        <div style="display:flex;flex-wrap:wrap;gap:6px;margin-bottom:10px">
          <span class="badge ${ratesState.isCached ? 'badge-amber' : 'badge-green'}">${ratesState.isCached ? '📦 آخر أسعار محفوظة' : '🟢 أسعار حية محدثة'}</span>
          ${ratesState.frankfurterVerified ? '<span class="badge badge-blue">✓ موثق Frankfurter</span>' : ''}
        </div>

        <div class="rates-grid" style="margin-bottom:9px">
          <div class="rate-card gold-accent"><div class="rate-top"><span>ذهب عيار 21</span><span>🪙</span></div><div class="rate-price" style="color:var(--gold)">${fmtEgp(ratesState.gold21, 0, true)}</div></div>
          <div class="rate-card gold-accent"><div class="rate-top"><span>ذهب عيار 24</span><span>✨</span></div><div class="rate-price" style="color:var(--gold)">${fmtEgp(ratesState.gold24, 0, true)}</div></div>
          <div class="rate-card gold-accent"><div class="rate-top"><span>ذهب عيار 18</span><span>💍</span></div><div class="rate-price">${fmtEgp(ratesState.gold18, 0, true)}</div></div>
          <div class="rate-card"><div class="rate-top"><span>جرام الفضة</span><span>🥈</span></div><div class="rate-price">${fmtEgp(ratesState.silverGram, 2, true)}</div></div>
        </div>

        <div class="rates-grid">
          <div class="rate-card"><div class="rate-top"><span>الدولار (USD)</span><span>🇺🇸</span></div><div class="rate-price">${fmtEgp(ratesState.usd, 2, true)}</div></div>
          <div class="rate-card"><div class="rate-top"><span>اليورو (EUR)</span><span>🇪🇺</span></div><div class="rate-price">${fmtEgp(ratesState.eur, 2, true)}</div></div>
          <div class="rate-card"><div class="rate-top"><span>الريال السعودي (SAR)</span><span>🇸🇦</span></div><div class="rate-price">${fmtEgp(ratesState.sar, 2, true)}</div></div>
          <div class="rate-card"><div class="rate-top"><span>الدرهم الإماراتي (AED)</span><span>🇦🇪</span></div><div class="rate-price">${fmtEgp(ratesState.aed, 2, true)}</div></div>
          <div class="rate-card" style="grid-column:span 2"><div class="rate-top"><span>الدينار الكويتي (KWD)</span><span>🇰🇼</span></div><div class="rate-price">${fmtEgp(ratesState.kwd, 2, true)}</div></div>
        </div>
      </div>

      <div class="card">
        <div class="card-header">
          <h2 class="card-title">🧮 حاسبة التحويل الفورية</h2>
          <button id="swapConverterBtn" class="mini-action-btn" type="button">⇄ عكس</button>
        </div>
        <div style="display:flex;flex-direction:column;gap:8px">
          <input id="convAmountInput" class="input-field" type="text" inputmode="decimal" value="${escapeHtml(converterState.amount)}" placeholder="المبلغ أو الوزن" />
          <div class="grid-2">
            <select id="convFromSelect" class="select-field">${unitOptions.map((u) => `<option value="${u}" ${converterState.from === u ? 'selected' : ''}>${getUnitLabel(u)}</option>`).join('')}</select>
            <select id="convToSelect" class="select-field">${unitOptions.map((u) => `<option value="${u}" ${converterState.to === u ? 'selected' : ''}>${getUnitLabel(u)}</option>`).join('')}</select>
          </div>
          <div class="converter-result">
            <span style="font-size:0.76rem;color:var(--text-muted)">النتيجة الفورية</span>
            <strong id="convResultVal" class="num-ltr">${fmtNum(convertedVal, converterState.to === 'EGP' ? 2 : 3)} ${converterState.to.startsWith('GOLD') || converterState.to === 'SILVER' ? 'جرام' : converterState.to}</strong>
          </div>
        </div>
      </div>

      <div class="card">
        <div class="card-header">
          <h2 class="card-title">🕌 حاسبة زكاة المال والذهب (2.5%)</h2>
          <span class="badge badge-amber">النصاب: ${fmtEgp(zakat.nisabEgp, 0, true)}</span>
        </div>
        <div class="grid-2">
          <div>
            <label class="form-label" for="zakatCashInput">المدخرات النقدية (ج.م)</label>
            <input id="zakatCashInput" class="input-field" type="text" inputmode="decimal" value="${escapeHtml(zakatState.cash)}" />
          </div>
          <div>
            <label class="form-label" for="zakatGold21Input">ذهب عيار 21 (جرام)</label>
            <input id="zakatGold21Input" class="input-field" type="text" inputmode="decimal" value="${escapeHtml(zakatState.gold21)}" />
          </div>
          <div>
            <label class="form-label" for="zakatGold24Input">ذهب عيار 24 (جرام)</label>
            <input id="zakatGold24Input" class="input-field" type="text" inputmode="decimal" value="${escapeHtml(zakatState.gold24)}" />
          </div>
          <div>
            <label class="form-label" for="zakatSilverInput">فضة (جرام)</label>
            <input id="zakatSilverInput" class="input-field" type="text" inputmode="decimal" value="${escapeHtml(zakatState.silver)}" />
          </div>
        </div>
        <div id="zakatResultBox" class="converter-result" style="margin-top:10px;border-color:${zakat.eligible ? 'rgba(16,185,129,0.45)' : 'var(--border)'}">
          <span style="font-size:0.78rem;color:var(--text-muted)">إجمالي الوعاء الزكوي: ${fmtEgp(zakat.totalWealth, 0, true)}</span>
          <strong style="color:${zakat.eligible ? 'var(--emerald-text)' : 'var(--text-muted)'}">
            ${zakat.eligible ? `الزكاة المستحقة: ${fmtNum(zakat.zakatDue, 0)} ج.م` : 'أقل من النصاب الشرعي (85 جم عيار 24)'}
          </strong>
        </div>
      </div>

      <div class="card">
        <div class="card-header">
          <h2 class="card-title">🍕 حاسبة تقسيم الخروجات</h2>
        </div>
        <div class="grid-2" style="margin-bottom:8px">
          <div>
            <label class="form-label" for="splitTotalInput">إجمالي الفاتورة (ج.م)</label>
            <input id="splitTotalInput" class="input-field" type="text" inputmode="decimal" value="${escapeHtml(splitState.total)}" />
          </div>
          <div>
            <label class="form-label" for="splitFriendsInput">عدد الأفراد</label>
            <input id="splitFriendsInput" class="input-field" type="text" inputmode="numeric" value="${escapeHtml(splitState.friends)}" />
          </div>
          <div>
            <label class="form-label" for="splitTipInput">الخدمة / البقشيش (%)</label>
            <input id="splitTipInput" class="input-field" type="text" inputmode="decimal" value="${escapeHtml(splitState.tipPct)}" />
          </div>
          <div>
            <label class="form-label" for="splitWalletSelect">المحفظة للدفع</label>
            <select id="splitWalletSelect" class="select-field">
              ${appState.wallets.map((w) => `<option value="${w.id}" ${splitState.walletId === w.id ? 'selected' : ''}>${w.icon || '💳'} ${escapeHtml(w.name)}</option>`).join('')}
            </select>
          </div>
        </div>
        <input id="splitNoteInput" class="input-field" type="text" placeholder="ملاحظة الخروجة" value="${escapeHtml(splitState.note)}" style="margin-bottom:8px" />
        <div class="converter-result" style="margin-bottom:10px">
          <span id="splitGrandMeta" style="font-size:0.76rem;color:var(--text-muted)">حصة الفرد الواحد (من إجمالي ${fmtNum(split.grandTotal, 0)} ج.م)</span>
          <strong id="splitShareVal" class="num-ltr">${fmtNum(split.perPerson, 2)} ج.م</strong>
        </div>
        <button id="logSplitShareBtn" class="btn-primary" type="button">تسجيل حصتي كمصروف الآن ✓</button>
      </div>
    `;
  }

  // 6. Dedicated Full Settings Screen (⚙️)
  function renderSettings() {
    const container = document.getElementById('tab-settings');
    if (!container) return;

    const customCats = appState.customCategories || [];
    const templates = appState.quickTemplates || [];

    container.innerHTML = `
      <div class="card">
        <div class="card-header">
          <h2 class="card-title">👛 إدارة المحافظ والعملات</h2>
          <button id="addWalletBtn" class="link-btn" type="button">+ محفظة جديدة</button>
        </div>
        <div class="tx-list">
          ${appState.wallets.map((w) => `
            <div class="tx-item">
              <div class="tx-main">
                <div class="tx-icon" style="background:var(--emerald-soft)">${w.icon || '💳'}</div>
                <div class="tx-info">
                  <div class="tx-title">${escapeHtml(w.name)}</div>
                  <div class="tx-meta">${escapeHtml(WALLET_TYPE_LABELS[w.type] || w.type)} • ${escapeHtml(w.currency)}</div>
                </div>
              </div>
              <div class="tx-right">
                <div class="tx-amount income">${fmtCurrency(w.balance, w.currency, w.currency === 'EGP' ? 0 : 2)}</div>
                <div class="tx-actions">
                  <button class="mini-action-btn" data-edit-wallet="${w.id}" type="button">تعديل</button>
                  ${appState.wallets.length > 1 ? `<button class="mini-action-btn danger" data-del-wallet="${w.id}" type="button">حذف</button>` : ''}
                </div>
              </div>
            </div>
          `).join('')}
        </div>
      </div>

      <div class="card">
        <div class="card-header">
          <h2 class="card-title">🏷️ التصنيفات المخصصة</h2>
          <button id="addCustomCatBtn" class="link-btn" type="button">+ تصنيف جديد</button>
        </div>
        <div class="tx-list">
          ${customCats.length ? customCats.map((c) => `
            <div class="tx-item">
              <div class="tx-main">
                <div class="tx-icon" style="background:${c.color}25">${c.icon}</div>
                <div class="tx-info">
                  <div class="tx-title">${escapeHtml(c.name)}</div>
                  <div class="tx-meta">${c.type === 'income' ? 'دخل' : 'مصروف'}</div>
                </div>
              </div>
              <button class="mini-action-btn danger" data-del-custom-cat="${c.id}" type="button">حذف</button>
            </div>
          `).join('') : '<div class="empty-state" style="padding:10px">يمكنك إضافة تصنيفاتك الخاصة بأيقونة ولون مميز.</div>'}
        </div>
      </div>

      <div class="card">
        <div class="card-header">
          <h2 class="card-title">⚡ قوالب التسجيل السريع (ضغطة واحدة)</h2>
          <button id="addTemplateBtn" class="link-btn" type="button">+ قالب جديد</button>
        </div>
        <div class="tx-list">
          ${templates.map((t) => `
            <div class="tx-item">
              <div class="tx-main">
                <div class="tx-icon" style="background:var(--emerald-soft)">${t.icon || '⚡'}</div>
                <div class="tx-info">
                  <div class="tx-title">${escapeHtml(t.title)}</div>
                  <div class="tx-meta">${escapeHtml(getCategory(t.categoryId).name)}</div>
                </div>
              </div>
              <div class="tx-right">
                <div class="tx-amount expense">${fmtEgp(t.amount, 0, true)}</div>
                <button class="mini-action-btn danger" data-del-template="${t.id}" type="button">حذف</button>
              </div>
            </div>
          `).join('')}
        </div>
      </div>

      <div class="card">
        <div class="card-header">
          <h2 class="card-title">🔒 الأمان والمظهر</h2>
        </div>
        <div class="settings-row">
          <div>
            <strong>الوضع الليلي / النهاري</strong>
            <div class="card-subtitle">${appState.settings.theme === 'dark' ? 'الوضع الليلي الداكن مفعّل' : 'الوضع النهاري الفاتح مفعّل'}</div>
          </div>
          <button id="settingsThemeSwitch" class="toggle-switch ${appState.settings.theme === 'dark' ? 'on' : ''}" type="button" aria-label="تبديل الثيم"></button>
        </div>
        <div class="settings-row">
          <div>
            <strong>وضع الخصوصية (إخفاء الأرقام)</strong>
            <div class="card-subtitle">استبدال المبالغ بعلامة ••••</div>
          </div>
          <button id="settingsPrivacySwitch" class="toggle-switch ${appState.settings.privacyMode ? 'on' : ''}" type="button" aria-label="تبديل وضع الخصوصية"></button>
        </div>
        <div class="settings-row">
          <div>
            <strong>قفل التطبيق برمز PIN (4 أرقام)</strong>
            <div class="card-subtitle">${appState.settings.pinCode ? 'مفعّل لحماية بياناتك' : 'غير مفعّل'}</div>
          </div>
          <button id="setupPinBtn" class="mini-action-btn ${appState.settings.pinCode ? 'danger' : 'emerald'}" type="button">
            ${appState.settings.pinCode ? 'إلغاء القفل' : 'تفعيل PIN'}
          </button>
        </div>
      </div>

      <div class="card">
        <div class="card-header">
          <h2 class="card-title">🤖 مفاتيح AI الاحتياطية (اختياري)</h2>
        </div>
        <span class="card-subtitle" style="display:block;margin-bottom:8px">تعمل محلياً من جهازك كخط احتياطي رابع إذا انتهت الباقة اليومية للسيرفر المشترك.</span>
        <div style="display:flex;flex-direction:column;gap:8px">
          <div>
            <label class="form-label" for="geminiKeyInput">مفتاح Gemini API</label>
            <input id="geminiKeyInput" class="input-field" type="password" placeholder="AIzaSy..." value="${escapeHtml(appState.settings.geminiApiKey || '')}" />
          </div>
          <div>
            <label class="form-label" for="groqKeyInput">مفتاح Groq API</label>
            <input id="groqKeyInput" class="input-field" type="password" placeholder="gsk_..." value="${escapeHtml(appState.settings.groqApiKey || '')}" />
          </div>
          <button id="saveApiKeysBtn" class="btn-secondary" type="button">حفظ المفاتيح محلياً ✓</button>
        </div>
      </div>

      <div class="card">
        <div class="card-header">
          <h2 class="card-title">📦 النسخ الاحتياطي والتقارير</h2>
        </div>
        <div style="display:flex;flex-direction:column;gap:8px">
          <button id="openStatementBtn" class="btn-primary" type="button">🖨️ كشف الحساب الشهري للطباعة</button>
          <button id="exportJsonBtn" class="btn-secondary" type="button">💾 تصدير نسخة احتياطية (JSON)</button>
          <button id="importJsonBtn" class="btn-secondary" type="button">📂 استيراد نسخة احتياطية (JSON)</button>
          <button id="exportCsvBtn" class="btn-secondary" type="button">📊 تصدير المعاملات إلى Excel (CSV)</button>
          <button id="resetAllBtn" class="btn-danger" type="button">🗑️ بدء من الصفر (مسح البيانات التجريبية)</button>
        </div>
      </div>

      <div class="card dev-signature-card">
        <div class="card-header">
          <h2 class="card-title">✨ بصمة المطور</h2>
          <span class="badge badge-amber">QR ECC-H</span>
        </div>

        <div class="dev-identity-row">
          <div class="dev-monogram-avatar" aria-hidden="true">B</div>
          <div style="min-width:0;flex:1">
            <h3 class="dev-name">${escapeHtml(DEV_PROFILE.nameAr)}</h3>
            <div class="dev-subtitle">${escapeHtml(DEV_PROFILE.roleAr)}</div>
          </div>
        </div>

        <div class="qr-showcase">
          <div class="qr-mode-toggle" role="group" aria-label="وضع رمز الاستجابة السريع">
            <button class="qr-mode-btn ${devQrMode === 'vcard' ? 'active' : ''}" data-qr-mode="vcard" type="button">بطاقة اتصال (vCard)</button>
            <button class="qr-mode-btn ${devQrMode === 'whatsapp' ? 'active' : ''}" data-qr-mode="whatsapp" type="button">رابط واتساب مباشر</button>
          </div>

          <div class="qr-canvas-frame">
            <canvas id="devQrCanvas" class="qr-canvas" width="640" height="640" aria-label="باركود التواصل مع المطور بلال محمد سليمان"></canvas>
          </div>

          <div id="devQrCaption" class="qr-caption">
            ${devQrMode === 'whatsapp'
              ? 'امسح الكود لفتح محادثة واتساب مباشرة مع المطور'
              : 'امسح الكود لحفظ بطاقة اتصال بلال محمد سليمان (vCard)'}
          </div>

          <button id="downloadDevQrBtn" class="btn-secondary" type="button">⬇️ تحميل الباركود (PNG)</button>
        </div>

        <div class="dev-actions-grid">
          <button id="devWhatsappBtn" class="dev-action-btn whatsapp" type="button">💬 تواصل واتساب</button>
          <button id="devGithubBtn" class="dev-action-btn github" type="button">💻 حساب GitHub</button>
          <button id="copyDevContactBtn" class="dev-action-btn" type="button">📋 نسخ بيانات التواصل</button>
          <button id="downloadDevVcfBtn" class="dev-action-btn gold" type="button">📇 حفظ vCard (.vcf)</button>
        </div>

        <div class="api-guide-box">
          <button id="toggleApiGuideBtn" class="api-guide-toggle" type="button" aria-expanded="${devApiGuideOpen ? 'true' : 'false'}">
            <span>📘 دليل إعداد مفاتيح API الخاصة (اختياري)</span>
            <span id="apiGuideChevron">${devApiGuideOpen ? '▲' : '▼'}</span>
          </button>
          <div id="apiGuideContent" class="api-guide-content" style="display:${devApiGuideOpen ? 'flex' : 'none'}">
            <div class="api-guide-step">
              <strong>1. متى تحتاج المفتاح الشخصي؟</strong>
              المستشار الذكي يعمل مجاناً بشكل افتراضي عبر السيرفر السحابي. يمكنك إضافة مفتاحك الخاص كخيار إضافي احتياطي إذا انتهت الحصة اليومية المشتركة.
            </div>
            <div class="api-guide-step">
              <strong>2. الحصول على مفتاح Gemini API مجاناً:</strong>
              افتح <button class="api-guide-link" data-ext-url="https://aistudio.google.com/apikey" type="button">aistudio.google.com/apikey</button> وسجل بحساب Google، ثم اضغط <b>Create API Key</b> وانسخ المفتاح (يبدأ بـ <span class="num-ltr">AIzaSy...</span>).
            </div>
            <div class="api-guide-step">
              <strong>3. أو الحصول على مفتاح Groq API مجاناً:</strong>
              افتح <button class="api-guide-link" data-ext-url="https://console.groq.com/keys" type="button">console.groq.com/keys</button>، أنشئ حساباً مجانياً ثم اختر <b>Create API Key</b> وانسخ المفتاح (يبدأ بـ <span class="num-ltr">gsk_...</span>).
            </div>
            <div class="api-guide-step">
              <strong>4. التفعيل الآمن داخل مصروفي:</strong>
              الصق المفتاح في خانة <b>"مفاتيح AI الاحتياطية"</b> بالأعلى واضغط <b>"حفظ المفاتيح محلياً ✓"</b>. تُحفظ المفاتيح على جهازك فقط داخل <span class="num-ltr">localStorage</span>.
            </div>
          </div>
        </div>
      </div>
    `;
    renderDeveloperQrCanvas();
  }

  const TAB_RENDERERS = {
    dashboard: renderDashboard,
    transactions: renderTransactions,
    budgets: renderBudgets,
    advisor: renderAdvisor,
    rates: renderRates,
    settings: renderSettings
  };

  function safeRender(containerId, renderFn) {
    const container = document.getElementById(containerId);
    if (!container) return;
    try {
      renderFn();
    } catch (_) {
      if (containerId === 'tab-advisor' && activeAdvisorChatId) {
        activeAdvisorChatId = null;
        applyThemeAndChrome();
      }
      container.innerHTML = `
        <div class="error-boundary-card" role="alert">
          <div style="font-size:2rem">🛡️</div>
          <strong style="font-size:0.95rem">حدث خطأ غير متوقع — اضغط لإعادة المحاولة</strong>
          <span class="card-subtitle">بياناتك محفوظة بأمان على جهازك ولم تتأثر.</span>
          <button class="btn-primary" style="max-width:220px" data-retry-render="${containerId}" type="button">إعادة المحاولة ↻</button>
        </div>
      `;
    }
  }

  function renderTabIfActive(tabId) {
    const fn = TAB_RENDERERS[tabId];
    if (!fn) return;
    dirtyTabs.delete(tabId);
    safeRender(`tab-${tabId}`, fn);
  }

  function renderAll() {
    applyThemeAndChrome();
    renderPinLock();
    Object.keys(TAB_RENDERERS).forEach((t) => dirtyTabs.add(t));
    renderTabIfActive(activeTab);
  }

  // Modal Helper & All Sheets
  function openModal(html) {
    const backdrop = document.getElementById('modalBackdrop');
    const sheet = document.getElementById('modalSheet');
    if (!backdrop || !sheet) return;
    try {
      sheet.innerHTML = html;
      backdrop.classList.add('open');
      modalOpen = true;
    } catch (_) {
      sheet.innerHTML = `
        <div class="error-boundary-card">
          <strong>حدث خطأ غير متوقع — اضغط لإعادة المحاولة</strong>
          <button class="btn-secondary" data-close-modal type="button">إغلاق</button>
        </div>
      `;
      backdrop.classList.add('open');
      modalOpen = true;
    }
  }

  function closeModal() {
    const backdrop = document.getElementById('modalBackdrop');
    if (!backdrop) return;
    backdrop.classList.remove('open');
    modalOpen = false;
  }

  function openTransactionModal(existingTx = null) {
    let type = existingTx ? existingTx.type : 'expense';
    let selectedCategoryId = existingTx ? existingTx.categoryId : 'food';
    let showSmsParser = false;

    function drawSheet() {
      const availableCats = getAllCategories().filter((c) => c.type === type || c.type === 'both');
      if (type !== 'transfer' && !availableCats.some((c) => c.id === selectedCategoryId)) {
        selectedCategoryId = availableCats[0]?.id || 'other';
      }
      const defaultWallet = existingTx?.walletId || appState.wallets[0]?.id || '';
      const defaultToWallet = existingTx?.toWalletId || appState.wallets[1]?.id || appState.wallets[0]?.id || '';

      openModal(`
        <div class="sheet-header">
          <h3>${existingTx ? 'تعديل المعاملة' : 'تسجيل معاملة جديدة'}</h3>
          <button class="close-sheet-btn" data-close-modal type="button">✕</button>
        </div>

        ${!existingTx && appState.quickTemplates.length ? `
          <div>
            <span class="form-label">⚡ قوالب سريعة (ضغطة واحدة للتسجيل)</span>
            <div class="template-chips">
              ${appState.quickTemplates.map((t) => `
                <button class="template-chip" data-run-template="${t.id}" type="button">
                  ${t.icon || '⚡'} ${escapeHtml(t.title)} (${fmtNum(t.amount, 0)} ج.م)
                </button>
              `).join('')}
            </div>
          </div>
        ` : ''}

        ${!existingTx ? `
          <div>
            <button id="toggleSmsParserBtn" class="mini-action-btn" style="width:100%;padding:8px;text-align:center" type="button">
              📩 ${showSmsParser ? 'إخفاء محلل رسائل البنك / انستا باي' : 'لصق رسالة بنك / انستا باي / فودافون كاش'}
            </button>
            ${showSmsParser ? `
              <div class="sms-box" style="margin-top:8px">
                <textarea id="smsRawInput" class="textarea-field" placeholder="الصق نص رسالة الخصم أو الإيداع هنا... مثال: تم خصم 350 جنيه عبر إنستا باي لمطعم..."></textarea>
                <button id="parseSmsBtn" class="mini-action-btn emerald" style="padding:8px" type="button">تحليل وتعبئة الحقول تلقائياً ✨</button>
              </div>
            ` : ''}
          </div>
        ` : ''}

        <div class="seg-tabs">
          <button class="seg-tab ${type === 'expense' ? 'active expense' : ''}" data-modal-type="expense" type="button">مصروف</button>
          <button class="seg-tab ${type === 'income' ? 'active income' : ''}" data-modal-type="income" type="button">دخل</button>
          <button class="seg-tab ${type === 'transfer' ? 'active transfer' : ''}" data-modal-type="transfer" type="button">تحويل</button>
        </div>

        <div>
          <label class="form-label" for="txAmtInput">المبلغ</label>
          <input id="txAmtInput" class="input-field" style="font-size:1.28rem;font-weight:800;text-align:center" type="text" inputmode="decimal" placeholder="0.00" value="${existingTx ? existingTx.amount : ''}" />
        </div>

        <div class="grid-2">
          <div>
            <label class="form-label" for="txWalletSelect">${type === 'transfer' ? 'من محفظة' : 'المحفظة'}</label>
            <select id="txWalletSelect" class="select-field">
              ${appState.wallets.map((w) => `<option value="${w.id}" ${w.id === defaultWallet ? 'selected' : ''}>${w.icon || '💳'} ${escapeHtml(w.name)} (${w.currency})</option>`).join('')}
            </select>
          </div>
          ${type === 'transfer' ? `
            <div>
              <label class="form-label" for="txToWalletSelect">إلى محفظة</label>
              <select id="txToWalletSelect" class="select-field">
                ${appState.wallets.map((w) => `<option value="${w.id}" ${w.id === defaultToWallet ? 'selected' : ''}>${w.icon || '💳'} ${escapeHtml(w.name)} (${w.currency})</option>`).join('')}
              </select>
            </div>
          ` : `
            <div>
              <label class="form-label" for="txDateInput">التاريخ</label>
              <input id="txDateInput" class="input-field" type="date" value="${existingTx ? existingTx.date : todayIso()}" />
            </div>
          `}
        </div>

        ${type === 'transfer' ? `
          <div>
            <label class="form-label" for="txDateInput">التاريخ</label>
            <input id="txDateInput" class="input-field" type="date" value="${existingTx ? existingTx.date : todayIso()}" />
          </div>
        ` : `
          <div>
            <label class="form-label">التصنيف</label>
            <div class="category-grid">
              ${availableCats.map((c) => `
                <button class="cat-chip ${c.id === selectedCategoryId ? 'active' : ''}" data-modal-cat="${c.id}" type="button">
                  <span style="font-size:1.2rem">${c.icon}</span>
                  <span>${escapeHtml(c.name)}</span>
                </button>
              `).join('')}
            </div>
          </div>
        `}

        <div>
          <label class="form-label" for="txNoteInput">ملاحظة أو وسم (#قهوة #سفر)</label>
          <input id="txNoteInput" class="input-field" type="text" placeholder="مثال: غداء مع الأصحاب #خروجة" value="${escapeHtml(existingTx ? existingTx.note : '')}" />
        </div>

        <button id="saveTxSubmitBtn" class="btn-primary" type="button">
          ${existingTx ? 'حفظ التعديلات ✓' : 'حفظ المعاملة ✓'}
        </button>
      `);

      const sheet = document.getElementById('modalSheet');
      sheet.querySelector('#toggleSmsParserBtn')?.addEventListener('click', () => {
        showSmsParser = !showSmsParser;
        drawSheet();
      });

      sheet.querySelector('#parseSmsBtn')?.addEventListener('click', () => {
        const raw = document.getElementById('smsRawInput')?.value || '';
        const parsed = parseEgyptianSms(raw);
        if (!parsed) {
          showToast('تعذر استخراج المبلغ من الرسالة — تأكد من لصق رسالة واضحة');
          return;
        }
        type = parsed.type;
        selectedCategoryId = parsed.categoryId;
        showSmsParser = false;
        drawSheet();
        document.getElementById('txAmtInput').value = parsed.amount;
        document.getElementById('txWalletSelect').value = parsed.walletId;
        document.getElementById('txNoteInput').value = parsed.note;
        showToast('تم استخراج بيانات الرسالة تلقائياً ✨');
      });

      sheet.querySelectorAll('[data-run-template]').forEach((btn) => {
        btn.addEventListener('click', () => {
          const tpl = appState.quickTemplates.find((t) => t.id === btn.getAttribute('data-run-template'));
          if (!tpl) return;
          const egpWallet = appState.wallets.find((w) => w.currency === 'EGP') || appState.wallets[0];
          const ok = saveTransactionRecord({
            type: 'expense',
            amount: tpl.amount,
            categoryId: tpl.categoryId,
            walletId: egpWallet?.id,
            date: todayIso(),
            note: tpl.title
          });
          if (ok) closeModal();
        });
      });

      sheet.querySelectorAll('[data-modal-type]').forEach((btn) => {
        btn.addEventListener('click', () => {
          type = btn.getAttribute('data-modal-type');
          drawSheet();
        });
      });
      sheet.querySelectorAll('[data-modal-cat]').forEach((btn) => {
        btn.addEventListener('click', () => {
          selectedCategoryId = btn.getAttribute('data-modal-cat');
          sheet.querySelectorAll('[data-modal-cat]').forEach((b) => b.classList.remove('active'));
          btn.classList.add('active');
        });
      });
      sheet.querySelector('#saveTxSubmitBtn')?.addEventListener('click', () => {
        const amt = document.getElementById('txAmtInput')?.value;
        const walletId = document.getElementById('txWalletSelect')?.value;
        const toWalletId = document.getElementById('txToWalletSelect')?.value || null;
        const date = document.getElementById('txDateInput')?.value || todayIso();
        const note = document.getElementById('txNoteInput')?.value || '';
        const ok = saveTransactionRecord({
          id: existingTx?.id || null,
          type, amount: amt, categoryId: selectedCategoryId, walletId, toWalletId, date, note
        });
        if (ok) closeModal();
      });
    }

    drawSheet();
  }

  function openBudgetModal(catId) {
    const cat = getCategory(catId);
    const currentLimit = Number(appState.budgets[catId]) || '';
    openModal(`
      <div class="sheet-header">
        <h3>ميزانية ${cat.icon} ${escapeHtml(cat.name)}</h3>
        <button class="close-sheet-btn" data-close-modal type="button">✕</button>
      </div>
      <div>
        <label class="form-label" for="budgetLimitInput">الحد الشهري الأقصى (ج.م) — اتركه 0 لإلغاء الحد</label>
        <input id="budgetLimitInput" class="input-field" type="text" inputmode="decimal" value="${currentLimit}" placeholder="3000" />
      </div>
      <button id="saveBudgetBtn" class="btn-primary" type="button">حفظ الميزانية ✓</button>
    `);
    document.getElementById('saveBudgetBtn')?.addEventListener('click', () => {
      const val = parseLocaleNumber(document.getElementById('budgetLimitInput')?.value, 0);
      if (val <= 0) delete appState.budgets[catId];
      else appState.budgets[catId] = val;
      saveState(appState);
      closeModal();
      showToast('تم تحديث حد الميزانية ✅');
      renderAll();
    });
  }

  function openGoalModal() {
    openModal(`
      <div class="sheet-header">
        <h3>إضافة هدف ادخار جديد</h3>
        <button class="close-sheet-btn" data-close-modal type="button">✕</button>
      </div>
      <div>
        <label class="form-label" for="goalTitleInput">اسم الهدف</label>
        <input id="goalTitleInput" class="input-field" type="text" placeholder="مثال: سبيكة ذهب، لاب توب..." />
      </div>
      <div class="grid-2">
        <div>
          <label class="form-label" for="goalTargetInput">المبلغ المطلوب (ج.م)</label>
          <input id="goalTargetInput" class="input-field" type="text" inputmode="decimal" placeholder="10000" />
        </div>
        <div>
          <label class="form-label" for="goalSavedInput">المدخر حالياً</label>
          <input id="goalSavedInput" class="input-field" type="text" inputmode="decimal" value="0" />
        </div>
      </div>
      <button id="saveGoalBtn" class="btn-primary" type="button">حفظ الهدف 🏆</button>
    `);
    document.getElementById('saveGoalBtn')?.addEventListener('click', () => {
      const title = (document.getElementById('goalTitleInput')?.value || '').trim();
      const target = parseLocaleNumber(document.getElementById('goalTargetInput')?.value, 0);
      const saved = Math.max(0, parseLocaleNumber(document.getElementById('goalSavedInput')?.value, 0));
      if (!title || target <= 0) { showToast('أدخل بيانات الهدف بشكل صحيح'); return; }
      appState.goals.unshift({ id: uid('goal'), title, target, saved, icon: '🎯' });
      saveState(appState);
      closeModal();
      showToast('تمت إضافة هدف الادخار ✅');
      renderAll();
    });
  }

  function openGoalDepositModal(goalId) {
    const goal = appState.goals.find((g) => g.id === goalId);
    if (!goal) return;
    openModal(`
      <div class="sheet-header">
        <h3>إيداع في «${escapeHtml(goal.title)}»</h3>
        <button class="close-sheet-btn" data-close-modal type="button">✕</button>
      </div>
      <div>
        <label class="form-label" for="goalDepAmt">مبلغ الإيداع (ج.م)</label>
        <input id="goalDepAmt" class="input-field" type="text" inputmode="decimal" placeholder="500" />
      </div>
      <div>
        <label class="form-label" for="goalDepWallet">خصم من محفظة (اختياري)</label>
        <select id="goalDepWallet" class="select-field">
          <option value="">إضافة للهدف فقط</option>
          ${appState.wallets.map((w) => `<option value="${w.id}">${w.icon || '💳'} ${escapeHtml(w.name)}</option>`).join('')}
        </select>
      </div>
      <button id="confirmGoalDepBtn" class="btn-primary" type="button">تأكيد الإيداع ✓</button>
    `);
    document.getElementById('confirmGoalDepBtn')?.addEventListener('click', () => {
      const amt = parseLocaleNumber(document.getElementById('goalDepAmt')?.value, 0);
      const wId = document.getElementById('goalDepWallet')?.value;
      if (amt <= 0) { showToast('أدخل مبلغاً أكبر من صفر'); return; }
      goal.saved = Number(((Number(goal.saved) || 0) + amt).toFixed(2));
      if (wId) {
        const w = getWallet(wId);
        if (w) w.balance = Number(((Number(w.balance) || 0) - safeDiv(amt, getUnitRateInEgp(w.currency), 0)).toFixed(2));
      }
      saveState(appState);
      closeModal();
      showToast('تم دعم الهدف بنجاح 🎉');
      renderAll();
    });
  }

  function openGam3eyaModal() {
    openModal(`
      <div class="sheet-header">
        <h3>إضافة جمعية جديدة (Gam3eya)</h3>
        <button class="close-sheet-btn" data-close-modal type="button">✕</button>
      </div>
      <div>
        <label class="form-label" for="gmTitleInput">اسم الجمعية</label>
        <input id="gmTitleInput" class="input-field" type="text" placeholder="مثال: جمعية العيلة" />
      </div>
      <div class="grid-2">
        <div>
          <label class="form-label" for="gmMonthlyInput">القسط الشهري (ج.م)</label>
          <input id="gmMonthlyInput" class="input-field" type="text" inputmode="decimal" placeholder="1000" />
        </div>
        <div>
          <label class="form-label" for="gmPayoutInput">مبلغ القبض الكلي</label>
          <input id="gmPayoutInput" class="input-field" type="text" inputmode="decimal" placeholder="10000" />
        </div>
        <div>
          <label class="form-label" for="gmMembersInput">عدد الأشهر</label>
          <input id="gmMembersInput" class="input-field" type="text" inputmode="numeric" value="10" />
        </div>
        <div>
          <label class="form-label" for="gmPaidInput">الأشهر المدفوعة</label>
          <input id="gmPaidInput" class="input-field" type="text" inputmode="numeric" value="0" />
        </div>
      </div>
      <div class="grid-2">
        <div>
          <label class="form-label" for="gmPayoutMonthInput">شهر القبض</label>
          <input id="gmPayoutMonthInput" class="input-field" type="text" placeholder="مثال: شهر يوليو" />
        </div>
        <div>
          <label class="form-label" for="gmWalletSelect">محفظة السداد</label>
          <select id="gmWalletSelect" class="select-field">
            ${appState.wallets.map((w) => `<option value="${w.id}">${escapeHtml(w.name)}</option>`).join('')}
          </select>
        </div>
      </div>
      <button id="saveGam3eyaBtn" class="btn-primary" type="button">حفظ الجمعية 🤝</button>
    `);
    document.getElementById('saveGam3eyaBtn')?.addEventListener('click', () => {
      const title = (document.getElementById('gmTitleInput')?.value || '').trim();
      const monthlyAmount = parseLocaleNumber(document.getElementById('gmMonthlyInput')?.value, 0);
      const totalMembers = Math.max(2, Math.round(parseLocaleNumber(document.getElementById('gmMembersInput')?.value, 10)));
      const payoutAmount = parseLocaleNumber(document.getElementById('gmPayoutInput')?.value, 0) || (monthlyAmount * totalMembers);
      const paidMonths = Math.max(0, Math.min(totalMembers, Math.round(parseLocaleNumber(document.getElementById('gmPaidInput')?.value, 0))));
      const payoutMonthLabel = (document.getElementById('gmPayoutMonthInput')?.value || '').trim() || 'غير محدد';
      const walletId = document.getElementById('gmWalletSelect')?.value || appState.wallets[0]?.id;
      if (!title || monthlyAmount <= 0) { showToast('أدخل اسم الجمعية والقسط الشهري'); return; }
      appState.gam3eyas.unshift({
        id: uid('gm'), title, monthlyAmount, payoutAmount, totalMembers, paidMonths, payoutMonthLabel, lastPaidMonth: '', walletId
      });
      saveState(appState);
      closeModal();
      showToast('تمت إضافة الجمعية ✅');
      renderAll();
    });
  }

  function openDebtModal() {
    openModal(`
      <div class="sheet-header">
        <h3>تسجيل دين أو سلفة</h3>
        <button class="close-sheet-btn" data-close-modal type="button">✕</button>
      </div>
      <div>
        <label class="form-label" for="debtPersonInput">اسم الشخص</label>
        <input id="debtPersonInput" class="input-field" type="text" placeholder="مثال: أحمد / كريم" />
      </div>
      <div class="grid-2">
        <div>
          <label class="form-label" for="debtTypeSelect">النوع</label>
          <select id="debtTypeSelect" class="select-field">
            <option value="owed_to_me">فلوس ليا بره (سلفت حد)</option>
            <option value="i_owe">فلوس عليا (استلفت)</option>
          </select>
        </div>
        <div>
          <label class="form-label" for="debtAmtInput">المبلغ (ج.م)</label>
          <input id="debtAmtInput" class="input-field" type="text" inputmode="decimal" placeholder="500" />
        </div>
      </div>
      <div>
        <label class="form-label" for="debtNoteInput">ملاحظة</label>
        <input id="debtNoteInput" class="input-field" type="text" placeholder="سبب السلفة..." />
      </div>
      <button id="saveDebtBtn" class="btn-primary" type="button">حفظ ✓</button>
    `);
    document.getElementById('saveDebtBtn')?.addEventListener('click', () => {
      const person = (document.getElementById('debtPersonInput')?.value || '').trim();
      const type = document.getElementById('debtTypeSelect')?.value || 'owed_to_me';
      const amt = parseLocaleNumber(document.getElementById('debtAmtInput')?.value, 0);
      const note = (document.getElementById('debtNoteInput')?.value || '').trim();
      if (!person || amt <= 0) { showToast('أدخل اسم الشخص والمبلغ'); return; }
      appState.debts.unshift({ id: uid('db'), person, type, totalAmount: amt, remainingAmount: amt, note, date: todayIso() });
      saveState(appState);
      closeModal();
      showToast('تم تسجيل السلفة ✅');
      renderAll();
    });
  }

  function openSettleDebtModal(debtId) {
    const debt = appState.debts.find((d) => d.id === debtId);
    if (!debt) return;
    const isOwedToMe = debt.type === 'owed_to_me';
    openModal(`
      <div class="sheet-header">
        <h3>${isOwedToMe ? `تحصيل من ${escapeHtml(debt.person)}` : `سداد لـ ${escapeHtml(debt.person)}`}</h3>
        <button class="close-sheet-btn" data-close-modal type="button">✕</button>
      </div>
      <div>
        <label class="form-label" for="settleAmtInput">المبلغ المسدد (جزئي أو كامل)</label>
        <input id="settleAmtInput" class="input-field" type="text" inputmode="decimal" value="${debt.remainingAmount}" />
      </div>
      <div>
        <label class="form-label" for="settleWalletSelect">المحفظة</label>
        <select id="settleWalletSelect" class="select-field">
          ${appState.wallets.map((w) => `<option value="${w.id}">${escapeHtml(w.name)}</option>`).join('')}
        </select>
      </div>
      <button id="confirmSettleDebtBtn" class="btn-primary" type="button">تأكيد التسوية ✓</button>
    `);
    document.getElementById('confirmSettleDebtBtn')?.addEventListener('click', () => {
      const amt = Math.min(debt.remainingAmount, Math.max(0, parseLocaleNumber(document.getElementById('settleAmtInput')?.value, 0)));
      const wId = document.getElementById('settleWalletSelect')?.value;
      if (amt <= 0) { showToast('أدخل مبلغاً صحيحاً'); return; }
      const ok = saveTransactionRecord({
        type: isOwedToMe ? 'income' : 'expense',
        amount: amt,
        categoryId: 'other',
        walletId: wId,
        date: todayIso(),
        note: `${isOwedToMe ? 'تحصيل سلفة من' : 'سداد دين لـ'} ${debt.person}`
      });
      if (ok) {
        debt.remainingAmount = Number((debt.remainingAmount - amt).toFixed(2));
        saveState(appState);
        renderAll();
        closeModal();
      }
    });
  }

  function openRecurringBillModal() {
    openModal(`
      <div class="sheet-header">
        <h3>إضافة فاتورة / اشتراك شهري</h3>
        <button class="close-sheet-btn" data-close-modal type="button">✕</button>
      </div>
      <div>
        <label class="form-label" for="billTitleInput">اسم الفاتورة / الاشتراك</label>
        <input id="billTitleInput" class="input-field" type="text" placeholder="مثال: باقة الإنترنت، إيجار، جيم..." />
      </div>
      <div class="grid-2">
        <div>
          <label class="form-label" for="billAmtInput">القيمة الشهرية (ج.م)</label>
          <input id="billAmtInput" class="input-field" type="text" inputmode="decimal" placeholder="400" />
        </div>
        <div>
          <label class="form-label" for="billDueInput">يوم الاستحقاق</label>
          <input id="billDueInput" class="input-field" type="text" inputmode="numeric" value="15" />
        </div>
      </div>
      <div>
        <label class="form-label" for="billWalletSelect">محفظة الدفع</label>
        <select id="billWalletSelect" class="select-field">
          ${appState.wallets.map((w) => `<option value="${w.id}">${escapeHtml(w.name)}</option>`).join('')}
        </select>
      </div>
      <button id="saveBillBtn" class="btn-primary" type="button">حفظ الفاتورة ✓</button>
    `);
    document.getElementById('saveBillBtn')?.addEventListener('click', () => {
      const title = (document.getElementById('billTitleInput')?.value || '').trim();
      const amount = parseLocaleNumber(document.getElementById('billAmtInput')?.value, 0);
      const dueDay = Math.min(28, Math.max(1, Math.round(parseLocaleNumber(document.getElementById('billDueInput')?.value, 1))));
      const walletId = document.getElementById('billWalletSelect')?.value || appState.wallets[0]?.id;
      if (!title || amount <= 0) { showToast('أدخل الاسم والقيمة'); return; }
      appState.recurringBills.unshift({ id: uid('rb'), title, amount, dueDay, categoryId: 'bills', walletId, lastPaidMonth: '' });
      saveState(appState);
      closeModal();
      showToast('تمت إضافة الفاتورة الثابتة ✅');
      renderAll();
    });
  }

  function openWalletModal(existingWallet = null) {
    openModal(`
      <div class="sheet-header">
        <h3>${existingWallet ? 'تعديل المحفظة' : 'إضافة محفظة جديدة'}</h3>
        <button class="close-sheet-btn" data-close-modal type="button">✕</button>
      </div>
      <div>
        <label class="form-label" for="walletNameInput">اسم المحفظة / الحساب</label>
        <input id="walletNameInput" class="input-field" type="text" placeholder="مثال: حساب CIB دولار" value="${escapeHtml(existingWallet?.name || '')}" />
      </div>
      <div class="grid-2">
        <div>
          <label class="form-label" for="walletTypeSelect">النوع</label>
          <select id="walletTypeSelect" class="select-field">
            <option value="cash" ${existingWallet?.type === 'cash' ? 'selected' : ''}>كاش / المحفظة</option>
            <option value="bank" ${existingWallet?.type === 'bank' ? 'selected' : ''}>حساب بنكي / انستا باي</option>
            <option value="mobile" ${existingWallet?.type === 'mobile' ? 'selected' : ''}>محفظة إلكترونية</option>
            <option value="credit" ${existingWallet?.type === 'credit' ? 'selected' : ''}>كارت مشتريات</option>
          </select>
        </div>
        <div>
          <label class="form-label" for="walletCurrencySelect">العملة</label>
          <select id="walletCurrencySelect" class="select-field">
            <option value="EGP" ${existingWallet?.currency === 'EGP' ? 'selected' : ''}>EGP (جنيه مصري)</option>
            <option value="USD" ${existingWallet?.currency === 'USD' ? 'selected' : ''}>USD (دولار)</option>
            <option value="SAR" ${existingWallet?.currency === 'SAR' ? 'selected' : ''}>SAR (ريال سعودي)</option>
            <option value="EUR" ${existingWallet?.currency === 'EUR' ? 'selected' : ''}>EUR (يورو)</option>
          </select>
        </div>
      </div>
      <div>
        <label class="form-label" for="walletBalInput">الرصيد الحالي</label>
        <input id="walletBalInput" class="input-field" type="text" inputmode="decimal" value="${existingWallet ? existingWallet.balance : 0}" />
      </div>
      <button id="saveWalletBtn" class="btn-primary" type="button">حفظ المحفظة ✓</button>
    `);

    document.getElementById('saveWalletBtn')?.addEventListener('click', () => {
      const name = (document.getElementById('walletNameInput')?.value || '').trim();
      const type = document.getElementById('walletTypeSelect')?.value || 'cash';
      const currency = document.getElementById('walletCurrencySelect')?.value || 'EGP';
      const balance = parseLocaleNumber(document.getElementById('walletBalInput')?.value, 0);
      const icons = { cash: '💵', bank: '🏦', mobile: '📲', credit: '💳' };
      if (!name) { showToast('أدخل اسم المحفظة'); return; }
      if (existingWallet) {
        existingWallet.name = name;
        existingWallet.type = type;
        existingWallet.currency = currency;
        existingWallet.balance = balance;
        existingWallet.icon = currency === 'USD' ? '💲' : (icons[type] || '💳');
      } else {
        appState.wallets.push({ id: uid('w'), name, type, currency, balance, icon: currency === 'USD' ? '💲' : (icons[type] || '💳') });
      }
      saveState(appState);
      closeModal();
      showToast('تم حفظ المحفظة ✅');
      renderAll();
    });
  }

  function openCustomCategoryModal() {
    const emojis = ['🏠', '🐾', '🎁', '🎮', '✈️', '🧴', '👶', '🔧'];
    const colors = ['#10B981', '#F59E0B', '#38BDF8', '#8B5CF6', '#EC4899', '#EF4444'];
    let pickedEmoji = emojis[0];
    let pickedColor = colors[0];

    openModal(`
      <div class="sheet-header">
        <h3>إضافة تصنيف مخصص</h3>
        <button class="close-sheet-btn" data-close-modal type="button">✕</button>
      </div>
      <div>
        <label class="form-label" for="catNameInput">اسم التصنيف</label>
        <input id="catNameInput" class="input-field" type="text" placeholder="مثال: صيانة السيارة، هدايا..." />
      </div>
      <div>
        <label class="form-label" for="catTypeSelect">النوع</label>
        <select id="catTypeSelect" class="select-field">
          <option value="expense">مصروف</option>
          <option value="income">دخل</option>
        </select>
      </div>
      <div>
        <label class="form-label">اختر أيقونة</label>
        <div class="filter-pills">
          ${emojis.map((em, idx) => `<button class="pill-btn ${idx === 0 ? 'active' : ''}" data-pick-emoji="${em}" type="button" style="font-size:1.1rem">${em}</button>`).join('')}
        </div>
      </div>
      <div>
        <label class="form-label">اختر اللون</label>
        <div class="filter-pills">
          ${colors.map((cl, idx) => `<button class="pill-btn ${idx === 0 ? 'active' : ''}" data-pick-color="${cl}" type="button" style="width:36px;background:${cl};border-color:${idx === 0 ? '#fff' : cl}"> </button>`).join('')}
        </div>
      </div>
      <button id="saveCustomCatBtn" class="btn-primary" type="button">حفظ التصنيف ✓</button>
    `);

    const sheet = document.getElementById('modalSheet');
    sheet.querySelectorAll('[data-pick-emoji]').forEach((b) => {
      b.addEventListener('click', () => {
        pickedEmoji = b.getAttribute('data-pick-emoji');
        sheet.querySelectorAll('[data-pick-emoji]').forEach((x) => x.classList.remove('active'));
        b.classList.add('active');
      });
    });
    sheet.querySelectorAll('[data-pick-color]').forEach((b) => {
      b.addEventListener('click', () => {
        pickedColor = b.getAttribute('data-pick-color');
        sheet.querySelectorAll('[data-pick-color]').forEach((x) => x.classList.remove('active'));
        b.classList.add('active');
      });
    });
    sheet.querySelector('#saveCustomCatBtn')?.addEventListener('click', () => {
      const name = (document.getElementById('catNameInput')?.value || '').trim();
      const type = document.getElementById('catTypeSelect')?.value || 'expense';
      if (!name) { showToast('أدخل اسم التصنيف'); return; }
      appState.customCategories.push({ id: uid('cat'), name, icon: pickedEmoji, color: pickedColor, type });
      saveState(appState);
      closeModal();
      showToast('تمت إضافة التصنيف المخصص ✅');
      renderAll();
    });
  }

  function openAddTemplateModal() {
    const expCats = getAllCategories().filter((c) => c.type === 'expense' || c.type === 'both');
    openModal(`
      <div class="sheet-header">
        <h3>إضافة قالب مصروف سريع</h3>
        <button class="close-sheet-btn" data-close-modal type="button">✕</button>
      </div>
      <div>
        <label class="form-label" for="tplTitleInput">الاسم</label>
        <input id="tplTitleInput" class="input-field" type="text" placeholder="مثال: قهوة الصبح" />
      </div>
      <div class="grid-2">
        <div>
          <label class="form-label" for="tplAmtInput">المبلغ (ج.م)</label>
          <input id="tplAmtInput" class="input-field" type="text" inputmode="decimal" placeholder="45" />
        </div>
        <div>
          <label class="form-label" for="tplCatSelect">التصنيف</label>
          <select id="tplCatSelect" class="select-field">
            ${expCats.map((c) => `<option value="${c.id}">${c.icon} ${escapeHtml(c.name)}</option>`).join('')}
          </select>
        </div>
      </div>
      <button id="saveTplBtn" class="btn-primary" type="button">حفظ القالب ⚡</button>
    `);
    document.getElementById('saveTplBtn')?.addEventListener('click', () => {
      const title = (document.getElementById('tplTitleInput')?.value || '').trim();
      const amount = parseLocaleNumber(document.getElementById('tplAmtInput')?.value, 0);
      const categoryId = document.getElementById('tplCatSelect')?.value || 'other';
      const icon = getCategory(categoryId).icon;
      if (!title || amount <= 0) { showToast('أدخل اسم ومبلغ القالب'); return; }
      appState.quickTemplates.push({ id: uid('tpl'), title, amount, categoryId, icon });
      saveState(appState);
      closeModal();
      showToast('تمت إضافة القالب السريع ⚡');
      renderAll();
    });
  }

  function openPinSetupModal() {
    if (appState.settings.pinCode) {
      openModal(`
        <div class="sheet-header">
          <h3>إلغاء رمز الحماية PIN</h3>
          <button class="close-sheet-btn" data-close-modal type="button">✕</button>
        </div>
        <p style="margin:0;font-size:0.86rem;color:var(--text-muted)">هل تريد إيقاف طلب رمز PIN عند فتح التطبيق؟</p>
        <div class="grid-2">
          <button class="btn-secondary" data-close-modal type="button">إبقاء القفل</button>
          <button id="disablePinConfirmBtn" class="btn-danger" type="button">إلغاء القفل</button>
        </div>
      `);
      document.getElementById('disablePinConfirmBtn')?.addEventListener('click', () => {
        appState.settings.pinCode = '';
        saveState(appState);
        closeModal();
        showToast('تم إلغاء رمز PIN');
        renderAll();
      });
      return;
    }

    openModal(`
      <div class="sheet-header">
        <h3>تعيين رمز حماية (4 أرقام)</h3>
        <button class="close-sheet-btn" data-close-modal type="button">✕</button>
      </div>
      <div>
        <label class="form-label" for="newPinInput">أدخل 4 أرقام</label>
        <input id="newPinInput" class="input-field" style="text-align:center;font-size:1.3rem;letter-spacing:8px" type="password" maxlength="4" inputmode="numeric" placeholder="••••" />
      </div>
      <button id="savePinBtn" class="btn-primary" type="button">تفعيل القفل 🔒</button>
    `);
    document.getElementById('savePinBtn')?.addEventListener('click', () => {
      const pin = normalizeArabicDigits(document.getElementById('newPinInput')?.value || '').trim();
      if (!/^\d{4}$/.test(pin)) {
        showToast('يجب إدخال 4 أرقام صحيحة');
        return;
      }
      appState.settings.pinCode = pin;
      saveState(appState);
      closeModal();
      showToast('تم تفعيل قفل التطبيق برمز PIN 🔒');
      renderAll();
    });
  }

  function openApiKeyQuickModal() {
    openModal(`
      <div class="sheet-header">
        <h3>مفاتيح الذكاء الاصطناعي الاحتياطية</h3>
        <button class="close-sheet-btn" data-close-modal type="button">✕</button>
      </div>
      <div>
        <label class="form-label" for="modalGeminiKey">Gemini API Key</label>
        <input id="modalGeminiKey" class="input-field" type="password" placeholder="AIzaSy..." value="${escapeHtml(appState.settings.geminiApiKey || '')}" />
      </div>
      <div>
        <label class="form-label" for="modalGroqKey">Groq API Key</label>
        <input id="modalGroqKey" class="input-field" type="password" placeholder="gsk_..." value="${escapeHtml(appState.settings.groqApiKey || '')}" />
      </div>
      <button id="modalSaveKeysBtn" class="btn-primary" type="button">حفظ المفتاح الآن ✓</button>
    `);
    document.getElementById('modalSaveKeysBtn')?.addEventListener('click', () => {
      appState.settings.geminiApiKey = (document.getElementById('modalGeminiKey')?.value || '').trim();
      appState.settings.groqApiKey = (document.getElementById('modalGroqKey')?.value || '').trim();
      saveState(appState);
      aiQuotaBannerVisible = false;
      closeModal();
      showToast('تم حفظ المفتاح محلياً بنجاح ✅');
      renderAll();
    });
  }

  function openPrintableStatementModal() {
    const m = computeDashboardMetrics();
    const monthTxs = getMonthTransactions(currentMonthKey());

    const statementHtml = `
      <h2 style="margin:0 0 4px">كشف الحساب الشهري — مصروفي (${currentMonthKey()})</h2>
      <p style="margin:0 0 10px;font-size:12px;color:#475569">تاريخ الإصدار: ${todayIso()}</p>
      <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-bottom:12px">
        <div style="border:1px solid #CBD5E1;padding:8px;border-radius:8px"><strong>الدخل:</strong> ${fmtNum(m.monthIncome, 0)} ج.م</div>
        <div style="border:1px solid #CBD5E1;padding:8px;border-radius:8px"><strong>المصروفات:</strong> ${fmtNum(m.monthExpense, 0)} ج.م</div>
        <div style="border:1px solid #CBD5E1;padding:8px;border-radius:8px"><strong>الصافي:</strong> ${fmtNum(m.netSurplus, 0)} ج.م</div>
      </div>
      <table class="print-table">
        <thead>
          <tr><th>التاريخ</th><th>النوع</th><th>الفئة</th><th>المحفظة</th><th>المبلغ</th><th>ملاحظة</th></tr>
        </thead>
        <tbody>
          ${monthTxs.map((tx) => {
            const w = getWallet(tx.walletId);
            const tLabel = tx.type === 'income' ? 'دخل' : tx.type === 'expense' ? 'مصروف' : 'تحويل';
            return `<tr><td>${tx.date}</td><td>${tLabel}</td><td>${escapeHtml(getCategory(tx.categoryId).name)}</td><td>${escapeHtml(w?.name || '')}</td><td>${fmtNum(tx.amount, 0)} ${w?.currency || 'EGP'}</td><td>${escapeHtml(tx.note || '')}</td></tr>`;
          }).join('')}
        </tbody>
      </table>
    `;

    const printRoot = document.getElementById('printRoot');
    if (printRoot) printRoot.innerHTML = statementHtml;

    openModal(`
      <div class="sheet-header">
        <h3>🖨️ كشف الحساب الشهري (${currentMonthKey()})</h3>
        <button class="close-sheet-btn" data-close-modal type="button">✕</button>
      </div>
      <div class="grid-2">
        <div class="budget-item"><span class="card-subtitle">دخل الشهر</span><strong style="color:var(--emerald)">${fmtEgp(m.monthIncome, 0, true)}</strong></div>
        <div class="budget-item"><span class="card-subtitle">مصاريف الشهر</span><strong style="color:var(--red)">${fmtEgp(m.monthExpense, 0, true)}</strong></div>
      </div>
      <div class="budget-item">
        <div class="budget-top"><span>صافي الشهر</span><strong>${fmtEgp(m.netSurplus, 0, true)}</strong></div>
        <div class="budget-top"><span>عدد المعاملات</span><strong class="num-ltr">${monthTxs.length}</strong></div>
      </div>
      <button id="triggerPrintBtn" class="btn-primary" type="button">طباعة / حفظ كملف PDF 🖨️</button>
    `);

    document.getElementById('triggerPrintBtn')?.addEventListener('click', () => {
      if (window.MasroufyAndroidBridge && typeof window.MasroufyAndroidBridge.printDocument === 'function') {
        window.MasroufyAndroidBridge.printDocument(`Masroufy-Statement-${currentMonthKey()}`);
      } else {
        window.print();
      }
    });
  }

  function openResetConfirmModal() {
    openModal(`
      <div class="sheet-header">
        <h3 style="color:var(--red)">بدء من الصفر (مسح البيانات)</h3>
        <button class="close-sheet-btn" data-close-modal type="button">✕</button>
      </div>
      <p style="margin:0;font-size:0.86rem;color:var(--text-muted)">
        سيتم مسح جميع المعاملات والميزانيات والأهداف والجمعيات والديون وسجل المستشار، وتصفير المحافظ لتبدأ حسابك الشخصي من الصفر.
      </p>
      <div class="grid-2">
        <button class="btn-secondary" data-close-modal type="button">إلغاء</button>
        <button id="confirmResetBtn" class="btn-danger" type="button">تأكيد المسح</button>
      </div>
    `);
    document.getElementById('confirmResetBtn')?.addEventListener('click', () => {
      appState = createEmptyZeroState(appState.settings);
      aiChats = {};
      saveState(appState);
      saveAiChats(aiChats);
      closeModal();
      showToast('تم تصفير البيانات بنجاح — يمكنك البدء الآن');
      renderAll();
    });
  }

  // Export Helpers
  function downloadTextFile(filename, mimeType, content) {
    if (window.MasroufyAndroidBridge && typeof window.MasroufyAndroidBridge.exportFile === 'function') {
      try { window.MasroufyAndroidBridge.exportFile(filename, mimeType, content); return; } catch (_) {}
    }
    const blob = new Blob([content], { type: mimeType });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }

  function downloadDataUrlFile(filename, mimeType, dataUrl) {
    if (window.MasroufyAndroidBridge && typeof window.MasroufyAndroidBridge.exportBase64File === 'function') {
      try {
        window.MasroufyAndroidBridge.exportBase64File(filename, mimeType, dataUrl);
        return;
      } catch (_) {}
    }
    const a = document.createElement('a');
    a.href = dataUrl;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    a.remove();
  }

  function openExternalLink(url) {
    if (!url) return;
    if (window.MasroufyAndroidBridge && typeof window.MasroufyAndroidBridge.openExternalUrl === 'function') {
      try { window.MasroufyAndroidBridge.openExternalUrl(url); return; } catch (_) {}
    }
    window.open(url, '_blank', 'noopener,noreferrer');
  }

  function copyTextToClipboard(text) {
    if (navigator.clipboard && typeof navigator.clipboard.writeText === 'function') {
      return navigator.clipboard.writeText(text).catch(() => fallbackCopy(text));
    }
    fallbackCopy(text);
    return Promise.resolve();
  }

  function fallbackCopy(text) {
    const ta = document.createElement('textarea');
    ta.value = text;
    ta.setAttribute('readonly', '');
    ta.style.position = 'fixed';
    ta.style.opacity = '0';
    document.body.appendChild(ta);
    ta.select();
    try { document.execCommand('copy'); } catch (_) {}
    ta.remove();
  }

  function exportJsonBackup() {
    const payload = { app: 'Masroufy', exportedAt: new Date().toISOString(), state: appState, aiChats };
    downloadTextFile(`masroufy-backup-${todayIso()}.json`, 'application/json;charset=utf-8', JSON.stringify(payload, null, 2));
    showToast('تم تجهيز ملف النسخة الاحتياطية JSON ✅');
  }

  function exportTransactionsCsv() {
    const header = ['التاريخ', 'النوع', 'المبلغ', 'العملة', 'الفئة', 'المحفظة', 'إلى محفظة', 'الملاحظة'];
    const rows = appState.transactions.map((tx) => {
      const typeAr = tx.type === 'expense' ? 'مصروف' : tx.type === 'income' ? 'دخل' : 'تحويل';
      const w = getWallet(tx.walletId);
      const toW = tx.toWalletId ? getWallet(tx.toWalletId) : null;
      return [tx.date, typeAr, tx.amount, w?.currency || 'EGP', tx.type === 'transfer' ? 'تحويل' : getCategory(tx.categoryId).name, w?.name || '', toW?.name || '', tx.note || '']
        .map((cell) => `"${String(cell).replace(/"/g, '""')}"`).join(',');
    });
    const csv = '\uFEFF' + [header.join(','), ...rows].join('\n');
    downloadTextFile(`masroufy-transactions-${todayIso()}.csv`, 'text/csv;charset=utf-8', csv);
    showToast('تم تصدير المعاملات بصيغة CSV ✅');
  }

  function switchTab(tabId) {
    if (!TAB_RENDERERS[tabId]) return;
    stopChatVoiceInput(false);
    activeTab = tabId;
    if (tabId !== 'advisor') activeAdvisorChatId = null;
    document.querySelectorAll('.tab-panel').forEach((el) => el.classList.remove('active'));
    document.getElementById(`tab-${tabId}`)?.classList.add('active');
    document.querySelectorAll('.nav-item').forEach((btn) => {
      btn.classList.toggle('active', btn.getAttribute('data-tab') === tabId);
    });
    applyThemeAndChrome();
    if (dirtyTabs.has(tabId)) {
      renderTabIfActive(tabId);
    }
    window.scrollTo({ top: 0 });
  }

  // Event Binding
  function bindEvents() {
    document.getElementById('themeToggleBtn')?.addEventListener('click', () => {
      appState.settings.theme = appState.settings.theme === 'dark' ? 'light' : 'dark';
      saveState(appState);
      renderAll();
    });

    document.getElementById('privacyToggleBtn')?.addEventListener('click', () => {
      appState.settings.privacyMode = !appState.settings.privacyMode;
      saveState(appState);
      showToast(appState.settings.privacyMode ? 'تم تفعيل وضع الخصوصية 🙈' : 'تم إظهار الأرصدة 👁️');
      renderAll();
    });

    document.getElementById('openRatesBtn')?.addEventListener('click', () => switchTab('rates'));
    document.getElementById('openSettingsBtn')?.addEventListener('click', () => switchTab('settings'));
    document.getElementById('navAddTxBtn')?.addEventListener('click', () => openTransactionModal(null));

    document.querySelectorAll('.nav-item').forEach((btn) => {
      btn.addEventListener('click', () => switchTab(btn.getAttribute('data-tab')));
    });

    document.getElementById('modalBackdrop')?.addEventListener('click', (e) => {
      if (e.target.id === 'modalBackdrop') closeModal();
    });

    document.addEventListener('click', (e) => {
      const retryBtn = e.target.closest('[data-retry-render]');
      if (retryBtn) {
        const cid = retryBtn.getAttribute('data-retry-render');
        const tabKey = cid.replace(/^tab-/, '');
        if (TAB_RENDERERS[tabKey]) safeRender(cid, TAB_RENDERERS[tabKey]);
        return;
      }

      const pinKeyBtn = e.target.closest('[data-pin-key]');
      if (pinKeyBtn) {
        const key = pinKeyBtn.getAttribute('data-pin-key');
        if (key === 'مسح') pinEntryBuffer = '';
        else if (key === '⌫') pinEntryBuffer = pinEntryBuffer.slice(0, -1);
        else if (pinEntryBuffer.length < 4) pinEntryBuffer += key;

        if (pinEntryBuffer.length === 4) {
          if (pinEntryBuffer === appState.settings.pinCode) {
            isPinLocked = false;
            pinEntryBuffer = '';
            showToast('أهلاً بك في مصروفي 🔓');
          } else {
            pinEntryBuffer = '';
            showToast('رمز الحماية غير صحيح ❌');
          }
        }
        renderPinLock();
        return;
      }

      if (e.target.closest('[data-close-modal]')) { closeModal(); return; }

      const jumpBtn = e.target.closest('[data-jump-tab]');
      if (jumpBtn) { switchTab(jumpBtn.getAttribute('data-jump-tab')); return; }

      const tagBtn = e.target.closest('[data-filter-tag]');
      if (tagBtn) {
        const tag = tagBtn.getAttribute('data-filter-tag');
        txFilters.hashtag = txFilters.hashtag === tag ? '' : tag;
        if (activeTab !== 'transactions') switchTab('transactions');
        safeRender('tab-transactions', renderTransactions);
        return;
      }

      const txTypeBtn = e.target.closest('[data-tx-type]');
      if (txTypeBtn) { txFilters.type = txTypeBtn.getAttribute('data-tx-type'); safeRender('tab-transactions', renderTransactions); return; }

      const editTxBtn = e.target.closest('[data-edit-tx]');
      if (editTxBtn) {
        const tx = appState.transactions.find((t) => t.id === editTxBtn.getAttribute('data-edit-tx'));
        if (tx) openTransactionModal(tx);
        return;
      }

      const delTxBtn = e.target.closest('[data-del-tx]');
      if (delTxBtn) { deleteTransactionById(delTxBtn.getAttribute('data-del-tx')); return; }

      const subTabBtn = e.target.closest('[data-budget-subtab]');
      if (subTabBtn) { activeBudgetsSubTab = subTabBtn.getAttribute('data-budget-subtab'); safeRender('tab-budgets', renderBudgets); return; }

      const editBudgetBtn = e.target.closest('[data-edit-budget]');
      if (editBudgetBtn) { openBudgetModal(editBudgetBtn.getAttribute('data-edit-budget')); return; }

      if (e.target.id === 'addGoalBtn') { openGoalModal(); return; }
      const depGoalBtn = e.target.closest('[data-deposit-goal]');
      if (depGoalBtn) { openGoalDepositModal(depGoalBtn.getAttribute('data-deposit-goal')); return; }
      const delGoalBtn = e.target.closest('[data-del-goal]');
      if (delGoalBtn) {
        const id = delGoalBtn.getAttribute('data-del-goal');
        appState.goals = appState.goals.filter((g) => g.id !== id);
        saveState(appState);
        renderAll();
        return;
      }

      if (e.target.id === 'addGam3eyaBtn') { openGam3eyaModal(); return; }
      const payGamBtn = e.target.closest('[data-pay-gam3eya]');
      if (payGamBtn) {
        const gm = appState.gam3eyas.find((g) => g.id === payGamBtn.getAttribute('data-pay-gam3eya'));
        if (gm && gm.lastPaidMonth !== currentMonthKey()) {
          const ok = saveTransactionRecord({
            type: 'expense', amount: gm.monthlyAmount, categoryId: 'installments',
            walletId: gm.walletId || appState.wallets[0]?.id, date: todayIso(), note: `قسط ${gm.title} #جمعية`
          });
          if (ok) {
            gm.lastPaidMonth = currentMonthKey();
            gm.paidMonths = Math.min(gm.totalMembers || 10, (gm.paidMonths || 0) + 1);
            saveState(appState);
            renderAll();
          }
        }
        return;
      }
      const delGamBtn = e.target.closest('[data-del-gam3eya]');
      if (delGamBtn) {
        const id = delGamBtn.getAttribute('data-del-gam3eya');
        appState.gam3eyas = appState.gam3eyas.filter((g) => g.id !== id);
        saveState(appState);
        renderAll();
        return;
      }

      if (e.target.id === 'addDebtBtn') { openDebtModal(); return; }
      const settleDebtBtn = e.target.closest('[data-settle-debt]');
      if (settleDebtBtn) { openSettleDebtModal(settleDebtBtn.getAttribute('data-settle-debt')); return; }
      const delDebtBtn = e.target.closest('[data-del-debt]');
      if (delDebtBtn) {
        const id = delDebtBtn.getAttribute('data-del-debt');
        appState.debts = appState.debts.filter((d) => d.id !== id);
        saveState(appState);
        renderAll();
        return;
      }

      if (e.target.id === 'addBillBtn') { openRecurringBillModal(); return; }
      const payBillBtn = e.target.closest('[data-pay-bill]');
      if (payBillBtn) {
        const rb = appState.recurringBills.find((b) => b.id === payBillBtn.getAttribute('data-pay-bill'));
        if (rb && rb.lastPaidMonth !== currentMonthKey()) {
          const ok = saveTransactionRecord({
            type: 'expense', amount: rb.amount, categoryId: rb.categoryId || 'bills',
            walletId: rb.walletId || appState.wallets[0]?.id, date: todayIso(), note: `دفع ${rb.title} #فواتير`
          });
          if (ok) {
            rb.lastPaidMonth = currentMonthKey();
            saveState(appState);
            renderAll();
          }
        }
        return;
      }
      const delBillBtn = e.target.closest('[data-del-bill]');
      if (delBillBtn) {
        const id = delBillBtn.getAttribute('data-del-bill');
        appState.recurringBills = appState.recurringBills.filter((b) => b.id !== id);
        saveState(appState);
        renderAll();
        return;
      }

      const openAdvBtn = e.target.closest('[data-open-advisor]');
      if (openAdvBtn) {
        const chosen = resolveAdvisor(openAdvBtn.getAttribute('data-open-advisor'));
        if (!chosen) {
          showToast('تعذر فتح المستشار، جرب اختياره مجدداً');
          return;
        }
        activeAdvisorChatId = chosen.id;
        aiQuotaBannerVisible = false;
        applyThemeAndChrome();
        safeRender('tab-advisor', renderAdvisor);
        return;
      }
      if (e.target.closest('#advisorBackBtn')) {
        stopChatVoiceInput(false);
        activeAdvisorChatId = null;
        aiQuotaBannerVisible = false;
        applyThemeAndChrome();
        safeRender('tab-advisor', renderAdvisor);
        return;
      }
      if (e.target.closest('#clearPersonaChatBtn') && activeAdvisorChatId) {
        aiChats[activeAdvisorChatId] = [];
        saveAiChats(aiChats);
        showToast('تم مسح المحادثة');
        safeRender('tab-advisor', renderAdvisor);
        return;
      }
      if (e.target.closest('#aiVoiceBtn')) {
        startChatVoiceInput();
        return;
      }

      const suggBtn = e.target.closest('[data-ai-suggestion]');
      if (suggBtn) { sendAiAdvisorMessage(suggBtn.getAttribute('data-ai-suggestion')); return; }
      if (e.target.id === 'openAiKeySetupBtn') { openApiKeyQuickModal(); return; }
      if (e.target.id === 'dismissQuotaAlertBtn') { aiQuotaBannerVisible = false; safeRender('tab-advisor', renderAdvisor); return; }

      if (e.target.id === 'refreshRatesBtn') { fetchLiveRates(true); return; }
      if (e.target.id === 'swapConverterBtn') {
        const f = converterState.from; converterState.from = converterState.to; converterState.to = f;
        safeRender('tab-rates', renderRates);
        return;
      }
      if (e.target.id === 'logSplitShareBtn') {
        const s = computeSplitSummary();
        const wId = document.getElementById('splitWalletSelect')?.value || appState.wallets[0]?.id;
        const noteVal = (document.getElementById('splitNoteInput')?.value || '').trim() || 'حصة خروجة';
        saveTransactionRecord({
          type: 'expense',
          amount: Number(s.perPerson.toFixed(2)),
          categoryId: 'entertainment',
          walletId: wId,
          date: todayIso(),
          note: `${noteVal} (تقسيم ${s.friends}) #خروجة`
        });
        return;
      }

      if (e.target.id === 'addWalletBtn') { openWalletModal(null); return; }
      const editWalletBtn = e.target.closest('[data-edit-wallet]');
      if (editWalletBtn) { const w = getWallet(editWalletBtn.getAttribute('data-edit-wallet')); if (w) openWalletModal(w); return; }
      const delWalletBtn = e.target.closest('[data-del-wallet]');
      if (delWalletBtn) {
        const id = delWalletBtn.getAttribute('data-del-wallet');
        if (appState.wallets.length > 1) {
          appState.wallets = appState.wallets.filter((w) => w.id !== id);
          saveState(appState);
          renderAll();
        }
        return;
      }

      if (e.target.id === 'addCustomCatBtn') { openCustomCategoryModal(); return; }
      const delCatBtn = e.target.closest('[data-del-custom-cat]');
      if (delCatBtn) {
        const id = delCatBtn.getAttribute('data-del-custom-cat');
        appState.customCategories = appState.customCategories.filter((c) => c.id !== id);
        saveState(appState);
        renderAll();
        return;
      }

      if (e.target.id === 'addTemplateBtn') { openAddTemplateModal(); return; }
      const delTplBtn = e.target.closest('[data-del-template]');
      if (delTplBtn) {
        const id = delTplBtn.getAttribute('data-del-template');
        appState.quickTemplates = appState.quickTemplates.filter((t) => t.id !== id);
        saveState(appState);
        renderAll();
        return;
      }

      if (e.target.id === 'settingsThemeSwitch') {
        appState.settings.theme = appState.settings.theme === 'dark' ? 'light' : 'dark';
        saveState(appState);
        renderAll();
        return;
      }
      if (e.target.id === 'settingsPrivacySwitch') {
        appState.settings.privacyMode = !appState.settings.privacyMode;
        saveState(appState);
        renderAll();
        return;
      }
      if (e.target.id === 'setupPinBtn') { openPinSetupModal(); return; }

      if (e.target.id === 'saveApiKeysBtn') {
        appState.settings.geminiApiKey = (document.getElementById('geminiKeyInput')?.value || '').trim();
        appState.settings.groqApiKey = (document.getElementById('groqKeyInput')?.value || '').trim();
        saveState(appState);
        aiQuotaBannerVisible = false;
        showToast('تم حفظ المفاتيح محلياً ✅');
        return;
      }

      if (e.target.id === 'openStatementBtn') { openPrintableStatementModal(); return; }
      if (e.target.id === 'exportJsonBtn') { exportJsonBackup(); return; }
      if (e.target.id === 'importJsonBtn') { document.getElementById('jsonRestoreInput')?.click(); return; }
      if (e.target.id === 'exportCsvBtn') { exportTransactionsCsv(); return; }
      if (e.target.id === 'resetAllBtn') { openResetConfirmModal(); return; }

      const qrModeBtn = e.target.closest('[data-qr-mode]');
      if (qrModeBtn) {
        devQrMode = qrModeBtn.getAttribute('data-qr-mode') === 'whatsapp' ? 'whatsapp' : 'vcard';
        document.querySelectorAll('[data-qr-mode]').forEach((btn) => {
          btn.classList.toggle('active', btn.getAttribute('data-qr-mode') === devQrMode);
        });
        const cap = document.getElementById('devQrCaption');
        if (cap) {
          cap.textContent = devQrMode === 'whatsapp'
            ? 'امسح الكود لفتح محادثة واتساب مباشرة مع المطور'
            : 'امسح الكود لحفظ بطاقة اتصال بلال محمد سليمان (vCard)';
        }
        renderDeveloperQrCanvas();
        return;
      }

      if (e.target.id === 'downloadDevQrBtn') {
        const canvas = document.getElementById('devQrCanvas');
        if (canvas) {
          const dataUrl = canvas.toDataURL('image/png');
          downloadDataUrlFile(`masroufy-dev-qr-${devQrMode}.png`, 'image/png', dataUrl);
          showToast('تم تجهيز صورة الباركود PNG ✅');
        }
        return;
      }

      if (e.target.id === 'devWhatsappBtn') { openExternalLink(DEV_PROFILE.whatsappUrl); return; }
      if (e.target.id === 'devGithubBtn') { openExternalLink(DEV_PROFILE.githubUrl); return; }

      const extBtn = e.target.closest('[data-ext-url]');
      if (extBtn) { openExternalLink(extBtn.getAttribute('data-ext-url')); return; }

      if (e.target.id === 'copyDevContactBtn') {
        const summary = [
          `${DEV_PROFILE.nameAr} (${DEV_PROFILE.nameEn})`,
          DEV_PROFILE.roleAr,
          `واتساب: ${DEV_PROFILE.phone}`,
          `البريد: ${DEV_PROFILE.email}`,
          `GitHub: ${DEV_PROFILE.githubUrl}`
        ].join('\n');
        copyTextToClipboard(summary).then(() => showToast('تم نسخ بيانات التواصل ✅'));
        return;
      }

      if (e.target.id === 'downloadDevVcfBtn') {
        downloadTextFile('belal-mohamed-sleman.vcf', 'text/vcard;charset=utf-8', buildDeveloperVCard());
        showToast('تم تجهيز بطاقة الاتصال vCard ✅');
        return;
      }

      if (e.target.id === 'toggleApiGuideBtn') {
        devApiGuideOpen = !devApiGuideOpen;
        const contentEl = document.getElementById('apiGuideContent');
        const chevEl = document.getElementById('apiGuideChevron');
        const toggleBtn = document.getElementById('toggleApiGuideBtn');
        if (contentEl) contentEl.style.display = devApiGuideOpen ? 'flex' : 'none';
        if (chevEl) chevEl.textContent = devApiGuideOpen ? '▲' : '▼';
        if (toggleBtn) toggleBtn.setAttribute('aria-expanded', devApiGuideOpen ? 'true' : 'false');
        return;
      }
    });

    document.addEventListener('input', (e) => {
      if (e.target.id === 'txSearchInput') {
        txFilters.search = e.target.value;
        const listEl = document.querySelector('#tab-transactions .tx-list');
        if (listEl) {
          const filtered = getFilteredTransactions();
          listEl.innerHTML = filtered.length
            ? filtered.map((tx) => renderTransactionRow(tx, true)).join('')
            : '<div class="card empty-state">لا توجد معاملات مطابقة للبحث.</div>';
        }
        return;
      }
      if (e.target.id === 'convAmountInput') {
        converterState.amount = e.target.value;
        const outEl = document.getElementById('convResultVal');
        if (outEl) {
          const converted = computeConverterOutput();
          const suffix = converterState.to.startsWith('GOLD') || converterState.to === 'SILVER' ? 'جرام' : converterState.to;
          outEl.textContent = `${fmtNum(converted, converterState.to === 'EGP' ? 2 : 3)} ${suffix}`;
        }
        return;
      }
      if (['zakatCashInput', 'zakatGold21Input', 'zakatGold24Input', 'zakatSilverInput'].includes(e.target.id)) {
        zakatState.cash = document.getElementById('zakatCashInput')?.value || '0';
        zakatState.gold21 = document.getElementById('zakatGold21Input')?.value || '0';
        zakatState.gold24 = document.getElementById('zakatGold24Input')?.value || '0';
        zakatState.silver = document.getElementById('zakatSilverInput')?.value || '0';
        const z = computeZakatSummary();
        const box = document.getElementById('zakatResultBox');
        if (box) {
          box.style.borderColor = z.eligible ? 'rgba(16,185,129,0.45)' : 'var(--border)';
          box.innerHTML = `<span style="font-size:0.78rem;color:var(--text-muted)">إجمالي الوعاء الزكوي: ${fmtEgp(z.totalWealth, 0, true)}</span>
            <strong style="color:${z.eligible ? 'var(--emerald-text)' : 'var(--text-muted)'}">${z.eligible ? `الزكاة المستحقة: ${fmtNum(z.zakatDue, 0)} ج.م` : 'أقل من النصاب الشرعي (85 جم عيار 24)'}</strong>`;
        }
        return;
      }
      if (['splitTotalInput', 'splitFriendsInput', 'splitTipInput', 'splitNoteInput'].includes(e.target.id)) {
        splitState.total = document.getElementById('splitTotalInput')?.value || '0';
        splitState.friends = document.getElementById('splitFriendsInput')?.value || '1';
        splitState.tipPct = document.getElementById('splitTipInput')?.value || '0';
        splitState.note = document.getElementById('splitNoteInput')?.value || '';
        const s = computeSplitSummary();
        const metaEl = document.getElementById('splitGrandMeta');
        if (metaEl) metaEl.textContent = `حصة الفرد الواحد (من إجمالي ${fmtNum(s.grandTotal, 0)} ج.م)`;
        const el = document.getElementById('splitShareVal');
        if (el) el.textContent = `${fmtNum(s.perPerson, 2)} ج.م`;
      }
    });

    document.addEventListener('change', (e) => {
      if (e.target.id === 'txCatFilter') { txFilters.categoryId = e.target.value; safeRender('tab-transactions', renderTransactions); return; }
      if (e.target.id === 'txWalletFilter') { txFilters.walletId = e.target.value; safeRender('tab-transactions', renderTransactions); return; }
      if (e.target.id === 'txPeriodFilter') { txFilters.period = e.target.value; safeRender('tab-transactions', renderTransactions); return; }
      if (e.target.id === 'txCustomDate') { txFilters.customDate = e.target.value; safeRender('tab-transactions', renderTransactions); return; }
      if (e.target.id === 'convFromSelect') { converterState.from = e.target.value; safeRender('tab-rates', renderRates); return; }
      if (e.target.id === 'convToSelect') { converterState.to = e.target.value; safeRender('tab-rates', renderRates); return; }
      if (e.target.id === 'splitWalletSelect') { splitState.walletId = e.target.value; return; }
      if (e.target.id === 'jsonRestoreInput') {
        const file = e.target.files && e.target.files[0];
        if (!file) return;
        const reader = new FileReader();
        reader.onload = () => {
          try {
            const parsed = JSON.parse(String(reader.result || '{}'));
            const candidate = parsed.state || parsed;
            if (!candidate || !Array.isArray(candidate.wallets) || !Array.isArray(candidate.transactions)) throw new Error('Invalid');
            appState = normalizeAppState({ ...candidate, settings: { ...appState.settings, ...(candidate.settings || {}) } });
            if (parsed.aiChats && typeof parsed.aiChats === 'object') {
              aiChats = sanitizeAiChats(parsed.aiChats);
              saveAiChats(aiChats);
            }
            activeAdvisorChatId = null;
            isPinLocked = Boolean(appState.settings.pinCode && appState.settings.pinCode.length === 4);
            saveState(appState);
            showToast('تمت استعادة النسخة الاحتياطية بنجاح ✅');
            renderAll();
          } catch (_) {
            showToast('ملف النسخة الاحتياطية غير صالح');
          } finally {
            e.target.value = '';
          }
        };
        reader.readAsText(file);
      }
    });

    document.addEventListener('submit', (e) => {
      if (e.target.id === 'aiChatForm') {
        e.preventDefault();
        const input = document.getElementById('aiChatInput');
        if (input) {
          const val = input.value;
          input.value = '';
          sendAiAdvisorMessage(val);
        }
      }
    });

    document.addEventListener('focusin', (e) => {
      if (e.target.id === 'aiChatInput') {
        setTimeout(() => {
          const box = document.getElementById('aiChatBox');
          if (box) box.scrollTop = box.scrollHeight;
        }, 250);
      }
    });

    if (window.visualViewport) {
      window.visualViewport.addEventListener('resize', () => {
        if (activeTab === 'advisor' && activeAdvisorChatId) {
          const box = document.getElementById('aiChatBox');
          if (box) box.scrollTop = box.scrollHeight;
        }
      });
    }
  }

  window.addEventListener('unhandledrejection', (ev) => {
    ev.preventDefault();
  });

  window.masroufyHandleAndroidBack = function () {
    if (modalOpen) { closeModal(); return 'handled'; }
    if (activeTab === 'advisor' && activeAdvisorChatId) {
      stopChatVoiceInput(false);
      activeAdvisorChatId = null;
      applyThemeAndChrome();
      safeRender('tab-advisor', renderAdvisor);
      return 'handled';
    }
    if (activeTab !== 'dashboard') { switchTab('dashboard'); return 'handled'; }
    return 'exit';
  };

  if ('serviceWorker' in navigator && !location.hostname.endsWith('.local')) {
    window.addEventListener('load', () => { navigator.serviceWorker.register('./sw.js').catch(() => {}); });
  }

  bindEvents();
  renderAll();
  fetchLiveRates(false);
})();
