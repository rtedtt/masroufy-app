package com.example.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import com.example.MainActivity
import com.example.R
import com.example.data.local.MasroufyDatabase
import com.example.data.local.SettingsDataStore
import com.example.domain.FinanceCalculator
import com.example.domain.Formatters
import com.example.notifications.NotificationHelper
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class MasroufyAppWidget : AppWidgetProvider() {

    override fun onUpdate(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetIds: IntArray,
    ) {
        val pendingResult = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val db = MasroufyDatabase.getInstance(context.applicationContext)
                val settings = SettingsDataStore(context.applicationContext).getCurrentSettings()
                val wallets = db.walletDao().getAll()
                val envelopes = db.envelopeDao().getAll()
                val transactions = db.transactionDao().getAll()
                val zeroSpendDays = db.zeroSpendDao().getAll()
                val gameyas = db.gameyaDao().getAll()

                val snapshot = FinanceCalculator.calculateBudgetSnapshot(
                    wallets = wallets,
                    envelopes = envelopes,
                    transactions = transactions,
                    zeroSpendDays = zeroSpendDays,
                    cycleStartDay = settings.budgetCycleStartDay,
                    gameyas = gameyas,
                )

                val dailyText = Formatters.formatEgp(snapshot.dailySafeLimit.coerceAtLeast(0.0), isMasked = settings.isPrivacyMode)
                val freeText = Formatters.formatEgp(snapshot.freeBalance, isMasked = settings.isPrivacyMode)
                val cycleBadge = "باقي ${snapshot.remainingDaysInCycle} يوم"

                appWidgetIds.forEach { widgetId ->
                    val views = RemoteViews(context.packageName, R.layout.widget_masroufy).apply {
                        setTextViewText(R.id.widget_daily_safe, dailyText)
                        setTextViewText(R.id.widget_free_balance, freeText)
                        setTextViewText(R.id.widget_cycle_badge, cycleBadge)

                        val openAppIntent = Intent(context, MainActivity::class.java).apply {
                            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
                        }
                        val openAppPending = PendingIntent.getActivity(
                            context,
                            3101 + widgetId,
                            openAppIntent,
                            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
                        )
                        setOnClickPendingIntent(R.id.widget_root, openAppPending)

                        val quickLogIntent = Intent(context, MainActivity::class.java).apply {
                            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
                            putExtra(NotificationHelper.EXTRA_OPEN_QUICK_LOG, true)
                        }
                        val quickLogPending = PendingIntent.getActivity(
                            context,
                            3201 + widgetId,
                            quickLogIntent,
                            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
                        )
                        setOnClickPendingIntent(R.id.widget_quick_log_btn, quickLogPending)
                    }
                    appWidgetManager.updateAppWidget(widgetId, views)
                }
            } finally {
                pendingResult.finish()
            }
        }
    }

    companion object {
        fun requestUpdate(context: Context) {
            val appContext = context.applicationContext
            val manager = AppWidgetManager.getInstance(appContext)
            val component = ComponentName(appContext, MasroufyAppWidget::class.java)
            val ids = manager.getAppWidgetIds(component)
            if (ids.isNotEmpty()) {
                val intent = Intent(appContext, MasroufyAppWidget::class.java).apply {
                    action = AppWidgetManager.ACTION_APPWIDGET_UPDATE
                    putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, ids)
                }
                appContext.sendBroadcast(intent)
            }
        }
    }
}
