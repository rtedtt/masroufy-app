package com.example.workers

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.example.data.local.MasroufyDatabase
import com.example.data.local.SettingsDataStore
import com.example.data.local.TransactionType
import com.example.data.repository.MasroufyRepository
import com.example.notifications.NotificationHelper
import java.io.File
import java.time.Duration
import java.time.Instant
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneId
import java.util.concurrent.TimeUnit

class DailyCheckWorker(
    appContext: Context,
    workerParams: WorkerParameters,
) : CoroutineWorker(appContext, workerParams) {

    override suspend fun doWork(): Result {
        val db = MasroufyDatabase.getInstance(applicationContext)
        val settingsStore = SettingsDataStore(applicationContext)
        val settings = settingsStore.getCurrentSettings()
        val zone = ZoneId.systemDefault()
        val today = LocalDate.now(zone)

        // 1. Evening Reminder if no expenses logged today
        if (settings.dailyReminderEnabled) {
            val transactions = db.transactionDao().getAll()
            val hasExpenseToday = transactions.any { tx ->
                tx.type == TransactionType.EXPENSE &&
                    Instant.ofEpochMilli(tx.timestamp).atZone(zone).toLocalDate() == today
            }
            if (!hasExpenseToday) {
                NotificationHelper.showDailyEveningReminder(applicationContext)
            }
        }

        // 2. Debt Due-Date Reminders
        val dueDebts = db.debtDao().getAll().filter { debt ->
            if (debt.isSettled || debt.dueDateMillis == null) return@filter false
            val dueDate = Instant.ofEpochMilli(debt.dueDateMillis).atZone(zone).toLocalDate()
            !dueDate.isAfter(today)
        }
        if (dueDebts.isNotEmpty()) {
            NotificationHelper.showDebtDueReminder(
                context = applicationContext,
                count = dueDebts.size,
                firstPerson = dueDebts.first().personName,
            )
        }

        // 3. Subscriptions 48h Renewal Radar Reminder
        val soonSubs = db.subscriptionDao().getAll().filter { sub ->
            if (!sub.isActive) return@filter false
            val daysUntil = com.example.domain.FinanceCalculator.daysUntilRenewal(sub, today)
            daysUntil in 0L..2L
        }
        if (soonSubs.isNotEmpty()) {
            val firstSub = soonSubs.first()
            val days = com.example.domain.FinanceCalculator.daysUntilRenewal(firstSub, today)
            NotificationHelper.showSubscriptionRenewalAlert(
                context = applicationContext,
                title = firstSub.title,
                amountText = com.example.domain.Formatters.formatEgp(firstSub.amount),
                daysRemaining = days,
            )
        }

        return Result.success()
    }
}

class WeeklyBackupWorker(
    appContext: Context,
    workerParams: WorkerParameters,
) : CoroutineWorker(appContext, workerParams) {

    override suspend fun doWork(): Result {
        val db = MasroufyDatabase.getInstance(applicationContext)
        val settingsStore = SettingsDataStore(applicationContext)
        val settings = settingsStore.getCurrentSettings()
        if (!settings.weeklyAutoBackupEnabled) return Result.success()

        val repository = MasroufyRepository(db, settingsStore)
        val jsonText = repository.exportBackupJson()

        val backupsDir = File(applicationContext.filesDir, "backups").apply { mkdirs() }
        val latestFile = File(backupsDir, "masroufy_auto_backup_latest.json")
        latestFile.writeText(jsonText, Charsets.UTF_8)

        val datedFile = File(backupsDir, "masroufy_backup_${LocalDate.now()}.json")
        datedFile.writeText(jsonText, Charsets.UTF_8)

        // Retain latest 4 dated snapshots
        backupsDir.listFiles { f -> f.name.startsWith("masroufy_backup_") && f.name.endsWith(".json") }
            ?.sortedByDescending { it.lastModified() }
            ?.drop(4)
            ?.forEach { it.delete() }

        repository.setLastWeeklyBackupAt(System.currentTimeMillis())
        return Result.success()
    }
}

object WorkScheduler {
    private const val DAILY_CHECK_WORK = "masroufy_daily_check"
    private const val WEEKLY_BACKUP_WORK = "masroufy_weekly_backup"

    fun scheduleDailyCheck(context: Context, hour: Int = 22, minute: Int = 0) {
        val now = LocalDateTime.now()
        var target = now.withHour(hour.coerceIn(0, 23)).withMinute(minute.coerceIn(0, 59)).withSecond(0)
        if (!target.isAfter(now)) {
            target = target.plusDays(1)
        }
        val initialDelayMinutes = Duration.between(now, target).toMinutes().coerceAtLeast(1)

        val request = PeriodicWorkRequestBuilder<DailyCheckWorker>(24, TimeUnit.HOURS)
            .setInitialDelay(initialDelayMinutes, TimeUnit.MINUTES)
            .build()

        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
            DAILY_CHECK_WORK,
            ExistingPeriodicWorkPolicy.UPDATE,
            request,
        )
    }

    fun scheduleWeeklyBackup(context: Context, enabled: Boolean) {
        val wm = WorkManager.getInstance(context)
        if (!enabled) {
            wm.cancelUniqueWork(WEEKLY_BACKUP_WORK)
            return
        }
        val request = PeriodicWorkRequestBuilder<WeeklyBackupWorker>(7, TimeUnit.DAYS)
            .build()
        wm.enqueueUniquePeriodicWork(
            WEEKLY_BACKUP_WORK,
            ExistingPeriodicWorkPolicy.KEEP,
            request,
        )
    }
}
