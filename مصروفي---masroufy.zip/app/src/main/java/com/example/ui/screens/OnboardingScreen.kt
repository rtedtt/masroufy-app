package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AccountBalanceWallet
import androidx.compose.material.icons.rounded.RocketLaunch
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.data.local.WalletEntity
import com.example.domain.Formatters
import com.example.ui.components.FintechCard
import com.example.ui.components.IconBadge
import com.example.ui.components.IconsCatalog
import com.example.ui.theme.LocalMasroufyColors

@Composable
fun OnboardingScreen(
    wallets: List<WalletEntity>,
    onComplete: (walletBalances: Map<Long, Double>, cycleStartDay: Int) -> Unit,
    onSkip: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val semantic = LocalMasroufyColors.current
    val inputs = remember(wallets) {
        mutableStateMapOf<Long, String>().apply {
            wallets.forEach { put(it.id, "") }
        }
    }
    var cycleStartDay by remember { mutableIntStateOf(1) }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .safeDrawingPadding()
            .imePadding()
            .navigationBarsPadding(),
        contentAlignment = Alignment.Center,
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 560.dp)
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                IconBadge(
                    icon = Icons.Rounded.AccountBalanceWallet,
                    tint = semantic.emerald,
                    contentDescription = "مصروفي",
                    size = 54.dp,
                )
                TextButton(onClick = onSkip) {
                    Text("تخطي الآن")
                }
            }

            Column {
                Text(
                    text = "أهلاً بك في مصروفي 👋",
                    style = MaterialTheme.typography.headlineLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground,
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "ابدأ بأرقامك الحقيقية! أدخل رصيدك الحالي في كل محفظة وهنحسب لك الحد الآمن للصرف فوراً.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }

            FintechCard(borderColor = semantic.emerald.copy(alpha = 0.4f)) {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    wallets.forEach { wallet ->
                        val wColor = Color(wallet.colorHex)
                        OutlinedTextField(
                            value = inputs[wallet.id].orEmpty(),
                            onValueChange = { inputs[wallet.id] = it },
                            label = { Text("رصيد ${wallet.name} (ج.م)") },
                            placeholder = { Text("0") },
                            leadingIcon = {
                                Icon(
                                    imageVector = IconsCatalog.resolve(wallet.iconKey),
                                    contentDescription = wallet.name,
                                    tint = wColor,
                                )
                            },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            singleLine = true,
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("onboarding_wallet_${wallet.id}"),
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "يوم بداية مرتبك / دورتك الشهرية",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onSurface,
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        listOf(1, 5, 10, 15, 25).forEach { day ->
                            val selected = cycleStartDay == day
                            Surface(
                                onClick = { cycleStartDay = day },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(12.dp),
                                color = if (selected) semantic.emerald.copy(alpha = 0.2f) else MaterialTheme.colorScheme.surfaceVariant,
                                border = BorderStroke(1.dp, if (selected) semantic.emerald else semantic.cardBorder),
                            ) {
                                Text(
                                    text = "يوم $day",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = if (selected) semantic.emerald else MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.padding(vertical = 10.dp, horizontal = 4.dp),
                                )
                            }
                        }
                    }
                }
            }

            Button(
                onClick = {
                    val balances = wallets.associate { w ->
                        val parsed = Formatters.parseSafeDouble(inputs[w.id].orEmpty()) ?: 0.0
                        w.id to parsed.coerceAtLeast(0.0)
                    }
                    onComplete(balances, cycleStartDay)
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
                    .testTag("onboarding_start_button"),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = semantic.emerald,
                    contentColor = Color.White,
                ),
            ) {
                Icon(Icons.Rounded.RocketLaunch, contentDescription = null, modifier = Modifier.size(20.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("ابدأ الآن", style = MaterialTheme.typography.titleMedium)
            }
        }
    }
}
