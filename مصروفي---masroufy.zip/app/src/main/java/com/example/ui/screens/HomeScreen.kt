package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AccountBalanceWallet
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.BookmarkAdd
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.DriveFileMove
import androidx.compose.material.icons.rounded.EventRepeat
import androidx.compose.material.icons.rounded.FilterList
import androidx.compose.material.icons.rounded.FlightTakeoff
import androidx.compose.material.icons.rounded.LocalFireDepartment
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.ReceiptLong
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material.icons.rounded.SwapHoriz
import androidx.compose.material.icons.rounded.Tag
import androidx.compose.material.icons.rounded.TrendingUp
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.material.icons.rounded.WarningAmber
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.DateRangePicker
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.SwipeToDismissBox
import androidx.compose.material3.SwipeToDismissBoxValue
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDateRangePickerState
import androidx.compose.material3.rememberSwipeToDismissBoxState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.local.CategoryEntity
import com.example.data.local.QuickTemplateEntity
import com.example.data.local.RecurringTransactionEntity
import com.example.data.local.RolloverMode
import com.example.data.local.TransactionEntity
import com.example.data.local.TransactionType
import com.example.data.local.WalletEntity
import com.example.domain.BudgetSnapshot
import com.example.domain.Formatters
import com.example.domain.GamificationSnapshot
import com.example.domain.HashtagParser
import com.example.domain.SafeSpendStatus
import com.example.domain.TripSnapshot
import com.example.ui.components.ConfirmActionDialog
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.FintechCard
import com.example.ui.components.IconBadge
import com.example.ui.components.IconsCatalog
import com.example.ui.theme.LocalMasroufyColors
import com.example.viewmodel.MasroufyUiState
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

enum class DateFilterPreset(val label: String) {
    ALL("كل الأوقات"),
    TODAY("النهاردة"),
    LAST_7_DAYS("آخر 7 أيام"),
    THIS_MONTH("هذا الشهر"),
    CUSTOM("فترة مخصصة"),
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    state: MasroufyUiState,
    onOpenQuickLog: (mode: String, walletId: Long?) -> Unit,
    onOpenWalletStatement: (Long) -> Unit,
    onEditTransaction: (TransactionEntity) -> Unit,
    onDeleteTransaction: (TransactionEntity) -> Unit,
    onDuplicateTransaction: (TransactionEntity) -> Unit,
    onBulkDeleteTransactions: (Set<Long>) -> Unit,
    onBulkMoveTransactions: (Set<Long>, Long) -> Unit,
    onToggleZeroSpend: () -> Unit,
    onTogglePrivacyMode: () -> Unit,
    onLogQuickTemplate: (QuickTemplateEntity) -> Unit,
    onSaveQuickTemplate: (title: String, amount: Double, type: String, categoryId: Long?, walletId: Long, note: String) -> Unit,
    onDeleteQuickTemplate: (Long) -> Unit,
    onConfirmRecurringDue: (RecurringTransactionEntity) -> Unit,
    onOpenAiAdvisor: () -> Unit,
    onOpenThemesGallery: () -> Unit = {},
    modifier: Modifier = Modifier,
) {
    val semantic = LocalMasroufyColors.current
    val haptic = LocalHapticFeedback.current
    val masked = state.settings.isPrivacyMode
    val zone = remember { ZoneId.systemDefault() }
    val today = remember { LocalDate.now(zone) }

    val categoryMap = remember(state.categories) { state.categories.associateBy { it.id } }
    val walletMap = remember(state.wallets) { state.wallets.associateBy { it.id } }

    // #13 & #14 Search, Hashtag & Multi-Criteria Filter state
    var searchQuery by remember { mutableStateOf("") }
    var selectedHashtag by remember { mutableStateOf<String?>(null) }
    var showFiltersPanel by remember { mutableStateOf(false) }
    var filterType by remember { mutableStateOf<String?>(null) }
    var filterWalletId by remember { mutableStateOf<Long?>(null) }
    var filterCategoryId by remember { mutableStateOf<Long?>(null) }
    var datePreset by remember { mutableStateOf(DateFilterPreset.ALL) }
    var customStartMillis by remember { mutableStateOf<Long?>(null) }
    var customEndMillis by remember { mutableStateOf<Long?>(null) }
    var showDateRangePicker by remember { mutableStateOf(false) }

    // #18 Bulk Selection Mode state
    var selectedTxIds by remember { mutableStateOf<Set<Long>>(emptySet()) }
    val isBulkMode = selectedTxIds.isNotEmpty()
    var showBulkMoveDialog by remember { mutableStateOf(false) }

    // #3 Quick Template Dialogs
    var showCreateTemplateDialog by remember { mutableStateOf(false) }
    var templateToDelete by remember { mutableStateOf<QuickTemplateEntity?>(null) }

    BackHandler(enabled = isBulkMode) {
        selectedTxIds = emptySet()
    }

    val dueRecurring = remember(state.recurringTransactions, today) {
        val todayEpoch = today.toEpochDay()
        state.recurringTransactions.filter { it.isActive && !it.autoPost && it.nextDueEpochDay <= todayEpoch }
    }

    val filteredTransactions = remember(
        state.transactions,
        searchQuery,
        selectedHashtag,
        filterType,
        filterWalletId,
        filterCategoryId,
        datePreset,
        customStartMillis,
        customEndMillis,
        categoryMap,
        walletMap,
    ) {
        val normalizedQuery = Formatters.normalizeArabicDigits(searchQuery).trim().lowercase()
        state.transactions.filter { tx ->
            if (filterType != null && tx.type != filterType) return@filter false
            if (filterWalletId != null && tx.walletId != filterWalletId && tx.toWalletId != filterWalletId) return@filter false
            if (filterCategoryId != null && tx.categoryId != filterCategoryId) return@filter false
            if (selectedHashtag != null && !HashtagParser.matchesTag(tx.note, selectedHashtag!!)) return@filter false

            val txDate = Instant.ofEpochMilli(tx.timestamp).atZone(zone).toLocalDate()
            val matchesDate = when (datePreset) {
                DateFilterPreset.ALL -> true
                DateFilterPreset.TODAY -> txDate == today
                DateFilterPreset.LAST_7_DAYS -> !txDate.isBefore(today.minusDays(6)) && !txDate.isAfter(today)
                DateFilterPreset.THIS_MONTH -> !txDate.isBefore(state.budgetSnapshot.cycleStartDate) && !txDate.isAfter(today)
                DateFilterPreset.CUSTOM -> {
                    val startOk = customStartMillis == null || tx.timestamp >= customStartMillis!!
                    val endOk = customEndMillis == null || tx.timestamp <= (customEndMillis!! + 86_400_000L - 1)
                    startOk && endOk
                }
            }
            if (!matchesDate) return@filter false

            if (normalizedQuery.isNotEmpty()) {
                val catName = tx.categoryId?.let { categoryMap[it]?.name }.orEmpty().lowercase()
                val walletName = walletMap[tx.walletId]?.name.orEmpty().lowercase()
                val toWalletName = tx.toWalletId?.let { walletMap[it]?.name }.orEmpty().lowercase()
                val noteLower = tx.note.lowercase()
                val amountStr = Formatters.formatCompactNumber(tx.amount).lowercase()
                val rawAmountStr = tx.amount.toString()
                return@filter noteLower.contains(normalizedQuery) ||
                    catName.contains(normalizedQuery) ||
                    walletName.contains(normalizedQuery) ||
                    toWalletName.contains(normalizedQuery) ||
                    amountStr.contains(normalizedQuery) ||
                    rawAmountStr.contains(normalizedQuery)
            }
            true
        }
    }

    // #15 Group transactions by LocalDate
    val groupedTransactions = remember(filteredTransactions, zone) {
        filteredTransactions.groupBy { tx ->
            Instant.ofEpochMilli(tx.timestamp).atZone(zone).toLocalDate()
        }
    }

    val activeFilterCount = listOfNotNull(
        filterType,
        filterWalletId,
        filterCategoryId,
        selectedHashtag,
        if (datePreset != DateFilterPreset.ALL) datePreset else null,
    ).size

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter,
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 680.dp),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 108.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            // 1. Greeting + Level Pill + AI Coach Top Button + Cycle Badge
            item {
                HomeHeader(
                    remainingDays = state.budgetSnapshot.remainingDaysInCycle,
                    hasGeminiKey = state.settings.hasGeminiApiKey,
                    gamification = state.gamification,
                    onOpenThemesGallery = onOpenThemesGallery,
                    onOpenAiAdvisor = onOpenAiAdvisor,
                )
            }

            // 2. Master Balance Card with Privacy Eye Toggle (#25)
            item {
                MasterBalanceCard(
                    snapshot = state.budgetSnapshot,
                    isMasked = masked,
                    onTogglePrivacy = onTogglePrivacyMode,
                )
            }

            // 2b. Glowing AI Financial Coach Card
            item {
                AiCoachHomeCard(
                    hasGeminiKey = state.settings.hasGeminiApiKey,
                    onClick = onOpenAiAdvisor,
                )
            }

            // Active Trip / Event Mode Banner
            state.budgetSnapshot.activeTripSnapshot?.let { tripSnap ->
                item {
                    ActiveTripHomeBanner(tripSnapshot = tripSnap, isMasked = masked)
                }
            }

            // #8 & #9 Immediate Daily Limit / Low Balance Alerts
            if (state.budgetSnapshot.safeSpendStatus == SafeSpendStatus.DANGER ||
                state.budgetSnapshot.lowBalanceWallets.isNotEmpty()
            ) {
                item {
                    HomeAlertsBanner(
                        snapshot = state.budgetSnapshot,
                        isMasked = masked,
                    )
                }
            }

            // 3. Daily Safe-to-Spend Indicator
            item {
                DailySafeToSpendCard(snapshot = state.budgetSnapshot, isMasked = masked)
            }

            // 4. Wallets Horizontal Row (Tap opens Wallet Statement #24) + Internal Transfer
            item {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(
                            text = "المحافظ",
                            style = MaterialTheme.typography.titleLarge,
                            color = MaterialTheme.colorScheme.onBackground,
                        )
                        OutlinedButton(
                            onClick = { onOpenQuickLog(TransactionType.TRANSFER, state.wallets.firstOrNull()?.id) },
                            shape = RoundedCornerShape(14.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                            modifier = Modifier.testTag("internal_transfer_button"),
                        ) {
                            Icon(Icons.Rounded.SwapHoriz, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("تحويل بين المحافظ", style = MaterialTheme.typography.labelLarge)
                        }
                    }

                    LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        items(state.wallets, key = { it.id }) { wallet ->
                            WalletCardItem(
                                wallet = wallet,
                                isMasked = masked,
                                onClick = { onOpenWalletStatement(wallet.id) },
                            )
                        }
                    }
                }
            }

            // #3 Quick Transaction Templates Bar
            item {
                QuickTemplatesRow(
                    templates = state.quickTemplates,
                    categories = categoryMap,
                    isMasked = masked,
                    onTapTemplate = { tpl ->
                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        onLogQuickTemplate(tpl)
                    },
                    onLongPressTemplate = { tpl -> templateToDelete = tpl },
                    onAddTemplateClick = { showCreateTemplateDialog = true },
                )
            }

            // #4 Due Recurring Transactions Prompt
            if (dueRecurring.isNotEmpty()) {
                item {
                    DueRecurringCard(
                        dueItems = dueRecurring,
                        isMasked = masked,
                        onConfirmDue = { item ->
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            onConfirmRecurringDue(item)
                        },
                    )
                }
            }

            // 5. Zero-Spend Streak Card (#12 Haptic)
            item {
                ZeroSpendStreakCard(
                    snapshot = state.budgetSnapshot,
                    isMasked = masked,
                    onToggleZeroSpend = {
                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        onToggleZeroSpend()
                    },
                )
            }

            // 6. Bulk Action Bar (#16 & #18) OR Search & Multi-Criteria Filter Header (#13 & #14)
            item {
                if (isBulkMode) {
                    BulkSelectionBar(
                        selectedCount = selectedTxIds.size,
                        onDuplicateSingle = {
                            val singleId = selectedTxIds.firstOrNull()
                            val tx = state.transactions.firstOrNull { it.id == singleId }
                            if (tx != null) {
                                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                onDuplicateTransaction(tx)
                            }
                            selectedTxIds = emptySet()
                        },
                        onMoveClick = { showBulkMoveDialog = true },
                        onDeleteClick = {
                            onBulkDeleteTransactions(selectedTxIds)
                            selectedTxIds = emptySet()
                        },
                        onCancel = { selectedTxIds = emptySet() },
                    )
                } else {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text(
                                text = "سجل المعاملات",
                                style = MaterialTheme.typography.titleLarge,
                                color = MaterialTheme.colorScheme.onBackground,
                            )
                            Text(
                                text = "${filteredTransactions.size} معاملة",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }

                        // Instant Search Bar + Filter Toggle
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            OutlinedTextField(
                                value = searchQuery,
                                onValueChange = { searchQuery = it },
                                placeholder = { Text("ابحث بالملاحظة، التصنيف، المبلغ...") },
                                leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = "بحث") },
                                trailingIcon = {
                                    if (searchQuery.isNotEmpty()) {
                                        IconButton(onClick = { searchQuery = "" }) {
                                            Icon(Icons.Rounded.Close, contentDescription = "مسح البحث")
                                        }
                                    }
                                },
                                singleLine = true,
                                shape = RoundedCornerShape(16.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("home_search_input"),
                            )
                            Surface(
                                shape = RoundedCornerShape(16.dp),
                                color = if (activeFilterCount > 0 || showFiltersPanel) {
                                    semantic.emerald.copy(alpha = 0.2f)
                                } else {
                                    MaterialTheme.colorScheme.surface
                                },
                                border = BorderStroke(
                                    1.dp,
                                    if (activeFilterCount > 0 || showFiltersPanel) semantic.emerald else semantic.cardBorder,
                                ),
                                modifier = Modifier
                                    .size(54.dp)
                                    .clip(RoundedCornerShape(16.dp))
                                    .clickable { showFiltersPanel = !showFiltersPanel }
                                    .testTag("toggle_filters_button"),
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Rounded.FilterList,
                                        contentDescription = "تصفية المعاملات",
                                        tint = if (activeFilterCount > 0) semantic.emerald else MaterialTheme.colorScheme.onSurface,
                                    )
                                }
                            }
                        }

                        // Expandable Multi-Criteria Filters (#14)
                        AnimatedVisibility(visible = showFiltersPanel) {
                            FiltersPanel(
                                wallets = state.wallets,
                                categories = state.categories,
                                filterType = filterType,
                                filterWalletId = filterWalletId,
                                filterCategoryId = filterCategoryId,
                                datePreset = datePreset,
                                onSelectType = { filterType = it },
                                onSelectWallet = { filterWalletId = it },
                                onSelectCategory = { filterCategoryId = it },
                                onSelectDatePreset = { preset ->
                                    if (preset == DateFilterPreset.CUSTOM) {
                                        showDateRangePicker = true
                                    } else {
                                        datePreset = preset
                                    }
                                },
                                onResetFilters = {
                                    filterType = null
                                    filterWalletId = null
                                    filterCategoryId = null
                                    selectedHashtag = null
                                    datePreset = DateFilterPreset.ALL
                                    customStartMillis = null
                                    customEndMillis = null
                                },
                            )
                        }

                        // Clickable #Hashtags Summary Chips
                        if (state.hashtagSummaries.isNotEmpty()) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                            ) {
                                if (selectedHashtag != null) {
                                    FilterPill(
                                        label = "إلغاء الوسم ✕",
                                        selected = false,
                                        onClick = { selectedHashtag = null },
                                    )
                                }
                                state.hashtagSummaries.forEach { tagSummary ->
                                    val isTagSelected = selectedHashtag.equals(tagSummary.tag, ignoreCase = true)
                                    val tagLabel = "${tagSummary.tag} (${tagSummary.count}) • ${Formatters.formatEgp(tagSummary.totalExpense, isMasked = masked)}"
                                    Surface(
                                        shape = RoundedCornerShape(12.dp),
                                        color = if (isTagSelected) semantic.sky.copy(alpha = 0.22f) else MaterialTheme.colorScheme.surface,
                                        border = BorderStroke(1.dp, if (isTagSelected) semantic.sky else semantic.cardBorder),
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(12.dp))
                                            .clickable {
                                                selectedHashtag = if (isTagSelected) null else tagSummary.tag
                                            }
                                            .testTag("hashtag_chip_${tagSummary.tag}"),
                                    ) {
                                        Text(
                                            text = tagLabel,
                                            style = MaterialTheme.typography.labelMedium,
                                            color = if (isTagSelected) semantic.sky else MaterialTheme.colorScheme.onSurface,
                                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // 7. Grouped Daily Transactions List (#15)
            if (filteredTransactions.isEmpty()) {
                item {
                    EmptyStateCard(
                        icon = Icons.Rounded.ReceiptLong,
                        title = if (state.transactions.isEmpty()) "لسه مفيش معاملات مسجلة" else "مفيش نتائج مطابقة للبحث",
                        subtitle = if (state.transactions.isEmpty()) {
                            "اضغط على زر + تحت عشان تسجل أول مصروف أو دخل أو تلصق رسالة بنك."
                        } else {
                            "جرّب تغيير كلمات البحث أو إزالة الفلاتر."
                        },
                        actionText = if (state.transactions.isEmpty()) "سجل أول معاملة" else null,
                        onAction = if (state.transactions.isEmpty()) {
                            { onOpenQuickLog(TransactionType.EXPENSE, null) }
                        } else null,
                    )
                }
            } else {
                groupedTransactions.forEach { (date, dayTxs) ->
                    val dayExpenseTotal = dayTxs.filter { it.type == TransactionType.EXPENSE }.sumOf { it.amount }
                    val dayIncomeTotal = dayTxs.filter { it.type == TransactionType.INCOME }.sumOf { it.amount }
                    item(key = "header_${date.toEpochDay()}") {
                        DayGroupHeader(
                            date = date,
                            expenseTotal = dayExpenseTotal,
                            incomeTotal = dayIncomeTotal,
                            isMasked = masked,
                        )
                    }
                    items(
                        items = dayTxs,
                        key = { it.id },
                    ) { tx ->
                        val isSelected = tx.id in selectedTxIds
                        SwipeableTransactionRow(
                            tx = tx,
                            category = tx.categoryId?.let { categoryMap[it] },
                            wallet = walletMap[tx.walletId],
                            toWallet = tx.toWalletId?.let { walletMap[it] },
                            isMasked = masked,
                            isBulkMode = isBulkMode,
                            isSelected = isSelected,
                            onTap = {
                                if (isBulkMode) {
                                    selectedTxIds = if (isSelected) selectedTxIds - tx.id else selectedTxIds + tx.id
                                } else {
                                    onEditTransaction(tx)
                                }
                            },
                            onLongPress = {
                                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                selectedTxIds = if (isSelected) selectedTxIds - tx.id else selectedTxIds + tx.id
                            },
                            onTagClick = { tag ->
                                selectedHashtag = if (selectedHashtag.equals(tag, ignoreCase = true)) null else tag
                            },
                            onDelete = { onDeleteTransaction(tx) },
                        )
                    }
                }
            }
        }
    }

    // --- Dialogs ---
    if (showBulkMoveDialog) {
        BulkMoveWalletDialog(
            wallets = state.wallets,
            count = selectedTxIds.size,
            onConfirm = { targetId ->
                onBulkMoveTransactions(selectedTxIds, targetId)
                selectedTxIds = emptySet()
                showBulkMoveDialog = false
            },
            onDismiss = { showBulkMoveDialog = false },
        )
    }

    if (showCreateTemplateDialog) {
        CreateTemplateDialog(
            wallets = state.wallets,
            categories = state.categories,
            onSave = { title, amount, type, catId, wId, note ->
                onSaveQuickTemplate(title, amount, type, catId, wId, note)
                showCreateTemplateDialog = false
            },
            onDismiss = { showCreateTemplateDialog = false },
        )
    }

    templateToDelete?.let { tpl ->
        ConfirmActionDialog(
            title = "حذف القالب السريع؟",
            message = "هل تريد حذف قالب «${tpl.title}»؟",
            confirmText = "حذف",
            isDestructive = true,
            onConfirm = {
                onDeleteQuickTemplate(tpl.id)
                templateToDelete = null
            },
            onDismiss = { templateToDelete = null },
        )
    }

    if (showDateRangePicker) {
        val pickerState = rememberDateRangePickerState()
        DatePickerDialog(
            onDismissRequest = { showDateRangePicker = false },
            confirmButton = {
                TextButton(
                    onClick = {
                        customStartMillis = pickerState.selectedStartDateMillis
                        customEndMillis = pickerState.selectedEndDateMillis ?: pickerState.selectedStartDateMillis
                        datePreset = DateFilterPreset.CUSTOM
                        showDateRangePicker = false
                    },
                ) { Text("تطبيق") }
            },
            dismissButton = {
                TextButton(onClick = { showDateRangePicker = false }) { Text("إلغاء") }
            },
        ) {
            DateRangePicker(state = pickerState, modifier = Modifier.height(420.dp))
        }
    }
}

@Composable
private fun HomeHeader(
    remainingDays: Int,
    hasGeminiKey: Boolean,
    gamification: GamificationSnapshot,
    onOpenThemesGallery: () -> Unit,
    onOpenAiAdvisor: () -> Unit,
) {
    val semantic = LocalMasroufyColors.current
    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "مصروفي",
                    style = MaterialTheme.typography.headlineMedium,
                    color = MaterialTheme.colorScheme.onBackground,
                )
                Text(
                    text = "تحكم ذكي في فلوسك يوم بيوم",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = if (hasGeminiKey) semantic.emeraldContainer else semantic.amberContainer,
                    border = BorderStroke(
                        1.dp,
                        (if (hasGeminiKey) semantic.emerald else semantic.amber).copy(alpha = 0.55f),
                    ),
                    modifier = Modifier
                        .clip(RoundedCornerShape(14.dp))
                        .clickable(onClick = onOpenAiAdvisor)
                        .testTag("home_ai_topbar_button"),
                ) {
                    Box(
                        modifier = Modifier.size(42.dp),
                        contentAlignment = Alignment.Center,
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.AutoAwesome,
                            contentDescription = "المستشار المالي الذكي",
                            tint = if (hasGeminiKey) semantic.emerald else semantic.amber,
                            modifier = Modifier.size(20.dp),
                        )
                    }
                }
                Surface(
                    color = semantic.emeraldContainer,
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, semantic.emerald.copy(alpha = 0.4f)),
                ) {
                    Text(
                        text = "باقي $remainingDays يوم بالدورة",
                        style = MaterialTheme.typography.labelMedium,
                        color = semantic.emerald,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 9.dp),
                    )
                }
            }
        }

        // Gamification Level & XP Pill -> opens ThemesGallerySheet
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surface,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.35f)),
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .clickable(onClick = onOpenThemesGallery)
                .testTag("home_level_pill"),
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(4.dp),
                ) {
                    Text(
                        text = gamification.rank.title,
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    LinearProgressIndicator(
                        progress = { gamification.progressToNextLevel },
                        modifier = Modifier
                            .fillMaxWidth(0.85f)
                            .height(5.dp)
                            .clip(RoundedCornerShape(3.dp)),
                        color = MaterialTheme.colorScheme.primary,
                        trackColor = MaterialTheme.colorScheme.surfaceVariant,
                        strokeCap = StrokeCap.Round,
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = MaterialTheme.colorScheme.primary.copy(alpha = 0.16f),
                ) {
                    Text(
                        text = "${gamification.xp} XP • السمات",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                    )
                }
            }
        }
    }
}

@Composable
private fun AiCoachHomeCard(
    hasGeminiKey: Boolean,
    onClick: () -> Unit,
) {
    val semantic = LocalMasroufyColors.current
    val infiniteTransition = rememberInfiniteTransition(label = "ai_glow")
    val glowAlpha by infiniteTransition.animateFloat(
        initialValue = 0.45f,
        targetValue = 0.95f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1800, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse,
        ),
        label = "glow_alpha",
    )

    val borderBrush = Brush.linearGradient(
        colors = listOf(
            semantic.emerald.copy(alpha = glowAlpha),
            semantic.sky.copy(alpha = glowAlpha),
            semantic.amber.copy(alpha = glowAlpha * 0.9f),
        ),
    )

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .clickable(onClick = onClick)
            .testTag("home_ai_coach_card"),
        shape = RoundedCornerShape(20.dp),
        border = BorderStroke(1.6.dp, borderBrush),
        shadowElevation = 6.dp,
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.horizontalGradient(
                        colors = listOf(
                            semantic.emerald.copy(alpha = 0.16f),
                            semantic.sky.copy(alpha = 0.14f),
                            MaterialTheme.colorScheme.surface,
                        ),
                    ),
                )
                .padding(horizontal = 16.dp, vertical = 14.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Box(
                    modifier = Modifier
                        .size(46.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.linearGradient(
                                listOf(semantic.emerald, semantic.sky),
                            ),
                        ),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(
                        imageVector = Icons.Rounded.AutoAwesome,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(24.dp),
                    )
                }
                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(3.dp),
                ) {
                    Text(
                        text = "اسأل المستشار المالي ✨",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                    )
                    Text(
                        text = if (hasGeminiKey) {
                            "متصل بـ Gemini AI • حلل مصاريفك واسأل عن خطط التحويش"
                        } else {
                            "الوضع الأوفلاين الذكي جاهز • فعّل Gemini مجاناً في 30 ثانية"
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = if (hasGeminiKey) semantic.emerald.copy(alpha = 0.18f) else semantic.amber.copy(alpha = 0.18f),
                ) {
                    Text(
                        text = if (hasGeminiKey) "تحدث الآن" else "اسأل الآن",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = if (hasGeminiKey) semantic.emerald else semantic.amber,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                    )
                }
            }
        }
    }
}

@Composable
private fun MasterBalanceCard(
    snapshot: BudgetSnapshot,
    isMasked: Boolean,
    onTogglePrivacy: () -> Unit,
) {
    val semantic = LocalMasroufyColors.current
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("master_balance_card"),
        shape = RoundedCornerShape(24.dp),
        border = BorderStroke(1.dp, semantic.emerald.copy(alpha = 0.35f)),
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.linearGradient(
                        colors = listOf(semantic.heroStart, semantic.heroEnd),
                    ),
                )
                .padding(20.dp),
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "إجمالي الرصيد",
                                style = MaterialTheme.typography.bodyMedium,
                                color = Color(0xFF94A3B8),
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            // #25 Privacy Eye Mode Toggle
                            IconButton(
                                onClick = onTogglePrivacy,
                                modifier = Modifier
                                    .size(32.dp)
                                    .testTag("privacy_eye_button"),
                            ) {
                                Icon(
                                    imageVector = if (isMasked) Icons.Rounded.VisibilityOff else Icons.Rounded.Visibility,
                                    contentDescription = if (isMasked) "إظهار الأرقام" else "إخفاء الأرقام",
                                    tint = Color(0xFF94A3B8),
                                    modifier = Modifier.size(18.dp),
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = Formatters.formatEgp(snapshot.totalLiquidity, isMasked = isMasked),
                            style = MaterialTheme.typography.displayMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                        )
                    }
                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .background(semantic.emerald.copy(alpha = 0.18f)),
                        contentAlignment = Alignment.Center,
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.AccountBalanceWallet,
                            contentDescription = "إجمالي الرصيد",
                            tint = semantic.emerald,
                            modifier = Modifier.size(26.dp),
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    Surface(
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(16.dp),
                        color = semantic.emerald.copy(alpha = 0.13f),
                        border = BorderStroke(1.dp, semantic.emerald.copy(alpha = 0.35f)),
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Rounded.TrendingUp, contentDescription = null, tint = semantic.emerald, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("الحر المتاح للصرف", style = MaterialTheme.typography.labelSmall, color = Color(0xFFA7F3D0))
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = Formatters.formatEgp(snapshot.freeBalance, isMasked = isMasked),
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                            )
                        }
                    }

                    Surface(
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(16.dp),
                        color = semantic.amber.copy(alpha = 0.13f),
                        border = BorderStroke(1.dp, semantic.amber.copy(alpha = 0.35f)),
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Rounded.Lock, contentDescription = null, tint = semantic.amber, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("محجوز للالتزامات", style = MaterialTheme.typography.labelSmall, color = Color(0xFFFDE68A))
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = Formatters.formatEgp(snapshot.reservedTotal, isMasked = isMasked),
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun HomeAlertsBanner(
    snapshot: BudgetSnapshot,
    isMasked: Boolean,
) {
    val semantic = LocalMasroufyColors.current
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        if (snapshot.safeSpendStatus == SafeSpendStatus.DANGER) {
            Surface(
                color = semantic.coralContainer,
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, semantic.coral),
                modifier = Modifier.testTag("daily_limit_exceeded_banner"),
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(Icons.Rounded.WarningAmber, contentDescription = null, tint = semantic.coral, modifier = Modifier.size(22.dp))
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "تنبيه: صرفت اليوم ${Formatters.formatEgp(snapshot.todaySpent, isMasked = isMasked)} وتجاوزت الحد الآمن اليومي (${Formatters.formatEgp(snapshot.dailySafeLimit, isMasked = isMasked)})!",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface,
                    )
                }
            }
        }
        if (snapshot.lowBalanceWallets.isNotEmpty()) {
            val names = snapshot.lowBalanceWallets.joinToString("، ") { it.name }
            Surface(
                color = semantic.amberContainer,
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, semantic.amber),
                modifier = Modifier.testTag("low_wallet_alert_banner"),
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(Icons.Rounded.WarningAmber, contentDescription = null, tint = semantic.amber, modifier = Modifier.size(22.dp))
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "رصيد منخفض في: $names",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface,
                    )
                }
            }
        }
    }
}

@Composable
private fun ActiveTripHomeBanner(tripSnapshot: TripSnapshot, isMasked: Boolean) {
    val semantic = LocalMasroufyColors.current
    val over = tripSnapshot.trip.budget > 0.0 && tripSnapshot.spent > tripSnapshot.trip.budget
    val accent = if (over) semantic.coral else semantic.sky

    FintechCard(
        borderColor = accent.copy(alpha = 0.5f),
        containerColor = accent.copy(alpha = 0.12f),
        modifier = Modifier.testTag("active_trip_banner"),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                IconBadge(icon = Icons.Rounded.FlightTakeoff, tint = accent, contentDescription = "وضع الرحلة", size = 38.dp)
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text("وضع الرحلة نشط: ${tripSnapshot.trip.title} 🏖️", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                    Text(
                        text = "صرفت ${Formatters.formatEgp(tripSnapshot.spent, isMasked = isMasked)} من ${Formatters.formatEgp(tripSnapshot.trip.budget, isMasked = isMasked)} (معزول عن الحد اليومي)",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
        Spacer(modifier = Modifier.height(8.dp))
        LinearProgressIndicator(
            progress = { tripSnapshot.ratio.coerceIn(0f, 1f) },
            modifier = Modifier.fillMaxWidth().height(7.dp).clip(RoundedCornerShape(6.dp)),
            color = accent,
            trackColor = MaterialTheme.colorScheme.surfaceVariant,
            strokeCap = StrokeCap.Round,
        )
    }
}

@Composable
private fun DailySafeToSpendCard(snapshot: BudgetSnapshot, isMasked: Boolean) {
    val semantic = LocalMasroufyColors.current
    val targetColor = when (snapshot.safeSpendStatus) {
        SafeSpendStatus.SAFE -> semantic.emerald
        SafeSpendStatus.CAUTION -> semantic.amber
        SafeSpendStatus.DANGER -> semantic.coral
    }
    val statusColor by animateColorAsState(targetColor, animationSpec = tween(350), label = "safeColor")
    val animatedProgress by animateFloatAsState(
        targetValue = snapshot.todaySpendRatio.coerceIn(0f, 1f),
        animationSpec = tween(450),
        label = "safeProgress",
    )

    val statusText = when {
        snapshot.dailySafeLimit <= 0.0 && snapshot.todaySpent == 0.0 -> "أضف رصيداً في محافظك لحساب حد الصرف اليومي"
        snapshot.remainingToday >= 0.0 -> "متاح تصرف بأمان النهارده: ${Formatters.formatEgp(snapshot.remainingToday, isMasked = isMasked)}"
        else -> "تجاوزت الحد اليومي بـ ${Formatters.formatEgp(-snapshot.remainingToday, isMasked = isMasked)}"
    }

    FintechCard(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("daily_safe_card"),
        borderColor = statusColor.copy(alpha = 0.45f),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconBadge(icon = Icons.Rounded.Shield, tint = statusColor, contentDescription = "مؤشر الأمان اليومي", size = 40.dp)
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text("مؤشر الأمان اليومي", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurface)
                    Text(
                        "الحد الآمن: ${Formatters.formatEgp(snapshot.dailySafeLimit, isMasked = isMasked)} / يوم",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
            Surface(color = statusColor.copy(alpha = 0.16f), shape = RoundedCornerShape(12.dp)) {
                Text(
                    text = when (snapshot.safeSpendStatus) {
                        SafeSpendStatus.SAFE -> "آمن"
                        SafeSpendStatus.CAUTION -> "احذر"
                        SafeSpendStatus.DANGER -> "تجاوز"
                    },
                    style = MaterialTheme.typography.labelLarge,
                    color = statusColor,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                )
            }
        }
        if (snapshot.rolloverMode == RolloverMode.TODAY_BONUS && snapshot.yesterdaySurplusBonus > 0.5) {
            Spacer(modifier = Modifier.height(8.dp))
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = semantic.emerald.copy(alpha = 0.14f),
                border = BorderStroke(1.dp, semantic.emerald.copy(alpha = 0.4f)),
            ) {
                Text(
                    text = "✨ فائض الأمس المتاح لك اليوم: +${Formatters.formatEgp(snapshot.yesterdaySurplusBonus, isMasked = isMasked)}",
                    style = MaterialTheme.typography.labelSmall,
                    color = semantic.emerald,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                )
            }
        }
        Spacer(modifier = Modifier.height(14.dp))
        LinearProgressIndicator(
            progress = { animatedProgress },
            modifier = Modifier
                .fillMaxWidth()
                .height(10.dp)
                .clip(RoundedCornerShape(8.dp)),
            color = statusColor,
            trackColor = MaterialTheme.colorScheme.surfaceVariant,
            strokeCap = StrokeCap.Round,
        )
        Spacer(modifier = Modifier.height(10.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                text = statusText,
                style = MaterialTheme.typography.bodySmall,
                fontWeight = FontWeight.Medium,
                color = statusColor,
                modifier = Modifier.weight(1f),
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "صرفت اليوم: ${Formatters.formatEgp(snapshot.todaySpent, isMasked = isMasked)}",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
private fun WalletCardItem(
    wallet: WalletEntity,
    isMasked: Boolean,
    onClick: () -> Unit,
) {
    val semantic = LocalMasroufyColors.current
    val wColor = Color(wallet.colorHex)
    val isLow = wallet.minBalanceThreshold > 0.0 && wallet.balance < wallet.minBalanceThreshold
    FintechCard(
        modifier = Modifier
            .width(172.dp)
            .testTag("wallet_card_${wallet.name}"),
        borderColor = if (isLow) semantic.amber else wColor.copy(alpha = 0.35f),
        cornerRadius = 18.dp,
        onClick = onClick,
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconBadge(
                icon = IconsCatalog.resolve(wallet.iconKey),
                tint = wColor,
                contentDescription = wallet.name,
                size = 38.dp,
            )
            if (isLow) {
                Icon(
                    imageVector = Icons.Rounded.WarningAmber,
                    contentDescription = "رصيد منخفض",
                    tint = semantic.amber,
                    modifier = Modifier.size(18.dp),
                )
            }
        }
        Spacer(modifier = Modifier.height(12.dp))
        Text(
            text = wallet.name,
            style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = Formatters.formatEgp(wallet.balance, isMasked = isMasked),
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface,
            maxLines = 1,
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun QuickTemplatesRow(
    templates: List<QuickTemplateEntity>,
    categories: Map<Long, CategoryEntity>,
    isMasked: Boolean,
    onTapTemplate: (QuickTemplateEntity) -> Unit,
    onLongPressTemplate: (QuickTemplateEntity) -> Unit,
    onAddTemplateClick: () -> Unit,
) {
    val semantic = LocalMasroufyColors.current
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text("قوالب سريعة", style = MaterialTheme.typography.titleMedium)
            Text(
                text = "اضغط للتسجيل الفوري",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = semantic.emerald.copy(alpha = 0.14f),
                border = BorderStroke(1.dp, semantic.emerald.copy(alpha = 0.5f)),
                modifier = Modifier
                    .clip(RoundedCornerShape(14.dp))
                    .clickable(onClick = onAddTemplateClick)
                    .testTag("add_quick_template_chip"),
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 9.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(Icons.Rounded.BookmarkAdd, contentDescription = null, tint = semantic.emerald, modifier = Modifier.size(17.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("قالب جديد", style = MaterialTheme.typography.labelLarge, color = semantic.emerald)
                }
            }

            templates.forEach { tpl ->
                val cat = tpl.categoryId?.let { categories[it] }
                val accent = cat?.let { Color(it.colorHex) }
                    ?: if (tpl.type == TransactionType.INCOME) semantic.emerald else semantic.coral
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.surface,
                    border = BorderStroke(1.dp, semantic.cardBorder),
                    modifier = Modifier
                        .clip(RoundedCornerShape(14.dp))
                        .combinedClickable(
                            onClick = { onTapTemplate(tpl) },
                            onLongClick = { onLongPressTemplate(tpl) },
                        )
                        .testTag("quick_template_${tpl.id}"),
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 9.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Icon(
                            imageVector = IconsCatalog.resolve(cat?.iconKey ?: "other"),
                            contentDescription = null,
                            tint = accent,
                            modifier = Modifier.size(16.dp),
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "${tpl.title} • ${Formatters.formatEgp(tpl.amount, isMasked = isMasked)}",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurface,
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun DueRecurringCard(
    dueItems: List<RecurringTransactionEntity>,
    isMasked: Boolean,
    onConfirmDue: (RecurringTransactionEntity) -> Unit,
) {
    val semantic = LocalMasroufyColors.current
    FintechCard(borderColor = semantic.sky.copy(alpha = 0.5f)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconBadge(icon = Icons.Rounded.EventRepeat, tint = semantic.sky, contentDescription = "معاملات مستحقة", size = 38.dp)
            Spacer(modifier = Modifier.width(10.dp))
            Text(
                text = "معاملات متكررة مستحقة (${dueItems.size})",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
            )
        }
        Spacer(modifier = Modifier.height(10.dp))
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            dueItems.forEach { item ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(item.title, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
                        Text(
                            Formatters.formatEgp(item.amount, isMasked = isMasked),
                            style = MaterialTheme.typography.labelMedium,
                            color = if (item.type == TransactionType.INCOME) semantic.emerald else semantic.coral,
                        )
                    }
                    Button(
                        onClick = { onConfirmDue(item) },
                        shape = RoundedCornerShape(12.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    ) {
                        Text("تسجيل الآن", style = MaterialTheme.typography.labelMedium)
                    }
                }
            }
        }
    }
}

@Composable
private fun ZeroSpendStreakCard(
    snapshot: BudgetSnapshot,
    isMasked: Boolean,
    onToggleZeroSpend: () -> Unit,
) {
    val semantic = LocalMasroufyColors.current
    val confirmed = snapshot.isTodayZeroSpendConfirmed
    val hasExpenseToday = snapshot.todaySpent > 0.0

    FintechCard(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("zero_spend_card"),
        borderColor = if (confirmed) semantic.emerald.copy(alpha = 0.6f) else semantic.cardBorder,
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                IconBadge(
                    icon = Icons.Rounded.LocalFireDepartment,
                    tint = semantic.amber,
                    contentDescription = "تحدي بدون صرف",
                    size = 46.dp,
                )
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text("تحدي بدون صرف", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurface)
                    Text(
                        "سلسلتك: ${snapshot.zeroSpendStreak} يوم • وفّرت تقريباً ${Formatters.formatEgp(snapshot.estimatedMonthlySaved, isMasked = isMasked)}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        Button(
            onClick = onToggleZeroSpend,
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .testTag("zero_spend_button"),
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = when {
                    confirmed -> semantic.emeraldContainer
                    hasExpenseToday -> MaterialTheme.colorScheme.surfaceVariant
                    else -> semantic.emerald
                },
                contentColor = when {
                    confirmed -> semantic.emerald
                    hasExpenseToday -> MaterialTheme.colorScheme.onSurfaceVariant
                    else -> Color.White
                },
            ),
        ) {
            Icon(Icons.Rounded.CheckCircle, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = when {
                    confirmed -> "تم تسجيل اليوم بدون صرف ✓ (اضغط للإلغاء)"
                    hasExpenseToday -> "تم تسجيل مصروف اليوم — ابدأ التحدي بكرة"
                    else -> "عدّيت اليوم بدون صرف"
                },
                style = MaterialTheme.typography.labelLarge,
            )
        }
    }
}

@Composable
private fun BulkSelectionBar(
    selectedCount: Int,
    onDuplicateSingle: () -> Unit,
    onMoveClick: () -> Unit,
    onDeleteClick: () -> Unit,
    onCancel: () -> Unit,
) {
    val semantic = LocalMasroufyColors.current
    FintechCard(
        borderColor = semantic.emerald,
        containerColor = semantic.emeraldContainer.copy(alpha = 0.4f),
        modifier = Modifier.testTag("bulk_selection_bar"),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                text = "تم تحديد $selectedCount",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
            )
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                if (selectedCount == 1) {
                    IconButton(onClick = onDuplicateSingle, modifier = Modifier.testTag("bulk_duplicate_button")) {
                        Icon(Icons.Rounded.ContentCopy, contentDescription = "تكرار المعاملة", tint = semantic.sky)
                    }
                }
                IconButton(onClick = onMoveClick, modifier = Modifier.testTag("bulk_move_button")) {
                    Icon(Icons.Rounded.DriveFileMove, contentDescription = "نقل لمحفظة", tint = semantic.emerald)
                }
                IconButton(onClick = onDeleteClick, modifier = Modifier.testTag("bulk_delete_button")) {
                    Icon(Icons.Rounded.DeleteOutline, contentDescription = "حذف المحدد", tint = semantic.coral)
                }
                IconButton(onClick = onCancel) {
                    Icon(Icons.Rounded.Close, contentDescription = "إلغاء التحديد")
                }
            }
        }
    }
}

@Composable
private fun FiltersPanel(
    wallets: List<WalletEntity>,
    categories: List<CategoryEntity>,
    filterType: String?,
    filterWalletId: Long?,
    filterCategoryId: Long?,
    datePreset: DateFilterPreset,
    onSelectType: (String?) -> Unit,
    onSelectWallet: (Long?) -> Unit,
    onSelectCategory: (Long?) -> Unit,
    onSelectDatePreset: (DateFilterPreset) -> Unit,
    onResetFilters: () -> Unit,
) {
    val semantic = LocalMasroufyColors.current
    FintechCard(cornerRadius = 16.dp) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text("تصفية متقدمة", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            TextButton(onClick = onResetFilters) { Text("إعادة ضبط") }
        }

        // Type chips
        Row(
            modifier = Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            listOf(
                null to "الكل",
                TransactionType.EXPENSE to "مصروف",
                TransactionType.INCOME to "دخل",
                TransactionType.TRANSFER to "تحويل",
            ).forEach { (key, label) ->
                FilterPill(label = label, selected = filterType == key, onClick = { onSelectType(key) })
            }
        }

        Spacer(modifier = Modifier.height(8.dp))
        // Date Presets
        Row(
            modifier = Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            DateFilterPreset.entries.forEach { preset ->
                FilterPill(label = preset.label, selected = datePreset == preset, onClick = { onSelectDatePreset(preset) })
            }
        }

        Spacer(modifier = Modifier.height(8.dp))
        // Wallet Filter
        Row(
            modifier = Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            FilterPill(label = "كل المحافظ", selected = filterWalletId == null, onClick = { onSelectWallet(null) })
            wallets.forEach { w ->
                FilterPill(label = w.name, selected = filterWalletId == w.id, onClick = { onSelectWallet(w.id) })
            }
        }

        Spacer(modifier = Modifier.height(8.dp))
        // Category Filter
        Row(
            modifier = Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            FilterPill(label = "كل التصنيفات", selected = filterCategoryId == null, onClick = { onSelectCategory(null) })
            categories.forEach { c ->
                FilterPill(label = c.name, selected = filterCategoryId == c.id, onClick = { onSelectCategory(c.id) })
            }
        }
    }
}

@Composable
private fun FilterPill(label: String, selected: Boolean, onClick: () -> Unit) {
    val semantic = LocalMasroufyColors.current
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = if (selected) semantic.emerald.copy(alpha = 0.2f) else MaterialTheme.colorScheme.surfaceVariant,
        border = BorderStroke(1.dp, if (selected) semantic.emerald else semantic.cardBorder),
        modifier = Modifier
            .clip(RoundedCornerShape(10.dp))
            .clickable(onClick = onClick),
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium,
            color = if (selected) semantic.emerald else MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
        )
    }
}

@Composable
private fun DayGroupHeader(
    date: LocalDate,
    expenseTotal: Double,
    incomeTotal: Double,
    isMasked: Boolean,
) {
    val semantic = LocalMasroufyColors.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 6.dp, bottom = 2.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            text = Formatters.formatDayHeader(date),
            style = MaterialTheme.typography.labelLarge,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (expenseTotal > 0.0) {
                Text(
                    text = "صرفت ${Formatters.formatEgp(expenseTotal, isMasked = isMasked)}",
                    style = MaterialTheme.typography.labelSmall,
                    color = semantic.coral,
                )
            }
            if (incomeTotal > 0.0) {
                Text(
                    text = "دخل ${Formatters.formatEgp(incomeTotal, isMasked = isMasked)}",
                    style = MaterialTheme.typography.labelSmall,
                    color = semantic.emerald,
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
private fun SwipeableTransactionRow(
    tx: TransactionEntity,
    category: CategoryEntity?,
    wallet: WalletEntity?,
    toWallet: WalletEntity?,
    isMasked: Boolean,
    isBulkMode: Boolean,
    isSelected: Boolean,
    onTap: () -> Unit,
    onLongPress: () -> Unit,
    onTagClick: (String) -> Unit,
    onDelete: () -> Unit,
) {
    val semantic = LocalMasroufyColors.current
    val rowTags = remember(tx.note) { HashtagParser.extractTags(tx.note) }
    val dismissState = rememberSwipeToDismissBoxState(
        confirmValueChange = { value ->
            if (!isBulkMode && (value == SwipeToDismissBoxValue.EndToStart || value == SwipeToDismissBoxValue.StartToEnd)) {
                onDelete()
                true
            } else {
                false
            }
        },
    )

    SwipeToDismissBox(
        state = dismissState,
        enableDismissFromStartToEnd = !isBulkMode,
        enableDismissFromEndToStart = !isBulkMode,
        backgroundContent = {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .clip(RoundedCornerShape(18.dp))
                    .background(semantic.coral.copy(alpha = 0.22f))
                    .padding(horizontal = 20.dp),
                contentAlignment = Alignment.CenterEnd,
            ) {
                Icon(Icons.Rounded.DeleteOutline, contentDescription = "حذف المعاملة", tint = semantic.coral)
            }
        },
        content = {
            val (accent, icon, titleText) = when (tx.type) {
                TransactionType.INCOME -> Triple(
                    semantic.emerald,
                    IconsCatalog.resolve(category?.iconKey ?: "salary"),
                    category?.name ?: "دخل",
                )
                TransactionType.TRANSFER -> Triple(
                    semantic.sky,
                    Icons.Rounded.SwapHoriz,
                    "تحويل بين المحافظ",
                )
                else -> Triple(
                    category?.let { Color(it.colorHex) } ?: semantic.coral,
                    IconsCatalog.resolve(category?.iconKey ?: "other"),
                    category?.name ?: "مصروف",
                )
            }

            val walletSubtitle = if (tx.type == TransactionType.TRANSFER) {
                "${wallet?.name ?: "محفظة"} ← ${toWallet?.name ?: "محفظة"}"
            } else {
                wallet?.name ?: "محفظة"
            }

            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(18.dp))
                    .combinedClickable(
                        onClick = onTap,
                        onLongClick = onLongPress,
                    )
                    .testTag("tx_item_${tx.id}"),
                shape = RoundedCornerShape(18.dp),
                color = if (isSelected) semantic.emerald.copy(alpha = 0.14f) else MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, if (isSelected) semantic.emerald else semantic.cardBorder),
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    if (isBulkMode) {
                        Checkbox(checked = isSelected, onCheckedChange = { onTap() })
                        Spacer(modifier = Modifier.width(4.dp))
                    }
                    IconBadge(icon = icon, tint = accent, contentDescription = titleText, size = 44.dp)
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (tx.note.isNotBlank()) "$titleText • ${tx.note}" else titleText,
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurface,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                        ) {
                            Surface(color = MaterialTheme.colorScheme.surfaceVariant, shape = RoundedCornerShape(8.dp)) {
                                Text(
                                    text = walletSubtitle,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                )
                            }
                            if (tx.tripEventId != null) {
                                Surface(color = semantic.sky.copy(alpha = 0.18f), shape = RoundedCornerShape(8.dp)) {
                                    Text(
                                        text = "رحلة 🏖️",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = semantic.sky,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                    )
                                }
                            }
                            Text(
                                text = Formatters.formatRelativeDateTime(tx.timestamp),
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1,
                            )
                        }
                        if (rowTags.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(
                                modifier = Modifier.horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                            ) {
                                rowTags.forEach { tag ->
                                    Surface(
                                        shape = RoundedCornerShape(8.dp),
                                        color = semantic.sky.copy(alpha = 0.14f),
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(8.dp))
                                            .clickable { onTagClick(tag) },
                                    ) {
                                        Text(
                                            text = tag,
                                            style = MaterialTheme.typography.labelSmall,
                                            color = semantic.sky,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                        )
                                    }
                                }
                            }
                        }
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    val amountColor = when (tx.type) {
                        TransactionType.INCOME -> semantic.emerald
                        TransactionType.TRANSFER -> semantic.sky
                        else -> semantic.coral
                    }
                    val formattedAmount = when (tx.type) {
                        TransactionType.INCOME -> Formatters.formatEgp(tx.amount, showPositiveSign = true, isMasked = isMasked)
                        TransactionType.EXPENSE -> Formatters.formatEgp(-tx.amount, isMasked = isMasked)
                        else -> Formatters.formatEgp(tx.amount, isMasked = isMasked)
                    }
                    Text(
                        text = formattedAmount,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = amountColor,
                    )
                }
            }
        },
    )
}

@Composable
private fun BulkMoveWalletDialog(
    wallets: List<WalletEntity>,
    count: Int,
    onConfirm: (Long) -> Unit,
    onDismiss: () -> Unit,
) {
    var selectedWalletId by remember { mutableLongStateOf(wallets.firstOrNull()?.id ?: 0L) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("نقل $count معاملة إلى محفظة", style = MaterialTheme.typography.titleLarge) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                wallets.forEach { w ->
                    val selected = selectedWalletId == w.id
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { selectedWalletId = w.id },
                        shape = RoundedCornerShape(12.dp),
                        color = if (selected) MaterialTheme.colorScheme.primary.copy(alpha = 0.2f) else MaterialTheme.colorScheme.surfaceVariant,
                        border = BorderStroke(1.dp, if (selected) MaterialTheme.colorScheme.primary else LocalMasroufyColors.current.cardBorder),
                    ) {
                        Text(w.name, modifier = Modifier.padding(12.dp), style = MaterialTheme.typography.labelLarge)
                    }
                }
            }
        },
        confirmButton = {
            Button(onClick = { if (selectedWalletId != 0L) onConfirm(selectedWalletId) }) { Text("نقل") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } },
        containerColor = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(22.dp),
    )
}

@Composable
private fun CreateTemplateDialog(
    wallets: List<WalletEntity>,
    categories: List<CategoryEntity>,
    onSave: (title: String, amount: Double, type: String, categoryId: Long?, walletId: Long, note: String) -> Unit,
    onDismiss: () -> Unit,
) {
    var title by remember { mutableStateOf("") }
    var amountText by remember { mutableStateOf("") }
    var type by remember { mutableStateOf(TransactionType.EXPENSE) }
    val cats = remember(categories, type) { categories.filter { it.type == type } }
    var selectedCatId by remember(cats) { mutableStateOf(cats.firstOrNull()?.id) }
    var selectedWalletId by remember { mutableLongStateOf(wallets.firstOrNull()?.id ?: 0L) }
    var error by remember { mutableStateOf<String?>(null) }
    val semantic = LocalMasroufyColors.current

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("إنشاء قالب معاملة سريعة", style = MaterialTheme.typography.titleLarge) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(TransactionType.EXPENSE to "مصروف", TransactionType.INCOME to "دخل").forEach { (k, lbl) ->
                        val sel = type == k
                        Surface(
                            modifier = Modifier.weight(1f).clickable { type = k },
                            shape = RoundedCornerShape(12.dp),
                            color = if (sel) semantic.emerald.copy(alpha = 0.2f) else MaterialTheme.colorScheme.surfaceVariant,
                            border = BorderStroke(1.dp, if (sel) semantic.emerald else semantic.cardBorder),
                        ) {
                            Text(lbl, modifier = Modifier.padding(8.dp), style = MaterialTheme.typography.labelLarge)
                        }
                    }
                }
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it; error = null },
                    label = { Text("اسم القالب (مثلاً: مواصلات)") },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = amountText,
                    onValueChange = { amountText = it; error = null },
                    label = { Text("المبلغ (ج.م)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth(),
                )
                Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    cats.forEach { c ->
                        FilterPill(label = c.name, selected = selectedCatId == c.id, onClick = { selectedCatId = c.id })
                    }
                }
                Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    wallets.forEach { w ->
                        FilterPill(label = w.name, selected = selectedWalletId == w.id, onClick = { selectedWalletId = w.id })
                    }
                }
                error?.let { Text(it, color = semantic.coral, style = MaterialTheme.typography.bodySmall) }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amt = Formatters.parseSafeDouble(amountText) ?: 0.0
                    when {
                        title.isBlank() -> error = "اكتب اسم القالب"
                        amt <= 0.0 -> error = "أدخل مبلغاً أكبر من صفر"
                        selectedWalletId == 0L -> error = "اختر المحفظة"
                        else -> onSave(title, amt, type, selectedCatId, selectedWalletId, title)
                    }
                },
            ) { Text("حفظ القالب") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } },
        containerColor = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(22.dp),
    )
}
