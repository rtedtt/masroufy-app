package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Core Brand Palette (Slate + Emerald + Coral + Amber)
val DeepSlate = Color(0xFF0F172A)
val ElevatedSlate = Color(0xFF1E293B)
val SlateSurfaceVariant = Color(0xFF273449)
val SlateBorder = Color(0xFF334155)
val SlateTextSecondary = Color(0xFF94A3B8)
val SlateTextPrimary = Color(0xFFF8FAFC)

val EmeraldGreen = Color(0xFF10B981)
val EmeraldDark = Color(0xFF059669)
val EmeraldContainerDark = Color(0xFF064E3B)
val EmeraldContainerLight = Color(0xFFD1FAE5)

val CoralRed = Color(0xFFEF4444)
val CoralDark = Color(0xFFDC2626)
val CoralContainerDark = Color(0xFF7F1D1D)
val CoralContainerLight = Color(0xFFFEE2E2)

val AmberGold = Color(0xFFF59E0B)
val AmberDark = Color(0xFFD97706)
val AmberContainerDark = Color(0xFF78350F)
val AmberContainerLight = Color(0xFFFEF3C7)

val SkyBlue = Color(0xFF38BDF8)
val SkyBlueDark = Color(0xFF0284C7)

// Light Mode Surfaces
val LightBackground = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFF1F5F9)
val LightBorder = Color(0xFFE2E8F0)
val LightTextPrimary = Color(0xFF0F172A)
val LightTextSecondary = Color(0xFF475569)
