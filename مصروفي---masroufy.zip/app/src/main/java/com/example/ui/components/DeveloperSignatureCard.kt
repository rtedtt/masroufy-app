package com.example.ui.components

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas as AndroidCanvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.net.Uri
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Chat
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.Verified
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.common.BitMatrix
import com.google.zxing.qrcode.QRCodeWriter
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel
import java.io.File

object DeveloperProfile {
    const val DEVELOPER_NAME = "بلال محمد سليمان"
    const val PHONE_DISPLAY = "01128079357"
    const val PHONE_WHATSAPP_URL = "https://wa.me/201128079357"
    const val MONOGRAM = "ب م"

    const val VCARD_PAYLOAD =
        "BEGIN:VCARD\n" +
            "VERSION:3.0\n" +
            "N:سليمان;بلال محمد;;;\n" +
            "FN:بلال محمد سليمان\n" +
            "TEL;TYPE=CELL:+201128079357\n" +
            "NOTE:مطور تطبيق مصروفي (Masroufy)\n" +
            "END:VCARD"
}

object QrMatrixHelper {
    fun generateMatrix(payload: String = DeveloperProfile.VCARD_PAYLOAD): BitMatrix {
        val hints = mapOf(
            EncodeHintType.ERROR_CORRECTION to ErrorCorrectionLevel.H,
            EncodeHintType.CHARACTER_SET to "UTF-8",
            EncodeHintType.MARGIN to 1,
        )
        return QRCodeWriter().encode(payload, BarcodeFormat.QR_CODE, 0, 0, hints)
    }

    fun isInFinderPattern(x: Int, y: Int, size: Int, quietMargin: Int): Boolean {
        val finderEnd = quietMargin + 7
        val rightStart = size - quietMargin - 7
        val inTopLeft = x in quietMargin until finderEnd && y in quietMargin until finderEnd
        val inTopRight = x in rightStart until (size - quietMargin) && y in quietMargin until finderEnd
        val inBottomLeft = x in quietMargin until finderEnd && y in rightStart until (size - quietMargin)
        return inTopLeft || inTopRight || inBottomLeft
    }

    fun detectQuietMargin(matrix: BitMatrix): Int {
        val size = matrix.width
        for (y in 0 until size) {
            for (x in 0 until size) {
                if (matrix.get(x, y)) return minOf(x, y)
            }
        }
        return 1
    }
}

@Composable
fun ArtisticDeveloperQrCode(
    modifier: Modifier = Modifier,
) {
    val matrix = remember { QrMatrixHelper.generateMatrix() }
    val matrixSize = matrix.width
    val quietMargin = remember(matrix) { QrMatrixHelper.detectQuietMargin(matrix) }

    val emerald = Color(0xFF10B981)
    val cyan = Color(0xFF06B6D4)
    val gold = Color(0xFFF59E0B)
    val deepSlate = Color(0xFF0B1120)

    Box(
        modifier = modifier
            .aspectRatio(1f)
            .clip(RoundedCornerShape(22.dp))
            .background(deepSlate)
            .border(
                width = 1.5.dp,
                brush = Brush.linearGradient(listOf(emerald.copy(alpha = 0.7f), cyan.copy(alpha = 0.6f), gold.copy(alpha = 0.75f))),
                shape = RoundedCornerShape(22.dp),
            )
            .padding(12.dp),
        contentAlignment = Alignment.Center,
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val canvasWidth = size.width
            val canvasHeight = size.height
            val cellSize = minOf(canvasWidth, canvasHeight) / matrixSize.toFloat()

            val dataGradient = Brush.linearGradient(
                colors = listOf(emerald, cyan, gold),
                start = Offset.Zero,
                end = Offset(canvasWidth, canvasHeight),
            )

            // Center badge clear zone (covered safely by ErrorCorrectionLevel.H 30% tolerance)
            val centerPt = Offset(canvasWidth / 2f, canvasHeight / 2f)
            val clearRadius = minOf(canvasWidth, canvasHeight) * 0.145f

            // Draw data modules as smooth circular dots & connected pills
            for (y in 0 until matrixSize) {
                for (x in 0 until matrixSize) {
                    if (!matrix.get(x, y)) continue
                    if (QrMatrixHelper.isInFinderPattern(x, y, matrixSize, quietMargin)) continue

                    val cx = (x + 0.5f) * cellSize
                    val cy = (y + 0.5f) * cellSize
                    val dx = cx - centerPt.x
                    val dy = cy - centerPt.y
                    if (dx * dx + dy * dy <= clearRadius * clearRadius) continue

                    val hasRightNeighbor = x + 1 < matrixSize &&
                        matrix.get(x + 1, y) &&
                        !QrMatrixHelper.isInFinderPattern(x + 1, y, matrixSize, quietMargin)

                    if (hasRightNeighbor) {
                        val nextCx = (x + 1.5f) * cellSize
                        val ndx = nextCx - centerPt.x
                        val ndy = cy - centerPt.y
                        if (ndx * ndx + ndy * ndy > clearRadius * clearRadius) {
                            drawRoundRect(
                                brush = dataGradient,
                                topLeft = Offset(x * cellSize + cellSize * 0.08f, y * cellSize + cellSize * 0.12f),
                                size = Size(cellSize * 1.84f, cellSize * 0.76f),
                                cornerRadius = CornerRadius(cellSize * 0.38f, cellSize * 0.38f),
                            )
                            continue
                        }
                    }

                    val hasLeftNeighbor = x - 1 >= 0 &&
                        matrix.get(x - 1, y) &&
                        !QrMatrixHelper.isInFinderPattern(x - 1, y, matrixSize, quietMargin)
                    if (hasLeftNeighbor) {
                        val prevCx = (x - 0.5f) * cellSize
                        val pdx = prevCx - centerPt.x
                        val pdy = cy - centerPt.y
                        if (pdx * pdx + pdy * pdy > clearRadius * clearRadius) {
                            continue
                        }
                    }

                    drawCircle(
                        brush = dataGradient,
                        radius = cellSize * 0.40f,
                        center = Offset(cx, cy),
                    )
                }
            }

            // Draw 3 corner finder patterns as custom nested rounded squircles with glowing emerald-gold borders
            val finderCorners = listOf(
                Offset(quietMargin * cellSize, quietMargin * cellSize),
                Offset((matrixSize - quietMargin - 7) * cellSize, quietMargin * cellSize),
                Offset(quietMargin * cellSize, (matrixSize - quietMargin - 7) * cellSize),
            )
            val finderSize = 7f * cellSize
            val finderBrush = Brush.linearGradient(
                colors = listOf(emerald, gold),
                start = Offset.Zero,
                end = Offset(canvasWidth, canvasHeight),
            )

            finderCorners.forEach { topLeft ->
                // Subtle outer glow
                drawRoundRect(
                    color = emerald.copy(alpha = 0.22f),
                    topLeft = Offset(topLeft.x - cellSize * 0.18f, topLeft.y - cellSize * 0.18f),
                    size = Size(finderSize + cellSize * 0.36f, finderSize + cellSize * 0.36f),
                    cornerRadius = CornerRadius(cellSize * 2.1f, cellSize * 2.1f),
                )
                // Outer squircle ring (7x7)
                drawRoundRect(
                    brush = finderBrush,
                    topLeft = Offset(topLeft.x + cellSize * 0.45f, topLeft.y + cellSize * 0.45f),
                    size = Size(finderSize - cellSize * 0.90f, finderSize - cellSize * 0.90f),
                    cornerRadius = CornerRadius(cellSize * 1.75f, cellSize * 1.75f),
                    style = Stroke(width = cellSize * 0.92f),
                )
                // Inner core squircle (3x3)
                drawRoundRect(
                    brush = Brush.linearGradient(listOf(gold, emerald)),
                    topLeft = Offset(topLeft.x + cellSize * 2.0f, topLeft.y + cellSize * 2.0f),
                    size = Size(cellSize * 3.0f, cellSize * 3.0f),
                    cornerRadius = CornerRadius(cellSize * 0.95f, cellSize * 0.95f),
                )
            }
        }

        // Center metallic circular badge with gold border & stylized Arabic monogram "ب م"
        Box(
            modifier = Modifier
                .size(46.dp)
                .clip(CircleShape)
                .background(
                    Brush.radialGradient(
                        colors = listOf(Color(0xFF1E293B), Color(0xFF0B1120)),
                    ),
                )
                .border(2.dp, gold, CircleShape),
            contentAlignment = Alignment.Center,
        ) {
            Text(
                text = DeveloperProfile.MONOGRAM,
                color = gold,
                fontSize = 14.sp,
                fontWeight = FontWeight.ExtraBold,
                textAlign = TextAlign.Center,
            )
        }
    }
}

@Composable
fun DeveloperSignatureCard(
    onShowMessage: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current

    val emerald = Color(0xFF10B981)
    val cyan = Color(0xFF06B6D4)
    val gold = Color(0xFFF59E0B)
    val deepBg = Color(0xFF0B1120)

    val infiniteTransition = rememberInfiniteTransition(label = "vip_shimmer")
    val shimmerOffset by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1200f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 3400, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse,
        ),
        label = "shimmer_offset",
    )

    val shimmerBrush = Brush.linearGradient(
        colors = listOf(
            emerald.copy(alpha = 0.75f),
            gold.copy(alpha = 0.95f),
            cyan.copy(alpha = 0.75f),
            emerald.copy(alpha = 0.75f),
        ),
        start = Offset(shimmerOffset - 400f, 0f),
        end = Offset(shimmerOffset + 250f, 600f),
    )

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .testTag("developer_signature_card"),
        shape = RoundedCornerShape(24.dp),
        color = deepBg,
        border = BorderStroke(1.8.dp, shimmerBrush),
        shadowElevation = 10.dp,
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(Color(0xFF111C33), deepBg),
                    ),
                )
                .padding(18.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            // Badge + Title
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = gold.copy(alpha = 0.16f),
                border = BorderStroke(1.dp, gold.copy(alpha = 0.55f)),
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    Icon(Icons.Rounded.Verified, contentDescription = null, tint = gold, modifier = Modifier.size(16.dp))
                    Text(
                        text = "مطور التطبيق",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = gold,
                    )
                }
            }

            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    text = DeveloperProfile.DEVELOPER_NAME,
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color.White,
                    textAlign = TextAlign.Center,
                )
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                    Text(
                        text = DeveloperProfile.PHONE_DISPLAY,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = cyan,
                        letterSpacing = 1.sp,
                    )
                }
            }

            ArtisticDeveloperQrCode(
                modifier = Modifier
                    .widthIn(max = 220.dp)
                    .fillMaxWidth(0.72f),
            )

            Text(
                text = "امسح الكود بالكاميرا لحفظ بيانات التواصل مباشرة",
                style = MaterialTheme.typography.bodySmall,
                color = Color(0xFF94A3B8),
                textAlign = TextAlign.Center,
            )

            // 3 Action Buttons: نسخ الرقم | واتساب | مشاركة الكود
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                OutlinedButton(
                    onClick = {
                        clipboard.setText(AnnotatedString(DeveloperProfile.PHONE_DISPLAY))
                        onShowMessage("تم نسخ الرقم: ${DeveloperProfile.PHONE_DISPLAY}")
                    },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("dev_copy_phone_button"),
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, cyan.copy(alpha = 0.55f)),
                    contentPadding = PaddingValues(horizontal = 6.dp, vertical = 10.dp),
                ) {
                    Icon(Icons.Rounded.ContentCopy, contentDescription = null, tint = cyan, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("نسخ الرقم", color = Color.White, style = MaterialTheme.typography.labelMedium, maxLines = 1)
                }

                Button(
                    onClick = {
                        try {
                            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(DeveloperProfile.PHONE_WHATSAPP_URL))
                            context.startActivity(intent)
                        } catch (_: Exception) {
                            onShowMessage("تعذر فتح واتساب على هذا الجهاز")
                        }
                    },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("dev_whatsapp_button"),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = emerald, contentColor = Color.White),
                    contentPadding = PaddingValues(horizontal = 6.dp, vertical = 10.dp),
                ) {
                    Icon(Icons.Rounded.Chat, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("واتساب", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, maxLines = 1)
                }

                OutlinedButton(
                    onClick = {
                        shareDeveloperQrCard(context, onShowMessage)
                    },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("dev_share_qr_button"),
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, gold.copy(alpha = 0.65f)),
                    contentPadding = PaddingValues(horizontal = 6.dp, vertical = 10.dp),
                ) {
                    Icon(Icons.Rounded.Share, contentDescription = null, tint = gold, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("مشاركة الكود", color = gold, style = MaterialTheme.typography.labelMedium, maxLines = 1)
                }
            }
        }
    }
}

private fun shareDeveloperQrCard(context: Context, onShowMessage: (String) -> Unit) {
    try {
        val bitmap = renderDeveloperCardBitmap()
        val dir = File(context.cacheDir, "reports").apply { mkdirs() }
        val file = File(dir, "masroufy_developer_card.png")
        file.outputStream().use { out ->
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
        }
        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file,
        )
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "image/png"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(
                Intent.EXTRA_TEXT,
                "تواصل مع مطور تطبيق مصروفي: ${DeveloperProfile.DEVELOPER_NAME} - ${DeveloperProfile.PHONE_DISPLAY}",
            )
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, "مشاركة بطاقة المطور"))
    } catch (_: Exception) {
        onShowMessage("تعذر مشاركة صورة الكود")
    }
}

private fun renderDeveloperCardBitmap(): Bitmap {
    val width = 900
    val height = 1140
    val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
    val canvas = AndroidCanvas(bitmap)

    val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        shader = LinearGradient(
            0f,
            0f,
            0f,
            height.toFloat(),
            android.graphics.Color.rgb(17, 28, 51),
            android.graphics.Color.rgb(11, 17, 32),
            Shader.TileMode.CLAMP,
        )
    }
    canvas.drawRoundRect(RectF(0f, 0f, width.toFloat(), height.toFloat()), 48f, 48f, bgPaint)

    val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 6f
        shader = LinearGradient(
            0f,
            0f,
            width.toFloat(),
            height.toFloat(),
            intArrayOf(
                android.graphics.Color.rgb(16, 185, 129),
                android.graphics.Color.rgb(245, 158, 11),
                android.graphics.Color.rgb(6, 182, 212),
            ),
            null,
            Shader.TileMode.CLAMP,
        )
    }
    canvas.drawRoundRect(RectF(14f, 14f, width - 14f, height - 14f), 42f, 42f, borderPaint)

    val badgePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = android.graphics.Color.rgb(245, 158, 11)
        textSize = 30f
        textAlign = Paint.Align.CENTER
        typeface = Typeface.DEFAULT_BOLD
    }
    canvas.drawText("مطور تطبيق مصروفي", width / 2f, 96f, badgePaint)

    val namePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = android.graphics.Color.WHITE
        textSize = 48f
        textAlign = Paint.Align.CENTER
        typeface = Typeface.DEFAULT_BOLD
    }
    canvas.drawText(DeveloperProfile.DEVELOPER_NAME, width / 2f, 162f, namePaint)

    val phonePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = android.graphics.Color.rgb(6, 182, 212)
        textSize = 34f
        textAlign = Paint.Align.CENTER
        typeface = Typeface.DEFAULT_BOLD
    }
    canvas.drawText(DeveloperProfile.PHONE_DISPLAY, width / 2f, 216f, phonePaint)

    // Render stylized QR inside centered square
    val qrSize = 620f
    val qrLeft = (width - qrSize) / 2f
    val qrTop = 276f
    val matrix = QrMatrixHelper.generateMatrix()
    val matrixSize = matrix.width
    val quietMargin = QrMatrixHelper.detectQuietMargin(matrix)
    val cellSize = qrSize / matrixSize.toFloat()

    val qrBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = android.graphics.Color.rgb(11, 17, 32)
    }
    canvas.drawRoundRect(RectF(qrLeft - 24f, qrTop - 24f, qrLeft + qrSize + 24f, qrTop + qrSize + 24f), 36f, 36f, qrBgPaint)
    canvas.drawRoundRect(RectF(qrLeft - 24f, qrTop - 24f, qrLeft + qrSize + 24f, qrTop + qrSize + 24f), 36f, 36f, borderPaint)

    val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        shader = LinearGradient(
            qrLeft,
            qrTop,
            qrLeft + qrSize,
            qrTop + qrSize,
            intArrayOf(
                android.graphics.Color.rgb(16, 185, 129),
                android.graphics.Color.rgb(6, 182, 212),
                android.graphics.Color.rgb(245, 158, 11),
            ),
            null,
            Shader.TileMode.CLAMP,
        )
    }

    val centerX = width / 2f
    val centerY = qrTop + qrSize / 2f
    val clearRadius = qrSize * 0.145f

    for (y in 0 until matrixSize) {
        for (x in 0 until matrixSize) {
            if (!matrix.get(x, y)) continue
            if (QrMatrixHelper.isInFinderPattern(x, y, matrixSize, quietMargin)) continue
            val cx = qrLeft + (x + 0.5f) * cellSize
            val cy = qrTop + (y + 0.5f) * cellSize
            val dx = cx - centerX
            val dy = cy - centerY
            if (dx * dx + dy * dy <= clearRadius * clearRadius) continue
            canvas.drawCircle(cx, cy, cellSize * 0.42f, dotPaint)
        }
    }

    val finderStrokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = cellSize * 0.92f
        shader = dotPaint.shader
    }
    val finderSize = 7f * cellSize
    val corners = listOf(
        Pair(qrLeft + quietMargin * cellSize, qrTop + quietMargin * cellSize),
        Pair(qrLeft + (matrixSize - quietMargin - 7) * cellSize, qrTop + quietMargin * cellSize),
        Pair(qrLeft + quietMargin * cellSize, qrTop + (matrixSize - quietMargin - 7) * cellSize),
    )
    corners.forEach { (lx, ty) ->
        canvas.drawRoundRect(
            RectF(lx + cellSize * 0.45f, ty + cellSize * 0.45f, lx + finderSize - cellSize * 0.45f, ty + finderSize - cellSize * 0.45f),
            cellSize * 1.75f,
            cellSize * 1.75f,
            finderStrokePaint,
        )
        canvas.drawRoundRect(
            RectF(lx + cellSize * 2.0f, ty + cellSize * 2.0f, lx + cellSize * 5.0f, ty + cellSize * 5.0f),
            cellSize * 0.95f,
            cellSize * 0.95f,
            dotPaint,
        )
    }

    // Center badge
    val centerBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        shader = RadialGradient(
            centerX,
            centerY,
            clearRadius * 0.85f,
            android.graphics.Color.rgb(30, 41, 59),
            android.graphics.Color.rgb(11, 17, 32),
            Shader.TileMode.CLAMP,
        )
    }
    canvas.drawCircle(centerX, centerY, clearRadius * 0.82f, centerBgPaint)
    val goldStrokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 5f
        color = android.graphics.Color.rgb(245, 158, 11)
    }
    canvas.drawCircle(centerX, centerY, clearRadius * 0.82f, goldStrokePaint)
    val monogramPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = android.graphics.Color.rgb(245, 158, 11)
        textSize = 40f
        textAlign = Paint.Align.CENTER
        typeface = Typeface.DEFAULT_BOLD
    }
    canvas.drawText(DeveloperProfile.MONOGRAM, centerX, centerY + 14f, monogramPaint)

    val hintPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = android.graphics.Color.rgb(148, 163, 184)
        textSize = 26f
        textAlign = Paint.Align.CENTER
    }
    canvas.drawText("امسح الكود بالكاميرا لحفظ بيانات التواصل مباشرة", width / 2f, 1020f, hintPaint)

    return bitmap
}
