package com.example.ui.components

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AccountBalance
import androidx.compose.material.icons.rounded.PieChart
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material.icons.rounded.SwapHoriz
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.data.local.GoalEntity
import com.example.data.local.WalletEntity
import com.example.domain.Formatters
import com.example.domain.ZeroBasedBudgetSummary
import com.example.ui.theme.LocalMasroufyColors
import kotlin.math.abs
import kotlin.math.roundToInt

@Composable
fun ZeroBasedBudgetCard(
    summary: ZeroBasedBudgetSummary,
    isMasked: Boolean,
    onOpen503020Click: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val semantic = LocalMasroufyColors.current
    val isBalanced = summary.monthlyIncome > 0.0 && abs(summary.unallocatedBalance) < 50.0
    val isDeficit = summary.unallocatedBalance < -1.0
    val accent = when {
        isBalanced -> semantic.emerald
        isDeficit -> semantic.coral
        else -> semantic.amber
    }

    FintechCard(
        modifier = modifier.fillMaxWidth().testTag("zero_based_budget_card"),
        borderColor = accent.copy(alpha = 0.45f),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                IconBadge(
                    icon = Icons.Rounded.AccountBalance,
                    tint = accent,
                    contentDescription = "الموازنة الصفرية",
                    size = 38.dp,
                )
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text("الموازنة الصفرية للدورة", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                    Text(
                        text = when {
                            isBalanced -> "ممتاز! كل جنيه ليه وظيفة (الباقي ≈ 0)"
                            isDeficit -> "تنبيه: المخصصات أكبر من دخل الدورة بـ ${Formatters.formatEgp(-summary.unallocatedBalance, isMasked = isMasked)}"
                            else -> "فلوس غير موجهة: ${Formatters.formatEgp(summary.unallocatedBalance, isMasked = isMasked)}"
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = accent,
                    )
                }
            }
            OutlinedButton(
                onClick = onOpen503020Click,
                shape = RoundedCornerShape(12.dp),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                modifier = Modifier.testTag("open_503020_button"),
            ) {
                Icon(Icons.Rounded.PieChart, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("50/30/20", style = MaterialTheme.typography.labelMedium)
            }
        }
        Spacer(modifier = Modifier.height(10.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Text(
                text = "الدخل: ${Formatters.formatEgp(summary.monthlyIncome, isMasked = isMasked)}",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Text(
                text = "الموجه: ${Formatters.formatEgp(summary.totalAllocated, isMasked = isMasked)}",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
fun EmergencyFundCard(
    savedAmount: Double,
    targetAmount: Double,
    isMasked: Boolean,
    onDepositClick: () -> Unit,
    onWithdrawClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val semantic = LocalMasroufyColors.current
    val safeTarget = targetAmount.coerceAtLeast(1.0)
    val progress = (savedAmount / safeTarget).toFloat().coerceIn(0f, 1f)
    val pct = (progress * 100f).roundToInt()

    FintechCard(
        modifier = modifier.fillMaxWidth().testTag("emergency_fund_card"),
        borderColor = semantic.sky.copy(alpha = 0.45f),
        containerColor = semantic.sky.copy(alpha = 0.08f),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                IconBadge(
                    icon = Icons.Rounded.Shield,
                    tint = semantic.sky,
                    contentDescription = "صندوق الطوارئ",
                    size = 40.dp,
                )
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text("درع الطوارئ (معزول) 🛡️", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                    Text(
                        text = "الهدف المقترح (3 شهور أساسيات): ${Formatters.formatEgp(targetAmount, isMasked = isMasked)}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
            Text("$pct%", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = semantic.sky)
        }
        Spacer(modifier = Modifier.height(10.dp))
        Text(
            text = "المحفوظ حالياً: ${Formatters.formatEgp(savedAmount, isMasked = isMasked)}",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = semantic.sky,
        )
        Spacer(modifier = Modifier.height(6.dp))
        LinearProgressIndicator(
            progress = { progress },
            modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(8.dp)),
            color = semantic.sky,
            trackColor = MaterialTheme.colorScheme.surfaceVariant,
            strokeCap = StrokeCap.Round,
        )
        Spacer(modifier = Modifier.height(10.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = onDepositClick,
                modifier = Modifier.weight(1f).testTag("emergency_deposit_button"),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = semantic.sky, contentColor = Color.White),
            ) {
                Text("+ إيداع طوارئ", style = MaterialTheme.typography.labelLarge)
            }
            OutlinedButton(
                onClick = onWithdrawClick,
                enabled = savedAmount > 0.0,
                modifier = Modifier.weight(1f).testTag("emergency_withdraw_button"),
                shape = RoundedCornerShape(12.dp),
            ) {
                Text("سحب للمحفظة", style = MaterialTheme.typography.labelLarge)
            }
        }
    }
}

@Composable
fun IncomeAllocator503020Dialog(
    wallets: List<WalletEntity>,
    goals: List<GoalEntity>,
    onApply: (amount: Double, walletId: Long, toEmergencyFund: Boolean, targetGoalId: Long?) -> Unit,
    onDismiss: () -> Unit,
) {
    BackHandler(enabled = true) { onDismiss() }

    val semantic = LocalMasroufyColors.current
    var amountText by remember { mutableStateOf("") }
    var selectedWalletId by remember { mutableLongStateOf(wallets.firstOrNull()?.id ?: 0L) }
    var toEmergency by remember { mutableStateOf(true) }
    var selectedGoalId by remember { mutableStateOf(goals.firstOrNull()?.id) }
    var error by remember { mutableStateOf<String?>(null) }

    val parsedAmount = (Formatters.parseSafeDouble(amountText) ?: 0.0).coerceAtLeast(0.0)

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("موزع الدخل الذكي 50 / 30 / 20", style = MaterialTheme.typography.titleLarge) },
        text = {
            Column(
                modifier = Modifier
                    .verticalScroll(rememberScrollState())
                    .imePadding(),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Text(
                    "وزّع أي مبلغ تلقائياً: 50% لظرف الأساسيات، 30% للصرف الحر، 20% للطوارئ أو حصالة هدف.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                OutlinedTextField(
                    value = amountText,
                    onValueChange = { amountText = it; error = null },
                    label = { Text("المبلغ المراد توزيعه (ج.م)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth().testTag("allocator_amount_input"),
                )
                if (parsedAmount > 0.0) {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = semantic.emerald.copy(alpha = 0.1f),
                        border = BorderStroke(1.dp, semantic.emerald.copy(alpha = 0.4f)),
                    ) {
                        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text("• 50% أساسيات (ظرف): ${Formatters.formatEgp(parsedAmount * 0.50)}", style = MaterialTheme.typography.labelMedium)
                            Text("• 30% حر يومي: ${Formatters.formatEgp(parsedAmount * 0.30)}", style = MaterialTheme.typography.labelMedium)
                            Text("• 20% تحويش/طوارئ: ${Formatters.formatEgp(parsedAmount * 0.20)}", style = MaterialTheme.typography.labelMedium, color = semantic.emerald)
                        }
                    }
                }
                Text("اختر المحفظة:", style = MaterialTheme.typography.labelLarge)
                Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    wallets.forEach { w ->
                        val sel = selectedWalletId == w.id
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = if (sel) semantic.emerald.copy(alpha = 0.2f) else MaterialTheme.colorScheme.surfaceVariant,
                            border = BorderStroke(1.dp, if (sel) semantic.emerald else semantic.cardBorder),
                            modifier = Modifier.clickable { selectedWalletId = w.id },
                        ) {
                            Text(w.name, style = MaterialTheme.typography.labelMedium, modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp))
                        }
                    }
                }
                Text("وجهة الـ 20% للتحويش:", style = MaterialTheme.typography.labelLarge)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(true to "صندوق الطوارئ 🛡️", false to "هدف بالحصالة 🎯").forEach { (isEmerg, lbl) ->
                        val sel = toEmergency == isEmerg
                        Surface(
                            modifier = Modifier.weight(1f).clickable {
                                if (!isEmerg && goals.isEmpty()) {
                                    error = "أضف هدفاً في الحصالة أولاً أو اختر صندوق الطوارئ"
                                } else {
                                    toEmergency = isEmerg
                                    error = null
                                }
                            },
                            shape = RoundedCornerShape(12.dp),
                            color = if (sel) semantic.sky.copy(alpha = 0.2f) else MaterialTheme.colorScheme.surfaceVariant,
                            border = BorderStroke(1.dp, if (sel) semantic.sky else semantic.cardBorder),
                        ) {
                            Text(lbl, style = MaterialTheme.typography.labelMedium, modifier = Modifier.padding(10.dp))
                        }
                    }
                }
                if (!toEmergency && goals.isNotEmpty()) {
                    Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        goals.forEach { g ->
                            val sel = selectedGoalId == g.id
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = if (sel) Color(g.colorHex).copy(alpha = 0.2f) else MaterialTheme.colorScheme.surfaceVariant,
                                border = BorderStroke(1.dp, if (sel) Color(g.colorHex) else semantic.cardBorder),
                                modifier = Modifier.clickable { selectedGoalId = g.id },
                            ) {
                                Text(g.title, style = MaterialTheme.typography.labelMedium, modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp))
                            }
                        }
                    }
                }
                error?.let { Text(it, color = semantic.coral, style = MaterialTheme.typography.bodySmall) }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    when {
                        parsedAmount <= 0.0 -> error = "أدخل مبلغاً أكبر من صفر"
                        selectedWalletId == 0L -> error = "اختر المحفظة"
                        !toEmergency && selectedGoalId == null -> error = "اختر هدف التحويش"
                        else -> {
                            onApply(parsedAmount, selectedWalletId, toEmergency, selectedGoalId)
                            onDismiss()
                        }
                    }
                },
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.testTag("confirm_503020_button"),
            ) { Text("تنفيذ التوزيع") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } },
        containerColor = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(22.dp),
    )
}

data class RebalanceOption(
    val id: Long,
    val name: String,
    val availableAmount: Double,
)

@Composable
fun RebalanceTransferDialog(
    title: String,
    subtitle: String,
    options: List<RebalanceOption>,
    initialTargetId: Long? = null,
    onConfirm: (fromId: Long, toId: Long, amount: Double) -> Unit,
    onDismiss: () -> Unit,
) {
    BackHandler(enabled = true) { onDismiss() }

    val semantic = LocalMasroufyColors.current
    var toId by remember { mutableLongStateOf(initialTargetId ?: options.lastOrNull()?.id ?: 0L) }
    var fromId by remember {
        mutableLongStateOf(options.firstOrNull { it.id != toId && it.availableAmount > 0.0 }?.id ?: options.firstOrNull { it.id != toId }?.id ?: 0L)
    }
    var amountText by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Rounded.SwapHoriz, contentDescription = null, tint = semantic.amber)
                Text(title, style = MaterialTheme.typography.titleLarge)
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .verticalScroll(rememberScrollState())
                    .imePadding(),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("من (المصدر ذو الفائض):", style = MaterialTheme.typography.labelLarge)
                Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    options.forEach { opt ->
                        val sel = fromId == opt.id
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = if (sel) semantic.emerald.copy(alpha = 0.2f) else MaterialTheme.colorScheme.surfaceVariant,
                            border = BorderStroke(1.dp, if (sel) semantic.emerald else semantic.cardBorder),
                            modifier = Modifier.clickable {
                                fromId = opt.id
                                if (toId == opt.id) {
                                    toId = options.firstOrNull { it.id != opt.id }?.id ?: toId
                                }
                                error = null
                            },
                        ) {
                            Column(modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)) {
                                Text(opt.name, style = MaterialTheme.typography.labelMedium)
                                Text(Formatters.formatEgp(opt.availableAmount), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
                Text("إلى (لتغطية العجز):", style = MaterialTheme.typography.labelLarge)
                Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    options.filter { it.id != fromId }.forEach { opt ->
                        val sel = toId == opt.id
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = if (sel) semantic.amber.copy(alpha = 0.2f) else MaterialTheme.colorScheme.surfaceVariant,
                            border = BorderStroke(1.dp, if (sel) semantic.amber else semantic.cardBorder),
                            modifier = Modifier.clickable { toId = opt.id; error = null },
                        ) {
                            Column(modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)) {
                                Text(opt.name, style = MaterialTheme.typography.labelMedium)
                                Text(Formatters.formatEgp(opt.availableAmount), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
                OutlinedTextField(
                    value = amountText,
                    onValueChange = { amountText = it; error = null },
                    label = { Text("المبلغ المحول (ج.م)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth().testTag("rebalance_amount_input"),
                )
                error?.let { Text(it, color = semantic.coral, style = MaterialTheme.typography.bodySmall) }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amt = Formatters.parseSafeDouble(amountText) ?: 0.0
                    val source = options.firstOrNull { it.id == fromId }
                    when {
                        fromId == 0L || toId == 0L || fromId == toId -> error = "اختر مصدر ووجهة مختلفين"
                        amt <= 0.0 -> error = "أدخل مبلغاً أكبر من صفر"
                        source != null && amt > source.availableAmount -> error = "المبلغ أكبر من المتاح في «${source.name}»"
                        else -> {
                            onConfirm(fromId, toId, amt)
                            onDismiss()
                        }
                    }
                },
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.testTag("confirm_rebalance_button"),
            ) { Text("تنفيذ التغطية") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } },
        containerColor = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(22.dp),
    )
}

@Composable
fun EmergencyFundActionDialog(
    isDeposit: Boolean,
    maxWithdrawAmount: Double,
    wallets: List<WalletEntity>,
    onConfirm: (walletId: Long, amount: Double) -> Unit,
    onDismiss: () -> Unit,
) {
    BackHandler(enabled = true) { onDismiss() }

    val semantic = LocalMasroufyColors.current
    var selectedWalletId by remember { mutableLongStateOf(wallets.firstOrNull()?.id ?: 0L) }
    var amountText by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                if (isDeposit) "إيداع في صندوق الطوارئ 🛡️" else "سحب من صندوق الطوارئ",
                style = MaterialTheme.typography.titleLarge,
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .verticalScroll(rememberScrollState())
                    .imePadding(),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Text(
                    if (isDeposit) "سيتم خصم المبلغ من المحفظة المختارة وعزله في صندوق الطوارئ."
                    else "الرصيد المتاح للسحب: ${Formatters.formatEgp(maxWithdrawAmount)}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                OutlinedTextField(
                    value = amountText,
                    onValueChange = { amountText = it; error = null },
                    label = { Text("المبلغ (ج.م)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth().testTag("emergency_amount_input"),
                )
                Text(if (isDeposit) "من محفظة:" else "إلى محفظة:", style = MaterialTheme.typography.labelLarge)
                Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    wallets.forEach { w ->
                        val sel = selectedWalletId == w.id
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = if (sel) semantic.sky.copy(alpha = 0.2f) else MaterialTheme.colorScheme.surfaceVariant,
                            border = BorderStroke(1.dp, if (sel) semantic.sky else semantic.cardBorder),
                            modifier = Modifier.clickable { selectedWalletId = w.id },
                        ) {
                            Text(w.name, style = MaterialTheme.typography.labelMedium, modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp))
                        }
                    }
                }
                error?.let { Text(it, color = semantic.coral, style = MaterialTheme.typography.bodySmall) }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amt = Formatters.parseSafeDouble(amountText) ?: 0.0
                    when {
                        amt <= 0.0 -> error = "أدخل مبلغاً أكبر من صفر"
                        !isDeposit && amt > maxWithdrawAmount -> error = "المبلغ أكبر من رصيد صندوق الطوارئ"
                        selectedWalletId == 0L -> error = "اختر المحفظة"
                        else -> {
                            onConfirm(selectedWalletId, amt)
                            onDismiss()
                        }
                    }
                },
                shape = RoundedCornerShape(12.dp),
            ) { Text(if (isDeposit) "تأكيد الإيداع" else "تأكيد السحب") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } },
        containerColor = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(22.dp),
    )
}
