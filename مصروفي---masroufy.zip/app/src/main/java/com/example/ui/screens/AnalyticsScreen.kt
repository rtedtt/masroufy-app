package com.example.ui.screens

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.BarChart
import androidx.compose.material.icons.rounded.CalendarMonth
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.LocalFireDepartment
import androidx.compose.material.icons.rounded.PictureAsPdf
import androidx.compose.material.icons.rounded.PieChart
import androidx.compose.material.icons.rounded.SwapHoriz
import androidx.compose.material.icons.rounded.TrendingUp
import androidx.compose.material.icons.rounded.WaterDrop
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.domain.AnalyticsSnapshot
import com.example.domain.AnalyticsTimeframe
import com.example.domain.BudgetSnapshot
import com.example.domain.CategoryBudgetProgress
import com.example.domain.CategorySlice
import com.example.domain.DailyBarPoint
import com.example.domain.FinancialHealthScore
import com.example.domain.Formatters
import com.example.domain.HeatmapDayCell
import com.example.domain.HeatmapIntensity
import com.example.domain.InflationSpikeAlert
import com.example.domain.MonthlyComparisonPoint
import com.example.domain.ReportExporter
import com.example.domain.SmallLeaksSummary
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.FintechCard
import com.example.ui.components.IconBadge
import com.example.ui.components.IconsCatalog
import com.example.ui.components.RebalanceOption
import com.example.ui.components.RebalanceTransferDialog
import com.example.ui.theme.LocalMasroufyColors
import com.example.viewmodel.MasroufyUiState
import java.time.LocalDate
import kotlin.math.max
import kotlin.math.roundToInt

@Composable
fun AnalyticsScreen(
    state: MasroufyUiState,
    onSelectTimeframe: (AnalyticsTimeframe) -> Unit,
    onRebalanceCategoryBudgets: (fromCategoryId: Long, toCategoryId: Long, amount: Double) -> Unit = { _, _, _ -> },
    onShowMessage: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    val semantic = LocalMasroufyColors.current
    val analytics = state.analyticsSnapshot
    val masked = state.settings.isPrivacyMode

    var selectedSliceIndex by remember(state.selectedTimeframe, analytics.categorySlices) {
        mutableStateOf<Int?>(null)
    }
    var showBudgetRebalanceDialog by remember { mutableStateOf(false) }

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter,
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 680.dp),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 108.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            item {
                Column {
                    Text(
                        text = "التحليلات والرادار المالي",
                        style = MaterialTheme.typography.headlineMedium,
                        color = MaterialTheme.colorScheme.onBackground,
                    )
                    Text(
                        text = "افهم أنماط صرفك، التوقعات، والتسرب المالي",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }

            // #23 Export CSV & PDF Report Quick Buttons
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    OutlinedButton(
                        onClick = {
                            try {
                                val csv = ReportExporter.buildCsvContent(
                                    state.transactions,
                                    state.wallets,
                                    state.categories,
                                )
                                ReportExporter.shareTempFile(
                                    context = context,
                                    fileName = "masroufy_report_${LocalDate.now()}.csv",
                                    mimeType = "text/csv",
                                ) { out -> out.write(csv.toByteArray(Charsets.UTF_8)) }
                            } catch (_: Exception) {
                                onShowMessage("تعذر تصدير ملف CSV")
                            }
                        },
                        modifier = Modifier.weight(1f).testTag("analytics_export_csv"),
                        shape = RoundedCornerShape(14.dp),
                    ) {
                        Icon(Icons.Rounded.Download, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("تصدير Excel (CSV)", style = MaterialTheme.typography.labelMedium)
                    }
                    OutlinedButton(
                        onClick = {
                            try {
                                ReportExporter.shareTempFile(
                                    context = context,
                                    fileName = "masroufy_summary_${LocalDate.now()}.pdf",
                                    mimeType = "application/pdf",
                                ) { out ->
                                    ReportExporter.writePdfReport(
                                        outputStream = out,
                                        transactions = state.transactions,
                                        wallets = state.wallets,
                                        categories = state.categories,
                                        budgetSnapshot = state.budgetSnapshot,
                                    )
                                }
                            } catch (_: Exception) {
                                onShowMessage("تعذر إنشاء ملف PDF")
                            }
                        },
                        modifier = Modifier.weight(1f).testTag("analytics_export_pdf"),
                        shape = RoundedCornerShape(14.dp),
                    ) {
                        Icon(Icons.Rounded.PictureAsPdf, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("تقرير PDF", style = MaterialTheme.typography.labelMedium)
                    }
                }
            }

            // Timeframe Filter Chips
            item {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    AnalyticsTimeframe.entries.forEach { tf ->
                        val selected = state.selectedTimeframe == tf
                        Surface(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(14.dp))
                                .clickable { onSelectTimeframe(tf) }
                                .testTag("timeframe_chip_${tf.name}"),
                            shape = RoundedCornerShape(14.dp),
                            color = if (selected) MaterialTheme.colorScheme.primary.copy(alpha = 0.2f)
                            else MaterialTheme.colorScheme.surface,
                            border = BorderStroke(
                                width = 1.dp,
                                color = if (selected) MaterialTheme.colorScheme.primary else semantic.cardBorder,
                            ),
                        ) {
                            Text(
                                text = tf.label,
                                style = MaterialTheme.typography.labelLarge,
                                color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.padding(vertical = 10.dp),
                            )
                        }
                    }
                }
            }

            // Income vs Expense Summary Row
            item {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    FintechCard(modifier = Modifier.weight(1f), borderColor = semantic.coral.copy(alpha = 0.4f)) {
                        Text("إجمالي المصاريف", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(Formatters.formatEgp(analytics.totalExpense, isMasked = masked), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = semantic.coral)
                    }
                    FintechCard(modifier = Modifier.weight(1f), borderColor = semantic.emerald.copy(alpha = 0.4f)) {
                        Text("إجمالي الدخل", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(Formatters.formatEgp(analytics.totalIncome, isMasked = masked), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = semantic.emerald)
                    }
                }
            }

            // Financial Health Score (0-100 Gauge)
            item {
                FinancialHealthScoreCard(health = state.financialHealthScore)
            }

            // Inflation & Price Spike Radar (> 15% over historical avg)
            if (state.inflationAlerts.isNotEmpty()) {
                item {
                    InflationSpikeRadarCard(alerts = state.inflationAlerts, isMasked = masked)
                }
            }

            // #22 End-of-Month Balance Forecast Card
            item {
                BalanceForecastCard(snapshot = state.budgetSnapshot, isMasked = masked)
            }

            // #21 Small Leaks Detector Card
            item {
                SmallLeaksCard(leaks = analytics.smallLeaks, isMasked = masked)
            }

            // #28 Per-Category Monthly Budgets Progress + Rebalance
            if (analytics.categoryBudgets.isNotEmpty()) {
                item {
                    CategoryBudgetsCard(
                        budgets = analytics.categoryBudgets,
                        isMasked = masked,
                        onRebalanceClick = { showBudgetRebalanceDialog = true },
                    )
                }
            }

            // Category Donut Chart
            item {
                if (analytics.categorySlices.isEmpty()) {
                    EmptyStateCard(
                        icon = Icons.Rounded.PieChart,
                        title = "لا توجد مصاريف في هذه الفترة",
                        subtitle = "بمجرد تسجيل مصاريف، هيظهر هنا توزيع التصنيفات بالنسبة المئوية.",
                    )
                } else {
                    CategoryDonutChartCard(
                        slices = analytics.categorySlices,
                        totalExpense = analytics.totalExpense,
                        selectedIndex = selectedSliceIndex,
                        isMasked = masked,
                        onSelectIndex = { idx ->
                            selectedSliceIndex = if (selectedSliceIndex == idx) null else idx
                        },
                    )
                }
            }

            // #19 Income vs Expense Monthly Grouped Bar Chart
            item {
                MonthlyIncomeExpenseChartCard(points = analytics.monthlyComparisons)
            }

            // Daily Spending Bar Chart vs Daily Safe Limit
            item {
                DailyBarChartCard(
                    bars = analytics.dailyBars,
                    dailySafeLimit = state.budgetSnapshot.dailySafeLimit,
                    isMasked = masked,
                )
            }

            // #20 Monthly Spending Heatmap Calendar
            item {
                SpendingHeatmapCalendarCard(cells = analytics.heatmapCells, isMasked = masked)
            }

            // Smart Arabic Insights Card
            item {
                SmartArabicInsightsCard(analytics = analytics)
            }
        }
    }

    if (showBudgetRebalanceDialog && analytics.categoryBudgets.size >= 2) {
        RebalanceTransferDialog(
            title = "تغطية عجز ميزانية التصنيفات",
            subtitle = "انقل جزء من الحد الشهري لتصنيف به فائض إلى تصنيف آخر اقترب من النفاد.",
            options = analytics.categoryBudgets.map { item ->
                val remainingBudget = (item.budget - item.spent).coerceAtLeast(0.0)
                RebalanceOption(
                    id = item.category.id,
                    name = item.category.name,
                    availableAmount = remainingBudget.takeIf { it > 0.0 } ?: item.budget,
                )
            },
            onConfirm = { fromId, toId, amt ->
                onRebalanceCategoryBudgets(fromId, toId, amt)
            },
            onDismiss = { showBudgetRebalanceDialog = false },
        )
    }
}

@Composable
private fun FinancialHealthScoreCard(health: FinancialHealthScore) {
    val semantic = LocalMasroufyColors.current
    val scoreColor = when {
        health.score >= 75 -> semantic.emerald
        health.score >= 45 -> semantic.amber
        else -> semantic.coral
    }
    val animatedSweep by animateFloatAsState(
        targetValue = (health.score.coerceIn(0, 100) / 100f) * 240f,
        animationSpec = tween(700),
        label = "healthArc",
    )

    FintechCard(
        borderColor = scoreColor.copy(alpha = 0.5f),
        modifier = Modifier.testTag("financial_health_score_card"),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Box(
                modifier = Modifier.size(96.dp),
                contentAlignment = Alignment.Center,
            ) {
                val trackColor = MaterialTheme.colorScheme.surfaceVariant
                Canvas(modifier = Modifier.fillMaxSize().padding(6.dp)) {
                    drawArc(
                        color = trackColor,
                        startAngle = 150f,
                        sweepAngle = 240f,
                        useCenter = false,
                        style = Stroke(width = 10.dp.toPx(), cap = StrokeCap.Round),
                    )
                    drawArc(
                        color = scoreColor,
                        startAngle = 150f,
                        sweepAngle = animatedSweep,
                        useCenter = false,
                        style = Stroke(width = 10.dp.toPx(), cap = StrokeCap.Round),
                    )
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "${health.score}",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = scoreColor,
                    )
                    Text(
                        text = "/ 100",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }

            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Icon(Icons.Rounded.Favorite, contentDescription = null, tint = scoreColor, modifier = Modifier.size(18.dp))
                    Text("مؤشر الصحة المالية", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                }
                Text(
                    text = "التقييم العام: ${health.label}",
                    style = MaterialTheme.typography.labelLarge,
                    color = scoreColor,
                )
                Text(
                    text = "ادخار ${health.savingsComponent}/30 • حد يومي ${health.dailyLimitComponent}/30 • التزام ${health.streakComponent}/20 • ديون ${health.debtComponent}/20",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
        if (health.tips.isNotEmpty()) {
            Spacer(modifier = Modifier.height(10.dp))
            health.tips.take(2).forEach { tip ->
                Text(
                    text = "• $tip",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

@Composable
private fun InflationSpikeRadarCard(alerts: List<InflationSpikeAlert>, isMasked: Boolean) {
    val semantic = LocalMasroufyColors.current
    FintechCard(
        borderColor = semantic.coral.copy(alpha = 0.5f),
        containerColor = semantic.coralContainer.copy(alpha = 0.35f),
        modifier = Modifier.testTag("inflation_radar_card"),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconBadge(icon = Icons.Rounded.LocalFireDepartment, tint = semantic.coral, contentDescription = "رادار التضخم", size = 40.dp)
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text("رادار تضخم المصاريف 📈", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text("بنود ارتفع صرفك فيها عن متوسطك التاريخي بنسبة > 15%", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        Spacer(modifier = Modifier.height(10.dp))
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            alerts.forEach { alert ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        text = "${alert.categoryName}: ${Formatters.formatEgp(alert.currentMonthSpend, isMasked = isMasked)} (المتوسط ${Formatters.formatEgp(alert.historicalMonthlyAvg, isMasked = isMasked)})",
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.weight(1f),
                    )
                    Surface(shape = RoundedCornerShape(8.dp), color = semantic.coral.copy(alpha = 0.2f)) {
                        Text(
                            text = "+${alert.increasePercent}%",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = semantic.coral,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun BalanceForecastCard(snapshot: BudgetSnapshot, isMasked: Boolean) {
    val semantic = LocalMasroufyColors.current
    val positive = snapshot.projectedEndOfCycleBalance >= 0.0
    val accent = if (positive) semantic.emerald else semantic.coral

    FintechCard(borderColor = accent.copy(alpha = 0.45f), modifier = Modifier.testTag("balance_forecast_card")) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconBadge(icon = Icons.Rounded.TrendingUp, tint = accent, contentDescription = "توقع الرصيد", size = 40.dp)
            Spacer(modifier = Modifier.width(10.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text("توقع الرصيد بنهاية الدورة", style = MaterialTheme.typography.titleMedium)
                Text(
                    "بناءً على متوسط صرفك (${Formatters.formatEgp(snapshot.currentCycleAvgDailySpend, isMasked = isMasked)} / يوم)",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
        Spacer(modifier = Modifier.height(10.dp))
        Text(
            text = Formatters.formatEgp(snapshot.projectedEndOfCycleBalance, showPositiveSign = true, isMasked = isMasked),
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold,
            color = accent,
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = if (positive) {
                "لو استمريت بنفس المعدل هتنهي الشهر بفائض آمن إن شاء الله."
            } else {
                "انتبه: بنفس معدل الصرف الحالي ممكن يحصل عجز قبل نهاية الدورة."
            },
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun SmallLeaksCard(leaks: SmallLeaksSummary, isMasked: Boolean) {
    val semantic = LocalMasroufyColors.current
    FintechCard(borderColor = semantic.amber.copy(alpha = 0.4f), modifier = Modifier.testTag("small_leaks_card")) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconBadge(icon = Icons.Rounded.WaterDrop, tint = semantic.amber, contentDescription = "كاشف التسرب المالي", size = 40.dp)
            Spacer(modifier = Modifier.width(10.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text("كاشف التسرب المالي (≤ 50 ج.م)", style = MaterialTheme.typography.titleMedium)
                Text(
                    if (leaks.count == 0) "مفيش مصاريف صغيرة متكررة في الفترة دي — ممتاز!"
                    else "${leaks.count} مصروف صغير كلّفوك ${Formatters.formatEgp(leaks.totalAmount, isMasked = isMasked)}",
                    style = MaterialTheme.typography.bodySmall,
                    color = if (leaks.count > 0) semantic.amber else MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
        if (leaks.topCategoryName != null && leaks.count > 0) {
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "أغلب المصاريف الصغيرة راحت في بند «${leaks.topCategoryName}».",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
private fun CategoryBudgetsCard(
    budgets: List<CategoryBudgetProgress>,
    isMasked: Boolean,
    onRebalanceClick: () -> Unit,
) {
    val semantic = LocalMasroufyColors.current
    FintechCard(modifier = Modifier.testTag("category_budgets_card")) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text("ميزانية التصنيفات الشهرية", style = MaterialTheme.typography.titleMedium)
            if (budgets.size >= 2) {
                OutlinedButton(
                    onClick = onRebalanceClick,
                    shape = RoundedCornerShape(12.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                    modifier = Modifier.testTag("rebalance_budgets_button"),
                ) {
                    Icon(Icons.Rounded.SwapHoriz, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("موازنة", style = MaterialTheme.typography.labelMedium)
                }
            }
        }
        Spacer(modifier = Modifier.height(12.dp))
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            budgets.forEach { item ->
                val color = when {
                    item.ratio > 1.0f -> semantic.coral
                    item.ratio > 0.75f -> semantic.amber
                    else -> semantic.emerald
                }
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = IconsCatalog.resolve(item.category.iconKey),
                                contentDescription = item.category.name,
                                tint = Color(item.category.colorHex),
                                modifier = Modifier.size(18.dp),
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(item.category.name, style = MaterialTheme.typography.labelLarge)
                        }
                        Text(
                            text = "${Formatters.formatEgp(item.spent, isMasked = isMasked)} / ${Formatters.formatEgp(item.budget, isMasked = isMasked)}",
                            style = MaterialTheme.typography.labelMedium,
                            color = color,
                        )
                    }
                    LinearProgressIndicator(
                        progress = { item.ratio.coerceIn(0f, 1f) },
                        modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(8.dp)),
                        color = color,
                        trackColor = MaterialTheme.colorScheme.surfaceVariant,
                        strokeCap = StrokeCap.Round,
                    )
                }
            }
        }
    }
}

@Composable
private fun MonthlyIncomeExpenseChartCard(points: List<MonthlyComparisonPoint>) {
    val semantic = LocalMasroufyColors.current
    val maxVal = max(points.maxOfOrNull { max(it.income, it.expense) } ?: 0.0, 100.0)
    val gridColor = MaterialTheme.colorScheme.outlineVariant

    FintechCard(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text("الدخل مقابل المصروف شهرياً", style = MaterialTheme.typography.titleMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(semantic.emerald))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("دخل", style = MaterialTheme.typography.labelSmall)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(semantic.coral))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("مصروف", style = MaterialTheme.typography.labelSmall)
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Canvas(modifier = Modifier.fillMaxWidth().height(150.dp)) {
            val count = points.size.coerceAtLeast(1)
            val slotWidth = size.width / count
            val barWidth = (slotWidth * 0.28f).coerceAtMost(18.dp.toPx())
            val pairGap = 4.dp.toPx()

            drawLine(
                color = gridColor,
                start = Offset(0f, size.height),
                end = Offset(size.width, size.height),
                strokeWidth = 1.dp.toPx(),
            )

            points.forEachIndexed { idx, pt ->
                val centerX = idx * slotWidth + slotWidth / 2f
                val incH = ((pt.income / maxVal).toFloat().coerceIn(0f, 1f) * size.height)
                    .coerceAtLeast(if (pt.income > 0) 4.dp.toPx() else 0f)
                val expH = ((pt.expense / maxVal).toFloat().coerceIn(0f, 1f) * size.height)
                    .coerceAtLeast(if (pt.expense > 0) 4.dp.toPx() else 0f)

                if (incH > 0f) {
                    drawRoundRect(
                        color = semantic.emerald,
                        topLeft = Offset(centerX - barWidth - pairGap / 2f, size.height - incH),
                        size = Size(barWidth, incH),
                        cornerRadius = CornerRadius(4.dp.toPx(), 4.dp.toPx()),
                    )
                }
                if (expH > 0f) {
                    drawRoundRect(
                        color = semantic.coral,
                        topLeft = Offset(centerX + pairGap / 2f, size.height - expH),
                        size = Size(barWidth, expH),
                        cornerRadius = CornerRadius(4.dp.toPx(), 4.dp.toPx()),
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))
        Row(modifier = Modifier.fillMaxWidth()) {
            points.forEach { pt ->
                Text(
                    text = pt.label,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.weight(1f),
                    maxLines = 1,
                )
            }
        }
    }
}

@Composable
private fun SpendingHeatmapCalendarCard(cells: List<HeatmapDayCell>, isMasked: Boolean) {
    val semantic = LocalMasroufyColors.current
    var selectedCell by remember(cells) { mutableStateOf<HeatmapDayCell?>(null) }

    FintechCard(modifier = Modifier.fillMaxWidth().testTag("spending_heatmap_card")) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconBadge(icon = Icons.Rounded.CalendarMonth, tint = semantic.emerald, contentDescription = "خريطة الصرف", size = 38.dp)
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text("خريطة الصرف الشهرية", style = MaterialTheme.typography.titleMedium)
                Text("اضغط على أي يوم لمعرفة تفاصيل صرفه", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // 7-column grid
        val rows = cells.chunked(7)
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            rows.forEach { week ->
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    week.forEach { cell ->
                        val bg = when (cell.intensity) {
                            HeatmapIntensity.NONE -> MaterialTheme.colorScheme.surfaceVariant
                            HeatmapIntensity.ZERO_SPEND -> semantic.sky.copy(alpha = 0.35f)
                            HeatmapIntensity.LOW -> semantic.emerald.copy(alpha = 0.35f)
                            HeatmapIntensity.MEDIUM -> semantic.amber.copy(alpha = 0.45f)
                            HeatmapIntensity.HIGH -> semantic.coral.copy(alpha = 0.55f)
                        }
                        val isSel = selectedCell?.dayOfMonth == cell.dayOfMonth
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .aspectRatio(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(bg)
                                .clickable { selectedCell = cell },
                            contentAlignment = Alignment.Center,
                        ) {
                            Text(
                                text = "${cell.dayOfMonth}",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = if (isSel) FontWeight.Bold else FontWeight.Medium,
                                color = MaterialTheme.colorScheme.onSurface,
                            )
                        }
                    }
                    repeat(7 - week.size) {
                        Spacer(modifier = Modifier.weight(1f))
                    }
                }
            }
        }

        selectedCell?.let { cell ->
            Spacer(modifier = Modifier.height(10.dp))
            Surface(color = MaterialTheme.colorScheme.surfaceVariant, shape = RoundedCornerShape(12.dp)) {
                Text(
                    text = "${Formatters.formatShortDate(cell.date)}: صرفت ${Formatters.formatEgp(cell.amount, isMasked = isMasked)} (${cell.txCount} معاملات)",
                    style = MaterialTheme.typography.labelMedium,
                    modifier = Modifier.fillMaxWidth().padding(10.dp),
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            LegendDot("بدون صرف", semantic.sky)
            LegendDot("منخفض", semantic.emerald)
            LegendDot("متوسط", semantic.amber)
            LegendDot("مرتفع", semantic.coral)
        }
    }
}

@Composable
private fun LegendDot(label: String, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(modifier = Modifier.size(10.dp).clip(CircleShape).background(color.copy(alpha = 0.6f)))
        Spacer(modifier = Modifier.width(4.dp))
        Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun CategoryDonutChartCard(
    slices: List<CategorySlice>,
    totalExpense: Double,
    selectedIndex: Int?,
    isMasked: Boolean,
    onSelectIndex: (Int) -> Unit,
) {
    val sweepProgress by animateFloatAsState(targetValue = 1f, animationSpec = tween(durationMillis = 650), label = "donutSweep")
    val selectedSlice = selectedIndex?.let { slices.getOrNull(it) }
    val trackColor = MaterialTheme.colorScheme.surfaceVariant

    FintechCard(modifier = Modifier.fillMaxWidth()) {
        Text("توزيع المصاريف حسب التصنيف", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurface)
        Spacer(modifier = Modifier.height(16.dp))

        Box(modifier = Modifier.fillMaxWidth().height(200.dp), contentAlignment = Alignment.Center) {
            Canvas(modifier = Modifier.size(176.dp)) {
                val strokeWidth = 28.dp.toPx()
                val arcSize = Size(size.width - strokeWidth, size.height - strokeWidth)
                val topLeft = Offset(strokeWidth / 2f, strokeWidth / 2f)

                drawArc(
                    color = trackColor,
                    startAngle = 0f,
                    sweepAngle = 360f,
                    useCenter = false,
                    topLeft = topLeft,
                    size = arcSize,
                    style = Stroke(width = strokeWidth),
                )

                var startAngle = -90f
                slices.forEachIndexed { index, slice ->
                    val rawSweep = (slice.percentage / 100f) * 360f * sweepProgress
                    val gap = if (slices.size > 1) 2.5f else 0f
                    val sweep = (rawSweep - gap).coerceAtLeast(1f)
                    val isHighlighted = selectedIndex == null || selectedIndex == index
                    val sliceStroke = if (selectedIndex == index) strokeWidth + 6.dp.toPx() else strokeWidth

                    drawArc(
                        color = Color(slice.colorHex).copy(alpha = if (isHighlighted) 1f else 0.3f),
                        startAngle = startAngle,
                        sweepAngle = sweep,
                        useCenter = false,
                        topLeft = topLeft,
                        size = arcSize,
                        style = Stroke(width = sliceStroke, cap = StrokeCap.Butt),
                    )
                    startAngle += rawSweep
                }
            }

            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(selectedSlice?.name ?: "الإجمالي", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(
                    Formatters.formatEgp(selectedSlice?.amount ?: totalExpense, isMasked = isMasked),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface,
                )
                if (selectedSlice != null) {
                    Text("${selectedSlice.percentage.roundToInt()}%", style = MaterialTheme.typography.labelSmall, color = Color(selectedSlice.colorHex))
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            slices.forEachIndexed { index, slice ->
                val isSelected = selectedIndex == index
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (isSelected) Color(slice.colorHex).copy(alpha = 0.14f) else Color.Transparent)
                        .clickable { onSelectIndex(index) }
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Box(modifier = Modifier.size(12.dp).clip(CircleShape).background(Color(slice.colorHex)))
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(slice.name, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurface, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text("${slice.percentage.roundToInt()}%", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(Formatters.formatEgp(slice.amount, isMasked = isMasked), style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                }
            }
        }
    }
}

@Composable
private fun DailyBarChartCard(bars: List<DailyBarPoint>, dailySafeLimit: Double, isMasked: Boolean) {
    val semantic = LocalMasroufyColors.current
    val maxData = max(bars.maxOfOrNull { it.amount } ?: 0.0, dailySafeLimit)
    val chartMax = if (maxData > 0.0) maxData * 1.15 else 100.0
    val gridColor = MaterialTheme.colorScheme.outlineVariant

    FintechCard(modifier = Modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconBadge(icon = Icons.Rounded.BarChart, tint = semantic.sky, contentDescription = "الصرف اليومي", size = 38.dp)
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text("الصرف اليومي مقابل الحد الآمن", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurface)
                Text("الخط المتقطع يوضح الحد الآمن (${Formatters.formatEgp(dailySafeLimit, isMasked = isMasked)})", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }

        Spacer(modifier = Modifier.height(18.dp))

        Canvas(modifier = Modifier.fillMaxWidth().height(160.dp)) {
            val count = bars.size.coerceAtLeast(1)
            val slotWidth = size.width / count
            val barWidth = (slotWidth * 0.52f).coerceAtMost(28.dp.toPx())

            drawLine(color = gridColor, start = Offset(0f, size.height), end = Offset(size.width, size.height), strokeWidth = 1.dp.toPx())

            bars.forEachIndexed { idx, point ->
                val ratio = (point.amount / chartMax).toFloat().coerceIn(0f, 1f)
                val barHeight = (size.height * ratio).coerceAtLeast(if (point.amount > 0) 4.dp.toPx() else 0f)
                val left = idx * slotWidth + (slotWidth - barWidth) / 2f
                val top = size.height - barHeight
                val barColor = when {
                    dailySafeLimit > 0.0 && point.amount > dailySafeLimit -> semantic.coral
                    dailySafeLimit > 0.0 && point.amount > dailySafeLimit * 0.75 -> semantic.amber
                    else -> semantic.emerald
                }
                if (barHeight > 0f) {
                    drawRoundRect(
                        color = barColor,
                        topLeft = Offset(left, top),
                        size = Size(barWidth, barHeight),
                        cornerRadius = CornerRadius(6.dp.toPx(), 6.dp.toPx()),
                    )
                }
            }

            if (dailySafeLimit > 0.0) {
                val safeY = size.height - ((dailySafeLimit / chartMax).toFloat() * size.height)
                drawLine(
                    color = semantic.amber,
                    start = Offset(0f, safeY),
                    end = Offset(size.width, safeY),
                    strokeWidth = 2.dp.toPx(),
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(12f, 10f), 0f),
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            bars.forEach { point ->
                Text(point.label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center, modifier = Modifier.weight(1f), maxLines = 1)
            }
        }
    }
}

@Composable
private fun SmartArabicInsightsCard(analytics: AnalyticsSnapshot) {
    val semantic = LocalMasroufyColors.current
    FintechCard(
        modifier = Modifier.fillMaxWidth().testTag("smart_insights_card"),
        borderColor = semantic.emerald.copy(alpha = 0.4f),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconBadge(icon = Icons.Rounded.AutoAwesome, tint = semantic.emerald, contentDescription = "الرادار الذكي", size = 40.dp)
            Spacer(modifier = Modifier.width(10.dp))
            Text("ملخص الرادار المالي الذكي", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurface)
        }
        Spacer(modifier = Modifier.height(12.dp))
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            analytics.insights.forEachIndexed { index, insight ->
                Surface(color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f), shape = RoundedCornerShape(14.dp)) {
                    Row(modifier = Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.Top) {
                        Box(
                            modifier = Modifier.size(24.dp).clip(CircleShape).background(semantic.emerald.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center,
                        ) {
                            Text("${index + 1}", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = semantic.emerald)
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(insight, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurface, modifier = Modifier.weight(1f))
                    }
                }
            }
        }
    }
}
