package com.example.ui.screens

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.print.PrintAttributes
import android.print.PrintManager
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.FileProvider
import java.io.File

private const val LOCAL_APP_HOST = "masroufy.appassets.local"
private const val LOCAL_APP_URL = "https://$LOCAL_APP_HOST/index.html"

private class MasroufyAndroidBridge(
    private val context: Context,
    private val webViewProvider: () -> WebView?,
    private val onRequestVoice: (String) -> Unit,
) {
    @JavascriptInterface
    fun exportFile(filename: String, mimeType: String, content: String) {
        val safeName = filename.replace(Regex("[^A-Za-z0-9._-]"), "_").ifBlank { "masroufy_export.txt" }
        val exportDir = File(context.cacheDir, "exports").apply { mkdirs() }
        val outFile = File(exportDir, safeName)
        outFile.writeText(content, Charsets.UTF_8)

        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            outFile,
        )
        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = mimeType.substringBefore(';').ifBlank { "text/plain" }
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, safeName)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        val chooser = Intent.createChooser(shareIntent, "حفظ أو مشاركة الملف").apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(chooser)
    }

    @JavascriptInterface
    fun exportBase64File(filename: String, mimeType: String, base64Data: String) {
        val safeName = filename.replace(Regex("[^A-Za-z0-9._-]"), "_").ifBlank { "masroufy_qr.png" }
        val cleanBase64 = base64Data.substringAfter("base64,", base64Data)
        val bytes = try {
            android.util.Base64.decode(cleanBase64, android.util.Base64.DEFAULT)
        } catch (_: Exception) {
            return
        }
        val exportDir = File(context.cacheDir, "exports").apply { mkdirs() }
        val outFile = File(exportDir, safeName)
        outFile.writeBytes(bytes)

        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            outFile,
        )
        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = mimeType.substringBefore(';').ifBlank { "image/png" }
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, safeName)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        val chooser = Intent.createChooser(shareIntent, "حفظ أو مشاركة الصورة").apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(chooser)
    }

    @JavascriptInterface
    fun openExternalUrl(url: String) {
        val parsed = try { Uri.parse(url) } catch (_: Exception) { null } ?: return
        val scheme = parsed.scheme?.lowercase() ?: return
        if (scheme != "https" && scheme != "http") return
        try {
            context.startActivity(Intent(Intent.ACTION_VIEW, parsed).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Exception) {
        }
    }

    @JavascriptInterface
    fun startVoiceRecognition(lang: String) {
        onRequestVoice(lang.ifBlank { "ar-EG" })
    }

    @JavascriptInterface
    fun printDocument(jobTitle: String) {
        val wv = webViewProvider() ?: return
        wv.post {
            val printManager = context.getSystemService(Context.PRINT_SERVICE) as? PrintManager ?: return@post
            val adapter = wv.createPrintDocumentAdapter(jobTitle.ifBlank { "Masroufy-Statement" })
            printManager.print(jobTitle.ifBlank { "كشف حساب مصروفي" }, adapter, PrintAttributes.Builder().build())
        }
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun MasroufyWebViewScreen(
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    var webViewRef by remember { mutableStateOf<WebView?>(null) }
    var pendingFileCallback by remember { mutableStateOf<ValueCallback<Array<Uri>>?>(null) }
    var lastBackPressAt by remember { mutableLongStateOf(0L) }

    val voiceLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult(),
    ) { result ->
        val wv = webViewRef ?: return@rememberLauncherForActivityResult
        if (result.resultCode == Activity.RESULT_OK) {
            val spoken = result.data
                ?.getStringArrayListExtra(android.speech.RecognizerIntent.EXTRA_RESULTS)
                ?.firstOrNull()
                .orEmpty()
                .trim()
            val quoted = org.json.JSONObject.quote(spoken)
            wv.post {
                wv.evaluateJavascript("window.masroufyOnVoiceResult && window.masroufyOnVoiceResult($quoted);", null)
            }
        } else {
            wv.post {
                wv.evaluateJavascript("window.masroufyOnVoiceError && window.masroufyOnVoiceError('');", null)
            }
        }
    }

    val filePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument(),
    ) { uri ->
        val callback = pendingFileCallback
        pendingFileCallback = null
        if (callback != null) {
            callback.onReceiveValue(if (uri != null) arrayOf(uri) else null)
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            pendingFileCallback?.onReceiveValue(null)
            pendingFileCallback = null
            webViewRef?.destroy()
            webViewRef = null
        }
    }

    BackHandler(enabled = true) {
        val wv = webViewRef
        if (wv == null) {
            (context as? Activity)?.finish()
            return@BackHandler
        }
        wv.evaluateJavascript("(window.masroufyHandleAndroidBack && window.masroufyHandleAndroidBack()) || 'exit'") { result ->
            val cleaned = result?.trim('"') ?: "exit"
            if (cleaned != "handled") {
                val now = System.currentTimeMillis()
                if (now - lastBackPressAt < 2000L) {
                    (context as? Activity)?.finish()
                } else {
                    lastBackPressAt = now
                    Toast.makeText(context, "اضغط مرة أخرى للخروج", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .windowInsetsPadding(WindowInsets.safeDrawing)
            .imePadding(),
    ) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { ctx ->
                WebView(ctx).apply {
                    layoutParams = android.view.ViewGroup.LayoutParams(
                        android.view.ViewGroup.LayoutParams.MATCH_PARENT,
                        android.view.ViewGroup.LayoutParams.MATCH_PARENT,
                    )
                    setBackgroundColor(android.graphics.Color.parseColor("#0F172A"))
                    settings.apply {
                        javaScriptEnabled = true
                        domStorageEnabled = true
                        databaseEnabled = true
                        allowFileAccess = false
                        allowContentAccess = true
                        mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
                        setSupportZoom(false)
                        builtInZoomControls = false
                        displayZoomControls = false
                        useWideViewPort = true
                        loadWithOverviewMode = false
                        cacheMode = WebSettings.LOAD_DEFAULT
                    }

                    addJavascriptInterface(
                        MasroufyAndroidBridge(
                            context = ctx,
                            webViewProvider = { webViewRef },
                            onRequestVoice = { lang ->
                                val wv = webViewRef ?: return@MasroufyAndroidBridge
                                wv.post {
                                    try {
                                        val intent = Intent(android.speech.RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                                            putExtra(
                                                android.speech.RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                                                android.speech.RecognizerIntent.LANGUAGE_MODEL_FREE_FORM,
                                            )
                                            putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE, lang)
                                            putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, lang)
                                            putExtra(android.speech.RecognizerIntent.EXTRA_PROMPT, "تحدث الآن باللهجة المصرية...")
                                        }
                                        voiceLauncher.launch(intent)
                                    } catch (_: android.content.ActivityNotFoundException) {
                                        val msg = org.json.JSONObject.quote("التسجيل الصوتي غير مدعوم في هذا المتصفح، استخدم مايك لوحة المفاتيح")
                                        wv.evaluateJavascript("window.masroufyOnVoiceError && window.masroufyOnVoiceError($msg);", null)
                                    } catch (_: Exception) {
                                        val msg = org.json.JSONObject.quote("التسجيل الصوتي غير مدعوم في هذا المتصفح، استخدم مايك لوحة المفاتيح")
                                        wv.evaluateJavascript("window.masroufyOnVoiceError && window.masroufyOnVoiceError($msg);", null)
                                    }
                                }
                            },
                        ),
                        "MasroufyAndroidBridge",
                    )

                    webViewClient = object : WebViewClient() {
                        override fun shouldInterceptRequest(
                            view: WebView?,
                            request: WebResourceRequest?,
                        ): WebResourceResponse? {
                            val url = request?.url ?: return null
                            if (url.host != LOCAL_APP_HOST) return null

                            val rawPath = url.path?.trimStart('/').orEmpty().ifBlank { "index.html" }
                            if (rawPath.contains("..")) return null
                            val assetPath = "web/$rawPath"

                            return try {
                                val stream = ctx.assets.open(assetPath)
                                val mime = when {
                                    rawPath.endsWith(".html") -> "text/html"
                                    rawPath.endsWith(".css") -> "text/css"
                                    rawPath.endsWith(".js") -> "application/javascript"
                                    rawPath.endsWith(".json") -> "application/json"
                                    rawPath.endsWith(".svg") -> "image/svg+xml"
                                    rawPath.endsWith(".png") -> "image/png"
                                    else -> "application/octet-stream"
                                }
                                WebResourceResponse(
                                    mime,
                                    "UTF-8",
                                    200,
                                    "OK",
                                    mapOf("Cache-Control" to "no-store"),
                                    stream,
                                )
                            } catch (_: Exception) {
                                null
                            }
                        }

                        override fun shouldOverrideUrlLoading(
                            view: WebView?,
                            request: WebResourceRequest?,
                        ): Boolean {
                            val url = request?.url ?: return false
                            if (url.host == LOCAL_APP_HOST) return false
                            return try {
                                ctx.startActivity(Intent(Intent.ACTION_VIEW, url).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                                true
                            } catch (_: Exception) {
                                false
                            }
                        }
                    }

                    webChromeClient = object : WebChromeClient() {
                        override fun onShowFileChooser(
                            webView: WebView?,
                            filePathCallback: ValueCallback<Array<Uri>>?,
                            fileChooserParams: FileChooserParams?,
                        ): Boolean {
                            pendingFileCallback?.onReceiveValue(null)
                            pendingFileCallback = filePathCallback
                            return try {
                                filePickerLauncher.launch(arrayOf("application/json", "text/plain", "*/*"))
                                true
                            } catch (_: Exception) {
                                pendingFileCallback = null
                                false
                            }
                        }
                    }

                    webViewRef = this
                    loadUrl(LOCAL_APP_URL)
                }
            },
        )
    }
}
