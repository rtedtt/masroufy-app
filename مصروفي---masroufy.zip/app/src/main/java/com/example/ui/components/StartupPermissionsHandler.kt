package com.example.ui.components

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.NotificationsActive
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.example.notifications.NotificationHelper
import com.example.ui.theme.LocalMasroufyColors

@Composable
fun StartupPermissionsHandler(
    shouldAutoPrompt: Boolean,
    manualTriggerKey: Int = 0,
    onPromptCompleted: () -> Unit,
    onResultMessage: ((String) -> Unit)? = null,
) {
    val context = LocalContext.current
    val semantic = LocalMasroufyColors.current
    var showListenerDialog by remember { mutableStateOf(false) }

    val permissionsLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions(),
    ) { _ ->
        onPromptCompleted()
        if (!NotificationHelper.isNotificationListenerEnabled(context)) {
            showListenerDialog = true
        } else {
            onResultMessage?.invoke("كل الأذونات مفعلة وجاهزة ✅")
        }
    }

    fun launchPermissionsSequence() {
        val missing = buildList {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
            ) {
                add(Manifest.permission.POST_NOTIFICATIONS)
            }
            if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                add(Manifest.permission.RECORD_AUDIO)
            }
        }

        if (missing.isNotEmpty()) {
            permissionsLauncher.launch(missing.toTypedArray())
        } else {
            onPromptCompleted()
            if (!NotificationHelper.isNotificationListenerEnabled(context)) {
                showListenerDialog = true
            } else {
                onResultMessage?.invoke("كل الأذونات مفعلة بالفعل ✅")
            }
        }
    }

    LaunchedEffect(shouldAutoPrompt) {
        if (shouldAutoPrompt) {
            launchPermissionsSequence()
        }
    }

    LaunchedEffect(manualTriggerKey) {
        if (manualTriggerKey > 0) {
            launchPermissionsSequence()
        }
    }

    if (showListenerDialog) {
        BackHandler(enabled = true) { showListenerDialog = false }
        AlertDialog(
            onDismissRequest = { showListenerDialog = false },
            containerColor = MaterialTheme.colorScheme.surface,
            shape = RoundedCornerShape(22.dp),
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconBadge(
                        icon = Icons.Rounded.NotificationsActive,
                        tint = semantic.emerald,
                        contentDescription = "الرصد التلقائي",
                        size = 40.dp,
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "تفعيل الرصد التلقائي للمعاملات",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                    )
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "عشان مصروفي يرصد إشعارات الدفع من إنستا باي وفودافون كاش والبنوك تلقائياً ويسهّل عليك التسجيل بضغطة واحدة:",
                        style = MaterialTheme.typography.bodyMedium,
                    )
                    Text(
                        text = "اضغط «فتح الإعدادات للتفعيل» ثم فعّل اختيار «مصروفي / رصد معاملات مصروفي».",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        showListenerDialog = false
                        NotificationHelper.openNotificationListenerSettings(context)
                    },
                    shape = RoundedCornerShape(12.dp),
                ) {
                    Text("فتح الإعدادات للتفعيل")
                }
            },
            dismissButton = {
                TextButton(onClick = { showListenerDialog = false }) {
                    Text("لاحقاً")
                }
            },
        )
    }
}
