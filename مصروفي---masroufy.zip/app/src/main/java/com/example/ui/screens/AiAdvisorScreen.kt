package com.example.ui.screens

import android.Manifest
import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.automirrored.rounded.VolumeUp
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.DeleteSweep
import androidx.compose.material.icons.rounded.Key
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.Psychology
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.example.data.local.AiChatMessageEntity
import com.example.domain.Formatters
import com.example.ui.components.ApiKeySetupBottomSheet
import com.example.ui.components.ConfirmActionDialog
import com.example.ui.components.IconBadge
import com.example.ui.theme.LocalMasroufyColors
import com.example.viewmodel.MasroufyUiState
import java.util.Locale

private val quickPromptChips = listOf(
    "إيه المصاريف اللي ملهاش لازمة؟ 💸",
    "اعمل لي خطة تحويش 🎯",
    "قيّم وضعي المالي الشهر ده 📊",
    "إزاي أوفر من مصاريفي اليومية؟ 💡",
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AiAdvisorScreen(
    state: MasroufyUiState,
    onBack: () -> Unit,
    onSendMessage: (String) -> Unit,
    onClearChat: () -> Unit,
    onTestAndSaveApiKey: suspend (String) -> Result<Unit>,
    onClearApiKey: () -> Unit,
    onShowMessage: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    BackHandler(enabled = true) { onBack() }

    val context = LocalContext.current
    val semantic = LocalMasroufyColors.current
    val listState = rememberLazyListState()
    var inputText by remember { mutableStateOf("") }
    var showApiKeySheet by remember { mutableStateOf(false) }
    var showClearConfirm by remember { mutableStateOf(false) }
    var isTtsReady by remember { mutableStateOf(false) }
    var speakingMessageId by remember { mutableStateOf<Long?>(null) }

    val tts = remember(context) {
        var engine: TextToSpeech? = null
        engine = TextToSpeech(context.applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val res = engine?.setLanguage(Locale("ar"))
                if (res == TextToSpeech.LANG_MISSING_DATA || res == TextToSpeech.LANG_NOT_SUPPORTED) {
                    engine?.setLanguage(Locale.getDefault())
                }
                isTtsReady = true
            }
        }
        engine.setOnUtteranceProgressListener(
            object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}
                override fun onDone(utteranceId: String?) {
                    speakingMessageId = null
                }

                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    speakingMessageId = null
                }
            },
        )
        engine
    }

    DisposableEffect(tts) {
        onDispose {
            tts.stop()
            tts.shutdown()
        }
    }

    val voiceRecognitionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult(),
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val spoken = result.data
                ?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                ?.firstOrNull()
                ?.trim()
                .orEmpty()
            if (spoken.isNotBlank()) {
                inputText = if (inputText.isBlank()) spoken else "$inputText $spoken"
            }
        }
    }

    fun launchAdvisorVoiceInput() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-EG")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "ar-EG")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "اسأل المستشار المالي بصوتك...")
        }
        try {
            voiceRecognitionLauncher.launch(intent)
        } catch (_: ActivityNotFoundException) {
            onShowMessage("خدمة التعرف الصوتي غير متوفرة على هذا الجهاز حالياً")
        } catch (_: Exception) {
            onShowMessage("تعذر تشغيل الإدخال الصوتي")
        }
    }

    val audioPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission(),
    ) { granted ->
        if (granted) {
            launchAdvisorVoiceInput()
        } else {
            onShowMessage("يرجى السماح بإذن الميكروفون للتحدث مع المستشار")
        }
    }

    val hasKey = state.settings.hasGeminiApiKey

    LaunchedEffect(state.aiChatMessages.size, state.isAiThinking) {
        val targetIndex = (state.aiChatMessages.size - 1).coerceAtLeast(0)
        if (state.aiChatMessages.isNotEmpty()) {
            listState.animateScrollToItem(targetIndex)
        }
    }

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .imePadding(),
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface,
                ),
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("ai_back_button")) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "رجوع")
                    }
                },
                title = {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(
                                text = "المستشار المالي الذكي",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                            Icon(
                                Icons.Rounded.AutoAwesome,
                                contentDescription = null,
                                tint = semantic.amber,
                                modifier = Modifier.size(16.dp),
                            )
                        }
                        Text(
                            text = if (hasKey) "متصل بـ Gemini AI • تحليل حي لبياناتك" else "الوضع الأوفلاين الذكي • متصل ببياناتك",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (hasKey) semantic.emerald else semantic.amber,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = { showApiKeySheet = true },
                        modifier = Modifier.testTag("ai_api_key_button"),
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Key,
                            contentDescription = "إعداد مفتاح Gemini API",
                            tint = if (hasKey) semantic.emerald else semantic.amber,
                        )
                    }
                    if (state.aiChatMessages.isNotEmpty()) {
                        IconButton(
                            onClick = { showClearConfirm = true },
                            modifier = Modifier.testTag("ai_clear_chat_button"),
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.DeleteSweep,
                                contentDescription = "مسح المحادثة",
                                tint = semantic.coral,
                            )
                        }
                    }
                },
            )
        },
        bottomBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surface)
                    .navigationBarsPadding()
                    .padding(top = 8.dp, bottom = 10.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                // Horizontal Quick Prompt Chips
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState())
                        .padding(horizontal = 14.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    quickPromptChips.forEach { prompt ->
                        Surface(
                            shape = RoundedCornerShape(20.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            border = BorderStroke(1.dp, semantic.cardBorder),
                            modifier = Modifier
                                .clip(RoundedCornerShape(20.dp))
                                .clickable(enabled = !state.isAiThinking) {
                                    onSendMessage(prompt)
                                },
                        ) {
                            Text(
                                text = prompt,
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                            )
                        }
                    }
                }

                // Chat Input Bar
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    FilledIconButton(
                        onClick = {
                            if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                                launchAdvisorVoiceInput()
                            } else {
                                audioPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                            }
                        },
                        enabled = !state.isAiThinking,
                        colors = IconButtonDefaults.filledIconButtonColors(
                            containerColor = semantic.sky.copy(alpha = 0.16f),
                            contentColor = semantic.sky,
                        ),
                        modifier = Modifier
                            .size(50.dp)
                            .testTag("ai_voice_button"),
                    ) {
                        Icon(Icons.Rounded.Mic, contentDescription = "التحدث مع المستشار")
                    }
                    OutlinedTextField(
                        value = inputText,
                        onValueChange = { inputText = it },
                        placeholder = {
                            Text(
                                "اسأل عن مصاريفك، تحويش، أو ينفع أشتري حاجة بـ...",
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                        },
                        shape = RoundedCornerShape(22.dp),
                        maxLines = 3,
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                        keyboardActions = KeyboardActions(
                            onSend = {
                                if (inputText.isNotBlank() && !state.isAiThinking) {
                                    onSendMessage(inputText)
                                    inputText = ""
                                }
                            },
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("ai_chat_input"),
                    )
                    FilledIconButton(
                        onClick = {
                            if (inputText.isNotBlank() && !state.isAiThinking) {
                                onSendMessage(inputText)
                                inputText = ""
                            }
                        },
                        enabled = inputText.isNotBlank() && !state.isAiThinking,
                        colors = IconButtonDefaults.filledIconButtonColors(
                            containerColor = semantic.emerald,
                            contentColor = Color.White,
                        ),
                        modifier = Modifier
                            .size(50.dp)
                            .testTag("ai_send_button"),
                    ) {
                        Icon(Icons.AutoMirrored.Rounded.Send, contentDescription = "إرسال")
                    }
                }
            }
        },
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            // Friendly banner when no API key is configured
            AnimatedVisibility(visible = !hasKey) {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .widthIn(max = 680.dp)
                        .padding(horizontal = 14.dp, vertical = 8.dp),
                    shape = RoundedCornerShape(16.dp),
                    color = semantic.amber.copy(alpha = 0.14f),
                    border = BorderStroke(1.dp, semantic.amber.copy(alpha = 0.45f)),
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        Text(
                            text = "أنت على الوضع الأوفلاين الذكي • فعّل الذكاء الاصطناعي الكامل مجاناً في 30 ثانية",
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Medium,
                            color = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.weight(1f),
                        )
                        Button(
                            onClick = { showApiKeySheet = true },
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = semantic.emerald,
                                contentColor = Color.White,
                            ),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                            modifier = Modifier.testTag("activate_ai_banner_button"),
                        ) {
                            Text("تفعيل الآن", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            if (state.aiChatMessages.isEmpty() && !state.isAiThinking) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier.widthIn(max = 420.dp),
                    ) {
                        Box(
                            modifier = Modifier
                                .size(72.dp)
                                .clip(CircleShape)
                                .background(
                                    Brush.linearGradient(
                                        listOf(
                                            semantic.emerald.copy(alpha = 0.25f),
                                            semantic.sky.copy(alpha = 0.25f),
                                        ),
                                    ),
                                ),
                            contentAlignment = Alignment.Center,
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Psychology,
                                contentDescription = null,
                                tint = semantic.emerald,
                                modifier = Modifier.size(38.dp),
                            )
                        }
                        Text(
                            text = "أهلاً بك في المستشار المالي الذكي",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                        )
                        Text(
                            text = "بقرأ محافظك وأظرفك ومصاريف الشهر ده لحظة بلحظة عشان أساعدك تاخد قرارات مالية صح — جرب تضغط على أي سؤال سريع تحت أو اتكلم بالميكروفون!",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            } else {
                LazyColumn(
                    state = listState,
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .widthIn(max = 680.dp),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    items(state.aiChatMessages, key = { it.id }) { msg ->
                        ChatMessageBubble(
                            message = msg,
                            isSpeaking = speakingMessageId == msg.id,
                            onToggleSpeak = {
                                if (speakingMessageId == msg.id) {
                                    tts.stop()
                                    speakingMessageId = null
                                } else if (!isTtsReady) {
                                    onShowMessage("محرك القراءة الصوتية غير متاح حالياً")
                                } else {
                                    tts.stop()
                                    speakingMessageId = msg.id
                                    tts.speak(msg.text, TextToSpeech.QUEUE_FLUSH, null, "msg_${msg.id}")
                                }
                            },
                        )
                    }
                    if (state.isAiThinking) {
                        item(key = "typing_indicator") {
                            TypingBubble()
                        }
                    }
                }
            }
        }
    }

    if (showApiKeySheet) {
        ApiKeySetupBottomSheet(
            currentApiKey = state.settings.geminiApiKey,
            onTestAndSaveKey = onTestAndSaveApiKey,
            onClearKey = onClearApiKey,
            onShowMessage = onShowMessage,
            onDismiss = { showApiKeySheet = false },
        )
    }

    if (showClearConfirm) {
        BackHandler(enabled = true) { showClearConfirm = false }
        ConfirmActionDialog(
            title = "مسح المحادثة؟",
            message = "سيتم حذف جميع رسائل المحادثة الحالية مع المستشار المالي.",
            confirmText = "مسح المحادثة",
            isDestructive = true,
            onConfirm = {
                tts.stop()
                speakingMessageId = null
                onClearChat()
                showClearConfirm = false
            },
            onDismiss = { showClearConfirm = false },
        )
    }
}

@Composable
private fun ChatMessageBubble(
    message: AiChatMessageEntity,
    isSpeaking: Boolean,
    onToggleSpeak: () -> Unit,
) {
    val semantic = LocalMasroufyColors.current
    val isUser = message.isUser

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (isUser) Arrangement.Start else Arrangement.End,
    ) {
        Surface(
            modifier = Modifier.widthIn(max = 320.dp),
            shape = RoundedCornerShape(
                topStart = 18.dp,
                topEnd = 18.dp,
                bottomStart = if (isUser) 4.dp else 18.dp,
                bottomEnd = if (isUser) 18.dp else 4.dp,
            ),
            color = if (isUser) {
                semantic.emerald.copy(alpha = 0.2f)
            } else {
                MaterialTheme.colorScheme.surface
            },
            border = BorderStroke(
                width = 1.dp,
                color = if (isUser) semantic.emerald.copy(alpha = 0.5f) else semantic.cardBorder,
            ),
        ) {
            Column(
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                if (!isUser) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                        ) {
                            IconBadge(
                                icon = if (message.isOfflineEngine) Icons.Rounded.Psychology else Icons.Rounded.AutoAwesome,
                                tint = if (message.isOfflineEngine) semantic.amber else semantic.emerald,
                                contentDescription = "رد المستشار المالي",
                                size = 22.dp,
                            )
                            Text(
                                text = if (message.isOfflineEngine) "محلل أوفلاين ذكي" else "Gemini AI",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = if (message.isOfflineEngine) semantic.amber else semantic.emerald,
                            )
                        }
                        IconButton(
                            onClick = onToggleSpeak,
                            modifier = Modifier
                                .size(34.dp)
                                .testTag("ai_tts_${message.id}"),
                        ) {
                            Icon(
                                imageVector = if (isSpeaking) Icons.Rounded.Stop else Icons.AutoMirrored.Rounded.VolumeUp,
                                contentDescription = if (isSpeaking) "إيقاف القراءة" else "استماع للرد",
                                tint = if (isSpeaking) semantic.coral else semantic.sky,
                                modifier = Modifier.size(18.dp),
                            )
                        }
                    }
                }
                Text(
                    text = message.text,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurface,
                )
                Text(
                    text = Formatters.formatRelativeDateTime(message.timestamp),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

@Composable
private fun TypingBubble() {
    val semantic = LocalMasroufyColors.current
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.End,
    ) {
        Surface(
            shape = RoundedCornerShape(18.dp),
            color = MaterialTheme.colorScheme.surface,
            border = BorderStroke(1.dp, semantic.cardBorder),
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                CircularProgressIndicator(
                    modifier = Modifier.size(16.dp),
                    strokeWidth = 2.dp,
                    color = semantic.emerald,
                )
                Text(
                    text = "المستشار بيحلل أرقامك وبيجهز الرد...",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}
