package com.example.ui.components

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.CreditScore
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.data.local.InstallmentEntity
import com.example.data.local.WalletEntity
import com.example.domain.FinanceCalculator
import com.example.domain.Formatters
import com.example.ui.theme.LocalMasroufyColors

@Composable
fun InstallmentsSection(
    installments: List<InstallmentEntity>,
    wallets: List<WalletEntity>,
    reservedInstallmentsTotal: Double,
    isMasked: Boolean,
    onCreateClick: () -> Unit,
    onPayMonth: (installmentId: Long, walletId: Long) -> Unit,
    onDeleteInstallment: (Long) -> Unit,
) {
    val semantic = LocalMasroufyColors.current
    val currentCycle = FinanceCalculator.currentGameyaCycleKey()
    var payingTarget by remember { mutableStateOf<InstallmentEntity?>(null) }

    val totalRemainingCommitment = installments
        .filter { it.paidMonths < it.totalMonths }
        .sumOf { (it.totalMonths - it.paidMonths) * it.monthlyAmount }

    LazyColumn(
        contentPadding = PaddingValues(bottom = 108.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            FintechCard(
                borderColor = semantic.amber.copy(alpha = 0.45f),
                containerColor = semantic.amberContainer.copy(alpha = 0.3f),
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconBadge(
                        icon = Icons.Rounded.CreditScore,
                        tint = semantic.amber,
                        contentDescription = "متتبع الأقساط",
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text("متتبع الأقساط الشهرية 💳", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text(
                            text = "محجوز لأقساط الشهر: ${Formatters.formatEgp(reservedInstallmentsTotal, isMasked = isMasked)} • المتبقي الكلي: ${Formatters.formatEgp(totalRemainingCommitment, isMasked = isMasked)}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }
        }

        if (installments.isEmpty()) {
            item {
                EmptyStateCard(
                    icon = Icons.Rounded.CreditScore,
                    title = "مفيش أقساط مسجلة حالياً",
                    subtitle = "سجّل أقساط فاليو أو البطاقات أو الأجهزة عشان نحجز قسط الشهر تلقائياً من الرصيد الحر.",
                    actionText = "إضافة قسط جديد",
                    onAction = onCreateClick,
                )
            }
        } else {
            items(installments, key = { it.id }) { inst ->
                val isCompleted = inst.paidMonths >= inst.totalMonths
                val isPaidThisMonth = inst.lastPaidCycleKey == currentCycle
                val progress = if (inst.totalMonths > 0) (inst.paidMonths.toFloat() / inst.totalMonths.toFloat()).coerceIn(0f, 1f) else 0f

                FintechCard(
                    modifier = Modifier.testTag("installment_card_${inst.id}"),
                    borderColor = if (isCompleted) semantic.emerald else semantic.cardBorder,
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                            IconBadge(
                                icon = if (isCompleted) Icons.Rounded.CheckCircle else Icons.Rounded.CreditScore,
                                tint = if (isCompleted) semantic.emerald else semantic.amber,
                                contentDescription = inst.itemName,
                                size = 40.dp,
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(inst.itemName, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                Text(
                                    text = "قسط شهري: ${Formatters.formatEgp(inst.monthlyAmount, isMasked = isMasked)} • يوم ${inst.dueDay}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                        }
                        IconButton(onClick = { onDeleteInstallment(inst.id) }) {
                            Icon(Icons.Rounded.DeleteOutline, contentDescription = "حذف القسط", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(
                            text = "تم سداد ${inst.paidMonths} من ${inst.totalMonths} قسط",
                            style = MaterialTheme.typography.labelLarge,
                            color = if (isCompleted) semantic.emerald else semantic.amber,
                        )
                        val remainingAmt = ((inst.totalMonths - inst.paidMonths).coerceAtLeast(0)) * inst.monthlyAmount
                        Text(
                            text = "متبقي: ${Formatters.formatEgp(remainingAmt, isMasked = isMasked)}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    LinearProgressIndicator(
                        progress = { progress },
                        modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(8.dp)),
                        color = if (isCompleted) semantic.emerald else semantic.amber,
                        trackColor = MaterialTheme.colorScheme.surfaceVariant,
                        strokeCap = StrokeCap.Round,
                    )
                    if (!isCompleted) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Button(
                            onClick = { payingTarget = inst },
                            enabled = !isPaidThisMonth,
                            modifier = Modifier.fillMaxWidth().testTag("pay_installment_${inst.id}"),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isPaidThisMonth) MaterialTheme.colorScheme.surfaceVariant else semantic.amber,
                                contentColor = if (isPaidThisMonth) MaterialTheme.colorScheme.onSurfaceVariant else Color(0xFF1E1B18),
                            ),
                        ) {
                            Text(
                                text = if (isPaidThisMonth) "تم دفع قسط هذا الشهر ✓" else "دفع قسط الشهر الآن",
                                style = MaterialTheme.typography.labelLarge,
                            )
                        }
                    }
                }
            }
        }
    }

    payingTarget?.let { target ->
        BackHandler(enabled = true) { payingTarget = null }
        var selectedWalletId by remember(target) {
            mutableLongStateOf(wallets.firstOrNull { it.id == target.walletId }?.id ?: wallets.firstOrNull()?.id ?: 0L)
        }
        AlertDialog(
            onDismissRequest = { payingTarget = null },
            title = { Text("سداد قسط «${target.itemName}»", style = MaterialTheme.typography.titleLarge) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        "سيتم خصم ${Formatters.formatEgp(target.monthlyAmount)} وتسجيل القسط رقم ${target.paidMonths + 1}.",
                        style = MaterialTheme.typography.bodySmall,
                    )
                    wallets.forEach { w ->
                        val sel = selectedWalletId == w.id
                        Surface(
                            modifier = Modifier.fillMaxWidth().clickable { selectedWalletId = w.id },
                            shape = RoundedCornerShape(12.dp),
                            color = if (sel) semantic.amber.copy(alpha = 0.2f) else MaterialTheme.colorScheme.surfaceVariant,
                            border = BorderStroke(1.dp, if (sel) semantic.amber else semantic.cardBorder),
                        ) {
                            Row(modifier = Modifier.padding(10.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(w.name, style = MaterialTheme.typography.labelLarge)
                                Text(Formatters.formatEgp(w.balance), style = MaterialTheme.typography.labelMedium)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (selectedWalletId != 0L) {
                            onPayMonth(target.id, selectedWalletId)
                            payingTarget = null
                        }
                    },
                    shape = RoundedCornerShape(12.dp),
                ) { Text("تأكيد السداد") }
            },
            dismissButton = { TextButton(onClick = { payingTarget = null }) { Text("إلغاء") } },
            containerColor = MaterialTheme.colorScheme.surface,
            shape = RoundedCornerShape(22.dp),
        )
    }
}

@Composable
fun CreateInstallmentDialog(
    wallets: List<WalletEntity>,
    onSave: (itemName: String, monthlyAmount: Double, paidMonths: Int, totalMonths: Int, dueDay: Int, walletId: Long) -> Unit,
    onDismiss: () -> Unit,
) {
    BackHandler(enabled = true) { onDismiss() }

    val semantic = LocalMasroufyColors.current
    var itemName by remember { mutableStateOf("") }
    var monthlyText by remember { mutableStateOf("") }
    var totalMonthsText by remember { mutableStateOf("12") }
    var paidMonthsText by remember { mutableStateOf("0") }
    var dueDayText by remember { mutableStateOf("1") }
    var selectedWalletId by remember { mutableLongStateOf(wallets.firstOrNull()?.id ?: 0L) }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("إضافة قسط شهري جديد 💳", style = MaterialTheme.typography.titleLarge) },
        text = {
            Column(
                modifier = Modifier
                    .verticalScroll(rememberScrollState())
                    .imePadding(),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                OutlinedTextField(
                    value = itemName,
                    onValueChange = { itemName = it; error = null },
                    label = { Text("اسم القسط (مثلاً: موبايل، فاليو، سيارة)") },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth().testTag("installment_name_input"),
                )
                OutlinedTextField(
                    value = monthlyText,
                    onValueChange = { monthlyText = it; error = null },
                    label = { Text("القسط الشهري (ج.م)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth().testTag("installment_amount_input"),
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = paidMonthsText,
                        onValueChange = { paidMonthsText = it; error = null },
                        label = { Text("مدفوع") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.weight(1f),
                    )
                    OutlinedTextField(
                        value = totalMonthsText,
                        onValueChange = { totalMonthsText = it; error = null },
                        label = { Text("إجمالي الشهور") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.weight(1f),
                    )
                    OutlinedTextField(
                        value = dueDayText,
                        onValueChange = { dueDayText = it; error = null },
                        label = { Text("يوم (1-28)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.weight(1f),
                    )
                }
                Text("محفظة السداد الافتراضية:", style = MaterialTheme.typography.labelLarge)
                Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    wallets.forEach { w ->
                        val sel = selectedWalletId == w.id
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = if (sel) semantic.amber.copy(alpha = 0.2f) else MaterialTheme.colorScheme.surfaceVariant,
                            border = BorderStroke(1.dp, if (sel) semantic.amber else semantic.cardBorder),
                            modifier = Modifier.clickable { selectedWalletId = w.id },
                        ) {
                            Text(w.name, style = MaterialTheme.typography.labelMedium, modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp))
                        }
                    }
                }
                error?.let { Text(it, color = semantic.coral, style = MaterialTheme.typography.bodySmall) }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val monthly = Formatters.parseSafeDouble(monthlyText) ?: 0.0
                    val total = Formatters.normalizeArabicDigits(totalMonthsText).toIntOrNull() ?: 0
                    val paid = Formatters.normalizeArabicDigits(paidMonthsText).toIntOrNull() ?: 0
                    val dueDay = (Formatters.normalizeArabicDigits(dueDayText).toIntOrNull() ?: 1).coerceIn(1, 28)
                    when {
                        itemName.isBlank() -> error = "اكتب اسم القسط"
                        monthly <= 0.0 -> error = "أدخل قيمة قسط أكبر من صفر"
                        total <= 0 -> error = "أدخل عدد شهور صحيح"
                        paid < 0 || paid > total -> error = "الشهور المدفوعة لا تتجاوز الإجمالي"
                        selectedWalletId == 0L -> error = "اختر المحفظة"
                        else -> {
                            onSave(itemName, monthly, paid, total, dueDay, selectedWalletId)
                            onDismiss()
                        }
                    }
                },
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.testTag("save_installment_button"),
            ) { Text("حفظ القسط") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } },
        containerColor = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(22.dp),
    )
}
