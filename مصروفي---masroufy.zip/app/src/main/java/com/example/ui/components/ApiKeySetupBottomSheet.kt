package com.example.ui.components

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.ContentPaste
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Key
import androidx.compose.material.icons.rounded.OpenInNew
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import com.example.ui.theme.LocalMasroufyColors
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ApiKeySetupBottomSheet(
    currentApiKey: String,
    onTestAndSaveKey: suspend (String) -> Result<Unit>,
    onClearKey: () -> Unit,
    onShowMessage: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    BackHandler(enabled = true) { onDismiss() }

    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val scope = rememberCoroutineScope()
    val semantic = LocalMasroufyColors.current

    var keyInput by remember(currentApiKey) { mutableStateOf(currentApiKey) }
    var showKey by remember { mutableStateOf(false) }
    var isTesting by remember { mutableStateOf(false) }
    var statusSuccess by remember { mutableStateOf<String?>(null) }
    var statusError by remember { mutableStateOf<String?>(null) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = MaterialTheme.colorScheme.surface,
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .navigationBarsPadding()
                .imePadding()
                .padding(horizontal = 20.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                IconBadge(
                    icon = Icons.Rounded.AutoAwesome,
                    tint = semantic.emerald,
                    contentDescription = "تفعيل المستشار الذكي",
                    size = 44.dp,
                )
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "تفعيل المستشار المالي الذكي",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                    )
                    Text(
                        text = "مجاني وسريع — مفتاحك محفوظ محلياً على جهازك فقط",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }

            // 3 Clear Arabic Steps
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                border = BorderStroke(1.dp, semantic.cardBorder),
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    Text(
                        text = "خطوات التفعيل في 30 ثانية:",
                        style = MaterialTheme.typography.labelLarge,
                        color = semantic.emerald,
                        fontWeight = FontWeight.Bold,
                    )
                    GuideStepRow(
                        number = "1",
                        text = "افتح صفحة Google AI Studio وسجل دخول بحساب جوجل.",
                    )
                    GuideStepRow(
                        number = "2",
                        text = "اضغط على زر \"Create API key\" وانسخ الكود اللي هيظهرلك.",
                    )
                    GuideStepRow(
                        number = "3",
                        text = "ارجع هنا واضغط \"لصق وحفظ\" لتشغيل المستشار فوراً.",
                    )
                }
            }

            // Direct link button
            OutlinedButton(
                onClick = {
                    try {
                        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://aistudio.google.com/apikey"))
                        context.startActivity(intent)
                    } catch (_: Exception) {
                        onShowMessage("تعذر فتح المتصفح — افتح aistudio.google.com/apikey يدوياً")
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("open_ai_studio_button"),
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(1.dp, semantic.sky.copy(alpha = 0.6f)),
            ) {
                Icon(Icons.Rounded.OpenInNew, contentDescription = null, tint = semantic.sky, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "فتح صفحة الحصول على المفتاح 🔗",
                    color = semantic.sky,
                    fontWeight = FontWeight.SemiBold,
                )
            }

            // Password-masked input field (LTR inside for API key readability)
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                OutlinedTextField(
                    value = keyInput,
                    onValueChange = {
                        keyInput = it
                        statusError = null
                        statusSuccess = null
                    },
                    label = { Text("Gemini API Key") },
                    placeholder = { Text("AIzaSy...") },
                    leadingIcon = {
                        Icon(Icons.Rounded.Key, contentDescription = null, tint = semantic.emerald)
                    },
                    trailingIcon = {
                        IconButton(onClick = { showKey = !showKey }) {
                            Icon(
                                imageVector = if (showKey) Icons.Rounded.VisibilityOff else Icons.Rounded.Visibility,
                                contentDescription = if (showKey) "إخفاء" else "إظهار",
                            )
                        }
                    },
                    visualTransformation = if (showKey) VisualTransformation.None else PasswordVisualTransformation(),
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("gemini_api_key_input"),
                )
            }

            // 1-Tap Paste + Test & Save row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                OutlinedButton(
                    onClick = {
                        val pasted = clipboard.getText()?.text?.trim().orEmpty()
                        if (pasted.isEmpty()) {
                            statusError = "الحافظة فارغة — انسخ المفتاح أولاً من Google AI Studio"
                        } else {
                            keyInput = pasted
                            statusError = null
                            statusSuccess = null
                        }
                    },
                    modifier = Modifier
                        .weight(0.9f)
                        .testTag("paste_api_key_button"),
                    shape = RoundedCornerShape(14.dp),
                    contentPadding = PaddingValues(vertical = 12.dp, horizontal = 8.dp),
                ) {
                    Icon(Icons.Rounded.ContentPaste, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("لصق من الحافظة", maxLines = 1)
                }

                Button(
                    onClick = {
                        if (keyInput.isBlank()) {
                            statusError = "من فضلك أدخل أو الصق مفتاح Gemini API أولاً"
                            return@Button
                        }
                        scope.launch {
                            isTesting = true
                            statusError = null
                            statusSuccess = null
                            val res = onTestAndSaveKey(keyInput.trim())
                            isTesting = false
                            if (res.isSuccess) {
                                statusSuccess = "تم التفعيل بنجاح! ✅"
                            } else {
                                statusError = res.exceptionOrNull()?.message ?: "تعذر التحقق من المفتاح"
                            }
                        }
                    },
                    enabled = !isTesting,
                    modifier = Modifier
                        .weight(1.1f)
                        .testTag("test_save_api_key_button"),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = semantic.emerald, contentColor = Color.White),
                    contentPadding = PaddingValues(vertical = 12.dp, horizontal = 8.dp),
                ) {
                    if (isTesting) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(18.dp),
                            color = Color.White,
                            strokeWidth = 2.dp,
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("جاري الفحص...")
                    } else {
                        Icon(Icons.Rounded.CheckCircle, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("اختبار وحفظ المفتاح", maxLines = 1)
                    }
                }
            }

            statusSuccess?.let { msg ->
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    color = semantic.emerald.copy(alpha = 0.16f),
                    border = BorderStroke(1.dp, semantic.emerald.copy(alpha = 0.5f)),
                ) {
                    Text(
                        text = msg,
                        color = semantic.emerald,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(12.dp),
                    )
                }
            }

            statusError?.let { err ->
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    color = semantic.coral.copy(alpha = 0.15f),
                    border = BorderStroke(1.dp, semantic.coral.copy(alpha = 0.5f)),
                ) {
                    Text(
                        text = err,
                        color = semantic.coral,
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier.padding(12.dp),
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                if (currentApiKey.isNotBlank()) {
                    TextButton(
                        onClick = {
                            onClearKey()
                            keyInput = ""
                            statusSuccess = null
                            statusError = null
                        },
                    ) {
                        Icon(Icons.Rounded.DeleteOutline, contentDescription = null, tint = semantic.coral, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("حذف المفتاح", color = semantic.coral)
                    }
                } else {
                    Spacer(modifier = Modifier.width(1.dp))
                }
                TextButton(onClick = onDismiss) {
                    Text("إغلاق")
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
        }
    }
}

@Composable
private fun GuideStepRow(
    number: String,
    text: String,
) {
    val semantic = LocalMasroufyColors.current
    Row(
        verticalAlignment = Alignment.Top,
        horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Box(
            modifier = Modifier
                .size(22.dp)
                .clip(CircleShape)
                .background(semantic.emerald.copy(alpha = 0.2f)),
            contentAlignment = Alignment.Center,
        ) {
            Text(
                text = number,
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = semantic.emerald,
            )
        }
        Text(
            text = text,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.weight(1f),
        )
    }
}
