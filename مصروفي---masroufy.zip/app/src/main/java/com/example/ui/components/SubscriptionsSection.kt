package com.example.ui.components

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CalendarToday
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Radar
import androidx.compose.material.icons.rounded.Subscriptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.data.local.BillingCycle
import com.example.data.local.CategoryEntity
import com.example.data.local.SubscriptionEntity
import com.example.data.local.TransactionType
import com.example.data.local.WalletEntity
import com.example.domain.FinanceCalculator
import com.example.domain.Formatters
import com.example.domain.SubscriptionsSummary
import com.example.ui.theme.LocalMasroufyColors
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

@Composable
fun SubscriptionsSection(
    subscriptions: List<SubscriptionEntity>,
    summary: SubscriptionsSummary,
    wallets: List<WalletEntity>,
    isMasked: Boolean,
    onCreateClick: () -> Unit,
    onToggleActive: (id: Long, active: Boolean) -> Unit,
    onRenewNow: (id: Long) -> Unit,
    onDeleteSubscription: (Long) -> Unit,
) {
    val semantic = LocalMasroufyColors.current
    val walletMap = remember(wallets) { wallets.associateBy { it.id } }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 108.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            FintechCard(borderColor = semantic.sky.copy(alpha = 0.45f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "رادار الاشتراكات والفواتير",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = semantic.sky,
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(16.dp),
                        ) {
                            Column {
                                Text(
                                    text = "شهرياً",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                                Text(
                                    text = Formatters.formatEgp(summary.monthlyCommitment, isMasked),
                                    style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.Bold,
                                )
                            }
                            Column {
                                Text(
                                    text = "التكلفة السنوية",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                                Text(
                                    text = Formatters.formatEgp(summary.annualizedTotal, isMasked),
                                    style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.Bold,
                                    color = semantic.amber,
                                )
                            }
                        }
                        if (summary.dueWithin48HoursCount > 0) {
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "تنبيه: ${summary.dueWithin48HoursCount} اشتراك يتجدد خلال 48 ساعة",
                                style = MaterialTheme.typography.labelMedium,
                                color = semantic.coral,
                            )
                        }
                    }
                    IconBadge(
                        icon = Icons.Rounded.Radar,
                        tint = semantic.sky,
                        contentDescription = "رادار الاشتراكات",
                        size = 48.dp,
                    )
                }
            }
        }

        if (subscriptions.isEmpty()) {
            item {
                EmptyStateCard(
                    icon = Icons.Rounded.Subscriptions,
                    title = "مفيش اشتراكات متسجلة",
                    subtitle = "سجّل باقة الموبايل، الإنترنت الأرضي، أو أي اشتراك رقمي عشان تعرف تكلفتهم السنوية ويوصلك تنبيه قبل التجديد بـ 48 ساعة.",
                    actionText = "إضافة اشتراك",
                    onAction = onCreateClick,
                )
            }
        } else {
            items(subscriptions, key = { it.id }) { sub ->
                val daysLeft = FinanceCalculator.daysUntilRenewal(sub)
                val badgeColor = when {
                    !sub.isActive -> MaterialTheme.colorScheme.onSurfaceVariant
                    daysLeft <= 2L -> semantic.coral
                    daysLeft <= 7L -> semantic.amber
                    else -> semantic.emerald
                }
                val countdownLabel = when {
                    !sub.isActive -> "متوقف مؤقتاً"
                    daysLeft < 0L -> "متأخر ${kotlin.math.abs(daysLeft)} يوم"
                    daysLeft == 0L -> "يتجدد اليوم!"
                    daysLeft == 1L -> "يتجدد بكرة"
                    else -> "يتجدد خلال $daysLeft أيام"
                }
                val walletName = walletMap[sub.walletId]?.name ?: "كاش"
                val annualCost = if (sub.billingCycle == BillingCycle.YEARLY) sub.amount else sub.amount * 12.0

                FintechCard(
                    borderColor = if (sub.isActive && daysLeft in 0L..2L) semantic.coral.copy(alpha = 0.65f) else semantic.cardBorder,
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = sub.title,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = badgeColor.copy(alpha = 0.16f),
                                ) {
                                    Text(
                                        text = countdownLabel,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = badgeColor,
                                        fontWeight = FontWeight.SemiBold,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "${Formatters.formatEgp(sub.amount, isMasked)} (${BillingCycle.label(sub.billingCycle)}) • سنوياً: ${Formatters.formatEgp(annualCost, isMasked)}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                            Text(
                                text = "المحفظة: $walletName • الموعد: ${LocalDate.ofEpochDay(sub.nextRenewalEpochDay)}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                        Switch(
                            checked = sub.isActive,
                            onCheckedChange = { onToggleActive(sub.id, it) },
                        )
                        IconButton(onClick = { onDeleteSubscription(sub.id) }) {
                            Icon(
                                imageVector = Icons.Rounded.DeleteOutline,
                                contentDescription = "حذف الاشتراك",
                                tint = semantic.coral,
                            )
                        }
                    }

                    if (sub.isActive) {
                        Spacer(modifier = Modifier.height(10.dp))
                        OutlinedButton(
                            onClick = { onRenewNow(sub.id) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("renew_sub_btn_${sub.id}"),
                            shape = RoundedCornerShape(12.dp),
                        ) {
                            Text("تسجيل دفع الاشتراك وتجديد الموعد")
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreateSubscriptionDialog(
    wallets: List<WalletEntity>,
    categories: List<CategoryEntity>,
    onSave: (title: String, amount: Double, billingCycle: String, nextRenewalEpochDay: Long, walletId: Long, categoryId: Long?, note: String) -> Unit,
    onDismiss: () -> Unit,
) {
    BackHandler(enabled = true) { onDismiss() }
    val semantic = LocalMasroufyColors.current
    val expenseCategories = remember(categories) { categories.filter { it.type == TransactionType.EXPENSE } }
    val internetCat = remember(expenseCategories) {
        expenseCategories.firstOrNull { it.name.contains("باقة") || it.name.contains("إنترنت") } ?: expenseCategories.firstOrNull()
    }

    var title by remember { mutableStateOf("") }
    var amountText by remember { mutableStateOf("") }
    var billingCycle by remember { mutableStateOf(BillingCycle.MONTHLY) }
    var nextRenewalEpoch by remember { mutableLongStateOf(LocalDate.now().plusDays(15).toEpochDay()) }
    var selectedWalletId by remember(wallets) { mutableStateOf(wallets.firstOrNull()?.id ?: 0L) }
    var selectedCategoryId by remember(internetCat) { mutableStateOf(internetCat?.id) }
    var showDatePicker by remember { mutableStateOf(false) }
    var errorText by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(22.dp),
        title = { Text("اشتراك أو فاتورة ثابتة", style = MaterialTheme.typography.titleLarge) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it; errorText = null },
                    label = { Text("الاسم (مثال: باقة الموبايل، نت منزلي)") },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = amountText,
                    onValueChange = { amountText = it; errorText = null },
                    label = { Text("المبلغ (ج.م)") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth(),
                )

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(BillingCycle.MONTHLY to "شهري", BillingCycle.YEARLY to "سنوي").forEach { (cycle, label) ->
                        val selected = billingCycle == cycle
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = if (selected) semantic.sky.copy(alpha = 0.2f) else MaterialTheme.colorScheme.surfaceVariant,
                            border = BorderStroke(1.dp, if (selected) semantic.sky else semantic.cardBorder),
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(12.dp))
                                .clickable { billingCycle = cycle },
                        ) {
                            Text(
                                text = label,
                                style = MaterialTheme.typography.labelLarge,
                                modifier = Modifier.padding(vertical = 9.dp, horizontal = 12.dp),
                            )
                        }
                    }
                }

                OutlinedButton(
                    onClick = { showDatePicker = true },
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Icon(Icons.Rounded.CalendarToday, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("موعد التجديد القادم: ${LocalDate.ofEpochDay(nextRenewalEpoch)}")
                }

                Text("الدفع من محفظة:", style = MaterialTheme.typography.labelMedium)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    wallets.forEach { w ->
                        val selected = selectedWalletId == w.id
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = if (selected) semantic.emerald.copy(alpha = 0.2f) else MaterialTheme.colorScheme.surfaceVariant,
                            border = BorderStroke(1.dp, if (selected) semantic.emerald else semantic.cardBorder),
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .clickable { selectedWalletId = w.id },
                        ) {
                            Text(
                                text = w.name,
                                style = MaterialTheme.typography.labelMedium,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp),
                            )
                        }
                    }
                }

                if (errorText != null) {
                    Text(
                        text = errorText.orEmpty(),
                        style = MaterialTheme.typography.bodySmall,
                        color = semantic.coral,
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amount = Formatters.parseSafeDouble(amountText) ?: 0.0
                    if (title.isBlank() || amount <= 0.0) {
                        errorText = "أدخل اسم الاشتراك والمبلغ بشكل صحيح"
                        return@Button
                    }
                    if (selectedWalletId == 0L) {
                        errorText = "اختر المحفظة أولاً"
                        return@Button
                    }
                    onSave(title, amount, billingCycle, nextRenewalEpoch, selectedWalletId, selectedCategoryId, "")
                    onDismiss()
                },
            ) {
                Text("حفظ")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("إلغاء") }
        },
    )

    if (showDatePicker) {
        val dateState = rememberDatePickerState(
            initialSelectedDateMillis = LocalDate.ofEpochDay(nextRenewalEpoch)
                .atStartOfDay(ZoneId.systemDefault())
                .toInstant()
                .toEpochMilli(),
        )
        DatePickerDialog(
            onDismissRequest = { showDatePicker = false },
            confirmButton = {
                TextButton(
                    onClick = {
                        dateState.selectedDateMillis?.let { millis ->
                            nextRenewalEpoch = Instant.ofEpochMilli(millis)
                                .atZone(ZoneId.systemDefault())
                                .toLocalDate()
                                .toEpochDay()
                        }
                        showDatePicker = false
                    },
                ) { Text("تأكيد") }
            },
            dismissButton = {
                TextButton(onClick = { showDatePicker = false }) { Text("إلغاء") }
            },
        ) {
            DatePicker(state = dateState)
        }
    }
}
