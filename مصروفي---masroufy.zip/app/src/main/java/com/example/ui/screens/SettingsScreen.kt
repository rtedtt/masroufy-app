package com.example.ui.screens

import android.Manifest
import android.content.Context
import android.net.Uri
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.biometric.BiometricManager
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AccountBalanceWallet
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.ArrowDownward
import androidx.compose.material.icons.rounded.ArrowUpward
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.AutoMode
import androidx.compose.material.icons.rounded.Backup
import androidx.compose.material.icons.rounded.Balance
import androidx.compose.material.icons.rounded.CalendarMonth
import androidx.compose.material.icons.rounded.Category
import androidx.compose.material.icons.rounded.DarkMode
import androidx.compose.material.icons.rounded.DeleteForever
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Fingerprint
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.NotificationsActive
import androidx.compose.material.icons.rounded.NotificationsNone
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.PictureAsPdf
import androidx.compose.material.icons.rounded.Radar
import androidx.compose.material.icons.rounded.Restore
import androidx.compose.material.icons.rounded.Security
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.TableChart
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.example.data.local.CategoryEntity
import com.example.data.local.RolloverMode
import com.example.data.local.ThemeMode
import com.example.data.local.TransactionType
import com.example.data.local.WalletEntity
import com.example.data.local.WalletType
import com.example.domain.Formatters
import com.example.domain.ReportExporter
import com.example.notifications.NotificationHelper
import com.example.ui.components.ApiKeySetupBottomSheet
import com.example.ui.components.ConfirmActionDialog
import com.example.ui.components.DeveloperSignatureCard
import com.example.ui.components.FintechCard
import com.example.ui.components.IconBadge
import com.example.ui.components.IconsCatalog
import com.example.ui.components.PinKeypad
import com.example.ui.theme.LocalMasroufyColors
import com.example.viewmodel.MasroufyUiState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.LocalDate

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SettingsScreen(
    state: MasroufyUiState,
    onSetThemeMode: (String) -> Unit,
    onTogglePrivacyMode: () -> Unit,
    onSetCycleStartDay: (Int) -> Unit,
    onSetDailyRolloverMode: (String) -> Unit = {},
    onSetDailyReminder: (enabled: Boolean, hour: Int, minute: Int) -> Unit,
    onSetPersistentQuickLog: (Boolean) -> Unit,
    onSetWeeklyAutoBackup: (Boolean) -> Unit,
    onEnablePin: (String) -> Unit,
    onDisablePin: () -> Unit,
    onToggleBiometric: (Boolean) -> Unit,
    onSaveWallet: (id: Long, name: String, balance: Double, type: String, iconKey: String, colorHex: Long, isDefault: Boolean, minBalanceThreshold: Double, sortOrder: Int) -> Unit,
    onDeleteWallet: (Long) -> Unit,
    onMoveWalletOrder: (id: Long, moveUp: Boolean) -> Unit,
    onReconcileWallet: (walletId: Long, actualBalance: Double) -> Unit,
    onSaveCategory: (id: Long, name: String, type: String, iconKey: String, colorHex: Long, isDefault: Boolean, monthlyBudget: Double?, sortOrder: Int) -> Unit,
    onDeleteCategory: (Long) -> Unit,
    onMoveCategoryOrder: (id: Long, moveUp: Boolean) -> Unit,
    onBuildBackupJson: suspend () -> String,
    onRestoreBackupJson: (String) -> Unit,
    onResetAllData: () -> Unit,
    onTestAndSaveGeminiApiKey: suspend (String) -> Result<Unit>,
    onClearGeminiApiKey: () -> Unit,
    onOpenThemesGallery: () -> Unit = {},
    onSetAutoNotificationCapture: (Boolean) -> Unit = {},
    onCheckAllPermissions: () -> Unit = {},
    onShowMessage: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val semantic = LocalMasroufyColors.current
    val listState = rememberLazyListState()
    val lifecycleOwner = LocalLifecycleOwner.current
    var isListenerEnabled by remember {
        mutableStateOf(NotificationHelper.isNotificationListenerEnabled(context))
    }
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                isListenerEnabled = NotificationHelper.isNotificationListenerEnabled(context)
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    var showCycleDayDialog by remember { mutableStateOf(false) }
    var showPinSetupDialog by remember { mutableStateOf(false) }
    var showManageWalletsSheet by remember { mutableStateOf(false) }
    var showManageCategoriesSheet by remember { mutableStateOf(false) }
    var showResetConfirmDialog by remember { mutableStateOf(false) }
    var showApiKeySetupSheet by remember { mutableStateOf(false) }

    var pendingNotificationAction by remember { mutableStateOf<(() -> Unit)?>(null) }
    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission(),
    ) { granted ->
        if (granted) {
            pendingNotificationAction?.invoke()
        } else {
            onShowMessage("يرجى السماح بالإشعارات من إعدادات الجهاز لتفعيل التذكيرات")
        }
        pendingNotificationAction = null
    }

    fun runWithNotificationPermission(action: () -> Unit) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && !NotificationHelper.hasNotificationPermission(context)) {
            pendingNotificationAction = action
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            action()
        }
    }

    val biometricAvailable = remember(context) { isBiometricAvailable(context) }

    // SAF JSON Export Launcher
    val exportJsonLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/json"),
    ) { uri: Uri? ->
        if (uri != null) {
            scope.launch {
                try {
                    val json = onBuildBackupJson()
                    withContext(Dispatchers.IO) {
                        context.contentResolver.openOutputStream(uri)?.use { out ->
                            out.write(json.toByteArray(Charsets.UTF_8))
                        }
                    }
                    onShowMessage("تم تصدير النسخة الاحتياطية بنجاح")
                } catch (_: Exception) {
                    onShowMessage("تعذر حفظ ملف النسخة الاحتياطية")
                }
            }
        }
    }

    // SAF JSON Import Launcher
    val importJsonLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument(),
    ) { uri: Uri? ->
        if (uri != null) {
            scope.launch {
                try {
                    val jsonText = withContext(Dispatchers.IO) {
                        context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                    }
                    if (!jsonText.isNullOrBlank()) {
                        onRestoreBackupJson(jsonText)
                    } else {
                        onShowMessage("الملف المختار فارغ")
                    }
                } catch (_: Exception) {
                    onShowMessage("تعذر قراءة ملف النسخة الاحتياطية")
                }
            }
        }
    }

    // SAF CSV Export Launcher (#23)
    val exportCsvLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("text/csv"),
    ) { uri: Uri? ->
        if (uri != null) {
            scope.launch {
                try {
                    val csv = ReportExporter.buildCsvContent(
                        transactions = state.transactions,
                        wallets = state.wallets,
                        categories = state.categories,
                    )
                    withContext(Dispatchers.IO) {
                        context.contentResolver.openOutputStream(uri)?.use { out ->
                            out.write(csv.toByteArray(Charsets.UTF_8))
                        }
                    }
                    onShowMessage("تم حفظ ملف CSV بنجاح")
                } catch (_: Exception) {
                    onShowMessage("تعذر حفظ ملف CSV")
                }
            }
        }
    }

    // SAF PDF Export Launcher (#23)
    val exportPdfLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/pdf"),
    ) { uri: Uri? ->
        if (uri != null) {
            scope.launch {
                try {
                    withContext(Dispatchers.IO) {
                        context.contentResolver.openOutputStream(uri)?.use { out ->
                            ReportExporter.writePdfReport(
                                outputStream = out,
                                transactions = state.transactions,
                                wallets = state.wallets,
                                categories = state.categories,
                                budgetSnapshot = state.budgetSnapshot,
                            )
                        }
                    }
                    onShowMessage("تم حفظ تقرير PDF بنجاح")
                } catch (_: Exception) {
                    onShowMessage("تعذر حفظ تقرير PDF")
                }
            }
        }
    }

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter,
    ) {
        LazyColumn(
            state = listState,
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 680.dp),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 108.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            item {
                Column {
                    Text(
                        text = "الإعدادات والأمان",
                        style = MaterialTheme.typography.headlineMedium,
                        color = MaterialTheme.colorScheme.onBackground,
                    )
                    Text(
                        text = "خصص التطبيق واحفظ بياناتك بأمان تام على جهازك",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }

            // Section 1: Appearance, Privacy & Budget Cycle
            item {
                FintechCard {
                    Text(
                        text = "المظهر والميزانية",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface,
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconBadge(
                            icon = Icons.Rounded.DarkMode,
                            tint = semantic.sky,
                            contentDescription = "ثيم التطبيق",
                            size = 40.dp,
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text("ثيم التطبيق", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                            Text(
                                "اختر الداكن أو الفاتح أو التزامن التلقائي مع النظام",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        listOf(
                            ThemeMode.DARK to "داكن",
                            ThemeMode.LIGHT to "فاتح",
                            ThemeMode.SYSTEM to "تلقائي (النظام)",
                        ).forEach { (mode, label) ->
                            val selected = state.settings.themeMode == mode
                            Surface(
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable { onSetThemeMode(mode) }
                                    .testTag("theme_mode_$mode"),
                                shape = RoundedCornerShape(12.dp),
                                color = if (selected) MaterialTheme.colorScheme.primary.copy(alpha = 0.18f) else MaterialTheme.colorScheme.surfaceVariant,
                                border = BorderStroke(1.dp, if (selected) MaterialTheme.colorScheme.primary else semantic.cardBorder),
                            ) {
                                Text(
                                    text = label,
                                    modifier = Modifier.padding(vertical = 10.dp, horizontal = 6.dp),
                                    textAlign = TextAlign.Center,
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                                    color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                )
                            }
                        }
                    }

                    HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp), color = semantic.cardBorder)

                    SettingsClickRow(
                        icon = Icons.Rounded.Palette,
                        tint = MaterialTheme.colorScheme.primary,
                        title = "معرض السمات والمستويات",
                        subtitle = "${state.gamification.activeThemePack.arabicName} • ${state.gamification.rank.title}",
                        onClick = onOpenThemesGallery,
                        testTag = "settings_themes_gallery_row",
                    )

                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = semantic.cardBorder)

                    SettingsSwitchRow(
                        icon = Icons.Rounded.VisibilityOff,
                        tint = semantic.amber,
                        title = "وضع الخصوصية (إخفاء الأرصدة)",
                        subtitle = "استبدال الأرقام بـ **** عند فتح التطبيق في الأماكن العامة",
                        checked = state.settings.isPrivacyMode,
                        onCheckedChange = { onTogglePrivacyMode() },
                        testTag = "privacy_mode_switch",
                    )

                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = semantic.cardBorder)

                    SettingsClickRow(
                        icon = Icons.Rounded.CalendarMonth,
                        tint = semantic.emerald,
                        title = "بداية الدورة الشهرية",
                        subtitle = "إعادة ضبط الميزانية يوم ${state.settings.budgetCycleStartDay} من كل شهر",
                        onClick = { showCycleDayDialog = true },
                        testTag = "cycle_day_row",
                    )

                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = semantic.cardBorder)

                    Text(
                        text = "ترحيل الفائض اليومي (مؤشر الأمان)",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onSurface,
                    )
                    Text(
                        text = RolloverMode.label(state.settings.dailyRolloverMode),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        listOf(
                            RolloverMode.NONE to "ثابت يومياً",
                            RolloverMode.TODAY_BONUS to "مكافأة اليوم",
                            RolloverMode.SPREAD_REMAINING to "توزيع تلقائي",
                        ).forEach { (modeKey, modeLabel) ->
                            FilterChip(
                                selected = state.settings.dailyRolloverMode == modeKey,
                                onClick = { onSetDailyRolloverMode(modeKey) },
                                label = { Text(modeLabel) },
                                modifier = Modifier.testTag("rollover_chip_$modeKey"),
                            )
                        }
                    }
                }
            }

            // Section 2: Notifications & Reminders (#7, #11)
            item {
                FintechCard {
                    Text(
                        text = "الإشعارات والتذكيرات",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface,
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    SettingsSwitchRow(
                        icon = Icons.Rounded.NotificationsActive,
                        tint = semantic.emerald,
                        title = "التذكير المسائي اليومي",
                        subtitle = "تذكير يومي الساعة ${formatReminderHour(state.settings.dailyReminderHour)} لو مسجلتش مصاريفك",
                        checked = state.settings.dailyReminderEnabled,
                        onCheckedChange = { enabled ->
                            if (enabled) {
                                runWithNotificationPermission {
                                    onSetDailyReminder(true, state.settings.dailyReminderHour, 0)
                                }
                            } else {
                                onSetDailyReminder(false, state.settings.dailyReminderHour, 0)
                            }
                        },
                        testTag = "daily_reminder_switch",
                    )

                    if (state.settings.dailyReminderEnabled) {
                        Spacer(modifier = Modifier.height(6.dp))
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp),
                        ) {
                            listOf(20, 21, 22, 23).forEach { hr ->
                                FilterChip(
                                    selected = state.settings.dailyReminderHour == hr,
                                    onClick = {
                                        runWithNotificationPermission {
                                            onSetDailyReminder(true, hr, 0)
                                        }
                                    },
                                    label = { Text(formatReminderHour(hr)) },
                                )
                            }
                        }
                    }

                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = semantic.cardBorder)

                    SettingsSwitchRow(
                        icon = Icons.Rounded.NotificationsNone,
                        tint = semantic.sky,
                        title = "إشعار التسجيل السريع المستمر",
                        subtitle = "اختصار دائم في شريط الإشعارات لفتح نافذة التسجيل بلمسة واحدة",
                        checked = state.settings.persistentQuickLogEnabled,
                        onCheckedChange = { enabled ->
                            if (enabled) {
                                runWithNotificationPermission {
                                    onSetPersistentQuickLog(true)
                                }
                            } else {
                                onSetPersistentQuickLog(false)
                            }
                        },
                        testTag = "persistent_quick_log_switch",
                    )

                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = semantic.cardBorder)

                    SettingsSwitchRow(
                        icon = Icons.Rounded.Radar,
                        tint = semantic.emerald,
                        title = "الرصد التلقائي لإشعارات الدفع",
                        subtitle = "التقاط معاملات إنستا باي وفودافون كاش والبنوك تلقائياً",
                        checked = state.settings.autoNotificationCaptureEnabled,
                        onCheckedChange = onSetAutoNotificationCapture,
                        testTag = "auto_capture_switch",
                    )

                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = semantic.cardBorder)

                    SettingsClickRow(
                        icon = Icons.Rounded.NotificationsActive,
                        tint = if (isListenerEnabled) semantic.emerald else semantic.amber,
                        title = "تفعيل إذن قراءة الإشعارات",
                        subtitle = if (isListenerEnabled) {
                            "مفعّل حالياً ✅ — يلتقط إشعارات المحافظ والبنوك"
                        } else {
                            "غير مفعّل — اضغط لفتح إعدادات الجهاز وتفعيل مصروفي"
                        },
                        onClick = { NotificationHelper.openNotificationListenerSettings(context) },
                        testTag = "notification_listener_settings_row",
                    )

                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = semantic.cardBorder)

                    SettingsClickRow(
                        icon = Icons.Rounded.Security,
                        tint = semantic.sky,
                        title = "فحص وتفعيل الأذونات",
                        subtitle = "مراجعة وتفعيل أذونات الإشعارات، الميكروفون الصوتي، وقراءة الإشعارات",
                        onClick = onCheckAllPermissions,
                        testTag = "check_all_permissions_row",
                    )
                }
            }

            // Section 3: Security (PIN & BiometricPrompt)
            item {
                FintechCard {
                    Text(
                        text = "الأمان والقفل",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface,
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    SettingsSwitchRow(
                        icon = Icons.Rounded.Lock,
                        tint = semantic.amber,
                        title = "قفل التطبيق برمز PIN",
                        subtitle = if (state.settings.isPinEnabled) "مفعّل (4 أرقام)" else "حماية التطبيق عند الفتح",
                        checked = state.settings.isPinEnabled,
                        onCheckedChange = { enable ->
                            if (enable) {
                                showPinSetupDialog = true
                            } else {
                                onDisablePin()
                            }
                        },
                        testTag = "pin_lock_switch",
                    )

                    if (state.settings.isPinEnabled) {
                        HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = semantic.cardBorder)
                        SettingsSwitchRow(
                            icon = Icons.Rounded.Fingerprint,
                            tint = semantic.emerald,
                            title = "الفتح بالبصمة أو الوجه",
                            subtitle = if (biometricAvailable) {
                                "فتح سريع عبر مستشعر الأمان"
                            } else {
                                "غير متاح أو غير مسجل على هذا الجهاز"
                            },
                            checked = state.settings.isBiometricEnabled,
                            enabled = biometricAvailable,
                            onCheckedChange = onToggleBiometric,
                            testTag = "biometric_switch",
                        )
                    }
                }
            }

            // Section 4: Manage Wallets & Categories (#6, #9, #27, #28)
            item {
                FintechCard {
                    Text(
                        text = "إدارة المحافظ والتصنيفات",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface,
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    SettingsClickRow(
                        icon = Icons.Rounded.AccountBalanceWallet,
                        tint = semantic.emerald,
                        title = "إدارة وترتيب المحافظ",
                        subtitle = "${state.wallets.size} محافظ نشطة (إضافة، جرد رصيد، تنبيه الانخفاض، ترتيب)",
                        onClick = { showManageWalletsSheet = true },
                        testTag = "manage_wallets_row",
                    )

                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = semantic.cardBorder)

                    SettingsClickRow(
                        icon = Icons.Rounded.Category,
                        tint = semantic.sky,
                        title = "إدارة التصنيفات والحدود الشهرية",
                        subtitle = "${state.categories.size} تصنيف (تعديل، حدود إنفاق، ترتيب)",
                        onClick = { showManageCategoriesSheet = true },
                        testTag = "manage_categories_row",
                    )
                }
            }

            // Section 5: Backup, Reports & Reset (#23, #29)
            item {
                FintechCard {
                    Text(
                        text = "النسخ الاحتياطي والتقارير",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface,
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    val lastBackupText = if (state.settings.lastWeeklyBackupAt > 0L) {
                        "آخر نسخة تلقائية: ${Formatters.formatRelativeDateTime(state.settings.lastWeeklyBackupAt)}"
                    } else {
                        "حفظ نسخة محلية تلقائياً كل أسبوع في مجلد التطبيق"
                    }

                    SettingsSwitchRow(
                        icon = Icons.Rounded.AutoMode,
                        tint = semantic.emerald,
                        title = "النسخ الاحتياطي التلقائي الأسبوعي",
                        subtitle = lastBackupText,
                        checked = state.settings.weeklyAutoBackupEnabled,
                        onCheckedChange = onSetWeeklyAutoBackup,
                        testTag = "weekly_auto_backup_switch",
                    )

                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = semantic.cardBorder)

                    SettingsClickRow(
                        icon = Icons.Rounded.Backup,
                        tint = semantic.emerald,
                        title = "تصدير نسخة احتياطية (JSON)",
                        subtitle = "حفظ كل المحافظ والمعاملات والأهداف والمتكررة في ملف",
                        onClick = {
                            val fileName = "masroufy_backup_${LocalDate.now()}.json"
                            exportJsonLauncher.launch(fileName)
                        },
                        testTag = "export_backup_row",
                    )

                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = semantic.cardBorder)

                    SettingsClickRow(
                        icon = Icons.Rounded.Restore,
                        tint = semantic.sky,
                        title = "استعادة نسخة احتياطية (JSON)",
                        subtitle = "استرجاع البيانات من ملف نسخة احتياطية سابق",
                        onClick = {
                            importJsonLauncher.launch(arrayOf("application/json", "text/plain", "*/*"))
                        },
                        testTag = "import_backup_row",
                    )

                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = semantic.cardBorder)

                    Text(
                        text = "تصدير ومشاركة التقارير المالية",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        OutlinedButton(
                            onClick = { exportCsvLauncher.launch("masroufy_${LocalDate.now()}.csv") },
                            modifier = Modifier.weight(1f).testTag("settings_export_csv_button"),
                            shape = RoundedCornerShape(12.dp),
                        ) {
                            Icon(Icons.Rounded.TableChart, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("حفظ CSV")
                        }
                        OutlinedButton(
                            onClick = { exportPdfLauncher.launch("masroufy_report_${LocalDate.now()}.pdf") },
                            modifier = Modifier.weight(1f).testTag("settings_export_pdf_button"),
                            shape = RoundedCornerShape(12.dp),
                        ) {
                            Icon(Icons.Rounded.PictureAsPdf, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("حفظ PDF")
                        }
                        OutlinedButton(
                            onClick = {
                                try {
                                    ReportExporter.shareTempFile(
                                        context = context,
                                        fileName = "masroufy_report_${LocalDate.now()}.pdf",
                                        mimeType = "application/pdf",
                                    ) { out ->
                                        ReportExporter.writePdfReport(
                                            outputStream = out,
                                            transactions = state.transactions,
                                            wallets = state.wallets,
                                            categories = state.categories,
                                            budgetSnapshot = state.budgetSnapshot,
                                        )
                                    }
                                } catch (_: Exception) {
                                    onShowMessage("تعذر مشاركة التقرير")
                                }
                            },
                            shape = RoundedCornerShape(12.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp),
                        ) {
                            Icon(Icons.Rounded.Share, contentDescription = "مشاركة التقرير", modifier = Modifier.size(18.dp))
                        }
                    }

                    HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp), color = semantic.cardBorder)

                    SettingsClickRow(
                        icon = Icons.Rounded.DeleteForever,
                        tint = semantic.coral,
                        title = "مسح كل البيانات",
                        subtitle = "إعادة ضبط التطبيق ومسح جميع السجلات",
                        onClick = { showResetConfirmDialog = true },
                        testTag = "reset_data_row",
                    )
                }
            }

            // Section 6: AI Financial Coach BYOK Setup
            item {
                FintechCard {
                    Text(
                        text = "المستشار المالي الذكي (Gemini AI)",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface,
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    SettingsClickRow(
                        icon = Icons.Rounded.AutoAwesome,
                        tint = if (state.settings.hasGeminiApiKey) semantic.emerald else semantic.amber,
                        title = if (state.settings.hasGeminiApiKey) "مفتاح Gemini API مفعّل ✅" else "تفعيل الذكاء الاصطناعي الكامل (مجاناً)",
                        subtitle = if (state.settings.hasGeminiApiKey) {
                            "اضغط لتغيير أو فحص أو حذف المفتاح الشخصي"
                        } else {
                            "أضف مفتاح Google AI Studio في 30 ثانية لتشغيل المحلل المتكامل"
                        },
                        onClick = { showApiKeySetupSheet = true },
                        testTag = "settings_ai_key_row",
                    )
                }
            }

            // Section 7: VIP Developer Signature Card ("بصمة المطور")
            item(key = "developer_signature_section") {
                DeveloperSignatureCard(onShowMessage = onShowMessage)
            }

            // Footer link
            item {
                Text(
                    text = "تطوير وتصميم: بلال محمد سليمان",
                    style = MaterialTheme.typography.labelLarge,
                    color = semantic.sky,
                    textAlign = TextAlign.Center,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .clickable {
                            scope.launch {
                                listState.animateScrollToItem(7)
                            }
                        }
                        .padding(vertical = 8.dp)
                        .testTag("developer_footer_link"),
                )
            }
        }
    }

    // --- Dialogs & Bottom Sheets (all guarded with BackHandler) ---

    if (showCycleDayDialog) {
        CycleDayPickerDialog(
            currentDay = state.settings.budgetCycleStartDay,
            onSelectDay = { day ->
                onSetCycleStartDay(day)
                showCycleDayDialog = false
            },
            onDismiss = { showCycleDayDialog = false },
        )
    }

    if (showPinSetupDialog) {
        PinSetupDialog(
            onPinConfirmed = { pin ->
                onEnablePin(pin)
                showPinSetupDialog = false
            },
            onDismiss = { showPinSetupDialog = false },
        )
    }

    if (showManageWalletsSheet) {
        ManageWalletsBottomSheet(
            wallets = state.wallets,
            isMasked = state.settings.isPrivacyMode,
            onSaveWallet = onSaveWallet,
            onDeleteWallet = onDeleteWallet,
            onMoveWalletOrder = onMoveWalletOrder,
            onReconcileWallet = onReconcileWallet,
            onDismiss = { showManageWalletsSheet = false },
        )
    }

    if (showManageCategoriesSheet) {
        ManageCategoriesBottomSheet(
            categories = state.categories,
            onSaveCategory = onSaveCategory,
            onDeleteCategory = onDeleteCategory,
            onMoveCategoryOrder = onMoveCategoryOrder,
            onDismiss = { showManageCategoriesSheet = false },
        )
    }

    if (showResetConfirmDialog) {
        BackHandler(enabled = true) { showResetConfirmDialog = false }
        ConfirmActionDialog(
            title = "مسح كل البيانات؟",
            message = "هيتم مسح جميع المعاملات والأظرف والأهداف والسُلف وإرجاع المحافظ الافتراضية. يفضل تصدير نسخة احتياطية الأول.",
            confirmText = "نعم، امسح الكل",
            isDestructive = true,
            onConfirm = {
                onResetAllData()
                showResetConfirmDialog = false
            },
            onDismiss = { showResetConfirmDialog = false },
        )
    }

    if (showApiKeySetupSheet) {
        ApiKeySetupBottomSheet(
            currentApiKey = state.settings.geminiApiKey,
            onTestAndSaveKey = onTestAndSaveGeminiApiKey,
            onClearKey = onClearGeminiApiKey,
            onShowMessage = onShowMessage,
            onDismiss = { showApiKeySetupSheet = false },
        )
    }
}

private fun formatReminderHour(hour24: Int): String {
    return when {
        hour24 == 0 -> "12 ص"
        hour24 < 12 -> "$hour24 ص"
        hour24 == 12 -> "12 م"
        else -> "${hour24 - 12} م"
    }
}

@Composable
private fun SettingsSwitchRow(
    icon: ImageVector,
    tint: Color,
    title: String,
    subtitle: String,
    checked: Boolean,
    enabled: Boolean = true,
    onCheckedChange: (Boolean) -> Unit,
    testTag: String,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        IconBadge(icon = icon, tint = tint, contentDescription = title, size = 40.dp)
        Spacer(modifier = Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            enabled = enabled,
            modifier = Modifier.testTag(testTag),
        )
    }
}

@Composable
private fun SettingsClickRow(
    icon: ImageVector,
    tint: Color,
    title: String,
    subtitle: String,
    onClick: () -> Unit,
    testTag: String,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 6.dp)
            .testTag(testTag),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        IconBadge(icon = icon, tint = tint, contentDescription = title, size = 40.dp)
        Spacer(modifier = Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun CycleDayPickerDialog(
    currentDay: Int,
    onSelectDay: (Int) -> Unit,
    onDismiss: () -> Unit,
) {
    BackHandler(enabled = true) { onDismiss() }
    val semantic = LocalMasroufyColors.current
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("اختر يوم بداية الدورة الشهرية", style = MaterialTheme.typography.titleLarge) },
        text = {
            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                maxItemsInEachRow = 7,
            ) {
                (1..28).forEach { day ->
                    val selected = day == currentDay
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant)
                            .border(1.dp, if (selected) MaterialTheme.colorScheme.primary else semantic.cardBorder, CircleShape)
                            .clickable { onSelectDay(day) },
                        contentAlignment = Alignment.Center,
                    ) {
                        Text(
                            text = "$day",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = if (selected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
                        )
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("إغلاق") }
        },
        containerColor = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(22.dp),
    )
}

@Composable
private fun PinSetupDialog(
    onPinConfirmed: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    BackHandler(enabled = true) { onDismiss() }
    var firstPin by remember { mutableStateOf("") }
    var currentInput by remember { mutableStateOf("") }
    var step by remember { mutableStateOf(1) }
    var error by remember { mutableStateOf<String?>(null) }

    fun handleDigit(digit: String) {
        if (currentInput.length >= 4) return
        error = null
        val updated = currentInput + digit
        currentInput = updated
        if (updated.length == 4) {
            if (step == 1) {
                firstPin = updated
                currentInput = ""
                step = 2
            } else {
                if (updated == firstPin) {
                    onPinConfirmed(updated)
                } else {
                    error = "الرمز غير متطابق — حاول مرة تانية"
                    firstPin = ""
                    currentInput = ""
                    step = 1
                }
            }
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = if (step == 1) "أنشئ رمز PIN من 4 أرقام" else "أعد إدخال الرمز للتأكيد",
                style = MaterialTheme.typography.titleLarge,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth(),
            )
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp),
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    repeat(4) { idx ->
                        val filled = idx < currentInput.length
                        Box(
                            modifier = Modifier
                                .size(16.dp)
                                .clip(CircleShape)
                                .background(
                                    if (filled) MaterialTheme.colorScheme.primary
                                    else MaterialTheme.colorScheme.surfaceVariant,
                                ),
                        )
                    }
                }
                error?.let {
                    Text(it, color = LocalMasroufyColors.current.coral, style = MaterialTheme.typography.bodySmall)
                }
                PinKeypad(
                    onDigitClick = ::handleDigit,
                    onBackspaceClick = {
                        if (currentInput.isNotEmpty()) currentInput = currentInput.dropLast(1)
                    },
                )
            }
        },
        confirmButton = {},
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("إلغاء") }
        },
        containerColor = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(24.dp),
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ManageWalletsBottomSheet(
    wallets: List<WalletEntity>,
    isMasked: Boolean,
    onSaveWallet: (id: Long, name: String, balance: Double, type: String, iconKey: String, colorHex: Long, isDefault: Boolean, minBalanceThreshold: Double, sortOrder: Int) -> Unit,
    onDeleteWallet: (Long) -> Unit,
    onMoveWalletOrder: (id: Long, moveUp: Boolean) -> Unit,
    onReconcileWallet: (walletId: Long, actualBalance: Double) -> Unit,
    onDismiss: () -> Unit,
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var editingWallet by remember { mutableStateOf<WalletEntity?>(null) }
    var reconcileTarget by remember { mutableStateOf<WalletEntity?>(null) }
    var showAddForm by remember { mutableStateOf(false) }

    BackHandler(enabled = true) {
        when {
            reconcileTarget != null -> reconcileTarget = null
            showAddForm || editingWallet != null -> {
                showAddForm = false
                editingWallet = null
            }
            else -> onDismiss()
        }
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = MaterialTheme.colorScheme.surface,
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .imePadding()
                .padding(horizontal = 20.dp),
            contentPadding = PaddingValues(top = 8.dp, bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text("إدارة المحافظ", style = MaterialTheme.typography.titleLarge)
                    Button(
                        onClick = { showAddForm = true },
                        shape = RoundedCornerShape(12.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    ) {
                        Icon(Icons.Rounded.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("إضافة محفظة")
                    }
                }
            }

            items(wallets.size, key = { wallets[it].id }) { index ->
                val w = wallets[index]
                FintechCard(cornerRadius = 16.dp) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        IconBadge(
                            icon = IconsCatalog.resolve(w.iconKey),
                            tint = Color(w.colorHex),
                            contentDescription = w.name,
                            size = 40.dp,
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(w.name, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                            Text(
                                Formatters.formatEgp(w.balance, isMasked = isMasked),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                            if (w.minBalanceThreshold > 0) {
                                Text(
                                    "تنبيه انخفاض عند ${Formatters.formatEgp(w.minBalanceThreshold, isMasked = isMasked)}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = LocalMasroufyColors.current.amber,
                                )
                            }
                        }
                        if (wallets.size > 1) {
                            IconButton(
                                onClick = { onMoveWalletOrder(w.id, true) },
                                enabled = index > 0,
                                modifier = Modifier.size(34.dp),
                            ) {
                                Icon(Icons.Rounded.ArrowUpward, contentDescription = "تحريك لأعلى", modifier = Modifier.size(18.dp))
                            }
                            IconButton(
                                onClick = { onMoveWalletOrder(w.id, false) },
                                enabled = index < wallets.lastIndex,
                                modifier = Modifier.size(34.dp),
                            ) {
                                Icon(Icons.Rounded.ArrowDownward, contentDescription = "تحريك لأسفل", modifier = Modifier.size(18.dp))
                            }
                        }
                        IconButton(
                            onClick = { reconcileTarget = w },
                            modifier = Modifier.size(36.dp),
                        ) {
                            Icon(
                                Icons.Rounded.Balance,
                                contentDescription = "جرد الرصيد الفعلي",
                                tint = LocalMasroufyColors.current.emerald,
                                modifier = Modifier.size(20.dp),
                            )
                        }
                        IconButton(
                            onClick = { editingWallet = w },
                            modifier = Modifier.size(36.dp),
                        ) {
                            Icon(Icons.Rounded.Edit, contentDescription = "تعديل", modifier = Modifier.size(20.dp))
                        }
                        if (wallets.size > 1) {
                            IconButton(
                                onClick = { onDeleteWallet(w.id) },
                                modifier = Modifier.size(36.dp),
                            ) {
                                Icon(
                                    Icons.Rounded.DeleteOutline,
                                    contentDescription = "حذف",
                                    tint = LocalMasroufyColors.current.coral,
                                    modifier = Modifier.size(20.dp),
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAddForm || editingWallet != null) {
        WalletEditDialog(
            initial = editingWallet,
            defaultSortOrder = wallets.size,
            onSave = { name, balance, threshold, iconKey, colorHex ->
                onSaveWallet(
                    editingWallet?.id ?: 0L,
                    name,
                    balance,
                    editingWallet?.type ?: WalletType.CUSTOM,
                    iconKey,
                    colorHex,
                    editingWallet?.isDefault ?: false,
                    threshold,
                    editingWallet?.sortOrder ?: wallets.size,
                )
                showAddForm = false
                editingWallet = null
            },
            onDismiss = {
                showAddForm = false
                editingWallet = null
            },
        )
    }

    reconcileTarget?.let { wallet ->
        ReconcileWalletDialog(
            wallet = wallet,
            onConfirm = { actual ->
                onReconcileWallet(wallet.id, actual)
                reconcileTarget = null
            },
            onDismiss = { reconcileTarget = null },
        )
    }
}

@Composable
private fun ReconcileWalletDialog(
    wallet: WalletEntity,
    onConfirm: (Double) -> Unit,
    onDismiss: () -> Unit,
) {
    BackHandler(enabled = true) { onDismiss() }
    var actualText by remember {
        mutableStateOf(
            if (wallet.balance % 1.0 == 0.0) wallet.balance.toLong().toString() else wallet.balance.toString(),
        )
    }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("جرد رصيد: ${wallet.name}", style = MaterialTheme.typography.titleLarge) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    "الرصيد المسجل حالياً: ${Formatters.formatEgp(wallet.balance)}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                OutlinedTextField(
                    value = actualText,
                    onValueChange = { actualText = it; error = null },
                    label = { Text("الرصيد الفعلي الموجود معك (ج.م)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth(),
                )
                Text(
                    "سيتم تسجيل فرق الجرد تلقائياً دون التأثير على ترتيب معاملاتك السابقة.",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                error?.let { Text(it, color = LocalMasroufyColors.current.coral, style = MaterialTheme.typography.bodySmall) }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val actual = Formatters.parseSafeDouble(actualText)
                    if (actual == null) {
                        error = "أدخل قيمة صحيحة"
                    } else {
                        onConfirm(actual)
                    }
                },
                shape = RoundedCornerShape(12.dp),
            ) { Text("تحديث الرصيد") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } },
        containerColor = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(22.dp),
    )
}

@Composable
private fun WalletEditDialog(
    initial: WalletEntity?,
    defaultSortOrder: Int,
    onSave: (name: String, balance: Double, minThreshold: Double, iconKey: String, colorHex: Long) -> Unit,
    onDismiss: () -> Unit,
) {
    BackHandler(enabled = true) { onDismiss() }
    var name by remember { mutableStateOf(initial?.name ?: "") }
    var balanceText by remember {
        mutableStateOf(
            initial?.let { if (it.balance % 1.0 == 0.0) it.balance.toLong().toString() else it.balance.toString() } ?: "0",
        )
    }
    var thresholdText by remember {
        mutableStateOf(
            initial?.let {
                if (it.minBalanceThreshold % 1.0 == 0.0) it.minBalanceThreshold.toLong().toString()
                else it.minBalanceThreshold.toString()
            } ?: "100",
        )
    }
    var iconKey by remember { mutableStateOf(initial?.iconKey ?: "wallet") }
    var colorHex by remember { mutableLongStateOf(initial?.colorHex ?: 0xFF10B981) }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "إضافة محفظة جديدة" else "تعديل المحفظة", style = MaterialTheme.typography.titleLarge) },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it; error = null },
                    label = { Text("اسم المحفظة") },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = balanceText,
                    onValueChange = { balanceText = it; error = null },
                    label = { Text("الرصيد الحالي (ج.م)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = thresholdText,
                    onValueChange = { thresholdText = it; error = null },
                    label = { Text("حد التنبيه لانخفاض الرصيد (ج.م)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth(),
                )
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    IconsCatalog.walletIconOptions.forEach { opt ->
                        val selected = iconKey == opt.key
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = if (selected) Color(colorHex).copy(alpha = 0.2f) else MaterialTheme.colorScheme.surfaceVariant,
                            border = BorderStroke(1.dp, if (selected) Color(colorHex) else LocalMasroufyColors.current.cardBorder),
                            modifier = Modifier.clickable { iconKey = opt.key },
                        ) {
                            Icon(opt.icon, contentDescription = opt.label, tint = Color(colorHex), modifier = Modifier.padding(10.dp))
                        }
                    }
                }
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    IconsCatalog.selectableColorHexes.forEach { hex ->
                        Box(
                            modifier = Modifier
                                .size(28.dp)
                                .clip(CircleShape)
                                .background(Color(hex))
                                .border(
                                    width = if (colorHex == hex) 2.5.dp else 0.dp,
                                    color = if (colorHex == hex) Color.White else Color.Transparent,
                                    shape = CircleShape,
                                )
                                .clickable { colorHex = hex },
                        )
                    }
                }
                error?.let { Text(it, color = LocalMasroufyColors.current.coral, style = MaterialTheme.typography.bodySmall) }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val bal = Formatters.parseSafeDouble(balanceText)
                    val threshold = Formatters.parseSafeDouble(thresholdText) ?: 0.0
                    when {
                        name.isBlank() -> error = "اكتب اسم المحفظة"
                        bal == null -> error = "أدخل رصيداً صحيحاً"
                        threshold < 0.0 -> error = "حد التنبيه يجب أن يكون صفر أو أكبر"
                        else -> onSave(name.trim(), bal, threshold, iconKey, colorHex)
                    }
                },
                shape = RoundedCornerShape(12.dp),
            ) { Text("حفظ") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } },
        containerColor = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(22.dp),
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ManageCategoriesBottomSheet(
    categories: List<CategoryEntity>,
    onSaveCategory: (id: Long, name: String, type: String, iconKey: String, colorHex: Long, isDefault: Boolean, monthlyBudget: Double?, sortOrder: Int) -> Unit,
    onDeleteCategory: (Long) -> Unit,
    onMoveCategoryOrder: (id: Long, moveUp: Boolean) -> Unit,
    onDismiss: () -> Unit,
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var editingCat by remember { mutableStateOf<CategoryEntity?>(null) }
    var showAddForm by remember { mutableStateOf(false) }

    BackHandler(enabled = true) {
        if (showAddForm || editingCat != null) {
            showAddForm = false
            editingCat = null
        } else {
            onDismiss()
        }
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = MaterialTheme.colorScheme.surface,
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .imePadding()
                .padding(horizontal = 20.dp),
            contentPadding = PaddingValues(top = 8.dp, bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text("إدارة التصنيفات", style = MaterialTheme.typography.titleLarge)
                    Button(
                        onClick = { showAddForm = true },
                        shape = RoundedCornerShape(12.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    ) {
                        Icon(Icons.Rounded.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("إضافة تصنيف")
                    }
                }
            }
            items(categories.size, key = { categories[it].id }) { index ->
                val cat = categories[index]
                FintechCard(cornerRadius = 16.dp) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        IconBadge(
                            icon = IconsCatalog.resolve(cat.iconKey),
                            tint = Color(cat.colorHex),
                            contentDescription = cat.name,
                            size = 38.dp,
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(cat.name, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                            val typeText = if (cat.type == TransactionType.EXPENSE) "مصروف" else "دخل"
                            val budgetText = cat.monthlyBudget?.takeIf { it > 0 }?.let {
                                " • حد شهري: ${Formatters.formatEgp(it)}"
                            } ?: ""
                            Text(
                                typeText + budgetText,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                        if (categories.size > 1) {
                            IconButton(
                                onClick = { onMoveCategoryOrder(cat.id, true) },
                                enabled = index > 0,
                                modifier = Modifier.size(34.dp),
                            ) {
                                Icon(Icons.Rounded.ArrowUpward, contentDescription = "تحريك لأعلى", modifier = Modifier.size(18.dp))
                            }
                            IconButton(
                                onClick = { onMoveCategoryOrder(cat.id, false) },
                                enabled = index < categories.lastIndex,
                                modifier = Modifier.size(34.dp),
                            ) {
                                Icon(Icons.Rounded.ArrowDownward, contentDescription = "تحريك لأسفل", modifier = Modifier.size(18.dp))
                            }
                        }
                        IconButton(
                            onClick = { editingCat = cat },
                            modifier = Modifier.size(36.dp),
                        ) {
                            Icon(Icons.Rounded.Edit, contentDescription = "تعديل", modifier = Modifier.size(20.dp))
                        }
                        if (!cat.isDefault) {
                            IconButton(
                                onClick = { onDeleteCategory(cat.id) },
                                modifier = Modifier.size(36.dp),
                            ) {
                                Icon(
                                    Icons.Rounded.DeleteOutline,
                                    contentDescription = "حذف",
                                    tint = LocalMasroufyColors.current.coral,
                                    modifier = Modifier.size(20.dp),
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAddForm || editingCat != null) {
        CategoryEditDialog(
            initial = editingCat,
            onSave = { name, type, iconKey, colorHex, monthlyBudget ->
                onSaveCategory(
                    editingCat?.id ?: 0L,
                    name,
                    type,
                    iconKey,
                    colorHex,
                    editingCat?.isDefault ?: false,
                    monthlyBudget,
                    editingCat?.sortOrder ?: categories.size,
                )
                showAddForm = false
                editingCat = null
            },
            onDismiss = {
                showAddForm = false
                editingCat = null
            },
        )
    }
}

@Composable
private fun CategoryEditDialog(
    initial: CategoryEntity?,
    onSave: (name: String, type: String, iconKey: String, colorHex: Long, monthlyBudget: Double?) -> Unit,
    onDismiss: () -> Unit,
) {
    BackHandler(enabled = true) { onDismiss() }
    var name by remember { mutableStateOf(initial?.name ?: "") }
    var type by remember { mutableStateOf(initial?.type ?: TransactionType.EXPENSE) }
    var budgetText by remember {
        mutableStateOf(
            initial?.monthlyBudget?.let {
                if (it % 1.0 == 0.0) it.toLong().toString() else it.toString()
            } ?: "",
        )
    }
    var iconKey by remember { mutableStateOf(initial?.iconKey ?: "other") }
    var colorHex by remember { mutableLongStateOf(initial?.colorHex ?: 0xFF10B981) }
    var error by remember { mutableStateOf<String?>(null) }
    val semantic = LocalMasroufyColors.current

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "إضافة تصنيف جديد" else "تعديل التصنيف", style = MaterialTheme.typography.titleLarge) },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                if (initial == null) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(
                            TransactionType.EXPENSE to "مصروف",
                            TransactionType.INCOME to "دخل",
                        ).forEach { (key, label) ->
                            val selected = type == key
                            Surface(
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable { type = key },
                                shape = RoundedCornerShape(12.dp),
                                color = if (selected) MaterialTheme.colorScheme.primary.copy(alpha = 0.2f) else MaterialTheme.colorScheme.surfaceVariant,
                                border = BorderStroke(1.dp, if (selected) MaterialTheme.colorScheme.primary else semantic.cardBorder),
                            ) {
                                Text(
                                    label,
                                    modifier = Modifier.padding(vertical = 8.dp),
                                    textAlign = TextAlign.Center,
                                    style = MaterialTheme.typography.labelLarge,
                                )
                            }
                        }
                    }
                }
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it; error = null },
                    label = { Text("اسم التصنيف") },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth(),
                )
                if (type == TransactionType.EXPENSE) {
                    OutlinedTextField(
                        value = budgetText,
                        onValueChange = { budgetText = it; error = null },
                        label = { Text("الحد الشهري للتصنيف (اختياري - ج.م)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    IconsCatalog.categoryIconOptions.forEach { opt ->
                        val selected = iconKey == opt.key
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = if (selected) Color(colorHex).copy(alpha = 0.2f) else MaterialTheme.colorScheme.surfaceVariant,
                            border = BorderStroke(1.dp, if (selected) Color(colorHex) else semantic.cardBorder),
                            modifier = Modifier.clickable { iconKey = opt.key },
                        ) {
                            Icon(opt.icon, contentDescription = opt.label, tint = Color(colorHex), modifier = Modifier.padding(10.dp))
                        }
                    }
                }
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    IconsCatalog.selectableColorHexes.forEach { hex ->
                        Box(
                            modifier = Modifier
                                .size(28.dp)
                                .clip(CircleShape)
                                .background(Color(hex))
                                .border(
                                    width = if (colorHex == hex) 2.5.dp else 0.dp,
                                    color = if (colorHex == hex) Color.White else Color.Transparent,
                                    shape = CircleShape,
                                )
                                .clickable { colorHex = hex },
                        )
                    }
                }
                error?.let { Text(it, color = semantic.coral, style = MaterialTheme.typography.bodySmall) }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val parsedBudget = if (budgetText.isBlank() || type != TransactionType.EXPENSE) {
                        null
                    } else {
                        val b = Formatters.parseSafeDouble(budgetText)
                        if (b == null || b <= 0.0) {
                            error = "أدخل حداً شهرياً صحيحاً أو اتركه فارغاً"
                            return@Button
                        }
                        b
                    }
                    if (name.isBlank()) {
                        error = "اكتب اسم التصنيف"
                    } else {
                        onSave(name.trim(), type, iconKey, colorHex, parsedBudget)
                    }
                },
                shape = RoundedCornerShape(12.dp),
            ) { Text("حفظ") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } },
        containerColor = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(22.dp),
    )
}

private fun isBiometricAvailable(context: Context): Boolean {
    val manager = BiometricManager.from(context)
    val result = manager.canAuthenticate(
        BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.BIOMETRIC_WEAK,
    )
    return result == BiometricManager.BIOMETRIC_SUCCESS
}
