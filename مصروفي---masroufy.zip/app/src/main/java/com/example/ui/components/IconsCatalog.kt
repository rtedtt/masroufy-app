package com.example.ui.components

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AccountBalance
import androidx.compose.material.icons.rounded.AccountBalanceWallet
import androidx.compose.material.icons.rounded.AddCard
import androidx.compose.material.icons.rounded.CardGiftcard
import androidx.compose.material.icons.rounded.Category
import androidx.compose.material.icons.rounded.CreditCard
import androidx.compose.material.icons.rounded.DirectionsCar
import androidx.compose.material.icons.rounded.Flight
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Laptop
import androidx.compose.material.icons.rounded.LocalCafe
import androidx.compose.material.icons.rounded.MailOutline
import androidx.compose.material.icons.rounded.MedicalServices
import androidx.compose.material.icons.rounded.Payments
import androidx.compose.material.icons.rounded.PhoneAndroid
import androidx.compose.material.icons.rounded.Restaurant
import androidx.compose.material.icons.rounded.Savings
import androidx.compose.material.icons.rounded.School
import androidx.compose.material.icons.rounded.ShoppingBag
import androidx.compose.material.icons.rounded.Smartphone
import androidx.compose.material.icons.rounded.TrendingUp
import androidx.compose.material.icons.rounded.Wifi
import androidx.compose.ui.graphics.vector.ImageVector

data class IconOption(
    val key: String,
    val label: String,
    val icon: ImageVector,
)

object IconsCatalog {
    fun resolve(key: String): ImageVector = when (key) {
        "cash" -> Icons.Rounded.Payments
        "bank" -> Icons.Rounded.AccountBalance
        "mobile_wallet" -> Icons.Rounded.PhoneAndroid
        "card" -> Icons.Rounded.CreditCard
        "wallet" -> Icons.Rounded.AccountBalanceWallet
        "savings" -> Icons.Rounded.Savings
        "transport" -> Icons.Rounded.DirectionsCar
        "food" -> Icons.Rounded.Restaurant
        "internet" -> Icons.Rounded.Wifi
        "study" -> Icons.Rounded.School
        "outing" -> Icons.Rounded.LocalCafe
        "health" -> Icons.Rounded.MedicalServices
        "shopping" -> Icons.Rounded.ShoppingBag
        "salary" -> Icons.Rounded.Payments
        "freelance" -> Icons.Rounded.Laptop
        "gift" -> Icons.Rounded.CardGiftcard
        "trending" -> Icons.Rounded.TrendingUp
        "income_other" -> Icons.Rounded.AddCard
        "envelope" -> Icons.Rounded.MailOutline
        "home" -> Icons.Rounded.Home
        "travel" -> Icons.Rounded.Flight
        "phone" -> Icons.Rounded.Smartphone
        else -> Icons.Rounded.Category
    }

    val walletIconOptions = listOf(
        IconOption("cash", "كاش", Icons.Rounded.Payments),
        IconOption("bank", "بنك", Icons.Rounded.AccountBalance),
        IconOption("mobile_wallet", "موبايل", Icons.Rounded.PhoneAndroid),
        IconOption("card", "بطاقة", Icons.Rounded.CreditCard),
        IconOption("savings", "حصالة", Icons.Rounded.Savings),
    )

    val categoryIconOptions = listOf(
        IconOption("food", "أكل", Icons.Rounded.Restaurant),
        IconOption("transport", "مواصلات", Icons.Rounded.DirectionsCar),
        IconOption("internet", "إنترنت", Icons.Rounded.Wifi),
        IconOption("study", "دراسة", Icons.Rounded.School),
        IconOption("outing", "خروجات", Icons.Rounded.LocalCafe),
        IconOption("health", "صحة", Icons.Rounded.MedicalServices),
        IconOption("shopping", "تسوق", Icons.Rounded.ShoppingBag),
        IconOption("home", "بيت", Icons.Rounded.Home),
        IconOption("travel", "سفر", Icons.Rounded.Flight),
        IconOption("salary", "راتب", Icons.Rounded.Payments),
        IconOption("freelance", "شغل", Icons.Rounded.Laptop),
        IconOption("gift", "هدية", Icons.Rounded.CardGiftcard),
        IconOption("other", "أخرى", Icons.Rounded.Category),
    )

    val goalIconOptions = listOf(
        IconOption("savings", "تحويش", Icons.Rounded.Savings),
        IconOption("phone", "موبايل", Icons.Rounded.Smartphone),
        IconOption("travel", "سفر", Icons.Rounded.Flight),
        IconOption("home", "بيت", Icons.Rounded.Home),
        IconOption("transport", "عربية", Icons.Rounded.DirectionsCar),
        IconOption("study", "كورس", Icons.Rounded.School),
        IconOption("gift", "هدية", Icons.Rounded.CardGiftcard),
    )

    val selectableColorHexes = listOf(
        0xFF10B981,
        0xFF38BDF8,
        0xFFF59E0B,
        0xFF8B5CF6,
        0xFFEC4899,
        0xFFF97316,
        0xFFEF4444,
        0xFF3B82F6,
        0xFF64748B,
    )
}
