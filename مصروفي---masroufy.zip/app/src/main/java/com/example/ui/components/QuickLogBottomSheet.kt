package com.example.ui.components

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.speech.RecognizerIntent
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.BookmarkAdd
import androidx.compose.material.icons.rounded.Calculate
import androidx.compose.material.icons.rounded.CameraAlt
import androidx.compose.material.icons.rounded.CardGiftcard
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.ContentPaste
import androidx.compose.material.icons.rounded.FlightTakeoff
import androidx.compose.material.icons.rounded.Group
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.PieChart
import androidx.compose.material.icons.rounded.Remove
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material.icons.rounded.SwapHoriz
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.example.data.local.CategoryEntity
import com.example.data.local.TransactionEntity
import com.example.data.local.TransactionType
import com.example.data.local.TripEventEntity
import com.example.data.local.WalletEntity
import com.example.data.local.WalletType
import com.example.domain.BudgetSnapshot
import com.example.domain.FinanceCalculator
import com.example.domain.Formatters
import com.example.domain.MathExpressionEvaluator
import com.example.domain.ParsedSmsResult
import com.example.domain.ScannedReceiptResult
import com.example.domain.VoiceParsedDraft
import com.example.ui.theme.LocalMasroufyColors

data class QuickLogPrefill(
    val amount: Double? = null,
    val type: String = TransactionType.EXPENSE,
    val walletId: Long? = null,
    val categoryId: Long? = null,
    val note: String = "",
)

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun QuickLogBottomSheet(
    wallets: List<WalletEntity>,
    categories: List<CategoryEntity>,
    budgetSnapshot: BudgetSnapshot,
    initialMode: String = TransactionType.EXPENSE,
    initialWalletId: Long? = null,
    editingTransaction: TransactionEntity? = null,
    prefill: QuickLogPrefill? = null,
    activeTrip: TripEventEntity? = null,
    autoLaunchVoice: Boolean = false,
    onParseSms: (String) -> ParsedSmsResult?,
    onParseVoice: (String) -> List<VoiceParsedDraft> = { emptyList() },
    onSaveVoiceBatch: (List<VoiceParsedDraft>) -> Unit = {},
    onScanReceipt: (Bitmap, (ScannedReceiptResult?, String?) -> Unit) -> Unit = { _, cb -> cb(null, "الماسح غير متاح") },
    onSave: (
        existingId: Long?,
        amount: Double,
        type: String,
        categoryId: Long?,
        walletId: Long,
        toWalletId: Long?,
        note: String,
        timestamp: Long,
        saveAsTemplate: Boolean,
        cashbackAmount: Double,
        tripEventId: Long?,
        apply503020OnSave: Boolean,
    ) -> Unit,
    onSaveSplitBill: (
        totalAmount: Double,
        friendsCount: Int,
        friendNames: List<String>,
        categoryId: Long?,
        walletId: Long,
        note: String,
    ) -> Unit,
    onDismiss: () -> Unit,
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val semantic = LocalMasroufyColors.current
    val clipboardManager = LocalClipboardManager.current
    val context = LocalContext.current
    val haptic = LocalHapticFeedback.current

    BackHandler(enabled = true) { onDismiss() }

    val cashWallet = remember(wallets) {
        wallets.firstOrNull { it.type == WalletType.CASH } ?: wallets.firstOrNull()
    }

    var mode by remember(editingTransaction, prefill, initialMode) {
        mutableStateOf(editingTransaction?.type ?: prefill?.type ?: initialMode)
    }
    var amountText by remember(editingTransaction, prefill) {
        mutableStateOf(
            editingTransaction?.let {
                if (it.amount % 1.0 == 0.0) it.amount.toLong().toString() else it.amount.toString()
            } ?: prefill?.amount?.let {
                if (it % 1.0 == 0.0) it.toLong().toString() else it.toString()
            } ?: "",
        )
    }
    var selectedWalletId by remember(editingTransaction, prefill, initialWalletId, wallets) {
        mutableStateOf(
            editingTransaction?.walletId
                ?: prefill?.walletId
                ?: initialWalletId
                ?: cashWallet?.id
                ?: 0L,
        )
    }
    var selectedToWalletId by remember(editingTransaction, wallets) {
        mutableStateOf(
            editingTransaction?.toWalletId
                ?: wallets.firstOrNull { it.id != (initialWalletId ?: cashWallet?.id) }?.id
                ?: cashWallet?.id
                ?: 0L,
        )
    }

    val categoriesForMode = remember(categories, mode) {
        categories.filter { it.type == mode }
    }
    var selectedCategoryId by remember(editingTransaction, prefill) {
        mutableStateOf(editingTransaction?.categoryId ?: prefill?.categoryId)
    }
    LaunchedEffect(categoriesForMode) {
        if (selectedCategoryId == null || categoriesForMode.none { it.id == selectedCategoryId }) {
            selectedCategoryId = categoriesForMode.firstOrNull()?.id
        }
    }

    var note by remember(editingTransaction, prefill) {
        mutableStateOf(editingTransaction?.note ?: prefill?.note ?: "")
    }

    // #5 Split Bill state
    var isSplitBill by remember { mutableStateOf(false) }
    var friendsCount by remember { mutableIntStateOf(1) }
    var friendNamesInput by remember { mutableStateOf("") }

    // #3 Save as Quick Template toggle
    var saveAsTemplate by remember { mutableStateOf(false) }

    var smsStatusMessage by remember(prefill) {
        mutableStateOf(
            if (prefill?.amount != null) "تم ملء البيانات تلقائياً من الإشعار المرصود" else null,
        )
    }
    var showManualSmsInput by remember { mutableStateOf(false) }
    var manualSmsText by remember { mutableStateOf("") }
    var validationError by remember { mutableStateOf<String?>(null) }

    // Voice-to-Transaction & Receipt Scanner state
    var voiceDrafts by remember { mutableStateOf<List<VoiceParsedDraft>>(emptyList()) }
    var voiceTranscriptPreview by remember { mutableStateOf<String?>(null) }
    var isScanningReceipt by remember { mutableStateOf(false) }

    // V3 Pro options
    var linkToActiveTrip by remember(editingTransaction, activeTrip) {
        mutableStateOf(
            if (editingTransaction != null) {
                editingTransaction.tripEventId != null && editingTransaction.tripEventId == activeTrip?.id
            } else {
                activeTrip != null
            },
        )
    }
    var cashbackText by remember(editingTransaction) { mutableStateOf("") }
    var apply503020OnSave by remember(editingTransaction) { mutableStateOf(false) }

    val receiptCameraLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicturePreview(),
    ) { bitmap ->
        if (bitmap != null) {
            isScanningReceipt = true
            smsStatusMessage = "جاري قراءة الفاتورة بالذكاء الاصطناعي..."
            onScanReceipt(bitmap) { scanned, errorMsg ->
                isScanningReceipt = false
                val scannedAmt = scanned?.amount
                if (scanned != null && scannedAmt != null && scannedAmt > 0.0) {
                    mode = TransactionType.EXPENSE
                    amountText = if (scannedAmt % 1.0 == 0.0) {
                        scannedAmt.toLong().toString()
                    } else {
                        scannedAmt.toString()
                    }
                    if (scanned.merchant.isNotBlank()) {
                        note = scanned.merchant
                    }
                    scanned.suggestedCategoryId?.let { selectedCategoryId = it }
                    smsStatusMessage = "تم استخراج بيانات الفاتورة (${Formatters.formatEgp(scannedAmt)}) ✅"
                    validationError = null
                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                } else {
                    smsStatusMessage = errorMsg ?: "تعذر قراءة الفاتورة — جرّب صورة أوضح"
                }
            }
        }
    }

    fun launchReceiptScanner() {
        try {
            receiptCameraLauncher.launch(null)
        } catch (_: Exception) {
            smsStatusMessage = "تعذر فتح الكاميرا على هذا الجهاز"
        }
    }

    val cameraPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission(),
    ) { granted ->
        if (granted) {
            launchReceiptScanner()
        } else {
            smsStatusMessage = "اسمح بإذن الكاميرا لمسح الفواتير"
        }
    }

    val speechLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult(),
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val spoken = result.data
                ?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                ?.firstOrNull()
                ?.trim()
                .orEmpty()
            if (spoken.isNotBlank()) {
                voiceTranscriptPreview = spoken
                val parsedList = onParseVoice(spoken)
                when {
                    parsedList.isEmpty() -> {
                        voiceDrafts = emptyList()
                        smsStatusMessage = "سمعنا: «$spoken» — ملقيناش مبلغ واضح، جرب تقول: دفعت 50 مواصلات"
                    }
                    parsedList.size == 1 -> {
                        val single = parsedList.first()
                        voiceDrafts = emptyList()
                        mode = single.type
                        amountText = if (single.amount % 1.0 == 0.0) {
                            single.amount.toLong().toString()
                        } else {
                            single.amount.toString()
                        }
                        single.walletId?.let { selectedWalletId = it }
                        single.categoryId?.let { selectedCategoryId = it }
                        note = single.note
                        smsStatusMessage = "تم فهم الإدخال الصوتي (${Formatters.formatEgp(single.amount)}) — راجع واحفظ!"
                        validationError = null
                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    }
                    else -> {
                        voiceDrafts = parsedList
                        smsStatusMessage = "تم رصد ${parsedList.size} معاملات من كلامك — راجع واضغط حفظ الكل!"
                        validationError = null
                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    }
                }
            }
        }
    }

    fun launchVoiceInput() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-EG")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "ar-EG")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "اتكلم بالمصري: مثلاً دفعت 35 مواصلات و 90 غدا من الكاش")
        }
        try {
            speechLauncher.launch(intent)
        } catch (_: Exception) {
            smsStatusMessage = "خدمة التعرف الصوتي من جوجل غير متوفرة على هذا الجهاز حالياً"
        }
    }

    val audioPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission(),
    ) { granted ->
        if (granted) {
            launchVoiceInput()
        } else {
            smsStatusMessage = "اسمح بإذن الميكروفون لاستخدام الإدخال الصوتي الذكي"
        }
    }

    LaunchedEffect(autoLaunchVoice) {
        if (autoLaunchVoice && editingTransaction == null) {
            if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                launchVoiceInput()
            } else {
                audioPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
            }
        }
    }

    // #1 Built-in Math Calculator live evaluation
    val hasMathExpr = remember(amountText) { MathExpressionEvaluator.containsOperator(amountText) }
    val evaluatedAmount = remember(amountText) {
        MathExpressionEvaluator.evaluate(amountText) ?: Formatters.parseSafeDouble(amountText) ?: 0.0
    }

    val effectiveUserExpense = remember(evaluatedAmount, isSplitBill, friendsCount) {
        if (isSplitBill && evaluatedAmount > 0.0) {
            evaluatedAmount / (friendsCount + 1).coerceAtLeast(2)
        } else {
            evaluatedAmount
        }
    }

    val impulseDays = remember(effectiveUserExpense, mode, budgetSnapshot) {
        if (mode == TransactionType.EXPENSE) {
            FinanceCalculator.calculateImpulseShieldDays(
                enteredAmount = effectiveUserExpense,
                freeBalance = budgetSnapshot.freeBalance,
                dailySafeLimit = budgetSnapshot.dailySafeLimit,
            )
        } else {
            null
        }
    }

    fun applyParsedSms(rawText: String) {
        val parsed = onParseSms(rawText)
        if (parsed == null || parsed.amount == null) {
            smsStatusMessage = "ملقيناش مبلغ واضح في الرسالة — تأكد من النص أو أدخل المبلغ يدوياً."
            return
        }
        mode = parsed.transactionType
        amountText = if (parsed.amount % 1.0 == 0.0) {
            parsed.amount.toLong().toString()
        } else {
            parsed.amount.toString()
        }
        parsed.suggestedWalletId?.let { selectedWalletId = it }
        parsed.suggestedCategoryId?.let { selectedCategoryId = it }
        if (note.isBlank()) {
            note = parsed.extractedNote
        }
        val sourceText = parsed.detectedSourceLabel?.let { " ($it)" } ?: ""
        smsStatusMessage = "تم استخراج ${Formatters.formatEgp(parsed.amount)}$sourceText بنجاح!"
        validationError = null
        showManualSmsInput = false
        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .padding(bottom = 24.dp)
                .navigationBarsPadding()
                .imePadding(),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    text = if (editingTransaction != null) "تعديل المعاملة" else "تسجيل معاملة سريعة",
                    style = MaterialTheme.typography.titleLarge,
                    color = MaterialTheme.colorScheme.onSurface,
                )
                IconButton(onClick = onDismiss) {
                    Icon(
                        imageVector = Icons.Rounded.Close,
                        contentDescription = "إغلاق",
                    )
                }
            }

            // Mode Switcher
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .padding(4.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                listOf(
                    Triple(TransactionType.EXPENSE, "مصروف", semantic.coral),
                    Triple(TransactionType.INCOME, "دخل", semantic.emerald),
                    Triple(TransactionType.TRANSFER, "تحويل", semantic.sky),
                ).forEach { (typeKey, label, accent) ->
                    val selected = mode == typeKey
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (selected) accent.copy(alpha = 0.2f) else Color.Transparent)
                            .border(
                                width = if (selected) 1.dp else 0.dp,
                                color = if (selected) accent else Color.Transparent,
                                shape = RoundedCornerShape(12.dp),
                            )
                            .clickable {
                                mode = typeKey
                                if (typeKey != TransactionType.EXPENSE) isSplitBill = false
                                if (typeKey == TransactionType.TRANSFER) saveAsTemplate = false
                                validationError = null
                                if (typeKey == TransactionType.TRANSFER && selectedToWalletId == selectedWalletId) {
                                    wallets.firstOrNull { it.id != selectedWalletId }?.let {
                                        selectedToWalletId = it.id
                                    }
                                }
                            }
                            .padding(vertical = 10.dp)
                            .testTag("mode_tab_$typeKey"),
                        contentAlignment = Alignment.Center,
                    ) {
                        Text(
                            text = label,
                            style = MaterialTheme.typography.labelLarge,
                            color = if (selected) accent else MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }

            // Smart Paste SMS, Egyptian Arabic Voice & Receipt Scanner Row
            if (editingTransaction == null && mode != TransactionType.TRANSFER) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    OutlinedButton(
                        onClick = {
                            val clip = clipboardManager.getText()?.text?.trim().orEmpty()
                            if (clip.isNotEmpty()) {
                                applyParsedSms(clip)
                            } else {
                                showManualSmsInput = !showManualSmsInput
                                smsStatusMessage = "الحافظة فاضية — تقدر تلصق رسالة البنك أو المحفظة هنا مباشرة."
                            }
                        },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("paste_sms_button"),
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(1.dp, semantic.sky.copy(alpha = 0.6f)),
                        colors = ButtonDefaults.outlinedButtonColors(
                            containerColor = semantic.sky.copy(alpha = 0.08f),
                            contentColor = semantic.sky,
                        ),
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.ContentPaste,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp),
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "رسالة بنك",
                            style = MaterialTheme.typography.labelMedium,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }

                    OutlinedButton(
                        onClick = {
                            if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                                launchVoiceInput()
                            } else {
                                audioPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                            }
                        },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("voice_input_button"),
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(1.dp, semantic.emerald.copy(alpha = 0.65f)),
                        colors = ButtonDefaults.outlinedButtonColors(
                            containerColor = semantic.emerald.copy(alpha = 0.10f),
                            contentColor = semantic.emerald,
                        ),
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Mic,
                            contentDescription = "إدخال صوتي ذكي",
                            modifier = Modifier.size(16.dp),
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "صوت ذكي",
                            style = MaterialTheme.typography.labelMedium,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }

                    OutlinedButton(
                        onClick = {
                            if (!isScanningReceipt) {
                                if (ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                                    launchReceiptScanner()
                                } else {
                                    cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
                                }
                            }
                        },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("scan_receipt_button"),
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(1.dp, semantic.amber.copy(alpha = 0.65f)),
                        colors = ButtonDefaults.outlinedButtonColors(
                            containerColor = semantic.amber.copy(alpha = 0.10f),
                            contentColor = semantic.amber,
                        ),
                    ) {
                        if (isScanningReceipt) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(16.dp),
                                strokeWidth = 2.dp,
                                color = semantic.amber,
                            )
                        } else {
                            Icon(
                                imageVector = Icons.Rounded.CameraAlt,
                                contentDescription = "مسح فاتورة بالكاميرا",
                                modifier = Modifier.size(16.dp),
                            )
                        }
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "فاتورة",
                            style = MaterialTheme.typography.labelMedium,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                }

                // Multi-Transaction Voice Confirmation Card
                AnimatedVisibility(visible = voiceDrafts.isNotEmpty()) {
                    Surface(
                        color = semantic.emeraldContainer,
                        shape = RoundedCornerShape(16.dp),
                        border = BorderStroke(1.dp, semantic.emerald),
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            Text(
                                text = "معاملات صوتية جاهزة للحفظ (${voiceDrafts.size})",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = semantic.emerald,
                            )
                            voiceTranscriptPreview?.let {
                                Text(
                                    text = "«$it»",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                            voiceDrafts.forEach { draft ->
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically,
                                ) {
                                    Text(
                                        text = "${draft.note} (${draft.categoryLabel} • ${draft.walletLabel})",
                                        style = MaterialTheme.typography.bodySmall,
                                        modifier = Modifier.weight(1f),
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = Formatters.formatEgp(draft.amount),
                                        style = MaterialTheme.typography.labelLarge,
                                        fontWeight = FontWeight.Bold,
                                        color = if (draft.type == TransactionType.INCOME) semantic.emerald else semantic.coral,
                                    )
                                }
                            }
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                            ) {
                                TextButton(
                                    onClick = { voiceDrafts = emptyList() },
                                    modifier = Modifier.weight(1f),
                                ) {
                                    Text("إلغاء")
                                }
                                Button(
                                    onClick = {
                                        onSaveVoiceBatch(voiceDrafts)
                                        voiceDrafts = emptyList()
                                        onDismiss()
                                    },
                                    modifier = Modifier
                                        .weight(2f)
                                        .testTag("save_voice_batch_button"),
                                    shape = RoundedCornerShape(12.dp),
                                ) {
                                    Text("حفظ الكل (${voiceDrafts.size})")
                                }
                            }
                        }
                    }
                }

                AnimatedVisibility(visible = showManualSmsInput) {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = manualSmsText,
                            onValueChange = { manualSmsText = it },
                            label = { Text("الصق نص رسالة البنك أو المحفظة هنا") },
                            placeholder = { Text("مثال: تم خصم مبلغ 250 جنيه عبر إنستا باي...") },
                            modifier = Modifier.fillMaxWidth(),
                            minLines = 2,
                            maxLines = 3,
                            shape = RoundedCornerShape(14.dp),
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End,
                        ) {
                            TextButton(onClick = { showManualSmsInput = false }) {
                                Text("إلغاء")
                            }
                            Button(
                                onClick = { applyParsedSms(manualSmsText) },
                                shape = RoundedCornerShape(12.dp),
                            ) {
                                Icon(Icons.Rounded.AutoAwesome, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("تحليل الرسالة")
                            }
                        }
                    }
                }

                AnimatedVisibility(visible = smsStatusMessage != null) {
                    Surface(
                        color = semantic.emeraldContainer,
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, semantic.emerald.copy(alpha = 0.4f)),
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.CheckCircle,
                                contentDescription = null,
                                tint = semantic.emerald,
                                modifier = Modifier.size(18.dp),
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = smsStatusMessage.orEmpty(),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurface,
                            )
                        }
                    }
                }
            }

            // #1 Amount Input with Built-in Math Calculator Support
            OutlinedTextField(
                value = amountText,
                onValueChange = {
                    amountText = it
                    validationError = null
                },
                label = { Text(if (isSplitBill) "إجمالي الفاتورة (ج.م)" else "المبلغ أو عملية حسابية (مثال: 50+35)") },
                placeholder = { Text("0") },
                suffix = {
                    Text(
                        text = "ج.م",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.primary,
                    )
                },
                textStyle = MaterialTheme.typography.headlineLarge.copy(
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Start,
                ),
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text),
                shape = RoundedCornerShape(18.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = when (mode) {
                        TransactionType.EXPENSE -> semantic.coral
                        TransactionType.INCOME -> semantic.emerald
                        else -> semantic.sky
                    },
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("amount_input"),
            )

            // Live Math Expression Result Pill (#1)
            AnimatedVisibility(visible = hasMathExpr) {
                Surface(
                    color = semantic.sky.copy(alpha = 0.14f),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, semantic.sky.copy(alpha = 0.4f)),
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Rounded.Calculate,
                                contentDescription = null,
                                tint = semantic.sky,
                                modifier = Modifier.size(18.dp),
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "الناتج الحسابي",
                                style = MaterialTheme.typography.labelMedium,
                                color = semantic.sky,
                            )
                        }
                        Text(
                            text = if (evaluatedAmount > 0.0) "= ${Formatters.formatEgp(evaluatedAmount)}" else "أكمل المعادلة...",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface,
                        )
                    }
                }
            }

            // #2 Quick Amount Additive Chips
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                listOf(5, 10, 20, 50, 100, 200).forEach { addVal ->
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        border = BorderStroke(1.dp, semantic.cardBorder),
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .clickable {
                                val next = (evaluatedAmount.coerceAtLeast(0.0) + addVal)
                                amountText = if (next % 1.0 == 0.0) next.toLong().toString() else Formatters.formatCompactNumber(next).replace(",", "")
                                validationError = null
                                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            }
                            .testTag("quick_add_$addVal"),
                    ) {
                        Text(
                            text = "+$addVal",
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                        )
                    }
                }
            }

            // #5 Split Bill Calculator Toggle (Expense only, new tx)
            if (mode == TransactionType.EXPENSE && editingTransaction == null) {
                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, if (isSplitBill) semantic.amber else semantic.cardBorder),
                ) {
                    Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Rounded.Group,
                                    contentDescription = null,
                                    tint = semantic.amber,
                                    modifier = Modifier.size(20.dp),
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text(
                                        text = "تقسيم فاتورة مع أصدقاء",
                                        style = MaterialTheme.typography.labelLarge,
                                        color = MaterialTheme.colorScheme.onSurface,
                                    )
                                    Text(
                                        text = "خصم حصتك فقط وتسجيل الباقي في دفتر السُلف",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    )
                                }
                            }
                            Switch(
                                checked = isSplitBill,
                                onCheckedChange = {
                                    isSplitBill = it
                                    if (it) saveAsTemplate = false
                                },
                                modifier = Modifier.testTag("split_bill_switch"),
                            )
                        }

                        AnimatedVisibility(visible = isSplitBill) {
                            Column(
                                modifier = Modifier.padding(top = 10.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp),
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically,
                                ) {
                                    Text(
                                        text = "عدد الأصدقاء معاك:",
                                        style = MaterialTheme.typography.bodyMedium,
                                    )
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    ) {
                                        IconButton(
                                            onClick = { if (friendsCount > 1) friendsCount-- },
                                            modifier = Modifier.size(36.dp),
                                        ) {
                                            Icon(Icons.Rounded.Remove, contentDescription = "إنقاص")
                                        }
                                        Text(
                                            text = "$friendsCount",
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Bold,
                                        )
                                        IconButton(
                                            onClick = { if (friendsCount < 15) friendsCount++ },
                                            modifier = Modifier.size(36.dp),
                                        ) {
                                            Icon(Icons.Rounded.Add, contentDescription = "زيادة")
                                        }
                                    }
                                }
                                if (evaluatedAmount > 0.0) {
                                    val share = evaluatedAmount / (friendsCount + 1)
                                    Text(
                                        text = "حصتك: ${Formatters.formatEgp(share)} • حصة كل صديق: ${Formatters.formatEgp(share)}",
                                        style = MaterialTheme.typography.labelLarge,
                                        color = semantic.amber,
                                    )
                                }
                                OutlinedTextField(
                                    value = friendNamesInput,
                                    onValueChange = { friendNamesInput = it },
                                    label = { Text("أسماء الأصدقاء (اختياري، افصل بينهم بفاصلة)") },
                                    placeholder = { Text("مثال: أحمد، كريم") },
                                    singleLine = true,
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier.fillMaxWidth(),
                                )
                            }
                        }
                    }
                }
            }

            // Impulse Purchase Shield Banner
            AnimatedVisibility(
                visible = impulseDays != null,
                enter = fadeIn() + expandVertically(),
                exit = fadeOut() + shrinkVertically(),
            ) {
                Surface(
                    color = semantic.amberContainer,
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, semantic.amber),
                    modifier = Modifier.testTag("impulse_shield_banner"),
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Shield,
                            contentDescription = "درع الشراء العشوائي",
                            tint = semantic.amber,
                            modifier = Modifier.size(26.dp),
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "درع الشراء العشوائي",
                                style = MaterialTheme.typography.labelLarge,
                                color = semantic.amber,
                            )
                            Text(
                                text = "خلي بالك: المبلغ ده بيعادل مصاريفك لمدة $impulseDays أيام!",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurface,
                            )
                        }
                    }
                }
            }

            // Category Grid (Expense / Income)
            if (mode != TransactionType.TRANSFER && categoriesForMode.isNotEmpty()) {
                Text(
                    text = "التصنيف",
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    maxItemsInEachRow = 4,
                ) {
                    categoriesForMode.forEach { cat ->
                        val isSelected = selectedCategoryId == cat.id
                        val catColor = Color(cat.colorHex)
                        Surface(
                            modifier = Modifier
                                .weight(1f, fill = false)
                                .clip(RoundedCornerShape(14.dp))
                                .clickable { selectedCategoryId = cat.id }
                                .testTag("category_chip_${cat.name}"),
                            shape = RoundedCornerShape(14.dp),
                            color = if (isSelected) catColor.copy(alpha = 0.22f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                            border = BorderStroke(
                                width = if (isSelected) 1.5.dp else 1.dp,
                                color = if (isSelected) catColor else semantic.cardBorder,
                            ),
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 9.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Icon(
                                    imageVector = IconsCatalog.resolve(cat.iconKey),
                                    contentDescription = cat.name,
                                    tint = catColor,
                                    modifier = Modifier.size(18.dp),
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = cat.name,
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                )
                            }
                        }
                    }
                }
            }

            // Wallet Selection
            Text(
                text = when (mode) {
                    TransactionType.TRANSFER -> "من محفظة"
                    TransactionType.INCOME -> "إلى محفظة"
                    else -> "الدفع من محفظة"
                },
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                wallets.forEach { wallet ->
                    val selected = selectedWalletId == wallet.id
                    val wColor = Color(wallet.colorHex)
                    Surface(
                        modifier = Modifier
                            .clip(RoundedCornerShape(14.dp))
                            .clickable {
                                selectedWalletId = wallet.id
                                if (mode == TransactionType.TRANSFER && selectedToWalletId == wallet.id) {
                                    wallets.firstOrNull { it.id != wallet.id }?.let {
                                        selectedToWalletId = it.id
                                    }
                                }
                            }
                            .testTag("source_wallet_${wallet.name}"),
                        shape = RoundedCornerShape(14.dp),
                        color = if (selected) wColor.copy(alpha = 0.20f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                        border = BorderStroke(
                            width = if (selected) 1.5.dp else 1.dp,
                            color = if (selected) wColor else semantic.cardBorder,
                        ),
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Icon(
                                imageVector = IconsCatalog.resolve(wallet.iconKey),
                                contentDescription = wallet.name,
                                tint = wColor,
                                modifier = Modifier.size(18.dp),
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Column {
                                Text(
                                    text = wallet.name,
                                    style = MaterialTheme.typography.labelLarge,
                                    color = MaterialTheme.colorScheme.onSurface,
                                )
                                Text(
                                    text = Formatters.formatEgp(wallet.balance),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                        }
                    }
                }
            }

            // Target Wallet (Transfer only)
            if (mode == TransactionType.TRANSFER) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(
                        imageVector = Icons.Rounded.SwapHoriz,
                        contentDescription = null,
                        tint = semantic.sky,
                        modifier = Modifier.size(18.dp),
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "إلى محفظة",
                        style = MaterialTheme.typography.titleSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    wallets.filter { it.id != selectedWalletId }.forEach { wallet ->
                        val selected = selectedToWalletId == wallet.id
                        val wColor = Color(wallet.colorHex)
                        Surface(
                            modifier = Modifier
                                .clip(RoundedCornerShape(14.dp))
                                .clickable { selectedToWalletId = wallet.id },
                            shape = RoundedCornerShape(14.dp),
                            color = if (selected) wColor.copy(alpha = 0.20f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                            border = BorderStroke(
                                width = if (selected) 1.5.dp else 1.dp,
                                color = if (selected) wColor else semantic.cardBorder,
                            ),
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Icon(
                                    imageVector = IconsCatalog.resolve(wallet.iconKey),
                                    contentDescription = wallet.name,
                                    tint = wColor,
                                    modifier = Modifier.size(18.dp),
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = wallet.name,
                                    style = MaterialTheme.typography.labelLarge,
                                    color = MaterialTheme.colorScheme.onSurface,
                                )
                            }
                        }
                    }
                }
            }

            // Note Field (supports #hashtags)
            OutlinedTextField(
                value = note,
                onValueChange = { note = it },
                label = { Text("ملاحظة قصيرة أو وسم # (اختياري)") },
                placeholder = { Text("مثال: قهوة #الجامعة، أوبر #شغل") },
                singleLine = true,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("note_input"),
            )

            // Trip Mode Toggle (Expense + Active Trip)
            if (mode == TransactionType.EXPENSE && activeTrip != null && !isSplitBill) {
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = if (linkToActiveTrip) semantic.sky.copy(alpha = 0.14f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                    border = BorderStroke(1.dp, if (linkToActiveTrip) semantic.sky else semantic.cardBorder),
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { linkToActiveTrip = !linkToActiveTrip }
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                            Icon(Icons.Rounded.FlightTakeoff, contentDescription = null, tint = semantic.sky, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text("ربط بالرحلة الحالية: ${activeTrip.title}", style = MaterialTheme.typography.labelLarge)
                                Text("يُحسب ضمن ميزانية الرحلة ولا يؤثر على الحد اليومي", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                        Switch(
                            checked = linkToActiveTrip,
                            onCheckedChange = { linkToActiveTrip = it },
                            modifier = Modifier.testTag("trip_link_switch"),
                        )
                    }
                }
            }

            // Cashback Logger (New Expense)
            if (editingTransaction == null && mode == TransactionType.EXPENSE && !isSplitBill) {
                OutlinedTextField(
                    value = cashbackText,
                    onValueChange = { cashbackText = it },
                    label = { Text("كاش باك مسترد (ج.م) 🎁 — اختياري") },
                    placeholder = { Text("مثال: 15") },
                    leadingIcon = { Icon(Icons.Rounded.CardGiftcard, contentDescription = null, tint = semantic.emerald) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("cashback_input"),
                )
            }

            // 50/30/20 Smart Income Allocation Toggle (New Income)
            if (editingTransaction == null && mode == TransactionType.INCOME) {
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = if (apply503020OnSave) semantic.emerald.copy(alpha = 0.14f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                    border = BorderStroke(1.dp, if (apply503020OnSave) semantic.emerald else semantic.cardBorder),
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { apply503020OnSave = !apply503020OnSave }
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                            Icon(Icons.Rounded.PieChart, contentDescription = null, tint = semantic.emerald, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text("توزيع ذكي تلقائي 50 / 30 / 20", style = MaterialTheme.typography.labelLarge)
                                Text("50% ظرف الأساسيات • 30% حر • 20% صندوق الطوارئ", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                        Switch(
                            checked = apply503020OnSave,
                            onCheckedChange = { apply503020OnSave = it },
                            modifier = Modifier.testTag("income_503020_switch"),
                        )
                    }
                }
            }

            // Save as Quick Template (#3)
            if (editingTransaction == null && mode != TransactionType.TRANSFER && !isSplitBill) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .clickable { saveAsTemplate = !saveAsTemplate }
                        .padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Rounded.BookmarkAdd,
                            contentDescription = null,
                            tint = semantic.emerald,
                            modifier = Modifier.size(20.dp),
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "حفظ كقالب سريع للتكرار بضغطة واحدة",
                            style = MaterialTheme.typography.bodyMedium,
                        )
                    }
                    Switch(
                        checked = saveAsTemplate,
                        onCheckedChange = { saveAsTemplate = it },
                    )
                }
            }

            if (validationError != null) {
                Text(
                    text = validationError.orEmpty(),
                    style = MaterialTheme.typography.bodySmall,
                    color = semantic.coral,
                )
            }

            // Save Button
            val buttonColor = when (mode) {
                TransactionType.EXPENSE -> semantic.coral
                TransactionType.INCOME -> semantic.emerald
                else -> semantic.sky
            }
            Button(
                onClick = {
                    if (evaluatedAmount <= 0.0) {
                        validationError = "من فضلك أدخل مبلغاً أكبر من صفر"
                        return@Button
                    }
                    if (selectedWalletId == 0L) {
                        validationError = "اختر المحفظة أولاً"
                        return@Button
                    }
                    if (mode == TransactionType.TRANSFER && (selectedToWalletId == 0L || selectedToWalletId == selectedWalletId)) {
                        validationError = "اختر محفظة مختلفة للتحويل إليها"
                        return@Button
                    }
                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    if (isSplitBill && mode == TransactionType.EXPENSE && editingTransaction == null) {
                        val names = friendNamesInput.split(",", "،")
                            .map { it.trim() }
                            .filter { it.isNotEmpty() }
                        onSaveSplitBill(
                            evaluatedAmount,
                            friendsCount,
                            names,
                            selectedCategoryId,
                            selectedWalletId,
                            note,
                        )
                    } else {
                        val cashbackVal = if (editingTransaction == null && mode == TransactionType.EXPENSE) {
                            (Formatters.parseSafeDouble(cashbackText) ?: 0.0).coerceAtLeast(0.0)
                        } else {
                            0.0
                        }
                        val resolvedTripId = if (mode == TransactionType.EXPENSE && linkToActiveTrip) {
                            activeTrip?.id ?: editingTransaction?.tripEventId
                        } else {
                            null
                        }
                        onSave(
                            editingTransaction?.id,
                            evaluatedAmount,
                            mode,
                            if (mode == TransactionType.TRANSFER) null else selectedCategoryId,
                            selectedWalletId,
                            if (mode == TransactionType.TRANSFER) selectedToWalletId else null,
                            note,
                            editingTransaction?.timestamp ?: System.currentTimeMillis(),
                            saveAsTemplate,
                            cashbackVal,
                            resolvedTripId,
                            mode == TransactionType.INCOME && editingTransaction == null && apply503020OnSave,
                        )
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
                    .testTag("save_transaction_button"),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = buttonColor,
                    contentColor = Color.White,
                ),
            ) {
                Text(
                    text = when {
                        editingTransaction != null -> "حفظ التعديلات"
                        isSplitBill -> "تسجيل الفاتورة المقسومة"
                        mode == TransactionType.EXPENSE -> "تسجيل المصروف"
                        mode == TransactionType.INCOME -> "إضافة الدخل"
                        else -> "تنفيذ التحويل"
                    },
                    style = MaterialTheme.typography.titleMedium,
                )
            }
        }
    }
}
