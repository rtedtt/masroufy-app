package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Balance
import androidx.compose.material.icons.rounded.ReceiptLong
import androidx.compose.material.icons.rounded.SwapHoriz
import androidx.compose.material.icons.rounded.WarningAmber
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.local.CategoryEntity
import com.example.data.local.TransactionEntity
import com.example.data.local.TransactionType
import com.example.data.local.WalletEntity
import com.example.domain.Formatters
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.FintechCard
import com.example.ui.components.IconBadge
import com.example.ui.components.IconsCatalog
import com.example.ui.theme.LocalMasroufyColors
import com.example.viewmodel.MasroufyUiState

@Composable
fun WalletStatementScreen(
    walletId: Long,
    state: MasroufyUiState,
    onBack: () -> Unit,
    onReconcileBalance: (walletId: Long, actualBalance: Double) -> Unit,
    onEditTransaction: (TransactionEntity) -> Unit,
    onAddTransactionForWallet: (Long) -> Unit,
    modifier: Modifier = Modifier,
) {
    BackHandler(enabled = true) { onBack() }

    val semantic = LocalMasroufyColors.current
    val masked = state.settings.isPrivacyMode
    val wallet = state.wallets.firstOrNull { it.id == walletId }
    val categoryMap = remember(state.categories) { state.categories.associateBy { it.id } }
    val walletMap = remember(state.wallets) { state.wallets.associateBy { it.id } }

    var showReconcileDialog by remember { mutableStateOf(false) }

    if (wallet == null) {
        LaunchedEffectBack(onBack)
        return
    }

    val walletTxs = remember(state.transactions, walletId) {
        state.transactions.filter { it.walletId == walletId || it.toWalletId == walletId }
    }

    val totalInflow = remember(walletTxs, walletId) {
        walletTxs.sumOf { tx ->
            when {
                tx.type == TransactionType.INCOME && tx.walletId == walletId -> tx.amount
                tx.type == TransactionType.TRANSFER && tx.toWalletId == walletId -> tx.amount
                else -> 0.0
            }
        }
    }
    val totalOutflow = remember(walletTxs, walletId) {
        walletTxs.sumOf { tx ->
            when {
                tx.type == TransactionType.EXPENSE && tx.walletId == walletId -> tx.amount
                tx.type == TransactionType.TRANSFER && tx.walletId == walletId -> tx.amount
                else -> 0.0
            }
        }
    }
    val netChange = totalInflow - totalOutflow
    val wColor = Color(wallet.colorHex)
    val isLow = wallet.minBalanceThreshold > 0.0 && wallet.balance < wallet.minBalanceThreshold

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter,
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 680.dp),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 108.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = onBack, modifier = Modifier.testTag("statement_back_button")) {
                            Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "رجوع")
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                        Column {
                            Text(
                                text = "كشف حساب: ${wallet.name}",
                                style = MaterialTheme.typography.titleLarge,
                                color = MaterialTheme.colorScheme.onBackground,
                            )
                            Text(
                                text = "${walletTxs.size} معاملة مسجلة",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                    OutlinedButton(
                        onClick = { onAddTransactionForWallet(wallet.id) },
                        shape = RoundedCornerShape(12.dp),
                    ) {
                        Text("+ معاملة")
                    }
                }
            }

            // Wallet Balance + Reconciliation Card (#6)
            item {
                FintechCard(borderColor = wColor.copy(alpha = 0.5f)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconBadge(
                                icon = IconsCatalog.resolve(wallet.iconKey),
                                tint = wColor,
                                contentDescription = wallet.name,
                                size = 48.dp,
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = "الرصيد الحالي",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                                Text(
                                    text = Formatters.formatEgp(wallet.balance, isMasked = masked),
                                    style = MaterialTheme.typography.headlineMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface,
                                )
                            }
                        }
                    }

                    if (isLow) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Surface(
                            color = semantic.amberContainer,
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, semantic.amber),
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 10.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Icon(Icons.Rounded.WarningAmber, contentDescription = null, tint = semantic.amber, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "الرصيد أقل من الحد الأدنى (${Formatters.formatEgp(wallet.minBalanceThreshold, isMasked = masked)})",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.onSurface,
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                    Button(
                        onClick = { showReconcileDialog = true },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("reconcile_wallet_button"),
                        shape = RoundedCornerShape(14.dp),
                    ) {
                        Icon(Icons.Rounded.Balance, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("تعديل الرصيد الفعلي (جرد سريع)")
                    }
                }
            }

            // Inflows / Outflows / Net Change
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    FintechCard(modifier = Modifier.weight(1f), borderColor = semantic.emerald.copy(alpha = 0.4f)) {
                        Text("الوارد", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            Formatters.formatEgp(totalInflow, showPositiveSign = true, isMasked = masked),
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = semantic.emerald,
                        )
                    }
                    FintechCard(modifier = Modifier.weight(1f), borderColor = semantic.coral.copy(alpha = 0.4f)) {
                        Text("الصادر", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            Formatters.formatEgp(-totalOutflow, isMasked = masked),
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = semantic.coral,
                        )
                    }
                    FintechCard(modifier = Modifier.weight(1f), borderColor = semantic.sky.copy(alpha = 0.4f)) {
                        Text("الصافي", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            Formatters.formatEgp(netChange, showPositiveSign = true, isMasked = masked),
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = if (netChange >= 0) semantic.emerald else semantic.coral,
                        )
                    }
                }
            }

            if (walletTxs.isEmpty()) {
                item {
                    EmptyStateCard(
                        icon = Icons.Rounded.ReceiptLong,
                        title = "لا توجد معاملات على هذه المحفظة",
                        subtitle = "كل المعاملات أو التحويلات المرتبطة بالمحفظة هتظهر هنا.",
                    )
                }
            } else {
                items(walletTxs, key = { it.id }) { tx ->
                    StatementTransactionItem(
                        tx = tx,
                        walletId = walletId,
                        category = tx.categoryId?.let { categoryMap[it] },
                        walletMap = walletMap,
                        isMasked = masked,
                        onClick = { onEditTransaction(tx) },
                    )
                }
            }
        }
    }

    if (showReconcileDialog) {
        ReconcileBalanceDialog(
            wallet = wallet,
            onConfirm = { actual ->
                onReconcileBalance(wallet.id, actual)
                showReconcileDialog = false
            },
            onDismiss = { showReconcileDialog = false },
        )
    }
}

@Composable
private fun LaunchedEffectBack(onBack: () -> Unit) {
    androidx.compose.runtime.LaunchedEffect(Unit) { onBack() }
}

@Composable
private fun StatementTransactionItem(
    tx: TransactionEntity,
    walletId: Long,
    category: CategoryEntity?,
    walletMap: Map<Long, WalletEntity>,
    isMasked: Boolean,
    onClick: () -> Unit,
) {
    val semantic = LocalMasroufyColors.current
    val isIncomingTransfer = tx.type == TransactionType.TRANSFER && tx.toWalletId == walletId
    val (accent, icon, titleText) = when {
        tx.type == TransactionType.INCOME -> Triple(
            semantic.emerald,
            IconsCatalog.resolve(category?.iconKey ?: "salary"),
            category?.name ?: "دخل",
        )
        tx.type == TransactionType.TRANSFER -> Triple(
            semantic.sky,
            Icons.Rounded.SwapHoriz,
            if (isIncomingTransfer) "تحويل وارد من ${walletMap[tx.walletId]?.name ?: "محفظة"}"
            else "تحويل صادر إلى ${walletMap[tx.toWalletId]?.name ?: "محفظة"}",
        )
        else -> Triple(
            category?.let { Color(it.colorHex) } ?: semantic.coral,
            IconsCatalog.resolve(category?.iconKey ?: "other"),
            category?.name ?: "مصروف",
        )
    }

    val signedAmount = when {
        tx.type == TransactionType.INCOME || isIncomingTransfer -> tx.amount
        else -> -tx.amount
    }

    FintechCard(cornerRadius = 16.dp, onClick = onClick) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconBadge(icon = icon, tint = accent, contentDescription = titleText, size = 40.dp)
            Spacer(modifier = Modifier.width(10.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = if (tx.note.isNotBlank()) "$titleText • ${tx.note}" else titleText,
                    style = MaterialTheme.typography.titleSmall,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    text = Formatters.formatRelativeDateTime(tx.timestamp),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Text(
                text = Formatters.formatEgp(signedAmount, showPositiveSign = true, isMasked = isMasked),
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = if (signedAmount >= 0) semantic.emerald else semantic.coral,
            )
        }
    }
}

@Composable
private fun ReconcileBalanceDialog(
    wallet: WalletEntity,
    onConfirm: (Double) -> Unit,
    onDismiss: () -> Unit,
) {
    var actualText by remember {
        mutableStateOf(
            if (wallet.balance % 1.0 == 0.0) wallet.balance.toLong().toString() else wallet.balance.toString(),
        )
    }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("تعديل الرصيد الفعلي (${wallet.name})", style = MaterialTheme.typography.titleLarge) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "الرصيد المسجل في التطبيق: ${Formatters.formatEgp(wallet.balance)}. إذا كان رصيدك الفعلي مختلفاً، سنسجل معاملة «فرق جرد» تلقائياً.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                OutlinedTextField(
                    value = actualText,
                    onValueChange = { actualText = it; error = null },
                    label = { Text("الرصيد الفعلي الآن (ج.م)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth(),
                )
                error?.let {
                    Text(it, color = LocalMasroufyColors.current.coral, style = MaterialTheme.typography.bodySmall)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val actual = Formatters.parseSafeDouble(actualText)
                    if (actual == null) error = "أدخل رصيداً صحيحاً" else onConfirm(actual)
                },
                shape = RoundedCornerShape(12.dp),
            ) { Text("تأكيد الجرد") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } },
        containerColor = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(22.dp),
    )
}
