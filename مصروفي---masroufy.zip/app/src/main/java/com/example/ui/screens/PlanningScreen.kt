package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.CalendarToday
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.EventRepeat
import androidx.compose.material.icons.rounded.ExpandLess
import androidx.compose.material.icons.rounded.ExpandMore
import androidx.compose.material.icons.rounded.Handshake
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.MailOutline
import androidx.compose.material.icons.rounded.Payments
import androidx.compose.material.icons.rounded.Savings
import androidx.compose.material.icons.rounded.SwapHoriz
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.data.local.CategoryEntity
import com.example.data.local.DebtEntity
import com.example.data.local.DebtType
import com.example.data.local.EnvelopeEntity
import com.example.data.local.GoalEntity
import com.example.data.local.RecurringFrequency
import com.example.data.local.RecurringTransactionEntity
import com.example.data.local.TransactionType
import com.example.data.local.WalletEntity
import com.example.domain.Formatters
import com.example.ui.components.CreateGameyaDialog
import com.example.ui.components.CreateInstallmentDialog
import com.example.ui.components.CreateSubscriptionDialog
import com.example.ui.components.CreateTripDialog
import com.example.ui.components.EmergencyFundActionDialog
import com.example.ui.components.EmergencyFundCard
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.FintechCard
import com.example.ui.components.GameyaSection
import com.example.ui.components.IconBadge
import com.example.ui.components.IconsCatalog
import com.example.ui.components.IncomeAllocator503020Dialog
import com.example.ui.components.InstallmentsSection
import com.example.ui.components.RebalanceOption
import com.example.ui.components.RebalanceTransferDialog
import com.example.ui.components.SubscriptionsSection
import com.example.ui.components.TripsSection
import com.example.ui.components.ZeroBasedBudgetCard
import com.example.ui.theme.LocalMasroufyColors
import com.example.viewmodel.MasroufyUiState
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import kotlin.math.roundToInt

@Composable
fun PlanningScreen(
    state: MasroufyUiState,
    onSaveEnvelope: (id: Long, title: String, target: Double, reserved: Double, dueDay: Int?) -> Unit,
    onDeleteEnvelope: (Long) -> Unit,
    onTopUpEnvelope: (envelopeId: Long, amount: Double) -> Unit,
    onSpendFromEnvelope: (envelopeId: Long, walletId: Long, amount: Double, categoryId: Long?, note: String) -> Unit,
    onSaveGoal: (id: Long, title: String, target: Double, saved: Double, iconKey: String, colorHex: Long) -> Unit,
    onDeleteGoal: (Long) -> Unit,
    onContributeToGoal: (goalId: Long, walletId: Long, amount: Double, onComplete: () -> Unit) -> Unit,
    onSaveDebt: (id: Long, personName: String, amount: Double, type: String, note: String, dueDateMillis: Long?) -> Unit,
    onDeleteDebt: (Long) -> Unit,
    onSettleDebt: (debtId: Long, walletId: Long) -> Unit,
    onSaveRecurring: (id: Long, title: String, amount: Double, type: String, categoryId: Long?, walletId: Long, frequency: String, nextDueEpochDay: Long, autoPost: Boolean, note: String) -> Unit,
    onDeleteRecurring: (Long) -> Unit,
    onConfirmRecurringDue: (RecurringTransactionEntity) -> Unit,
    onSaveGameya: (id: Long, title: String, monthlyInstallment: Double, totalMembers: Int, payoutTurnMonth: Int, startYearMonth: String, walletId: Long) -> Unit = { _, _, _, _, _, _, _ -> },
    onDeleteGameya: (Long) -> Unit = {},
    onPayGameyaInstallment: (gameyaId: Long, walletId: Long) -> Unit = { _, _ -> },
    onReceiveGameyaPayout: (gameyaId: Long, walletId: Long) -> Unit = { _, _ -> },
    onSaveSubscription: (id: Long, title: String, amount: Double, billingCycle: String, nextRenewalEpochDay: Long, walletId: Long, categoryId: Long?, note: String) -> Unit = { _, _, _, _, _, _, _, _ -> },
    onDeleteSubscription: (Long) -> Unit = {},
    onToggleSubscriptionActive: (id: Long, active: Boolean) -> Unit = { _, _ -> },
    onRenewSubscriptionNow: (Long) -> Unit = {},
    onApply503020: (amount: Double, walletId: Long, toEmergency: Boolean, targetGoalId: Long?) -> Unit = { _, _, _, _ -> },
    onRebalanceEnvelopes: (fromEnvelopeId: Long, toEnvelopeId: Long, amount: Double) -> Unit = { _, _, _ -> },
    onContributeEmergency: (walletId: Long, amount: Double) -> Unit = { _, _ -> },
    onWithdrawEmergency: (walletId: Long, amount: Double) -> Unit = { _, _ -> },
    onSaveTrip: (id: Long, title: String, budget: Double, isActive: Boolean) -> Unit = { _, _, _, _ -> },
    onToggleTripActive: (Long, Boolean) -> Unit = { _, _ -> },
    onDeleteTrip: (Long) -> Unit = {},
    onSaveInstallment: (id: Long, itemName: String, monthlyAmount: Double, paidMonths: Int, totalMonths: Int, dueDay: Int, walletId: Long) -> Unit = { _, _, _, _, _, _, _ -> },
    onDeleteInstallment: (Long) -> Unit = {},
    onPayInstallmentMonth: (installmentId: Long, walletId: Long) -> Unit = { _, _ -> },
    modifier: Modifier = Modifier,
) {
    var selectedTab by remember { mutableIntStateOf(0) }
    val masked = state.settings.isPrivacyMode
    val haptic = LocalHapticFeedback.current

    var showBalancingPanel by remember { mutableStateOf(false) }
    var show503020Dialog by remember { mutableStateOf(false) }
    var envelopeRebalanceTargetId by remember { mutableStateOf<Long?>(null) }
    var showEnvelopeRebalanceDialog by remember { mutableStateOf(false) }
    var emergencyDialogDeposit by remember { mutableStateOf<Boolean?>(null) }

    var showCreateEnvelopeDialog by remember { mutableStateOf(false) }
    var spendEnvelopeTarget by remember { mutableStateOf<EnvelopeEntity?>(null) }
    var topUpEnvelopeTarget by remember { mutableStateOf<EnvelopeEntity?>(null) }

    var showCreateGoalDialog by remember { mutableStateOf(false) }
    var contributeGoalTarget by remember { mutableStateOf<GoalEntity?>(null) }

    var showCreateDebtDialog by remember { mutableStateOf(false) }
    var settleDebtTarget by remember { mutableStateOf<DebtEntity?>(null) }

    var showCreateRecurringDialog by remember { mutableStateOf(false) }
    var showCreateGameyaDialog by remember { mutableStateOf(false) }
    var showCreateSubscriptionDialog by remember { mutableStateOf(false) }
    var showCreateTripDialog by remember { mutableStateOf(false) }
    var showCreateInstallmentDialog by remember { mutableStateOf(false) }

    val semantic = LocalMasroufyColors.current

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter,
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 680.dp)
                .padding(horizontal = 16.dp),
        ) {
            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column {
                    Text(
                        text = "التخطيط والأهداف",
                        style = MaterialTheme.typography.headlineMedium,
                        color = MaterialTheme.colorScheme.onBackground,
                    )
                    Text(
                        text = "احجز التزاماتك وحوّش لأحلامك وتابع السُلف والتكرار",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                Button(
                    onClick = {
                        when (selectedTab) {
                            0 -> showCreateEnvelopeDialog = true
                            1 -> showCreateInstallmentDialog = true
                            2 -> showCreateGameyaDialog = true
                            3 -> showCreateSubscriptionDialog = true
                            4 -> showCreateTripDialog = true
                            5 -> showCreateGoalDialog = true
                            6 -> showCreateDebtDialog = true
                            7 -> showCreateRecurringDialog = true
                        }
                    },
                    shape = RoundedCornerShape(14.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                    modifier = Modifier.testTag("planning_add_button"),
                ) {
                    Icon(Icons.Rounded.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = when (selectedTab) {
                            0 -> "ظرف جديد"
                            1 -> "قسط جديد"
                            2 -> "جمعية جديدة"
                            3 -> "اشتراك جديد"
                            4 -> "رحلة جديدة"
                            5 -> "هدف جديد"
                            6 -> "سلفة جديدة"
                            else -> "تكرار جديد"
                        },
                        style = MaterialTheme.typography.labelLarge,
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Compact Collapsible Financial Balancing Bar (Zero-Based + Emergency Fund + 50/30/20)
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, semantic.emerald.copy(alpha = 0.4f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .clickable { showBalancingPanel = !showBalancingPanel }
                    .testTag("balancing_panel_toggle"),
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        text = "⚖️ الموازنة الصفرية • 🛡️ الطوارئ (${Formatters.formatEgp(state.settings.emergencyFundSaved, isMasked = masked)})",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.weight(1f),
                    )
                    Icon(
                        imageVector = if (showBalancingPanel) Icons.Rounded.ExpandLess else Icons.Rounded.ExpandMore,
                        contentDescription = if (showBalancingPanel) "إخفاء الموازنة" else "عرض الموازنة والطوارئ",
                        tint = semantic.emerald,
                    )
                }
            }

            AnimatedVisibility(visible = showBalancingPanel) {
                Column(
                    modifier = Modifier.padding(top = 10.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    ZeroBasedBudgetCard(
                        summary = state.zeroBasedBudget,
                        isMasked = masked,
                        onOpen503020Click = { show503020Dialog = true },
                    )
                    EmergencyFundCard(
                        savedAmount = state.settings.emergencyFundSaved,
                        targetAmount = state.emergencyFundTarget,
                        isMasked = masked,
                        onDepositClick = { emergencyDialogDeposit = true },
                        onWithdrawClick = { emergencyDialogDeposit = false },
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // 8 Scrollable Segmented Tabs
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(MaterialTheme.colorScheme.surface)
                    .border(1.dp, semantic.cardBorder, RoundedCornerShape(16.dp))
                    .horizontalScroll(rememberScrollState())
                    .padding(4.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                listOf(
                    "الأظرف",
                    "الأقساط",
                    "الجمعيات",
                    "الاشتراكات",
                    "الرحلات",
                    "الحصالة",
                    "السُلف",
                    "المتكررة",
                ).forEachIndexed { index, label ->
                    val selected = selectedTab == index
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(
                                if (selected) MaterialTheme.colorScheme.primary.copy(alpha = 0.18f)
                                else Color.Transparent,
                            )
                            .clickable { selectedTab = index }
                            .padding(horizontal = 14.dp, vertical = 10.dp)
                            .testTag("planning_tab_$index"),
                        contentAlignment = Alignment.Center,
                    ) {
                        Text(
                            text = label,
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                            color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            when (selectedTab) {
                0 -> EnvelopesTab(
                    envelopes = state.envelopes,
                    zeroBasedSummary = state.zeroBasedBudget,
                    isMasked = masked,
                    onCreateClick = { showCreateEnvelopeDialog = true },
                    onOpen503020 = { show503020Dialog = true },
                    onRebalanceClick = { env ->
                        envelopeRebalanceTargetId = env?.id
                        showEnvelopeRebalanceDialog = true
                    },
                    onSpendClick = { spendEnvelopeTarget = it },
                    onTopUpClick = { topUpEnvelopeTarget = it },
                    onDeleteClick = { onDeleteEnvelope(it.id) },
                )
                1 -> InstallmentsSection(
                    installments = state.installments,
                    wallets = state.wallets,
                    reservedInstallmentsTotal = state.budgetSnapshot.reservedInstallmentsTotal,
                    isMasked = masked,
                    onCreateClick = { showCreateInstallmentDialog = true },
                    onPayMonth = { instId, wId ->
                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        onPayInstallmentMonth(instId, wId)
                    },
                    onDeleteInstallment = onDeleteInstallment,
                )
                2 -> GameyaSection(
                    gameyas = state.gameyas,
                    wallets = state.wallets,
                    reservedGameyaTotal = state.budgetSnapshot.reservedGameyaTotal,
                    isMasked = masked,
                    onCreateClick = { showCreateGameyaDialog = true },
                    onPayInstallment = { gId, wId ->
                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        onPayGameyaInstallment(gId, wId)
                    },
                    onReceivePayout = { gId, wId ->
                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        onReceiveGameyaPayout(gId, wId)
                    },
                    onDeleteGameya = onDeleteGameya,
                )
                3 -> SubscriptionsSection(
                    subscriptions = state.subscriptions,
                    summary = state.subscriptionsSummary,
                    wallets = state.wallets,
                    isMasked = masked,
                    onCreateClick = { showCreateSubscriptionDialog = true },
                    onToggleActive = onToggleSubscriptionActive,
                    onRenewNow = { subId ->
                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        onRenewSubscriptionNow(subId)
                    },
                    onDeleteSubscription = onDeleteSubscription,
                )
                4 -> TripsSection(
                    trips = state.tripEvents,
                    transactions = state.transactions,
                    isMasked = masked,
                    onCreateClick = { showCreateTripDialog = true },
                    onToggleActive = onToggleTripActive,
                    onDeleteTrip = onDeleteTrip,
                )
                5 -> GoalsTab(
                    goals = state.goals,
                    emergencySaved = state.settings.emergencyFundSaved,
                    emergencyTarget = state.emergencyFundTarget,
                    isMasked = masked,
                    onDepositEmergency = { emergencyDialogDeposit = true },
                    onWithdrawEmergency = { emergencyDialogDeposit = false },
                    onCreateClick = { showCreateGoalDialog = true },
                    onContributeClick = { contributeGoalTarget = it },
                    onDeleteClick = { onDeleteGoal(it.id) },
                )
                6 -> DebtsTab(
                    debts = state.debts,
                    isMasked = masked,
                    onCreateClick = { showCreateDebtDialog = true },
                    onSettleClick = { settleDebtTarget = it },
                    onDeleteClick = { onDeleteDebt(it.id) },
                )
                7 -> RecurringTab(
                    items = state.recurringTransactions,
                    wallets = state.wallets,
                    categories = state.categories,
                    isMasked = masked,
                    onCreateClick = { showCreateRecurringDialog = true },
                    onConfirmDue = {
                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        onConfirmRecurringDue(it)
                    },
                    onDeleteClick = { onDeleteRecurring(it.id) },
                )
            }
        }
    }

    // --- Dialogs ---
    if (showCreateGameyaDialog) {
        CreateGameyaDialog(
            wallets = state.wallets,
            onSave = { title, installment, members, turn, startYm, wId ->
                onSaveGameya(0L, title, installment, members, turn, startYm, wId)
            },
            onDismiss = { showCreateGameyaDialog = false },
        )
    }

    if (showCreateSubscriptionDialog) {
        CreateSubscriptionDialog(
            wallets = state.wallets,
            categories = state.categories,
            onSave = { title, amount, cycle, epoch, wId, catId, note ->
                onSaveSubscription(0L, title, amount, cycle, epoch, wId, catId, note)
            },
            onDismiss = { showCreateSubscriptionDialog = false },
        )
    }

    if (showCreateEnvelopeDialog) {
        CreateEnvelopeDialog(
            onSave = { title, target, reserved, dueDay ->
                onSaveEnvelope(0L, title, target, reserved, dueDay)
                showCreateEnvelopeDialog = false
            },
            onDismiss = { showCreateEnvelopeDialog = false },
        )
    }

    spendEnvelopeTarget?.let { envelope ->
        SpendFromEnvelopeDialog(
            envelope = envelope,
            wallets = state.wallets,
            expenseCategories = state.categories.filter { it.type == TransactionType.EXPENSE },
            onConfirm = { walletId, amount, categoryId, note ->
                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                onSpendFromEnvelope(envelope.id, walletId, amount, categoryId, note)
                spendEnvelopeTarget = null
            },
            onDismiss = { spendEnvelopeTarget = null },
        )
    }

    topUpEnvelopeTarget?.let { envelope ->
        AmountInputDialog(
            title = "تزويد ظرف «${envelope.title}»",
            subtitle = "سيتم إضافة المبلغ للرصيد المحجوز للالتزامات.",
            confirmLabel = "تزويد الظرف",
            onConfirm = { amount ->
                onTopUpEnvelope(envelope.id, amount)
                topUpEnvelopeTarget = null
            },
            onDismiss = { topUpEnvelopeTarget = null },
        )
    }

    if (showCreateGoalDialog) {
        CreateGoalDialog(
            onSave = { title, target, iconKey, colorHex ->
                onSaveGoal(0L, title, target, 0.0, iconKey, colorHex)
                showCreateGoalDialog = false
            },
            onDismiss = { showCreateGoalDialog = false },
        )
    }

    contributeGoalTarget?.let { goal ->
        SelectWalletAndAmountDialog(
            title = "إضافة لحصالة «${goal.title}»",
            subtitle = "سيتم خصم المبلغ من المحفظة المختارة وإضافته لمدخرات الهدف.",
            confirmLabel = "إضافة للحصالة",
            wallets = state.wallets,
            defaultAmount = null,
            onConfirm = { walletId, amount ->
                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                onContributeToGoal(goal.id, walletId, amount) {
                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                }
                contributeGoalTarget = null
            },
            onDismiss = { contributeGoalTarget = null },
        )
    }

    if (showCreateDebtDialog) {
        CreateDebtDialog(
            onSave = { personName, amount, type, note, dueDateMillis ->
                onSaveDebt(0L, personName, amount, type, note, dueDateMillis)
                showCreateDebtDialog = false
            },
            onDismiss = { showCreateDebtDialog = false },
        )
    }

    settleDebtTarget?.let { debt ->
        val actionWord = if (debt.type == DebtType.OWED_TO_ME) "إيداع التحصيل في" else "الدفع من"
        SelectWalletOnlyDialog(
            title = "تأكيد سداد ${Formatters.formatEgp(debt.amount, isMasked = masked)}",
            subtitle = "اختر المحفظة لـ$actionWord (${debt.personName}):",
            confirmLabel = "تم السداد",
            wallets = state.wallets,
            onConfirm = { walletId ->
                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                onSettleDebt(debt.id, walletId)
                settleDebtTarget = null
            },
            onDismiss = { settleDebtTarget = null },
        )
    }

    if (showCreateRecurringDialog) {
        CreateRecurringDialog(
            wallets = state.wallets,
            categories = state.categories,
            onSave = { title, amount, type, catId, wId, freq, autoPost, note ->
                onSaveRecurring(
                    0L,
                    title,
                    amount,
                    type,
                    catId,
                    wId,
                    freq,
                    LocalDate.now().toEpochDay(),
                    autoPost,
                    note,
                )
                showCreateRecurringDialog = false
            },
            onDismiss = { showCreateRecurringDialog = false },
        )
    }
    if (showCreateTripDialog) {
        CreateTripDialog(
            onSave = { title, budget -> onSaveTrip(0L, title, budget, true) },
            onDismiss = { showCreateTripDialog = false },
        )
    }

    if (showCreateInstallmentDialog) {
        CreateInstallmentDialog(
            wallets = state.wallets,
            onSave = { itemName, monthly, paid, total, dueDay, wId ->
                onSaveInstallment(0L, itemName, monthly, paid, total, dueDay, wId)
            },
            onDismiss = { showCreateInstallmentDialog = false },
        )
    }

    if (show503020Dialog) {
        IncomeAllocator503020Dialog(
            wallets = state.wallets,
            goals = state.goals,
            onApply = onApply503020,
            onDismiss = { show503020Dialog = false },
        )
    }

    if (showEnvelopeRebalanceDialog && state.envelopes.size >= 2) {
        RebalanceTransferDialog(
            title = "غطي العجز من ظرف تاني",
            subtitle = "انقل فائض من ظرف آخر لتغطية العجز فوراً بدون ما تأثر على الرصيد الحر.",
            options = state.envelopes.map { RebalanceOption(it.id, it.title, it.reservedAmount) },
            initialTargetId = envelopeRebalanceTargetId,
            onConfirm = { fromId, toId, amt ->
                onRebalanceEnvelopes(fromId, toId, amt)
            },
            onDismiss = { showEnvelopeRebalanceDialog = false },
        )
    }

    emergencyDialogDeposit?.let { isDeposit ->
        EmergencyFundActionDialog(
            isDeposit = isDeposit,
            maxWithdrawAmount = state.settings.emergencyFundSaved,
            wallets = state.wallets,
            onConfirm = { walletId, amt ->
                if (isDeposit) onContributeEmergency(walletId, amt)
                else onWithdrawEmergency(walletId, amt)
            },
            onDismiss = { emergencyDialogDeposit = null },
        )
    }
}

@Composable
private fun EnvelopesTab(
    envelopes: List<EnvelopeEntity>,
    zeroBasedSummary: com.example.domain.ZeroBasedBudgetSummary,
    isMasked: Boolean,
    onCreateClick: () -> Unit,
    onOpen503020: () -> Unit,
    onRebalanceClick: (EnvelopeEntity?) -> Unit,
    onSpendClick: (EnvelopeEntity) -> Unit,
    onTopUpClick: (EnvelopeEntity) -> Unit,
    onDeleteClick: (EnvelopeEntity) -> Unit,
) {
    val semantic = LocalMasroufyColors.current
    val totalReserved = envelopes.sumOf { it.reservedAmount }

    LazyColumn(
        contentPadding = PaddingValues(bottom = 108.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            ZeroBasedBudgetCard(
                summary = zeroBasedSummary,
                isMasked = isMasked,
                onOpen503020Click = onOpen503020,
            )
        }

        item {
            FintechCard(
                borderColor = semantic.amber.copy(alpha = 0.4f),
                containerColor = semantic.amberContainer.copy(alpha = 0.35f),
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                        IconBadge(icon = Icons.Rounded.Lock, tint = semantic.amber, contentDescription = "إجمالي المحجوز")
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text("إجمالي المحجوز في الأظرف", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(
                                Formatters.formatEgp(totalReserved, isMasked = isMasked),
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold,
                                color = semantic.amber,
                            )
                        }
                    }
                    if (envelopes.size >= 2) {
                        OutlinedButton(
                            onClick = { onRebalanceClick(null) },
                            shape = RoundedCornerShape(12.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                            modifier = Modifier.testTag("rebalance_envelopes_button"),
                        ) {
                            Icon(Icons.Rounded.SwapHoriz, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("غطي العجز", style = MaterialTheme.typography.labelMedium)
                        }
                    }
                }
            }
        }

        if (envelopes.isEmpty()) {
            item {
                EmptyStateCard(
                    icon = Icons.Rounded.MailOutline,
                    title = "مفيش أظرف محجوزة حالياً",
                    subtitle = "اعمل ظرف لباقة النت أو الجمعية أو الإيجار عشان تعزله عن رصيدك الحر.",
                    actionText = "إنشاء أول ظرف",
                    onAction = onCreateClick,
                )
            }
        } else {
            items(envelopes, key = { it.id }) { env ->
                val progress = if (env.targetAmount > 0.0) {
                    (env.reservedAmount / env.targetAmount).toFloat().coerceIn(0f, 1f)
                } else 0f

                FintechCard(modifier = Modifier.testTag("envelope_card_${env.id}")) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                            IconBadge(icon = Icons.Rounded.MailOutline, tint = semantic.amber, contentDescription = env.title, size = 40.dp)
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(env.title, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurface)
                                env.dueDay?.let { day ->
                                    Text("موعد الاستحقاق: يوم $day شهرياً", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                        IconButton(onClick = { onDeleteClick(env) }) {
                            Icon(Icons.Rounded.DeleteOutline, contentDescription = "حذف الظرف", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(
                            "المحجوز: ${Formatters.formatEgp(env.reservedAmount, isMasked = isMasked)}",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = semantic.amber,
                        )
                        Text(
                            "المستهدف: ${Formatters.formatEgp(env.targetAmount, isMasked = isMasked)}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    LinearProgressIndicator(
                        progress = { progress },
                        modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(8.dp)),
                        color = semantic.amber,
                        trackColor = MaterialTheme.colorScheme.surfaceVariant,
                        strokeCap = StrokeCap.Round,
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = { onSpendClick(env) },
                            enabled = env.reservedAmount > 0.0,
                            modifier = Modifier.weight(1f).testTag("spend_envelope_${env.id}"),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = semantic.amber, contentColor = Color(0xFF1E1B18)),
                        ) { Text("صرف", style = MaterialTheme.typography.labelLarge) }
                        OutlinedButton(onClick = { onTopUpClick(env) }, modifier = Modifier.weight(1f), shape = RoundedCornerShape(12.dp)) {
                            Text("+ تزويد", style = MaterialTheme.typography.labelLarge)
                        }
                        if (envelopes.size >= 2) {
                            OutlinedButton(
                                onClick = { onRebalanceClick(env) },
                                shape = RoundedCornerShape(12.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp),
                            ) {
                                Text("موازنة", style = MaterialTheme.typography.labelMedium)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun GoalsTab(
    goals: List<GoalEntity>,
    emergencySaved: Double,
    emergencyTarget: Double,
    isMasked: Boolean,
    onDepositEmergency: () -> Unit,
    onWithdrawEmergency: () -> Unit,
    onCreateClick: () -> Unit,
    onContributeClick: (GoalEntity) -> Unit,
    onDeleteClick: (GoalEntity) -> Unit,
) {
    val semantic = LocalMasroufyColors.current
    val totalSaved = goals.sumOf { it.savedAmount }

    LazyColumn(
        contentPadding = PaddingValues(bottom = 108.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            EmergencyFundCard(
                savedAmount = emergencySaved,
                targetAmount = emergencyTarget,
                isMasked = isMasked,
                onDepositClick = onDepositEmergency,
                onWithdrawClick = onWithdrawEmergency,
            )
        }

        item {
            FintechCard(
                borderColor = semantic.emerald.copy(alpha = 0.4f),
                containerColor = semantic.emeraldContainer.copy(alpha = 0.35f),
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconBadge(icon = Icons.Rounded.Savings, tint = semantic.emerald, contentDescription = "إجمالي الحصالة")
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text("إجمالي المدخرات في الحصالة", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(
                            Formatters.formatEgp(totalSaved, isMasked = isMasked),
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = semantic.emerald,
                        )
                    }
                }
            }
        }

        if (goals.isEmpty()) {
            item {
                EmptyStateCard(
                    icon = Icons.Rounded.Savings,
                    title = "حصالتك لسه فاضية",
                    subtitle = "حدد هدف تحويش زي موبايل جديد أو سفر أو صندوق طوارئ وابدأ بخطوة صغيرة.",
                    actionText = "أضف هدفاً جديداً",
                    onAction = onCreateClick,
                )
            }
        } else {
            items(goals, key = { it.id }) { goal ->
                val gColor = Color(goal.colorHex)
                val progress = if (goal.targetAmount > 0.0) (goal.savedAmount / goal.targetAmount).toFloat().coerceIn(0f, 1f) else 0f
                val pct = (progress * 100f).roundToInt()

                FintechCard(modifier = Modifier.testTag("goal_card_${goal.id}")) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                            IconBadge(icon = IconsCatalog.resolve(goal.iconKey), tint = gColor, contentDescription = goal.title, size = 42.dp)
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(goal.title, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurface)
                                Text("تم تحقيق $pct%", style = MaterialTheme.typography.bodySmall, color = gColor)
                            }
                        }
                        IconButton(onClick = { onDeleteClick(goal) }) {
                            Icon(Icons.Rounded.DeleteOutline, contentDescription = "حذف الهدف", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(Formatters.formatEgp(goal.savedAmount, isMasked = isMasked), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = gColor)
                        Text("من ${Formatters.formatEgp(goal.targetAmount, isMasked = isMasked)}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    LinearProgressIndicator(
                        progress = { progress },
                        modifier = Modifier.fillMaxWidth().height(10.dp).clip(RoundedCornerShape(8.dp)),
                        color = gColor,
                        trackColor = MaterialTheme.colorScheme.surfaceVariant,
                        strokeCap = StrokeCap.Round,
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Button(
                        onClick = { onContributeClick(goal) },
                        modifier = Modifier.fillMaxWidth().testTag("add_to_goal_${goal.id}"),
                        shape = RoundedCornerShape(12.dp),
                    ) { Text("+ إضافة للحصالة", style = MaterialTheme.typography.labelLarge) }
                }
            }
        }
    }
}

@Composable
private fun DebtsTab(
    debts: List<DebtEntity>,
    isMasked: Boolean,
    onCreateClick: () -> Unit,
    onSettleClick: (DebtEntity) -> Unit,
    onDeleteClick: (DebtEntity) -> Unit,
) {
    val semantic = LocalMasroufyColors.current
    val owedToMeTotal = debts.filter { !it.isSettled && it.type == DebtType.OWED_TO_ME }.sumOf { it.amount }
    val iOweTotal = debts.filter { !it.isSettled && it.type == DebtType.I_OWE }.sumOf { it.amount }
    val today = LocalDate.now()
    val zone = ZoneId.systemDefault()

    LazyColumn(
        contentPadding = PaddingValues(bottom = 108.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                FintechCard(modifier = Modifier.weight(1f), borderColor = semantic.emerald.copy(alpha = 0.4f)) {
                    Text("فلوس ليا بره", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(Formatters.formatEgp(owedToMeTotal, isMasked = isMasked), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = semantic.emerald)
                }
                FintechCard(modifier = Modifier.weight(1f), borderColor = semantic.coral.copy(alpha = 0.4f)) {
                    Text("فلوس عليا", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(Formatters.formatEgp(iOweTotal, isMasked = isMasked), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = semantic.coral)
                }
            }
        }

        if (debts.isEmpty()) {
            item {
                EmptyStateCard(
                    icon = Icons.Rounded.Handshake,
                    title = "دفتر السُلف نضيف",
                    subtitle = "سجّل أي سلفة ليك عند حد أو فلوس عليك مع موعد استحقاق وتذكير تلقائي.",
                    actionText = "تسجيل سلفة",
                    onAction = onCreateClick,
                )
            }
        } else {
            items(debts, key = { it.id }) { debt ->
                val isOwedToMe = debt.type == DebtType.OWED_TO_ME
                val accent = if (debt.isSettled) MaterialTheme.colorScheme.onSurfaceVariant
                else if (isOwedToMe) semantic.emerald else semantic.coral
                val dueLocalDate = debt.dueDateMillis?.let { Instant.ofEpochMilli(it).atZone(zone).toLocalDate() }
                val isOverdue = !debt.isSettled && dueLocalDate != null && !dueLocalDate.isAfter(today)

                FintechCard(modifier = Modifier.testTag("debt_card_${debt.id}")) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                            IconBadge(
                                icon = if (debt.isSettled) Icons.Rounded.CheckCircle else Icons.Rounded.Handshake,
                                tint = accent,
                                contentDescription = debt.personName,
                                size = 42.dp,
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(debt.personName, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurface)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Surface(color = accent.copy(alpha = 0.15f), shape = RoundedCornerShape(8.dp)) {
                                        Text(
                                            text = if (isOwedToMe) "ليا بره" else "عليا",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = accent,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                        )
                                    }
                                }
                                Text(
                                    text = buildString {
                                        append(Formatters.formatDateOnly(debt.dateMillis))
                                        if (debt.note.isNotBlank()) append(" • ${debt.note}")
                                    },
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                                if (debt.dueDateMillis != null && !debt.isSettled) {
                                    Text(
                                        text = if (isOverdue) "مستحق السداد: ${Formatters.formatDateOnly(debt.dueDateMillis)} ⏰" else "موعد السداد: ${Formatters.formatDateOnly(debt.dueDateMillis)}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = if (isOverdue) semantic.amber else MaterialTheme.colorScheme.onSurfaceVariant,
                                    )
                                }
                            }
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(Formatters.formatEgp(debt.amount, isMasked = isMasked), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = accent)
                            IconButton(onClick = { onDeleteClick(debt) }, modifier = Modifier.size(32.dp)) {
                                Icon(Icons.Rounded.DeleteOutline, contentDescription = "حذف السجل", tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(18.dp))
                            }
                        }
                    }

                    if (!debt.isSettled) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Button(
                            onClick = { onSettleClick(debt) },
                            modifier = Modifier.fillMaxWidth().testTag("settle_debt_${debt.id}"),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = accent, contentColor = Color.White),
                        ) {
                            Icon(Icons.Rounded.Payments, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("تم السداد", style = MaterialTheme.typography.labelLarge)
                        }
                    } else {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text("تم السداد ✓", style = MaterialTheme.typography.labelMedium, color = semantic.emerald)
                    }
                }
            }
        }
    }
}

@Composable
private fun RecurringTab(
    items: List<RecurringTransactionEntity>,
    wallets: List<WalletEntity>,
    categories: List<CategoryEntity>,
    isMasked: Boolean,
    onCreateClick: () -> Unit,
    onConfirmDue: (RecurringTransactionEntity) -> Unit,
    onDeleteClick: (RecurringTransactionEntity) -> Unit,
) {
    val semantic = LocalMasroufyColors.current
    val walletMap = remember(wallets) { wallets.associateBy { it.id } }
    val categoryMap = remember(categories) { categories.associateBy { it.id } }
    val todayEpoch = LocalDate.now().toEpochDay()

    LazyColumn(
        contentPadding = PaddingValues(bottom = 108.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        if (items.isEmpty()) {
            item {
                EmptyStateCard(
                    icon = Icons.Rounded.EventRepeat,
                    title = "مفيش معاملات متكررة",
                    subtitle = "جدوِل اشتراك النت، الإيجار، أو المصروف الدوري يومياً أو أسبوعياً أو شهرياً.",
                    actionText = "إضافة معاملة متكررة",
                    onAction = onCreateClick,
                )
            }
        } else {
            items(items, key = { it.id }) { item ->
                val isIncome = item.type == TransactionType.INCOME
                val accent = if (isIncome) semantic.emerald else semantic.coral
                val nextDate = LocalDate.ofEpochDay(item.nextDueEpochDay)
                val isDue = item.nextDueEpochDay <= todayEpoch

                FintechCard(modifier = Modifier.testTag("recurring_card_${item.id}")) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                            IconBadge(icon = Icons.Rounded.EventRepeat, tint = accent, contentDescription = item.title, size = 42.dp)
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(item.title, style = MaterialTheme.typography.titleMedium)
                                Text(
                                    text = "${RecurringFrequency.label(item.frequency)} • ${walletMap[item.walletId]?.name ?: ""} • ${item.categoryId?.let { categoryMap[it]?.name } ?: ""}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                                Text(
                                    text = "الموعد القادم: ${Formatters.formatShortDate(nextDate)} ${if (item.autoPost) "• تلقائي" else "• تأكيد يدوي"}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (isDue) semantic.amber else MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = Formatters.formatEgp(item.amount, isMasked = isMasked),
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = accent,
                            )
                            IconButton(onClick = { onDeleteClick(item) }, modifier = Modifier.size(32.dp)) {
                                Icon(Icons.Rounded.DeleteOutline, contentDescription = "حذف", modifier = Modifier.size(18.dp))
                            }
                        }
                    }

                    if (isDue) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Button(
                            onClick = { onConfirmDue(item) },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                        ) {
                            Text("تسجيل الدفعة المستحقة الآن")
                        }
                    }
                }
            }
        }
    }
}

// --- Planning Dialogs ---

@Composable
private fun CreateEnvelopeDialog(
    onSave: (title: String, target: Double, reserved: Double, dueDay: Int?) -> Unit,
    onDismiss: () -> Unit,
) {
    var title by remember { mutableStateOf("") }
    var targetText by remember { mutableStateOf("") }
    var reservedText by remember { mutableStateOf("") }
    var dueDayText by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("إنشاء ظرف التزام جديد", style = MaterialTheme.typography.titleLarge) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it; error = null },
                    label = { Text("اسم الظرف (مثلاً: باقة النت، جمعية)") },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = targetText,
                    onValueChange = { targetText = it; error = null },
                    label = { Text("المبلغ المستهدف (ج.م)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = reservedText,
                    onValueChange = { reservedText = it; error = null },
                    label = { Text("المبلغ المحجوز الآن (ج.م)") },
                    placeholder = { Text("يساوي المستهدف لو سبته فاضي") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = dueDayText,
                    onValueChange = { dueDayText = it },
                    label = { Text("يوم الاستحقاق الشهري (1-28 اختياري)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth(),
                )
                error?.let { Text(it, color = LocalMasroufyColors.current.coral, style = MaterialTheme.typography.bodySmall) }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val target = Formatters.parseSafeDouble(targetText) ?: 0.0
                    val reserved = if (reservedText.isBlank()) target else Formatters.parseSafeDouble(reservedText) ?: 0.0
                    val dueDay = Formatters.normalizeArabicDigits(dueDayText).toIntOrNull()?.coerceIn(1, 28)
                    when {
                        title.isBlank() -> error = "اكتب اسم الظرف"
                        target <= 0.0 -> error = "أدخل مبلغاً مستهدفاً أكبر من صفر"
                        else -> onSave(title, target, reserved.coerceAtLeast(0.0), dueDay)
                    }
                },
                shape = RoundedCornerShape(12.dp),
            ) { Text("حفظ الظرف") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } },
        containerColor = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(22.dp),
    )
}

@Composable
private fun SpendFromEnvelopeDialog(
    envelope: EnvelopeEntity,
    wallets: List<WalletEntity>,
    expenseCategories: List<CategoryEntity>,
    onConfirm: (walletId: Long, amount: Double, categoryId: Long?, note: String) -> Unit,
    onDismiss: () -> Unit,
) {
    var selectedWalletId by remember { mutableLongStateOf(wallets.firstOrNull()?.id ?: 0L) }
    var selectedCategoryId by remember { mutableStateOf(expenseCategories.firstOrNull()?.id) }
    var amountText by remember {
        mutableStateOf(
            if (envelope.reservedAmount % 1.0 == 0.0) envelope.reservedAmount.toLong().toString()
            else envelope.reservedAmount.toString(),
        )
    }
    var note by remember { mutableStateOf(envelope.title) }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("صرف من ظرف «${envelope.title}»", style = MaterialTheme.typography.titleLarge) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "سيتم خصم المبلغ من المحفظة المختارة وتقليل الحجز من الظرف وتسجيله كمصروف.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                OutlinedTextField(
                    value = amountText,
                    onValueChange = { amountText = it; error = null },
                    label = { Text("مبلغ الصرف (ج.م)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth(),
                )
                Text("اختر المحفظة:", style = MaterialTheme.typography.labelLarge)
                Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    wallets.forEach { w ->
                        val selected = selectedWalletId == w.id
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = if (selected) MaterialTheme.colorScheme.primary.copy(alpha = 0.2f) else MaterialTheme.colorScheme.surfaceVariant,
                            border = BorderStroke(1.dp, if (selected) MaterialTheme.colorScheme.primary else LocalMasroufyColors.current.cardBorder),
                            modifier = Modifier.clickable { selectedWalletId = w.id },
                        ) { Text(w.name, style = MaterialTheme.typography.labelMedium, modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp)) }
                    }
                }
                if (expenseCategories.isNotEmpty()) {
                    Text("التصنيف:", style = MaterialTheme.typography.labelLarge)
                    Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        expenseCategories.forEach { c ->
                            val selected = selectedCategoryId == c.id
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = if (selected) Color(c.colorHex).copy(alpha = 0.22f) else MaterialTheme.colorScheme.surfaceVariant,
                                border = BorderStroke(1.dp, if (selected) Color(c.colorHex) else LocalMasroufyColors.current.cardBorder),
                                modifier = Modifier.clickable { selectedCategoryId = c.id },
                            ) { Text(c.name, style = MaterialTheme.typography.labelMedium, modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp)) }
                        }
                    }
                }
                OutlinedTextField(
                    value = note,
                    onValueChange = { note = it },
                    label = { Text("ملاحظة") },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth(),
                )
                error?.let { Text(it, color = LocalMasroufyColors.current.coral, style = MaterialTheme.typography.bodySmall) }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amount = Formatters.parseSafeDouble(amountText) ?: 0.0
                    when {
                        amount <= 0.0 -> error = "أدخل مبلغاً أكبر من صفر"
                        selectedWalletId == 0L -> error = "اختر المحفظة"
                        else -> onConfirm(selectedWalletId, amount, selectedCategoryId, note)
                    }
                },
                shape = RoundedCornerShape(12.dp),
            ) { Text("تأكيد الصرف") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } },
        containerColor = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(22.dp),
    )
}

@Composable
private fun CreateGoalDialog(
    onSave: (title: String, target: Double, iconKey: String, colorHex: Long) -> Unit,
    onDismiss: () -> Unit,
) {
    var title by remember { mutableStateOf("") }
    var targetText by remember { mutableStateOf("") }
    var selectedIconKey by remember { mutableStateOf("savings") }
    var selectedColorHex by remember { mutableLongStateOf(0xFF10B981) }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("إضافة هدف تحويش جديد", style = MaterialTheme.typography.titleLarge) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it; error = null },
                    label = { Text("اسم الهدف (مثلاً: لابتوب، سفرية)") },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = targetText,
                    onValueChange = { targetText = it; error = null },
                    label = { Text("المبلغ المستهدف (ج.م)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth(),
                )
                Text("الأيقونة:", style = MaterialTheme.typography.labelLarge)
                Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    IconsCatalog.goalIconOptions.forEach { opt ->
                        val selected = selectedIconKey == opt.key
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = if (selected) Color(selectedColorHex).copy(alpha = 0.2f) else MaterialTheme.colorScheme.surfaceVariant,
                            border = BorderStroke(1.dp, if (selected) Color(selectedColorHex) else LocalMasroufyColors.current.cardBorder),
                            modifier = Modifier.clickable { selectedIconKey = opt.key },
                        ) { Icon(opt.icon, contentDescription = opt.label, tint = Color(selectedColorHex), modifier = Modifier.padding(10.dp).size(22.dp)) }
                    }
                }
                Text("اللون:", style = MaterialTheme.typography.labelLarge)
                Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    IconsCatalog.selectableColorHexes.forEach { hex ->
                        Box(
                            modifier = Modifier
                                .size(30.dp)
                                .clip(CircleShape)
                                .background(Color(hex))
                                .border(
                                    width = if (selectedColorHex == hex) 2.5.dp else 0.dp,
                                    color = if (selectedColorHex == hex) Color.White else Color.Transparent,
                                    shape = CircleShape,
                                )
                                .clickable { selectedColorHex = hex },
                        )
                    }
                }
                error?.let { Text(it, color = LocalMasroufyColors.current.coral, style = MaterialTheme.typography.bodySmall) }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val target = Formatters.parseSafeDouble(targetText) ?: 0.0
                    when {
                        title.isBlank() -> error = "اكتب اسم الهدف"
                        target <= 0.0 -> error = "أدخل مبلغاً مستهدفاً أكبر من صفر"
                        else -> onSave(title, target, selectedIconKey, selectedColorHex)
                    }
                },
                shape = RoundedCornerShape(12.dp),
            ) { Text("حفظ الهدف") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } },
        containerColor = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(22.dp),
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun CreateDebtDialog(
    onSave: (personName: String, amount: Double, type: String, note: String, dueDateMillis: Long?) -> Unit,
    onDismiss: () -> Unit,
) {
    var personName by remember { mutableStateOf("") }
    var amountText by remember { mutableStateOf("") }
    var debtType by remember { mutableStateOf(DebtType.OWED_TO_ME) }
    var note by remember { mutableStateOf("") }
    var dueDateMillis by remember { mutableStateOf<Long?>(null) }
    var showDatePicker by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val semantic = LocalMasroufyColors.current

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("تسجيل سُلفة جديدة", style = MaterialTheme.typography.titleLarge) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(DebtType.OWED_TO_ME to "فلوس ليا بره", DebtType.I_OWE to "فلوس عليا").forEach { (typeKey, label) ->
                        val selected = debtType == typeKey
                        val accent = if (typeKey == DebtType.OWED_TO_ME) semantic.emerald else semantic.coral
                        Surface(
                            modifier = Modifier.weight(1f).clickable { debtType = typeKey },
                            shape = RoundedCornerShape(12.dp),
                            color = if (selected) accent.copy(alpha = 0.2f) else MaterialTheme.colorScheme.surfaceVariant,
                            border = BorderStroke(1.dp, if (selected) accent else semantic.cardBorder),
                        ) {
                            Text(label, style = MaterialTheme.typography.labelLarge, color = if (selected) accent else MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(vertical = 10.dp, horizontal = 8.dp))
                        }
                    }
                }
                OutlinedTextField(
                    value = personName,
                    onValueChange = { personName = it; error = null },
                    label = { Text("اسم الشخص") },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = amountText,
                    onValueChange = { amountText = it; error = null },
                    label = { Text("المبلغ (ج.م)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = note,
                    onValueChange = { note = it },
                    label = { Text("ملاحظة (اختياري)") },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth(),
                )
                // #10 Optional Due-Date Reminder Picker
                OutlinedButton(
                    onClick = { showDatePicker = true },
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Icon(Icons.Rounded.CalendarToday, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = dueDateMillis?.let { "موعد التذكير: ${Formatters.formatDateOnly(it)}" }
                            ?: "تحديد موعد تذكير للسداد (اختياري)",
                    )
                }
                error?.let { Text(it, color = semantic.coral, style = MaterialTheme.typography.bodySmall) }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amount = Formatters.parseSafeDouble(amountText) ?: 0.0
                    when {
                        personName.isBlank() -> error = "اكتب اسم الشخص"
                        amount <= 0.0 -> error = "أدخل مبلغاً أكبر من صفر"
                        else -> onSave(personName, amount, debtType, note, dueDateMillis)
                    }
                },
                shape = RoundedCornerShape(12.dp),
            ) { Text("حفظ") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } },
        containerColor = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(22.dp),
    )

    if (showDatePicker) {
        val pickerState = rememberDatePickerState()
        DatePickerDialog(
            onDismissRequest = { showDatePicker = false },
            confirmButton = {
                TextButton(
                    onClick = {
                        dueDateMillis = pickerState.selectedDateMillis
                        showDatePicker = false
                    },
                ) { Text("تأكيد") }
            },
            dismissButton = {
                TextButton(onClick = { dueDateMillis = null; showDatePicker = false }) { Text("إلغاء الموعد") }
            },
        ) {
            DatePicker(state = pickerState)
        }
    }
}

@Composable
private fun CreateRecurringDialog(
    wallets: List<WalletEntity>,
    categories: List<CategoryEntity>,
    onSave: (title: String, amount: Double, type: String, categoryId: Long?, walletId: Long, frequency: String, autoPost: Boolean, note: String) -> Unit,
    onDismiss: () -> Unit,
) {
    var title by remember { mutableStateOf("") }
    var amountText by remember { mutableStateOf("") }
    var type by remember { mutableStateOf(TransactionType.EXPENSE) }
    val cats = remember(categories, type) { categories.filter { it.type == type } }
    var selectedCatId by remember(cats) { mutableStateOf(cats.firstOrNull()?.id) }
    var selectedWalletId by remember { mutableLongStateOf(wallets.firstOrNull()?.id ?: 0L) }
    var frequency by remember { mutableStateOf(RecurringFrequency.MONTHLY) }
    var autoPost by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val semantic = LocalMasroufyColors.current

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("إضافة معاملة متكررة", style = MaterialTheme.typography.titleLarge) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(TransactionType.EXPENSE to "مصروف", TransactionType.INCOME to "دخل").forEach { (k, lbl) ->
                        val sel = type == k
                        Surface(
                            modifier = Modifier.weight(1f).clickable { type = k },
                            shape = RoundedCornerShape(12.dp),
                            color = if (sel) semantic.emerald.copy(alpha = 0.2f) else MaterialTheme.colorScheme.surfaceVariant,
                            border = BorderStroke(1.dp, if (sel) semantic.emerald else semantic.cardBorder),
                        ) { Text(lbl, modifier = Modifier.padding(8.dp), style = MaterialTheme.typography.labelLarge) }
                    }
                }
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it; error = null },
                    label = { Text("العنوان (مثلاً: باقة الإنترنت، المرتب)") },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = amountText,
                    onValueChange = { amountText = it; error = null },
                    label = { Text("المبلغ (ج.م)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth(),
                )
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(
                        RecurringFrequency.DAILY to "يومياً",
                        RecurringFrequency.WEEKLY to "أسبوعياً",
                        RecurringFrequency.MONTHLY to "شهرياً",
                    ).forEach { (freq, lbl) ->
                        val sel = frequency == freq
                        Surface(
                            modifier = Modifier.weight(1f).clickable { frequency = freq },
                            shape = RoundedCornerShape(10.dp),
                            color = if (sel) semantic.sky.copy(alpha = 0.2f) else MaterialTheme.colorScheme.surfaceVariant,
                            border = BorderStroke(1.dp, if (sel) semantic.sky else semantic.cardBorder),
                        ) { Text(lbl, modifier = Modifier.padding(8.dp), style = MaterialTheme.typography.labelMedium) }
                    }
                }
                Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    wallets.forEach { w ->
                        val sel = selectedWalletId == w.id
                        Surface(
                            modifier = Modifier.clickable { selectedWalletId = w.id },
                            shape = RoundedCornerShape(10.dp),
                            color = if (sel) semantic.emerald.copy(alpha = 0.2f) else MaterialTheme.colorScheme.surfaceVariant,
                            border = BorderStroke(1.dp, if (sel) semantic.emerald else semantic.cardBorder),
                        ) { Text(w.name, modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp), style = MaterialTheme.typography.labelMedium) }
                    }
                }
                Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    cats.forEach { c ->
                        val sel = selectedCatId == c.id
                        Surface(
                            modifier = Modifier.clickable { selectedCatId = c.id },
                            shape = RoundedCornerShape(10.dp),
                            color = if (sel) Color(c.colorHex).copy(alpha = 0.2f) else MaterialTheme.colorScheme.surfaceVariant,
                            border = BorderStroke(1.dp, if (sel) Color(c.colorHex) else semantic.cardBorder),
                        ) { Text(c.name, modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp), style = MaterialTheme.typography.labelMedium) }
                    }
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text("تسجيل تلقائي عند الاستحقاق", style = MaterialTheme.typography.bodySmall)
                    Switch(checked = autoPost, onCheckedChange = { autoPost = it })
                }
                error?.let { Text(it, color = semantic.coral, style = MaterialTheme.typography.bodySmall) }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amt = Formatters.parseSafeDouble(amountText) ?: 0.0
                    when {
                        title.isBlank() -> error = "اكتب العنوان"
                        amt <= 0.0 -> error = "أدخل مبلغاً أكبر من صفر"
                        selectedWalletId == 0L -> error = "اختر المحفظة"
                        else -> onSave(title, amt, type, selectedCatId, selectedWalletId, frequency, autoPost, title)
                    }
                },
            ) { Text("حفظ") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } },
        containerColor = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(22.dp),
    )
}

@Composable
private fun AmountInputDialog(
    title: String,
    subtitle: String,
    confirmLabel: String,
    onConfirm: (Double) -> Unit,
    onDismiss: () -> Unit,
) {
    var amountText by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title, style = MaterialTheme.typography.titleLarge) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                OutlinedTextField(
                    value = amountText,
                    onValueChange = { amountText = it; error = null },
                    label = { Text("المبلغ (ج.م)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth(),
                )
                error?.let { Text(it, color = LocalMasroufyColors.current.coral, style = MaterialTheme.typography.bodySmall) }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amount = Formatters.parseSafeDouble(amountText) ?: 0.0
                    if (amount <= 0.0) error = "أدخل مبلغاً أكبر من صفر" else onConfirm(amount)
                },
                shape = RoundedCornerShape(12.dp),
            ) { Text(confirmLabel) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } },
        containerColor = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(22.dp),
    )
}

@Composable
private fun SelectWalletAndAmountDialog(
    title: String,
    subtitle: String,
    confirmLabel: String,
    wallets: List<WalletEntity>,
    defaultAmount: Double?,
    onConfirm: (walletId: Long, amount: Double) -> Unit,
    onDismiss: () -> Unit,
) {
    var selectedWalletId by remember { mutableLongStateOf(wallets.firstOrNull()?.id ?: 0L) }
    var amountText by remember { mutableStateOf(defaultAmount?.toString() ?: "") }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title, style = MaterialTheme.typography.titleLarge) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                OutlinedTextField(
                    value = amountText,
                    onValueChange = { amountText = it; error = null },
                    label = { Text("المبلغ (ج.م)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth(),
                )
                Text("اختر المحفظة:", style = MaterialTheme.typography.labelLarge)
                Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    wallets.forEach { w ->
                        val selected = selectedWalletId == w.id
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = if (selected) MaterialTheme.colorScheme.primary.copy(alpha = 0.2f) else MaterialTheme.colorScheme.surfaceVariant,
                            border = BorderStroke(1.dp, if (selected) MaterialTheme.colorScheme.primary else LocalMasroufyColors.current.cardBorder),
                            modifier = Modifier.clickable { selectedWalletId = w.id },
                        ) {
                            Column(modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp)) {
                                Text(w.name, style = MaterialTheme.typography.labelMedium)
                                Text(Formatters.formatEgp(w.balance), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
                error?.let { Text(it, color = LocalMasroufyColors.current.coral, style = MaterialTheme.typography.bodySmall) }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amount = Formatters.parseSafeDouble(amountText) ?: 0.0
                    when {
                        amount <= 0.0 -> error = "أدخل مبلغاً أكبر من صفر"
                        selectedWalletId == 0L -> error = "اختر المحفظة"
                        else -> onConfirm(selectedWalletId, amount)
                    }
                },
                shape = RoundedCornerShape(12.dp),
            ) { Text(confirmLabel) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } },
        containerColor = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(22.dp),
    )
}

@Composable
private fun SelectWalletOnlyDialog(
    title: String,
    subtitle: String,
    confirmLabel: String,
    wallets: List<WalletEntity>,
    onConfirm: (walletId: Long) -> Unit,
    onDismiss: () -> Unit,
) {
    var selectedWalletId by remember { mutableLongStateOf(wallets.firstOrNull()?.id ?: 0L) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title, style = MaterialTheme.typography.titleLarge) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                wallets.forEach { w ->
                    val selected = selectedWalletId == w.id
                    Surface(
                        modifier = Modifier.fillMaxWidth().clickable { selectedWalletId = w.id },
                        shape = RoundedCornerShape(12.dp),
                        color = if (selected) MaterialTheme.colorScheme.primary.copy(alpha = 0.18f) else MaterialTheme.colorScheme.surfaceVariant,
                        border = BorderStroke(1.dp, if (selected) MaterialTheme.colorScheme.primary else LocalMasroufyColors.current.cardBorder),
                    ) {
                        Row(modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(w.name, style = MaterialTheme.typography.labelLarge)
                            Text(Formatters.formatEgp(w.balance), style = MaterialTheme.typography.labelMedium)
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(onClick = { if (selectedWalletId != 0L) onConfirm(selectedWalletId) }, shape = RoundedCornerShape(12.dp)) { Text(confirmLabel) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } },
        containerColor = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(22.dp),
    )
}
