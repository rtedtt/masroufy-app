package com.example.ui.theme

import android.app.Activity
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat
import com.example.domain.MasroufyThemePack

@Immutable
data class MasroufySemanticColors(
    val emerald: Color,
    val emeraldContainer: Color,
    val coral: Color,
    val coralContainer: Color,
    val amber: Color,
    val amberContainer: Color,
    val sky: Color,
    val cardBorder: Color,
    val subtleSurface: Color,
    val heroStart: Color,
    val heroEnd: Color,
    val isDark: Boolean,
)

val LocalMasroufyColors = staticCompositionLocalOf {
    MasroufySemanticColors(
        emerald = EmeraldGreen,
        emeraldContainer = EmeraldContainerDark,
        coral = CoralRed,
        coralContainer = CoralContainerDark,
        amber = AmberGold,
        amberContainer = AmberContainerDark,
        sky = SkyBlue,
        cardBorder = SlateBorder,
        subtleSurface = SlateSurfaceVariant,
        heroStart = Color(0xFF132238),
        heroEnd = Color(0xFF0C1A2E),
        isDark = true,
    )
}

private val MasroufyShapes = Shapes(
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(20.dp),
    extraLarge = RoundedCornerShape(24.dp),
)

@Composable
fun MasroufyTheme(
    darkTheme: Boolean = true,
    themePackId: String = MasroufyThemePack.EMERALD_CLASSIC.id,
    content: @Composable () -> Unit,
) {
    val pack = MasroufyThemePack.fromId(themePackId)
    val packPrimary = Color(pack.primaryHex)
    val packSecondary = Color(pack.secondaryHex)
    val packTertiary = Color(pack.tertiaryHex)
    val packBackground = Color(pack.backgroundHex)
    val packSurface = Color(pack.surfaceHex)
    val packSurfaceVariant = Color(pack.surfaceVariantHex)
    val packBorder = Color(pack.cardBorderHex)

    val colorScheme = if (darkTheme) {
        darkColorScheme(
            primary = packPrimary,
            onPrimary = Color(pack.onPrimaryDarkHex),
            primaryContainer = lerp(packSurface, packPrimary, 0.25f),
            onPrimaryContainer = lerp(packPrimary, Color.White, 0.55f),
            secondary = packSecondary,
            onSecondary = Color(0xFF090D16),
            secondaryContainer = lerp(packSurface, packSecondary, 0.22f),
            onSecondaryContainer = lerp(packSecondary, Color.White, 0.6f),
            tertiary = packTertiary,
            onTertiary = Color(0xFF090D16),
            tertiaryContainer = lerp(packSurface, packTertiary, 0.22f),
            onTertiaryContainer = lerp(packTertiary, Color.White, 0.6f),
            error = CoralRed,
            onError = Color.White,
            errorContainer = CoralContainerDark,
            onErrorContainer = Color(0xFFFECACA),
            background = packBackground,
            onBackground = SlateTextPrimary,
            surface = packSurface,
            onSurface = SlateTextPrimary,
            surfaceVariant = packSurfaceVariant,
            onSurfaceVariant = SlateTextSecondary,
            outline = packBorder,
            outlineVariant = lerp(packSurface, packBorder, 0.6f),
        )
    } else {
        val lightPrimary = if (pack == MasroufyThemePack.ROYAL_PLATINUM) Color(0xFF334155) else lerp(packPrimary, Color.Black, 0.22f)
        val lightSecondary = lerp(packSecondary, Color.Black, 0.18f)
        lightColorScheme(
            primary = lightPrimary,
            onPrimary = Color.White,
            primaryContainer = lerp(lightPrimary, Color.White, 0.84f),
            onPrimaryContainer = lerp(lightPrimary, Color.Black, 0.45f),
            secondary = lightSecondary,
            onSecondary = Color.White,
            secondaryContainer = lerp(lightSecondary, Color.White, 0.85f),
            onSecondaryContainer = lerp(lightSecondary, Color.Black, 0.45f),
            tertiary = AmberDark,
            onTertiary = Color.White,
            tertiaryContainer = AmberContainerLight,
            onTertiaryContainer = Color(0xFF78350F),
            error = CoralDark,
            onError = Color.White,
            errorContainer = CoralContainerLight,
            onErrorContainer = Color(0xFF7F1D1D),
            background = LightBackground,
            onBackground = LightTextPrimary,
            surface = LightSurface,
            onSurface = LightTextPrimary,
            surfaceVariant = LightSurfaceVariant,
            onSurfaceVariant = LightTextSecondary,
            outline = LightBorder,
            outlineVariant = Color(0xFFE2E8F0),
        )
    }

    val semanticColors = if (darkTheme) {
        val positiveAccent = if (pack == MasroufyThemePack.ROYAL_PLATINUM) packSecondary else packPrimary
        MasroufySemanticColors(
            emerald = positiveAccent,
            emeraldContainer = lerp(packSurface, positiveAccent, 0.22f),
            coral = CoralRed,
            coralContainer = CoralContainerDark.copy(alpha = 0.45f),
            amber = if (pack == MasroufyThemePack.ROYAL_GOLD) packPrimary else AmberGold,
            amberContainer = lerp(packSurface, AmberGold, 0.22f),
            sky = packTertiary,
            cardBorder = packBorder,
            subtleSurface = packSurfaceVariant,
            heroStart = lerp(packSurface, packPrimary, 0.16f),
            heroEnd = lerp(packBackground, packSurface, 0.55f),
            isDark = true,
        )
    } else {
        val lightAccent = if (pack == MasroufyThemePack.ROYAL_PLATINUM) Color(0xFF059669) else lerp(packPrimary, Color.Black, 0.22f)
        MasroufySemanticColors(
            emerald = lightAccent,
            emeraldContainer = lerp(lightAccent, Color.White, 0.84f),
            coral = CoralDark,
            coralContainer = CoralContainerLight,
            amber = AmberDark,
            amberContainer = AmberContainerLight,
            sky = SkyBlueDark,
            cardBorder = LightBorder,
            subtleSurface = LightSurfaceVariant,
            heroStart = packBackground,
            heroEnd = packSurface,
            isDark = false,
        )
    }

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            if (window != null) {
                WindowCompat.getInsetsController(window, view).apply {
                    isAppearanceLightStatusBars = !darkTheme
                    isAppearanceLightNavigationBars = !darkTheme
                }
            }
        }
    }

    CompositionLocalProvider(
        LocalLayoutDirection provides LayoutDirection.Rtl,
        LocalMasroufyColors provides semanticColors,
    ) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = MasroufyTypography,
            shapes = MasroufyShapes,
            content = content,
        )
    }
}
