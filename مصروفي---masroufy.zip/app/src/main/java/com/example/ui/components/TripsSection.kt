package com.example.ui.components

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.FlightTakeoff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.data.local.TransactionEntity
import com.example.data.local.TransactionType
import com.example.data.local.TripEventEntity
import com.example.domain.Formatters
import com.example.ui.theme.LocalMasroufyColors

@Composable
fun TripsSection(
    trips: List<TripEventEntity>,
    transactions: List<TransactionEntity>,
    isMasked: Boolean,
    onCreateClick: () -> Unit,
    onToggleActive: (Long, Boolean) -> Unit,
    onDeleteTrip: (Long) -> Unit,
) {
    val semantic = LocalMasroufyColors.current
    val activeTrip = trips.firstOrNull { it.isActive }

    LazyColumn(
        contentPadding = PaddingValues(bottom = 108.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            FintechCard(
                borderColor = semantic.sky.copy(alpha = 0.45f),
                containerColor = semantic.sky.copy(alpha = 0.12f),
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconBadge(
                        icon = Icons.Rounded.FlightTakeoff,
                        tint = semantic.sky,
                        contentDescription = "وضع الرحلات والمناسبات",
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text("وضع الرحلات والمناسبات 🏖️", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text(
                            text = if (activeTrip != null) {
                                "الرحلة النشطة: «${activeTrip.title}» — مصاريفها معزولة عن الحد اليومي"
                            } else {
                                "افصل مصاريف المصيف أو العيد أو الخروجات الكبيرة عن ميزانيتك اليومية"
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }
        }

        if (trips.isEmpty()) {
            item {
                EmptyStateCard(
                    icon = Icons.Rounded.FlightTakeoff,
                    title = "مفيش رحلات أو مناسبات حالياً",
                    subtitle = "اعمل ميزانية خاصة لرحلة أو مناسبة (مثلاً: مصيف الساحل، تجهيز العيد) عشان متشوهش حد الصرف اليومي.",
                    actionText = "بدء رحلة / مناسبة",
                    onAction = onCreateClick,
                )
            }
        } else {
            items(trips, key = { it.id }) { trip ->
                val spent = transactions
                    .filter { it.tripEventId == trip.id && it.type == TransactionType.EXPENSE }
                    .sumOf { it.amount }
                val progress = if (trip.budget > 0.0) (spent / trip.budget).toFloat().coerceIn(0f, 1f) else 0f
                val overBudget = trip.budget > 0.0 && spent > trip.budget
                val barColor = if (overBudget) semantic.coral else semantic.sky

                FintechCard(
                    modifier = Modifier.testTag("trip_card_${trip.id}"),
                    borderColor = if (trip.isActive) semantic.sky else semantic.cardBorder,
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                            IconBadge(
                                icon = Icons.Rounded.FlightTakeoff,
                                tint = if (trip.isActive) semantic.sky else MaterialTheme.colorScheme.onSurfaceVariant,
                                contentDescription = trip.title,
                                size = 40.dp,
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(trip.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                Text(
                                    text = if (trip.isActive) "نشطة الآن في التسجيل السريع" else "موقفة",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (trip.isActive) semantic.sky else MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Switch(
                                checked = trip.isActive,
                                onCheckedChange = { onToggleActive(trip.id, it) },
                                modifier = Modifier.testTag("trip_active_switch_${trip.id}"),
                            )
                            IconButton(onClick = { onDeleteTrip(trip.id) }) {
                                Icon(Icons.Rounded.DeleteOutline, contentDescription = "حذف الرحلة", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(
                            "المصروف: ${Formatters.formatEgp(spent, isMasked = isMasked)}",
                            style = MaterialTheme.typography.labelLarge,
                            color = barColor,
                        )
                        Text(
                            "الميزانية: ${Formatters.formatEgp(trip.budget, isMasked = isMasked)}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    LinearProgressIndicator(
                        progress = { progress },
                        modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(8.dp)),
                        color = barColor,
                        trackColor = MaterialTheme.colorScheme.surfaceVariant,
                        strokeCap = StrokeCap.Round,
                    )
                }
            }
        }
    }
}

@Composable
fun CreateTripDialog(
    onSave: (title: String, budget: Double) -> Unit,
    onDismiss: () -> Unit,
) {
    BackHandler(enabled = true) { onDismiss() }

    var title by remember { mutableStateOf("") }
    var budgetText by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("بدء رحلة أو مناسبة جديدة 🏖️", style = MaterialTheme.typography.titleLarge) },
        text = {
            Column(
                modifier = Modifier
                    .verticalScroll(rememberScrollState())
                    .imePadding(),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it; error = null },
                    label = { Text("اسم الرحلة أو المناسبة (مثلاً: مصيف إسكندرية)") },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth().testTag("trip_title_input"),
                )
                OutlinedTextField(
                    value = budgetText,
                    onValueChange = { budgetText = it; error = null },
                    label = { Text("الميزانية المخصصة (ج.م)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth().testTag("trip_budget_input"),
                )
                error?.let { Text(it, color = LocalMasroufyColors.current.coral, style = MaterialTheme.typography.bodySmall) }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val budget = Formatters.parseSafeDouble(budgetText) ?: 0.0
                    when {
                        title.isBlank() -> error = "اكتب اسم الرحلة أو المناسبة"
                        budget <= 0.0 -> error = "أدخل ميزانية أكبر من صفر"
                        else -> {
                            onSave(title, budget)
                            onDismiss()
                        }
                    }
                },
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.testTag("save_trip_button"),
            ) { Text("حفظ وتفعيل") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } },
        containerColor = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(22.dp),
    )
}
