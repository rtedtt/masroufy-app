package com.example.ui.components

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Celebration
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Groups
import androidx.compose.material.icons.rounded.Payments
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.data.local.GameyaEntity
import com.example.data.local.WalletEntity
import com.example.domain.FinanceCalculator
import com.example.domain.Formatters
import com.example.ui.theme.LocalMasroufyColors
import java.time.YearMonth

@Composable
fun GameyaSection(
    gameyas: List<GameyaEntity>,
    wallets: List<WalletEntity>,
    reservedGameyaTotal: Double,
    isMasked: Boolean,
    onCreateClick: () -> Unit,
    onPayInstallment: (gameyaId: Long, walletId: Long) -> Unit,
    onReceivePayout: (gameyaId: Long, walletId: Long) -> Unit,
    onDeleteGameya: (Long) -> Unit,
) {
    val semantic = LocalMasroufyColors.current
    val walletMap = remember(wallets) { wallets.associateBy { it.id } }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 108.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            FintechCard(borderColor = semantic.amber.copy(alpha = 0.45f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "محجوز لأقساط الجمعيات هذا الشهر",
                            style = MaterialTheme.typography.labelLarge,
                            color = semantic.amber,
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = Formatters.formatEgp(reservedGameyaTotal, isMasked),
                            style = MaterialTheme.typography.headlineMedium,
                            fontWeight = FontWeight.Bold,
                        )
                        Text(
                            text = "يُخصم تلقائياً من الرصيد الحر لحماية التزامك",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    IconBadge(
                        icon = Icons.Rounded.Groups,
                        tint = semantic.amber,
                        contentDescription = "الجمعيات",
                        size = 48.dp,
                    )
                }
            }
        }

        if (gameyas.isEmpty()) {
            item {
                EmptyStateCard(
                    icon = Icons.Rounded.Groups,
                    title = "مفيش جمعيات مسجلة لسه",
                    subtitle = "ضيف أي جمعية داخل فيها وتابع الأقساط الشهرية وموعد القبض تلقائياً.",
                    actionText = "إضافة جمعية",
                    onAction = onCreateClick,
                )
            }
        } else {
            items(gameyas, key = { it.id }) { gameya ->
                val totalPayout = gameya.monthlyInstallment * gameya.totalMembers
                val currentMonthIndex = FinanceCalculator.computeGameyaCurrentMonthIndex(gameya)
                val isCyclePaid = FinanceCalculator.isGameyaCurrentCyclePaid(gameya)
                val payoutReady = FinanceCalculator.isGameyaPayoutReady(gameya)
                val progress = if (gameya.totalMembers > 0) {
                    (gameya.paidMonthsCount.toFloat() / gameya.totalMembers.toFloat()).coerceIn(0f, 1f)
                } else 0f
                val walletName = walletMap[gameya.walletId]?.name ?: wallets.firstOrNull()?.name ?: "كاش"
                val targetWalletId = walletMap[gameya.walletId]?.id ?: wallets.firstOrNull()?.id ?: 0L

                FintechCard(
                    borderColor = when {
                        payoutReady -> semantic.emerald
                        !isCyclePaid && gameya.isActive -> semantic.amber.copy(alpha = 0.55f)
                        else -> semantic.cardBorder
                    },
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = gameya.title,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                            )
                            Text(
                                text = "القسط: ${Formatters.formatEgp(gameya.monthlyInstallment, isMasked)} • القبض: ${Formatters.formatEgp(totalPayout, isMasked)}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                        IconButton(onClick = { onDeleteGameya(gameya.id) }) {
                            Icon(
                                imageVector = Icons.Rounded.DeleteOutline,
                                contentDescription = "حذف الجمعية",
                                tint = semantic.coral,
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                        Text(
                            text = "دور القبض: الشهر ${gameya.payoutTurnMonth} من ${gameya.totalMembers}",
                            style = MaterialTheme.typography.labelMedium,
                            color = semantic.sky,
                        )
                        Text(
                            text = "المدفوع: ${gameya.paidMonthsCount} / ${gameya.totalMembers}",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.SemiBold,
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    LinearProgressIndicator(
                        progress = { progress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(4.dp)),
                        color = if (gameya.isPayoutReceived) semantic.emerald else semantic.amber,
                        trackColor = MaterialTheme.colorScheme.surfaceVariant,
                        strokeCap = StrokeCap.Round,
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(
                            text = "المحفظة: $walletName • البداية: ${gameya.startYearMonth}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        if (gameya.isPayoutReceived) {
                            Text(
                                text = "تم القبض 🎉",
                                style = MaterialTheme.typography.labelMedium,
                                color = semantic.emerald,
                                fontWeight = FontWeight.Bold,
                            )
                        } else if (isCyclePaid) {
                            Text(
                                text = "مدفوع هذا الشهر ✅",
                                style = MaterialTheme.typography.labelMedium,
                                color = semantic.emerald,
                            )
                        } else if (currentMonthIndex > 0) {
                            Text(
                                text = "الشهر الحالي #$currentMonthIndex",
                                style = MaterialTheme.typography.labelSmall,
                                color = semantic.amber,
                            )
                        }
                    }

                    if (targetWalletId != 0L && (payoutReady || (gameya.paidMonthsCount < gameya.totalMembers && !isCyclePaid))) {
                        Spacer(modifier = Modifier.height(12.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            if (gameya.paidMonthsCount < gameya.totalMembers && !isCyclePaid) {
                                OutlinedButton(
                                    onClick = { onPayInstallment(gameya.id, targetWalletId) },
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("pay_gameya_btn_${gameya.id}"),
                                    shape = RoundedCornerShape(12.dp),
                                ) {
                                    Icon(Icons.Rounded.Payments, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("دفع قسط الشهر")
                                }
                            }
                            if (payoutReady) {
                                Button(
                                    onClick = { onReceivePayout(gameya.id, targetWalletId) },
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("receive_gameya_btn_${gameya.id}"),
                                    shape = RoundedCornerShape(12.dp),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = semantic.emerald,
                                        contentColor = Color.White,
                                    ),
                                ) {
                                    Icon(Icons.Rounded.Celebration, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("استلام قبض الجمعية 🎉")
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CreateGameyaDialog(
    wallets: List<WalletEntity>,
    onSave: (title: String, monthlyInstallment: Double, totalMembers: Int, payoutTurnMonth: Int, startYearMonth: String, walletId: Long) -> Unit,
    onDismiss: () -> Unit,
) {
    BackHandler(enabled = true) { onDismiss() }
    val semantic = LocalMasroufyColors.current
    var title by remember { mutableStateOf("") }
    var installmentText by remember { mutableStateOf("") }
    var membersText by remember { mutableStateOf("10") }
    var turnMonthText by remember { mutableStateOf("3") }
    var monthOffset by remember { mutableIntStateOf(0) }
    var selectedWalletId by remember(wallets) { mutableStateOf(wallets.firstOrNull()?.id ?: 0L) }
    var errorText by remember { mutableStateOf<String?>(null) }

    val startYm = remember(monthOffset) { YearMonth.now().plusMonths(monthOffset.toLong()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(22.dp),
        title = { Text("جمعية جديدة", style = MaterialTheme.typography.titleLarge) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it; errorText = null },
                    label = { Text("اسم الجمعية (مثال: جمعية الشغل)") },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = installmentText,
                    onValueChange = { installmentText = it; errorText = null },
                    label = { Text("قيمة القسط الشهري (ج.م)") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth(),
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = membersText,
                        onValueChange = { membersText = it; errorText = null },
                        label = { Text("عدد الأفراد") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.weight(1f),
                    )
                    OutlinedTextField(
                        value = turnMonthText,
                        onValueChange = { turnMonthText = it; errorText = null },
                        label = { Text("ترتيب شهر القبض") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.weight(1f),
                    )
                }

                // Start month quick toggle
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        text = "بداية الجمعية: $startYm",
                        style = MaterialTheme.typography.labelLarge,
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedButton(
                            onClick = { monthOffset-- },
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                            shape = RoundedCornerShape(10.dp),
                        ) { Text("-") }
                        OutlinedButton(
                            onClick = { monthOffset++ },
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                            shape = RoundedCornerShape(10.dp),
                        ) { Text("+") }
                    }
                }

                Text("المحفظة المرتبطة:", style = MaterialTheme.typography.labelMedium)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    wallets.forEach { w ->
                        val selected = selectedWalletId == w.id
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = if (selected) semantic.emerald.copy(alpha = 0.2f) else MaterialTheme.colorScheme.surfaceVariant,
                            border = BorderStroke(1.dp, if (selected) semantic.emerald else semantic.cardBorder),
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .clickable { selectedWalletId = w.id },
                        ) {
                            Text(
                                text = w.name,
                                style = MaterialTheme.typography.labelMedium,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp),
                            )
                        }
                    }
                }

                if (errorText != null) {
                    Text(
                        text = errorText.orEmpty(),
                        style = MaterialTheme.typography.bodySmall,
                        color = semantic.coral,
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val installment = Formatters.parseSafeDouble(installmentText) ?: 0.0
                    val members = Formatters.normalizeArabicDigits(membersText).toIntOrNull() ?: 0
                    val turn = Formatters.normalizeArabicDigits(turnMonthText).toIntOrNull() ?: 0
                    if (title.isBlank() || installment <= 0.0) {
                        errorText = "أدخل اسم الجمعية وقيمة القسط بشكل صحيح"
                        return@Button
                    }
                    if (members < 2 || turn !in 1..members) {
                        errorText = "تأكد أن عدد الأفراد >= 2 وترتيب القبض بين 1 و $members"
                        return@Button
                    }
                    if (selectedWalletId == 0L) {
                        errorText = "اختر المحفظة أولاً"
                        return@Button
                    }
                    onSave(title, installment, members, turn, startYm.toString(), selectedWalletId)
                    onDismiss()
                },
            ) {
                Text("حفظ")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("إلغاء") }
        },
    )
}
