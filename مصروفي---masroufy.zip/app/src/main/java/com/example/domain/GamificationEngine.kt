package com.example.domain

enum class MasroufyThemePack(
    val id: String,
    val arabicName: String,
    val description: String,
    val unlockLevel: Int,
    val backgroundHex: Long,
    val surfaceHex: Long,
    val surfaceVariantHex: Long,
    val cardBorderHex: Long,
    val primaryHex: Long,
    val secondaryHex: Long,
    val tertiaryHex: Long,
    val onPrimaryDarkHex: Long = 0xFF041C15,
) {
    EMERALD_CLASSIC(
        id = "EMERALD_CLASSIC",
        arabicName = "الزمرد الكلاسيكي",
        description = "الهوية الأساسية الهادئة بألوان الزمرد والأردواز",
        unlockLevel = 1,
        backgroundHex = 0xFF0F172A,
        surfaceHex = 0xFF1E293B,
        surfaceVariantHex = 0xFF273449,
        cardBorderHex = 0xFF334155,
        primaryHex = 0xFF10B981,
        secondaryHex = 0xFFF59E0B,
        tertiaryHex = 0xFF38BDF8,
        onPrimaryDarkHex = 0xFF022C22,
    ),
    ROYAL_GOLD(
        id = "ROYAL_GOLD",
        arabicName = "الذهب الملكي",
        description = "طابع فخم بالأسود الليلي والذهب الدافئ",
        unlockLevel = 2,
        backgroundHex = 0xFF09090B,
        surfaceHex = 0xFF18181B,
        surfaceVariantHex = 0xFF27272A,
        cardBorderHex = 0xFF3F3F46,
        primaryHex = 0xFFF59E0B,
        secondaryHex = 0xFFD97706,
        tertiaryHex = 0xFFFBBF24,
        onPrimaryDarkHex = 0xFF271400,
    ),
    CYBER_CYAN(
        id = "CYBER_CYAN",
        arabicName = "السايبر الفيروزي",
        description = "تباين رقمي عصري بالفيروزي والبنفسجي",
        unlockLevel = 3,
        backgroundHex = 0xFF020617,
        surfaceHex = 0xFF0F172A,
        surfaceVariantHex = 0xFF1E293B,
        cardBorderHex = 0xFF1E3A5F,
        primaryHex = 0xFF06B6D4,
        secondaryHex = 0xFF8B5CF6,
        tertiaryHex = 0xFF22D3EE,
        onPrimaryDarkHex = 0xFF042029,
    ),
    FIERY_RUBY(
        id = "FIERY_RUBY",
        arabicName = "الياقوت الناري",
        description = "ألوان جريئة بطاقة الياقوت الأحمر والذهبي",
        unlockLevel = 4,
        backgroundHex = 0xFF18181B,
        surfaceHex = 0xFF27272A,
        surfaceVariantHex = 0xFF3F3F46,
        cardBorderHex = 0xFF52525B,
        primaryHex = 0xFFF43F5E,
        secondaryHex = 0xFFFBBF24,
        tertiaryHex = 0xFFFB7185,
        onPrimaryDarkHex = 0xFFFFFFFF,
    ),
    ROYAL_PLATINUM(
        id = "ROYAL_PLATINUM",
        arabicName = "البلاتين الملكي",
        description = "قمة النخبة بلمسة بلاتينية وزمرد متألق",
        unlockLevel = 5,
        backgroundHex = 0xFF0A0F1C,
        surfaceHex = 0xFF162033,
        surfaceVariantHex = 0xFF22304A,
        cardBorderHex = 0xFF334155,
        primaryHex = 0xFFE2E8F0,
        secondaryHex = 0xFF34D399,
        tertiaryHex = 0xFF94A3B8,
        onPrimaryDarkHex = 0xFF0A0F1C,
    );

    companion object {
        fun fromId(id: String): MasroufyThemePack =
            entries.firstOrNull { it.id == id } ?: EMERALD_CLASSIC
    }
}

object XpAwards {
    const val TRANSACTION = 10
    const val ZERO_SPEND_DAY = 50
    const val GOAL_DEPOSIT = 30
    const val GOAL_COMPLETED = 200
    const val GAMEYA_OR_DEBT = 25
}

data class ArabicRank(
    val level: Int,
    val title: String,
    val minXp: Int,
    val badgeEmoji: String,
)

data class GamificationSnapshot(
    val xp: Int,
    val rank: ArabicRank,
    val nextRank: ArabicRank?,
    val xpIntoCurrentLevel: Int,
    val xpNeededForNextLevel: Int,
    val progressToNextLevel: Float,
    val activeThemePack: MasroufyThemePack,
)

object GamificationEngine {

    val ranks: List<ArabicRank> = listOf(
        ArabicRank(level = 1, title = "المستوى 1: مبتدئ التوفير 🌱", minXp = 0, badgeEmoji = "🌱"),
        ArabicRank(level = 2, title = "المستوى 2: مدير المصروف 💼", minXp = 200, badgeEmoji = "💼"),
        ArabicRank(level = 3, title = "المستوى 3: صياد الفكة 🎯", minXp = 600, badgeEmoji = "🎯"),
        ArabicRank(level = 4, title = "المستوى 4: خبير مالي 🧠", minXp = 1500, badgeEmoji = "🧠"),
        ArabicRank(level = 5, title = "المستوى 5: أسطورة التوفير 👑", minXp = 3000, badgeEmoji = "👑"),
    )

    fun rankForXp(xp: Int): ArabicRank {
        val safeXp = xp.coerceAtLeast(0)
        return ranks.lastOrNull { safeXp >= it.minXp } ?: ranks.first()
    }

    fun computeSnapshot(xp: Int, selectedThemeId: String): GamificationSnapshot {
        val safeXp = xp.coerceAtLeast(0)
        val currentRank = rankForXp(safeXp)
        val nextRank = ranks.firstOrNull { it.level == currentRank.level + 1 }

        val xpIntoLevel = (safeXp - currentRank.minXp).coerceAtLeast(0)
        val span = if (nextRank != null) (nextRank.minXp - currentRank.minXp).coerceAtLeast(1) else 1
        val progress = if (nextRank != null) (xpIntoLevel.toFloat() / span.toFloat()).coerceIn(0f, 1f) else 1f

        val requestedPack = MasroufyThemePack.fromId(selectedThemeId)
        val effectivePack = if (currentRank.level >= requestedPack.unlockLevel) {
            requestedPack
        } else {
            MasroufyThemePack.EMERALD_CLASSIC
        }

        return GamificationSnapshot(
            xp = safeXp,
            rank = currentRank,
            nextRank = nextRank,
            xpIntoCurrentLevel = xpIntoLevel,
            xpNeededForNextLevel = if (nextRank != null) (nextRank.minXp - safeXp).coerceAtLeast(0) else 0,
            progressToNextLevel = progress,
            activeThemePack = effectivePack,
        )
    }

    fun detectLevelUp(oldXp: Int, newXp: Int): ArabicRank? {
        val oldRank = rankForXp(oldXp)
        val newRank = rankForXp(newXp)
        return if (newRank.level > oldRank.level) newRank else null
    }
}
