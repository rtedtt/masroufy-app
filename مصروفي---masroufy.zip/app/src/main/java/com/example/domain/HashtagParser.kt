package com.example.domain

import com.example.data.local.TransactionEntity
import com.example.data.local.TransactionType

data class TagSpendSummary(
    val tag: String,
    val totalExpense: Double,
    val totalIncome: Double,
    val count: Int,
)

object HashtagParser {

    private val hashtagRegex = Regex("""#([\p{L}\p{N}_]+)""")

    fun extractTags(note: String): List<String> {
        if (note.isBlank()) return emptyList()
        return hashtagRegex.findAll(note)
            .map { "#${it.groupValues[1]}" }
            .distinct()
            .toList()
    }

    fun matchesTag(note: String, tagWithHash: String): Boolean {
        val target = tagWithHash.trim().removePrefix("#")
        if (target.isEmpty()) return false
        return extractTags(note).any { it.removePrefix("#").equals(target, ignoreCase = true) }
    }

    fun summarizeTagSpend(transactions: List<TransactionEntity>): List<TagSpendSummary> {
        val map = linkedMapOf<String, MutableList<TransactionEntity>>()
        transactions.forEach { tx ->
            val tags = extractTags(tx.note)
            tags.forEach { tag ->
                map.getOrPut(tag) { mutableListOf() }.add(tx)
            }
        }
        return map.entries.map { (tag, txs) ->
            val expense = txs.filter { it.type == TransactionType.EXPENSE }
                .sumOf { if (it.amount.isFinite()) it.amount.coerceAtLeast(0.0) else 0.0 }
            val income = txs.filter { it.type == TransactionType.INCOME }
                .sumOf { if (it.amount.isFinite()) it.amount.coerceAtLeast(0.0) else 0.0 }
            TagSpendSummary(
                tag = tag,
                totalExpense = expense,
                totalIncome = income,
                count = txs.size,
            )
        }.sortedWith(compareByDescending<TagSpendSummary> { it.totalExpense }.thenByDescending { it.count })
    }
}
