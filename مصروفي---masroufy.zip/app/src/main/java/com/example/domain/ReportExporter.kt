package com.example.domain

import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import androidx.core.content.FileProvider
import com.example.data.local.CategoryEntity
import com.example.data.local.TransactionEntity
import com.example.data.local.TransactionType
import com.example.data.local.WalletEntity
import java.io.File
import java.io.OutputStream
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

object ReportExporter {

    private val dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm", Locale.US)

    fun buildCsvContent(
        transactions: List<TransactionEntity>,
        wallets: List<WalletEntity>,
        categories: List<CategoryEntity>,
    ): String {
        val walletMap = wallets.associateBy { it.id }
        val categoryMap = categories.associateBy { it.id }
        val zone = ZoneId.systemDefault()

        val sb = StringBuilder()
        // UTF-8 BOM so Microsoft Excel renders Arabic cleanly
        sb.append('\uFEFF')
        sb.appendLine("التاريخ,النوع,التصنيف,المحفظة,إلى محفظة,المبلغ (ج.م),ملاحظة")

        transactions.forEach { tx ->
            val dateStr = Instant.ofEpochMilli(tx.timestamp).atZone(zone).format(dateTimeFormatter)
            val typeStr = when (tx.type) {
                TransactionType.EXPENSE -> "مصروف"
                TransactionType.INCOME -> "دخل"
                TransactionType.TRANSFER -> "تحويل"
                else -> tx.type
            }
            val catStr = tx.categoryId?.let { categoryMap[it]?.name } ?: "-"
            val walletStr = walletMap[tx.walletId]?.name ?: "-"
            val toWalletStr = tx.toWalletId?.let { walletMap[it]?.name } ?: "-"
            val noteEscaped = "\"${tx.note.replace("\"", "\"\"")}\""
            sb.appendLine("$dateStr,$typeStr,$catStr,$walletStr,$toWalletStr,${tx.amount},$noteEscaped")
        }
        return sb.toString()
    }

    fun writePdfReport(
        outputStream: OutputStream,
        transactions: List<TransactionEntity>,
        wallets: List<WalletEntity>,
        categories: List<CategoryEntity>,
        budgetSnapshot: BudgetSnapshot,
    ) {
        val document = PdfDocument()
        val pageWidth = 595
        val pageHeight = 842
        val walletMap = wallets.associateBy { it.id }
        val categoryMap = categories.associateBy { it.id }
        val zone = ZoneId.systemDefault()

        val titlePaint = Paint().apply {
            color = Color.rgb(15, 23, 42)
            textSize = 20f
            isFakeBoldText = true
            isAntiAlias = true
        }
        val headerPaint = Paint().apply {
            color = Color.rgb(16, 185, 129)
            textSize = 14f
            isFakeBoldText = true
            isAntiAlias = true
        }
        val bodyPaint = Paint().apply {
            color = Color.rgb(30, 41, 59)
            textSize = 11f
            isAntiAlias = true
        }
        val mutedPaint = Paint().apply {
            color = Color.rgb(100, 116, 139)
            textSize = 10f
            isAntiAlias = true
        }

        var pageNumber = 1
        var page = document.startPage(PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create())
        var canvas: Canvas = page.canvas
        var y = 48f

        canvas.drawText("Masroufy (مصروفي) - Financial Report", 40f, y, titlePaint)
        y += 22f
        canvas.drawText("Generated: ${LocalDate.now()}", 40f, y, mutedPaint)
        y += 26f

        canvas.drawText("Summary", 40f, y, headerPaint)
        y += 18f
        canvas.drawText("Total Liquidity: ${Formatters.formatCompactNumber(budgetSnapshot.totalLiquidity)} EGP", 40f, y, bodyPaint)
        y += 16f
        canvas.drawText("Free Spendable: ${Formatters.formatCompactNumber(budgetSnapshot.freeBalance)} EGP   |   Reserved: ${Formatters.formatCompactNumber(budgetSnapshot.reservedTotal)} EGP", 40f, y, bodyPaint)
        y += 16f
        canvas.drawText("Daily Safe Limit: ${Formatters.formatCompactNumber(budgetSnapshot.dailySafeLimit)} EGP   |   Cycle Remaining Days: ${budgetSnapshot.remainingDaysInCycle}", 40f, y, bodyPaint)
        y += 24f

        canvas.drawText("Wallets", 40f, y, headerPaint)
        y += 18f
        wallets.forEach { w ->
            canvas.drawText("- ${w.name}: ${Formatters.formatCompactNumber(w.balance)} EGP", 48f, y, bodyPaint)
            y += 15f
        }
        y += 16f

        canvas.drawText("Recent Transactions (${transactions.size})", 40f, y, headerPaint)
        y += 18f

        transactions.take(150).forEach { tx ->
            if (y > pageHeight - 48) {
                document.finishPage(page)
                pageNumber++
                page = document.startPage(PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create())
                canvas = page.canvas
                y = 48f
            }
            val dateStr = Instant.ofEpochMilli(tx.timestamp).atZone(zone).format(dateTimeFormatter)
            val catStr = tx.categoryId?.let { categoryMap[it]?.name } ?: "Transfer"
            val wStr = walletMap[tx.walletId]?.name ?: ""
            val sign = when (tx.type) {
                TransactionType.EXPENSE -> "-"
                TransactionType.INCOME -> "+"
                else -> "<->"
            }
            val line = "$dateStr  |  $sign${Formatters.formatCompactNumber(tx.amount)} EGP  |  $catStr  |  $wStr  |  ${tx.note.take(28)}"
            canvas.drawText(line, 40f, y, bodyPaint)
            y += 15f
        }

        document.finishPage(page)
        document.writeTo(outputStream)
        document.close()
    }

    fun shareTempFile(
        context: Context,
        fileName: String,
        mimeType: String,
        writer: (OutputStream) -> Unit,
    ) {
        val dir = File(context.cacheDir, "reports").apply { mkdirs() }
        val outFile = File(dir, fileName)
        outFile.outputStream().use(writer)
        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            outFile,
        )
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = mimeType
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, "مشاركة التقرير المالي"))
    }
}
