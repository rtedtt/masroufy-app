package com.example.domain

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream

object AchievementShareHelper {

    fun renderAchievementBitmap(
        gamification: GamificationSnapshot,
        zeroSpendStreak: Int,
        savingsRatePercent: Int,
        healthScore: Int,
    ): Bitmap {
        val width = 1080
        val height = 1350
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        // Deep Slate -> Emerald Dark gradient background
        val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = LinearGradient(
                0f,
                0f,
                width.toFloat(),
                height.toFloat(),
                intArrayOf(0xFF0F172A.toInt(), 0xFF0B2B26.toInt(), 0xFF0F172A.toInt()),
                floatArrayOf(0f, 0.55f, 1f),
                Shader.TileMode.CLAMP,
            )
        }
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bgPaint)

        // Subtle decorative glow circles
        val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0x1F10B981
        }
        canvas.drawCircle(width * 0.85f, height * 0.14f, 260f, glowPaint)
        glowPaint.color = 0x1AF59E0B
        canvas.drawCircle(width * 0.15f, height * 0.82f, 240f, glowPaint)

        // Outer Card Frame
        val cardRect = RectF(64f, 84f, width - 64f, height - 84f)
        val cardFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xE61E293B.toInt() }
        val cardStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 4f
            color = 0xFF10B981.toInt()
        }
        canvas.drawRoundRect(cardRect, 48f, 48f, cardFill)
        canvas.drawRoundRect(cardRect, 48f, 48f, cardStroke)

        // Brand Header
        val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0xFFF8FAFC.toInt()
            textAlign = Paint.Align.CENTER
            textSize = 54f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val subtitlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0xFF10B981.toInt()
            textAlign = Paint.Align.CENTER
            textSize = 32f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        canvas.drawText("بطاقة إنجاز مصروفي 🏆", width / 2f, 185f, titlePaint)
        canvas.drawText("ملخص خاص — بدون كشف أي أرصدة مالية", width / 2f, 240f, subtitlePaint)

        // Center Rank Medallion
        val medalCenterY = 430f
        val medalFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x26F59E0B }
        val medalBorder = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 5f
            color = 0xFFF59E0B.toInt()
        }
        canvas.drawCircle(width / 2f, medalCenterY, 125f, medalFill)
        canvas.drawCircle(width / 2f, medalCenterY, 125f, medalBorder)

        val emojiPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textAlign = Paint.Align.CENTER
            textSize = 110f
        }
        canvas.drawText(gamification.rank.badgeEmoji, width / 2f, medalCenterY + 36f, emojiPaint)

        val rankPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0xFFFBBF24.toInt()
            textAlign = Paint.Align.CENTER
            textSize = 44f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        canvas.drawText(gamification.rank.title, width / 2f, 625f, rankPaint)

        val xpPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0xFFCBD5E1.toInt()
            textAlign = Paint.Align.CENTER
            textSize = 34f
        }
        canvas.drawText("${gamification.xp} XP • سمة ${gamification.activeThemePack.arabicName}", width / 2f, 680f, xpPaint)

        // 3 Privacy-Safe Achievement Metric Boxes
        drawMetricRow(
            canvas = canvas,
            top = 740f,
            label = "سلسلة أيام بدون صرف",
            value = "$zeroSpendStreak يوم 🔥",
            accentColor = 0xFF10B981.toInt(),
            width = width,
        )
        drawMetricRow(
            canvas = canvas,
            top = 890f,
            label = "نسبة الادخار للدورة",
            value = "${savingsRatePercent.coerceIn(0, 100)}%",
            accentColor = 0xFF38BDF8.toInt(),
            width = width,
        )
        drawMetricRow(
            canvas = canvas,
            top = 1040f,
            label = "مؤشر الصحة المالية",
            value = "${healthScore.coerceIn(0, 100)} / 100 💯",
            accentColor = 0xFFF59E0B.toInt(),
            width = width,
        )

        // Bottom Brand Signature
        val footerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0xFF94A3B8.toInt()
            textAlign = Paint.Align.CENTER
            textSize = 28f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        canvas.drawText("تطبيق مصروفي • تطوير: بلال محمد سليمان", width / 2f, height - 135f, footerPaint)

        return bitmap
    }

    private fun drawMetricRow(
        canvas: Canvas,
        top: Float,
        label: String,
        value: String,
        accentColor: Int,
        width: Int,
    ) {
        val rect = RectF(110f, top, width - 110f, top + 122f)
        val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF0F172A.toInt() }
        val border = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 2.5f
            color = 0xFF334155.toInt()
        }
        canvas.drawRoundRect(rect, 28f, 28f, fill)
        canvas.drawRoundRect(rect, 28f, 28f, border)

        val valuePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = accentColor
            textAlign = Paint.Align.LEFT
            textSize = 40f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0xFFE2E8F0.toInt()
            textAlign = Paint.Align.RIGHT
            textSize = 34f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        canvas.drawText(value, 148f, top + 74f, valuePaint)
        canvas.drawText(label, width - 148f, top + 74f, labelPaint)
    }

    fun shareAchievementCard(
        context: Context,
        gamification: GamificationSnapshot,
        zeroSpendStreak: Int,
        savingsRatePercent: Int,
        healthScore: Int,
    ): Result<Unit> = runCatching {
        val bitmap = renderAchievementBitmap(
            gamification = gamification,
            zeroSpendStreak = zeroSpendStreak,
            savingsRatePercent = savingsRatePercent,
            healthScore = healthScore,
        )
        val dir = File(context.cacheDir, "achievements").apply { mkdirs() }
        val file = File(dir, "masroufy_achievement.png")
        FileOutputStream(file).use { out ->
            bitmap.compress(Bitmap.CompressFormat.PNG, 95, out)
        }
        bitmap.recycle()

        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file,
        )
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "image/png"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(
                Intent.EXTRA_TEXT,
                "وصلت إلى ${gamification.rank.title} (${gamification.xp} XP) في تطبيق مصروفي! 🏆",
            )
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        val chooser = Intent.createChooser(intent, "مشاركة إنجازي عبر")
        chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(chooser)
    }
}
