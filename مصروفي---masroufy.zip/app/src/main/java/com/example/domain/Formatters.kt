package com.example.domain

import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.abs

object Formatters {
    private val symbols = DecimalFormatSymbols(Locale.US).apply {
        groupingSeparator = ','
        decimalSeparator = '.'
    }

    private val wholeFormatter = DecimalFormat("#,##0", symbols)
    private val decimalFormatter = DecimalFormat("#,##0.##", symbols)

    private val arabicLocale = Locale("ar", "EG")
    private val dateFormatter = DateTimeFormatter.ofPattern("d MMM yyyy", arabicLocale)
    private val shortDateFormatter = DateTimeFormatter.ofPattern("d MMM", arabicLocale)
    private val timeFormatter = DateTimeFormatter.ofPattern("hh:mm a", arabicLocale)

    // Unicode Left-to-Right Isolate so "+ 150 ج.م" and "- 50 ج.م" never flip signs in RTL UI
    private const val LRI = "\u2066"
    private const val PDI = "\u2069"

    fun formatEgp(
        amount: Double,
        showPositiveSign: Boolean = false,
        isMasked: Boolean = false,
    ): String {
        if (isMasked) return "${LRI}****${PDI} ج.م"
        val safeAmount = if (amount.isNaN() || amount.isInfinite()) 0.0 else amount
        val absVal = abs(safeAmount)
        val isWhole = absVal % 1.0 < 0.005
        val formattedNumber = if (isWhole) {
            wholeFormatter.format(absVal)
        } else {
            decimalFormatter.format(absVal)
        }
        val sign = when {
            safeAmount < -0.005 -> "- "
            showPositiveSign && safeAmount > 0.005 -> "+ "
            else -> ""
        }
        return "$LRI$sign$formattedNumber$PDI ج.م"
    }

    fun formatCompactNumber(amount: Double, isMasked: Boolean = false): String {
        if (isMasked) return "****"
        val safeAmount = if (amount.isNaN() || amount.isInfinite()) 0.0 else amount
        val absVal = abs(safeAmount)
        val isWhole = absVal % 1.0 < 0.005
        return if (isWhole) wholeFormatter.format(safeAmount) else decimalFormatter.format(safeAmount)
    }

    fun formatRelativeDateTime(timestampMillis: Long): String {
        val zone = ZoneId.systemDefault()
        val zoned = Instant.ofEpochMilli(timestampMillis).atZone(zone)
        val date = zoned.toLocalDate()
        val today = LocalDate.now(zone)
        val datePart = when (date) {
            today -> "النهارده"
            today.minusDays(1) -> "إمبارح"
            else -> date.format(dateFormatter)
        }
        return "$datePart • ${zoned.format(timeFormatter)}"
    }

    fun formatDayHeader(date: LocalDate): String {
        val today = LocalDate.now()
        return when (date) {
            today -> "النهاردة"
            today.minusDays(1) -> "إمبارح"
            else -> date.format(dateFormatter)
        }
    }

    fun formatDateOnly(timestampMillis: Long): String {
        val zone = ZoneId.systemDefault()
        val date = Instant.ofEpochMilli(timestampMillis).atZone(zone).toLocalDate()
        return date.format(dateFormatter)
    }

    fun formatShortDate(date: LocalDate): String {
        return date.format(shortDateFormatter)
    }

    /**
     * Converts Arabic/Eastern digits (٠١٢٣٤٥٦٧٨٩ / ۰۱۲۳۴۵۶۷۸۹) to Western digits
     * and normalizes Arabic decimal/comma separators.
     */
    fun normalizeArabicDigits(input: String): String {
        val builder = StringBuilder(input.length)
        for (ch in input) {
            when (ch) {
                in '٠'..'٩' -> builder.append(('0'.code + (ch.code - '٠'.code)).toChar())
                in '۰'..'۹' -> builder.append(('0'.code + (ch.code - '۰'.code)).toChar())
                '٫' -> builder.append('.')
                '،' -> builder.append('.')
                else -> builder.append(ch)
            }
        }
        return builder.toString()
    }

    /**
     * Normalizes numeric/expression strings for safe parsing:
     * - Converts Arabic digits and '٫'/'،' to '.'
     * - Replaces ',' decimal commas (when no '.' exists and not a 3-digit thousands group, or single comma) with '.'
     *   and strips thousands grouping commas when '.' is present.
     */
    fun normalizeNumberString(input: String): String {
        val normalized = normalizeArabicDigits(input).trim()
        if (normalized.isEmpty()) return ""
        return if (normalized.contains('.')) {
            normalized.replace(",", "")
        } else if (normalized.contains(',')) {
            // If used as thousands grouping like 1,200, strip; if 12,5 or 50,25 convert to decimal dot
            val parts = normalized.split(',')
            if (parts.size == 2 && parts[1].length in 1..2 && parts[1].all { it.isDigit() }) {
                "${parts[0]}.${parts[1]}"
            } else {
                normalized.replace(",", "")
            }
        } else {
            normalized
        }
    }

    fun parseSafeDouble(input: String): Double? {
        val cleaned = normalizeNumberString(input)
        return cleaned.toDoubleOrNull()?.takeIf { !it.isNaN() && !it.isInfinite() }
    }
}
