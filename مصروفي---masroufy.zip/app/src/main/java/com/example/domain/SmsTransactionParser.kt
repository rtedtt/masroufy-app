package com.example.domain

import com.example.data.local.CategoryEntity
import com.example.data.local.TransactionType
import com.example.data.local.WalletEntity
import com.example.data.local.WalletType
import java.util.Locale

data class ParsedSmsResult(
    val amount: Double?,
    val transactionType: String,
    val suggestedWalletId: Long?,
    val suggestedCategoryId: Long?,
    val extractedNote: String,
    val detectedSourceLabel: String?,
)

object SmsTransactionParser {

    // Match numbers followed or preceded by currency markers (EGP, LE, جنيه, جم, ج.م) or general decimal amounts
    private val currencyAmountRegex = Regex(
        """(?i)(?:(?:egp|le|l\.e\.|جنيه|ج\.م|جم|بمبلغ|مبلغ|بقيمة|value|amount|of)\s*[:\-]?\s*)(\d{1,3}(?:,\d{3})*(?:\.\d{1,2})?|\d+(?:\.\d{1,2})?)|(\d{1,3}(?:,\d{3})*(?:\.\d{1,2})?|\d+(?:\.\d{1,2})?)\s*(?:egp|le|l\.e\.|جنيه|ج\.م|جم)""",
    )
    private val fallbackNumberRegex = Regex("""\b(\d{1,3}(?:,\d{3})*(?:\.\d{1,2})?|\d+(?:\.\d{1,2})?)\b""")

    private val incomeKeywords = listOf(
        "تم استلام", "استلمت", "استقبلت", "تم إضافة", "تم اضافة", "إيداع", "ايداع",
        "تحويل وارد", "رصيد مضاف", "received", "credited", "deposit", "added to",
        "incoming", "transferred to your", "cash in", "استرداد", "refund",
    )

    private val expenseKeywords = listOf(
        "تم خصم", "خصم", "تم دفع", "دفع", "شراء", "مشتريات", "سحب", "تم تحويل مبلغ",
        "تم التحويل", "فاتورة", "debited", "deducted", "purchased", "purchase",
        "payment", "paid", "withdrawn", "sent", "transfer of", "cash out", "pos",
    )

    private val bankOrInstaPayKeywords = listOf(
        "instapay", "إنستا باي", "انستا باي", "انستاباي", "بنك", "الأهلي", "الاهلي",
        "nbe", "cib", "qnb", "banque misr", "بنك مصر", "alexbank", "hsbc", "aaib",
        "visa", "mastercard", "فيزا", "ماستركارد", "بطاقة", "card", "حسابك", "atm",
    )

    private val mobileWalletKeywords = listOf(
        "vodafone cash", "فودافون كاش", "فودافون", "orange cash", "اورانج كاش",
        "etisalat cash", "اتصالات كاش", "we pay", "وي باي", "محفظة", "wallet",
        "instapay wallet", "bm wallet", "nbe phone cash", "فون كاش",
    )

    fun parse(
        rawText: String,
        wallets: List<WalletEntity>,
        categories: List<CategoryEntity>,
    ): ParsedSmsResult? {
        val normalized = Formatters.normalizeArabicDigits(rawText).trim()
        if (normalized.isBlank()) return null

        val lower = normalized.lowercase(Locale.ROOT)

        // 1. Extract amount (ignoring reference numbers / OTPs / 4-digit card suffixes when currency match exists)
        val currencyMatches = currencyAmountRegex.findAll(normalized).toList()
        val amount: Double? = if (currencyMatches.isNotEmpty()) {
            currencyMatches.firstNotNullOfOrNull { match ->
                val rawNum = match.groupValues[1].ifBlank { match.groupValues[2] }
                rawNum.replace(",", "").toDoubleOrNull()
            }
        } else {
            // Avoid picking card last-4 digits like ****1234 or dates
            val cleaned = normalized
                .replace(Regex("""\*{2,}\d{4}"""), " ")
                .replace(Regex("""\d{1,2}[/\-]\d{1,2}[/\-]\d{2,4}"""), " ")
                .replace(Regex("""\d{1,2}:\d{2}"""), " ")
            fallbackNumberRegex.findAll(cleaned)
                .mapNotNull { it.groupValues[1].replace(",", "").toDoubleOrNull() }
                .firstOrNull { it > 0.0 && it < 10_000_000.0 }
        }

        // 2. Detect transaction direction (Income vs Expense)
        val isIncome = incomeKeywords.any { lower.contains(it) }
        val isExpense = expenseKeywords.any { lower.contains(it) }
        val txType = when {
            isIncome && !isExpense -> TransactionType.INCOME
            isExpense -> TransactionType.EXPENSE
            isIncome -> TransactionType.INCOME
            else -> TransactionType.EXPENSE
        }

        // 3. Detect wallet
        val isMobileWallet = mobileWalletKeywords.any { lower.contains(it) }
        val isBank = bankOrInstaPayKeywords.any { lower.contains(it) }
        val (suggestedWallet, sourceLabel) = when {
            isMobileWallet -> {
                val w = wallets.firstOrNull { it.type == WalletType.MOBILE_WALLET }
                    ?: wallets.firstOrNull { it.name.contains("محفظة") }
                w to "محفظة إلكترونية"
            }
            isBank -> {
                val w = wallets.firstOrNull { it.type == WalletType.BANK }
                    ?: wallets.firstOrNull { it.name.contains("بنك") || it.name.contains("إنستا") }
                w to "بنك / إنستا باي"
            }
            else -> {
                wallets.firstOrNull { it.type == WalletType.CASH } to null
            }
        }

        // 4. Suggest category by merchant/keyword hints
        val targetCategories = categories.filter { it.type == txType }
        val suggestedCategory = findCategoryHint(lower, txType, targetCategories)

        // 5. Build clean short note
        val shortNote = buildNoteFromSms(normalized, sourceLabel)

        return ParsedSmsResult(
            amount = amount,
            transactionType = txType,
            suggestedWalletId = suggestedWallet?.id,
            suggestedCategoryId = suggestedCategory?.id,
            extractedNote = shortNote,
            detectedSourceLabel = sourceLabel,
        )
    }

    private fun findCategoryHint(
        lower: String,
        txType: String,
        categories: List<CategoryEntity>,
    ): CategoryEntity? {
        if (txType == TransactionType.INCOME) {
            return when {
                lower.contains("salary") || lower.contains("راتب") || lower.contains("مرتب") ->
                    categories.firstOrNull { it.name.contains("راتب") }
                else -> categories.firstOrNull()
            }
        }

        val hintName = when {
            lower.contains("uber") || lower.contains("careem") || lower.contains("indrive") ||
                lower.contains("swvl") || lower.contains("اوبر") || lower.contains("كريم") ||
                lower.contains("بنزين") || lower.contains("مواصلات") -> "مواصلات"

            lower.contains("talabat") || lower.contains("طلبات") || lower.contains("breadfast") ||
                lower.contains("carrefour") || lower.contains("كارفور") || lower.contains("مطعم") ||
                lower.contains("سوبرماركت") || lower.contains("food") || lower.contains("restaurant") -> "أكل وشرب"

            lower.contains("we ") || lower.contains("vodafone") || lower.contains("orange") ||
                lower.contains("etisalat") || lower.contains("باقة") || lower.contains("شحن") ||
                lower.contains("نت") || lower.contains("فاتورة") -> "باقة وإنترنت"

            lower.contains("pharmacy") || lower.contains("صيدلية") || lower.contains("مستشفى") ||
                lower.contains("دكتور") || lower.contains("عيادة") -> "صحة"

            lower.contains("cafe") || lower.contains("كافيه") || lower.contains("cinema") ||
                lower.contains("سينما") || lower.contains("starbucks") -> "خروجات"

            lower.contains("udemy") || lower.contains("coursera") || lower.contains("كورس") ||
                lower.contains("جامعة") || lower.contains("كتاب") -> "دراسة وكورسات"

            lower.contains("amazon") || lower.contains("noon") || lower.contains("نون") ||
                lower.contains("أمازون") || lower.contains("تسوق") || lower.contains("pos") -> "تسوق"

            else -> null
        }

        return if (hintName != null) {
            categories.firstOrNull { it.name.contains(hintName) } ?: categories.firstOrNull()
        } else {
            null
        }
    }

    private fun buildNoteFromSms(text: String, sourceLabel: String?): String {
        val singleLine = text.replace(Regex("""\s+"""), " ").trim()
        val snippet = if (singleLine.length > 55) singleLine.take(52) + "..." else singleLine
        return if (sourceLabel != null) "$sourceLabel: $snippet" else snippet
    }
}
