package com.example.domain

/**
 * Safe recursive-descent math expression evaluator supporting +, -, *, /, parentheses,
 * and Arabic/Eastern digits (e.g., "50+35+20", "100*2", "٥٠+٢٥").
 */
object MathExpressionEvaluator {

    fun containsOperator(raw: String): Boolean {
        val cleaned = Formatters.normalizeArabicDigits(raw).trim()
        if (cleaned.isEmpty()) return false
        val body = if (cleaned.startsWith("-") || cleaned.startsWith("+")) cleaned.drop(1) else cleaned
        return body.any { it == '+' || it == '-' || it == '*' || it == '/' || it == '×' || it == '÷' }
    }

    fun evaluate(raw: String): Double? {
        val normalized = Formatters.normalizeNumberString(raw)
            .replace("×", "*")
            .replace("÷", "/")
            .replace(" ", "")
        if (normalized.isBlank()) return null

        val parser = Parser(normalized)
        val result = parser.parseExpression() ?: return null
        if (!parser.isAtEnd()) return null
        if (result.isNaN() || result.isInfinite()) return null
        return result
    }

    private class Parser(private val expr: String) {
        private var pos = 0

        fun isAtEnd(): Boolean = pos >= expr.length

        fun parseExpression(): Double? {
            var left = parseTerm() ?: return null
            while (pos < expr.length) {
                when (expr[pos]) {
                    '+' -> {
                        pos++
                        val right = parseTerm() ?: return null
                        left += right
                    }
                    '-' -> {
                        pos++
                        val right = parseTerm() ?: return null
                        left -= right
                    }
                    else -> break
                }
            }
            return left
        }

        private fun parseTerm(): Double? {
            var left = parseFactor() ?: return null
            while (pos < expr.length) {
                when (expr[pos]) {
                    '*' -> {
                        pos++
                        val right = parseFactor() ?: return null
                        left *= right
                    }
                    '/' -> {
                        pos++
                        val right = parseFactor() ?: return null
                        if (right == 0.0) return null
                        left /= right
                    }
                    else -> break
                }
            }
            return left
        }

        private fun parseFactor(): Double? {
            if (pos >= expr.length) return null
            return when (expr[pos]) {
                '+' -> {
                    pos++
                    parseFactor()
                }
                '-' -> {
                    pos++
                    parseFactor()?.let { -it }
                }
                '(' -> {
                    pos++
                    val inside = parseExpression() ?: return null
                    if (pos >= expr.length || expr[pos] != ')') return null
                    pos++
                    inside
                }
                else -> parseNumber()
            }
        }

        private fun parseNumber(): Double? {
            val start = pos
            var hasDot = false
            while (pos < expr.length) {
                val c = expr[pos]
                if (c in '0'..'9') {
                    pos++
                } else if (c == '.' && !hasDot) {
                    hasDot = true
                    pos++
                } else {
                    break
                }
            }
            if (pos == start) return null
            return expr.substring(start, pos).toDoubleOrNull()
        }
    }
}
