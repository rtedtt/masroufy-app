package com.example.domain

import com.example.data.local.BillingCycle
import com.example.data.local.CategoryEntity
import com.example.data.local.DebtEntity
import com.example.data.local.DebtType
import com.example.data.local.EnvelopeEntity
import com.example.data.local.GameyaEntity
import com.example.data.local.InstallmentEntity
import com.example.data.local.RolloverMode
import com.example.data.local.SubscriptionEntity
import com.example.data.local.TransactionEntity
import com.example.data.local.TransactionType
import com.example.data.local.TripEventEntity
import com.example.data.local.WalletEntity
import com.example.data.local.ZeroSpendDayEntity
import java.time.Instant
import java.time.LocalDate
import java.time.YearMonth
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit
import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToInt

enum class AnalyticsTimeframe(val label: String) {
    WEEK("هذا الأسبوع"),
    MONTH("هذا الشهر"),
    ALL("الكل"),
}

enum class SafeSpendStatus {
    SAFE,
    CAUTION,
    DANGER,
}

enum class HeatmapIntensity {
    NONE,
    ZERO_SPEND,
    LOW,
    MEDIUM,
    HIGH,
}

data class DailyBarPoint(
    val date: LocalDate,
    val label: String,
    val amount: Double,
)

data class MonthlyComparisonPoint(
    val month: YearMonth,
    val label: String,
    val income: Double,
    val expense: Double,
)

data class HeatmapDayCell(
    val date: LocalDate,
    val dayOfMonth: Int,
    val amount: Double,
    val txCount: Int,
    val intensity: HeatmapIntensity,
)

data class SmallLeaksSummary(
    val count: Int,
    val totalAmount: Double,
    val topCategoryName: String?,
    val threshold: Double = 50.0,
)

data class CategoryBudgetProgress(
    val category: CategoryEntity,
    val spent: Double,
    val budget: Double,
    val ratio: Float,
)

data class CategorySlice(
    val categoryId: Long?,
    val name: String,
    val colorHex: Long,
    val amount: Double,
    val percentage: Float,
)

data class TripSnapshot(
    val trip: TripEventEntity,
    val spent: Double,
    val remaining: Double,
    val ratio: Float,
)

data class ZeroBasedBudgetSummary(
    val monthlyIncome: Double,
    val envelopesTotal: Double,
    val categoryBudgetsTotal: Double,
    val savingsAssigned: Double,
    val commitmentsTotal: Double,
    val totalAllocated: Double,
    val unallocatedBalance: Double,
)

data class InflationSpikeAlert(
    val categoryId: Long?,
    val categoryName: String,
    val currentMonthSpend: Double,
    val historicalMonthlyAvg: Double,
    val increasePercent: Int,
)

data class FinancialHealthScore(
    val score: Int,
    val label: String,
    val savingsComponent: Int,
    val dailyLimitComponent: Int,
    val streakComponent: Int,
    val debtComponent: Int,
    val tips: List<String>,
)

data class BudgetSnapshot(
    val totalLiquidity: Double,
    val reservedTotal: Double,
    val reservedEnvelopesTotal: Double = reservedTotal,
    val reservedGameyaTotal: Double = 0.0,
    val reservedInstallmentsTotal: Double = 0.0,
    val freeBalance: Double,
    val remainingDaysInCycle: Int,
    val cycleStartDate: LocalDate,
    val nextCycleDate: LocalDate,
    val todaySpent: Double,
    val dailySafeLimit: Double,
    val remainingToday: Double,
    val todaySpendRatio: Float,
    val safeSpendStatus: SafeSpendStatus,
    val zeroSpendStreak: Int,
    val isTodayZeroSpendConfirmed: Boolean,
    val estimatedMonthlySaved: Double,
    val projectedEndOfCycleBalance: Double,
    val currentCycleAvgDailySpend: Double,
    val lowBalanceWallets: List<WalletEntity>,
    val yesterdaySurplusBonus: Double = 0.0,
    val rolloverMode: String = RolloverMode.NONE,
    val activeTripSnapshot: TripSnapshot? = null,
)

data class SubscriptionsSummary(
    val activeCount: Int,
    val monthlyCommitment: Double,
    val annualizedTotal: Double,
    val dueWithin48HoursCount: Int,
)

data class AnalyticsSnapshot(
    val totalExpense: Double,
    val totalIncome: Double,
    val categorySlices: List<CategorySlice>,
    val dailyBars: List<DailyBarPoint>,
    val monthlyComparisons: List<MonthlyComparisonPoint>,
    val heatmapCells: List<HeatmapDayCell>,
    val smallLeaks: SmallLeaksSummary,
    val categoryBudgets: List<CategoryBudgetProgress>,
    val insights: List<String>,
)

object FinanceCalculator {

    private val arabicMonthFormatter = DateTimeFormatter.ofPattern("MMM", Locale("ar", "EG"))

    fun calculateBudgetSnapshot(
        wallets: List<WalletEntity>,
        envelopes: List<EnvelopeEntity>,
        transactions: List<TransactionEntity>,
        zeroSpendDays: List<ZeroSpendDayEntity>,
        cycleStartDay: Int,
        today: LocalDate = LocalDate.now(),
        gameyas: List<GameyaEntity> = emptyList(),
        installments: List<InstallmentEntity> = emptyList(),
        trips: List<TripEventEntity> = emptyList(),
        dailyRolloverMode: String = RolloverMode.NONE,
    ): BudgetSnapshot {
        val zone = ZoneId.systemDefault()
        val clampedStartDay = cycleStartDay.coerceIn(1, 28)

        val cycleStart = if (today.dayOfMonth >= clampedStartDay) {
            today.withDayOfMonth(clampedStartDay)
        } else {
            today.minusMonths(1).withDayOfMonth(clampedStartDay)
        }
        val nextCycleStart = cycleStart.plusMonths(1)
        val totalCycleDays = ChronoUnit.DAYS.between(cycleStart, nextCycleStart).toInt().coerceAtLeast(1)
        val remainingDays = ChronoUnit.DAYS.between(today, nextCycleStart).toInt().coerceAtLeast(1)
        val elapsedDaysInCycle = (ChronoUnit.DAYS.between(cycleStart, today).toInt() + 1).coerceAtLeast(1)

        val totalLiquidity = wallets.sumOf { it.balance.safeFinite() }
        val reservedEnvelopes = envelopes.sumOf { it.reservedAmount.safeFinite().coerceAtLeast(0.0) }
        val reservedGameya = gameyas
            .filter { needsCurrentCycleInstallmentReserve(it, today) }
            .sumOf { it.monthlyInstallment.safeFinite().coerceAtLeast(0.0) }
        val reservedInstallments = installments
            .filter { needsCurrentCycleInstallmentReserve(it, today) }
            .sumOf { it.monthlyAmount.safeFinite().coerceAtLeast(0.0) }
        val reservedTotal = reservedEnvelopes + reservedGameya + reservedInstallments
        val freeBalance = (totalLiquidity - reservedTotal).coerceAtLeast(0.0)

        // Regular expenses (exclude active trip/event expenses from distorting daily safe limit)
        val regularExpenses = transactions.filter {
            it.type == TransactionType.EXPENSE && it.tripEventId == null
        }

        val todaySpent = regularExpenses.asSequence()
            .filter { tx ->
                Instant.ofEpochMilli(tx.timestamp).atZone(zone).toLocalDate() == today
            }
            .sumOf { it.amount.safeFinite().coerceAtLeast(0.0) }

        val cycleSpent = regularExpenses.asSequence()
            .filter { tx ->
                val d = Instant.ofEpochMilli(tx.timestamp).atZone(zone).toLocalDate()
                !d.isBefore(cycleStart) && !d.isAfter(today)
            }
            .sumOf { it.amount.safeFinite().coerceAtLeast(0.0) }

        val startOfDayFreeBalance = (freeBalance + todaySpent).coerceAtLeast(0.0)

        // Yesterday surplus calculation for RolloverMode.TODAY_BONUS
        val yesterday = today.minusDays(1)
        val yesterdaySpent = regularExpenses.asSequence()
            .filter { tx ->
                Instant.ofEpochMilli(tx.timestamp).atZone(zone).toLocalDate() == yesterday
            }
            .sumOf { it.amount.safeFinite().coerceAtLeast(0.0) }
        val startOfYesterdayFree = (startOfDayFreeBalance + yesterdaySpent).coerceAtLeast(0.0)
        val yesterdayRemainingDays = (remainingDays + 1).coerceAtLeast(1)
        val yesterdayLimit = (startOfYesterdayFree / yesterdayRemainingDays.toDouble()).safeFinite().coerceAtLeast(0.0)
        val rawYesterdaySurplus = if (!yesterday.isBefore(cycleStart)) {
            (yesterdayLimit - yesterdaySpent).safeFinite().coerceAtLeast(0.0)
        } else {
            0.0
        }

        val yesterdaySurplusBonus: Double
        val dailySafeLimit: Double
        when (dailyRolloverMode) {
            RolloverMode.TODAY_BONUS -> {
                yesterdaySurplusBonus = rawYesterdaySurplus
                val basePool = (startOfDayFreeBalance - rawYesterdaySurplus).coerceAtLeast(0.0)
                val baseDaily = (basePool / remainingDays.toDouble()).safeFinite().coerceAtLeast(0.0)
                dailySafeLimit = (baseDaily + rawYesterdaySurplus)
                    .coerceAtMost(startOfDayFreeBalance)
                    .safeFinite()
                    .coerceAtLeast(0.0)
            }
            RolloverMode.SPREAD_REMAINING -> {
                yesterdaySurplusBonus = 0.0
                dailySafeLimit = (startOfDayFreeBalance / remainingDays.toDouble())
                    .safeFinite()
                    .coerceAtLeast(0.0)
            }
            else -> {
                yesterdaySurplusBonus = 0.0
                val cyclePool = (freeBalance + cycleSpent).coerceAtLeast(0.0)
                val fixedDaily = (cyclePool / totalCycleDays.toDouble()).safeFinite().coerceAtLeast(0.0)
                dailySafeLimit = fixedDaily.coerceAtMost(startOfDayFreeBalance).coerceAtLeast(0.0)
            }
        }
        val remainingToday = dailySafeLimit - todaySpent

        val ratio = when {
            dailySafeLimit > 0.0 -> (todaySpent / dailySafeLimit).toFloat().safeFinite().coerceAtLeast(0f)
            todaySpent > 0.0 -> 1.2f
            else -> 0f
        }

        val status = when {
            ratio > 1.0f -> SafeSpendStatus.DANGER
            ratio > 0.70f -> SafeSpendStatus.CAUTION
            else -> SafeSpendStatus.SAFE
        }

        val avgDailyCycle = (cycleSpent / elapsedDaysInCycle.toDouble()).safeFinite().coerceAtLeast(0.0)
        val futureDays = (remainingDays - 1).coerceAtLeast(0)
        val projectedEndBalance = (freeBalance - (avgDailyCycle * futureDays)).safeFinite()

        // Zero-spend streak calculation
        val expenseDaysSet = transactions.asSequence()
            .filter { it.type == TransactionType.EXPENSE }
            .map { Instant.ofEpochMilli(it.timestamp).atZone(zone).toLocalDate().toEpochDay() }
            .toSet()

        val confirmedDaysSet = zeroSpendDays
            .map { it.dateEpochDay }
            .filter { it !in expenseDaysSet }
            .toSet()

        val todayEpoch = today.toEpochDay()
        val isTodayConfirmed = todayEpoch in confirmedDaysSet

        var streak = 0
        var cursor = if (isTodayConfirmed) todayEpoch else todayEpoch - 1
        while (cursor in confirmedDaysSet) {
            streak++
            cursor--
        }

        val dailyBaseline = if (dailySafeLimit > 0.0) dailySafeLimit else 100.0
        val estimatedMonthlySaved = if (streak > 0) streak * dailyBaseline else 0.0

        val lowBalanceWallets = wallets.filter { it.minBalanceThreshold > 0.0 && it.balance < it.minBalanceThreshold }

        val activeTrip = trips.firstOrNull { it.isActive }
        val activeTripSnapshot = activeTrip?.let { trip ->
            val tripSpent = transactions.asSequence()
                .filter { it.type == TransactionType.EXPENSE && it.tripEventId == trip.id }
                .sumOf { it.amount.safeFinite().coerceAtLeast(0.0) }
            val safeBudget = trip.budget.safeFinite().coerceAtLeast(0.0)
            val tripRatio = if (safeBudget > 0.0) (tripSpent / safeBudget).toFloat().safeFinite().coerceAtLeast(0f) else 0f
            TripSnapshot(
                trip = trip,
                spent = tripSpent,
                remaining = safeBudget - tripSpent,
                ratio = tripRatio,
            )
        }

        return BudgetSnapshot(
            totalLiquidity = totalLiquidity,
            reservedTotal = reservedTotal,
            reservedEnvelopesTotal = reservedEnvelopes,
            reservedGameyaTotal = reservedGameya,
            reservedInstallmentsTotal = reservedInstallments,
            freeBalance = freeBalance,
            remainingDaysInCycle = remainingDays,
            cycleStartDate = cycleStart,
            nextCycleDate = nextCycleStart,
            todaySpent = todaySpent,
            dailySafeLimit = dailySafeLimit,
            remainingToday = remainingToday,
            todaySpendRatio = ratio,
            safeSpendStatus = status,
            zeroSpendStreak = streak,
            isTodayZeroSpendConfirmed = isTodayConfirmed,
            estimatedMonthlySaved = estimatedMonthlySaved,
            projectedEndOfCycleBalance = projectedEndBalance,
            currentCycleAvgDailySpend = avgDailyCycle,
            lowBalanceWallets = lowBalanceWallets,
            yesterdaySurplusBonus = yesterdaySurplusBonus,
            rolloverMode = dailyRolloverMode,
            activeTripSnapshot = activeTripSnapshot,
        )
    }

    fun currentGameyaCycleKey(today: LocalDate = LocalDate.now()): String = YearMonth.from(today).toString()

    fun computeGameyaCurrentMonthIndex(gameya: GameyaEntity, today: LocalDate = LocalDate.now()): Int {
        val startYm = runCatching { YearMonth.parse(gameya.startYearMonth) }.getOrNull() ?: YearMonth.from(today)
        val nowYm = YearMonth.from(today)
        val monthsDiff = ChronoUnit.MONTHS.between(startYm, nowYm).toInt()
        if (monthsDiff < 0) return 0
        return (monthsDiff + 1).coerceAtMost(gameya.totalMembers.coerceAtLeast(1))
    }

    fun isGameyaCurrentCyclePaid(gameya: GameyaEntity, today: LocalDate = LocalDate.now()): Boolean {
        return gameya.lastPaidCycleKey == currentGameyaCycleKey(today)
    }

    fun needsCurrentCycleInstallmentReserve(gameya: GameyaEntity, today: LocalDate = LocalDate.now()): Boolean {
        if (!gameya.isActive) return false
        if (gameya.paidMonthsCount >= gameya.totalMembers) return false
        val startYm = runCatching { YearMonth.parse(gameya.startYearMonth) }.getOrNull() ?: YearMonth.from(today)
        val nowYm = YearMonth.from(today)
        if (nowYm.isBefore(startYm)) return false
        return !isGameyaCurrentCyclePaid(gameya, today)
    }

    fun needsCurrentCycleInstallmentReserve(installment: InstallmentEntity, today: LocalDate = LocalDate.now()): Boolean {
        if (!installment.isActive) return false
        if (installment.paidMonths >= installment.totalMonths) return false
        return installment.lastPaidCycleKey != currentGameyaCycleKey(today)
    }

    fun isGameyaPayoutReady(gameya: GameyaEntity, today: LocalDate = LocalDate.now()): Boolean {
        if (!gameya.isActive || gameya.isPayoutReceived) return false
        val monthIdx = computeGameyaCurrentMonthIndex(gameya, today)
        return monthIdx >= gameya.payoutTurnMonth && monthIdx > 0
    }

    fun daysUntilRenewal(sub: SubscriptionEntity, today: LocalDate = LocalDate.now()): Long {
        return ChronoUnit.DAYS.between(today, LocalDate.ofEpochDay(sub.nextRenewalEpochDay))
    }

    fun calculateSubscriptionsSummary(
        subscriptions: List<SubscriptionEntity>,
        today: LocalDate = LocalDate.now(),
    ): SubscriptionsSummary {
        val active = subscriptions.filter { it.isActive }
        val monthly = active.sumOf { sub ->
            val amt = sub.amount.safeFinite().coerceAtLeast(0.0)
            if (sub.billingCycle == BillingCycle.YEARLY) amt / 12.0 else amt
        }
        val annualized = active.sumOf { sub ->
            val amt = sub.amount.safeFinite().coerceAtLeast(0.0)
            if (sub.billingCycle == BillingCycle.YEARLY) amt else amt * 12.0
        }
        val dueSoon = active.count { sub ->
            val days = daysUntilRenewal(sub, today)
            days in 0..2
        }
        return SubscriptionsSummary(
            activeCount = active.size,
            monthlyCommitment = monthly,
            annualizedTotal = annualized,
            dueWithin48HoursCount = dueSoon,
        )
    }

    fun calculateImpulseShieldDays(
        enteredAmount: Double,
        freeBalance: Double,
        dailySafeLimit: Double,
    ): Int? {
        if (enteredAmount <= 0.0 || enteredAmount.isNaN() || enteredAmount.isInfinite()) return null
        val exceedsFreePercent = freeBalance > 0.0 && enteredAmount > freeBalance * 0.20
        val exceedsDailyMultiple = dailySafeLimit > 0.0 && enteredAmount > dailySafeLimit * 3.0
        if (!exceedsFreePercent && !exceedsDailyMultiple) return null

        val divisor = when {
            dailySafeLimit > 1.0 -> dailySafeLimit
            freeBalance > 0.0 -> (freeBalance / 30.0).coerceAtLeast(1.0)
            else -> 1.0
        }
        return (enteredAmount / divisor).roundToInt().coerceAtLeast(1)
    }

    fun calculateAnalytics(
        transactions: List<TransactionEntity>,
        categories: List<CategoryEntity>,
        zeroSpendDays: List<ZeroSpendDayEntity>,
        timeframe: AnalyticsTimeframe,
        cycleStartDay: Int,
        dailySafeLimit: Double,
        today: LocalDate = LocalDate.now(),
    ): AnalyticsSnapshot {
        val zone = ZoneId.systemDefault()
        val categoryMap = categories.associateBy { it.id }
        val clampedStartDay = cycleStartDay.coerceIn(1, 28)

        val cycleStart = if (today.dayOfMonth >= clampedStartDay) {
            today.withDayOfMonth(clampedStartDay)
        } else {
            today.minusMonths(1).withDayOfMonth(clampedStartDay)
        }

        val startDate = when (timeframe) {
            AnalyticsTimeframe.WEEK -> today.minusDays(6)
            AnalyticsTimeframe.MONTH -> cycleStart
            AnalyticsTimeframe.ALL -> LocalDate.of(2000, 1, 1)
        }

        val filtered = transactions.filter { tx ->
            val date = Instant.ofEpochMilli(tx.timestamp).atZone(zone).toLocalDate()
            !date.isBefore(startDate) && !date.isAfter(today)
        }

        val expenses = filtered.filter { it.type == TransactionType.EXPENSE }
        val incomes = filtered.filter { it.type == TransactionType.INCOME }

        val totalExpense = expenses.sumOf { it.amount.safeFinite().coerceAtLeast(0.0) }
        val totalIncome = incomes.sumOf { it.amount.safeFinite().coerceAtLeast(0.0) }

        // Category breakdown (guarded against division by zero)
        val groupedByCat = expenses.groupBy { it.categoryId }
        val slices = groupedByCat.entries
            .map { (catId, txs) ->
                val sum = txs.sumOf { it.amount.safeFinite().coerceAtLeast(0.0) }
                val cat = catId?.let { categoryMap[it] }
                val pct = if (totalExpense > 0.0) ((sum / totalExpense) * 100.0).toFloat().coerceIn(0f, 100f) else 0f
                CategorySlice(
                    categoryId = catId,
                    name = cat?.name ?: "أخرى",
                    colorHex = cat?.colorHex ?: 0xFF64748B,
                    amount = sum,
                    percentage = pct,
                )
            }
            .sortedByDescending { it.amount }

        // Daily bar points
        val barDaysCount = when (timeframe) {
            AnalyticsTimeframe.WEEK -> 7
            AnalyticsTimeframe.MONTH -> 10
            AnalyticsTimeframe.ALL -> 10
        }
        val barStart = today.minusDays((barDaysCount - 1).toLong())
        val dailyTotals = expenses
            .groupBy { Instant.ofEpochMilli(it.timestamp).atZone(zone).toLocalDate() }
            .mapValues { (_, list) -> list.sumOf { it.amount.safeFinite().coerceAtLeast(0.0) } }

        val bars = (0 until barDaysCount).map { offset ->
            val d = barStart.plusDays(offset.toLong())
            DailyBarPoint(
                date = d,
                label = "${d.dayOfMonth}/${d.monthValue}",
                amount = dailyTotals[d] ?: 0.0,
            )
        }

        // #19 Income vs Expense Monthly Comparison (last 5 months)
        val currentYm = YearMonth.from(today)
        val monthlyComparisons = (4 downTo 0).map { monthsBack ->
            val ym = currentYm.minusMonths(monthsBack.toLong())
            val monthTxs = transactions.filter { tx ->
                val d = Instant.ofEpochMilli(tx.timestamp).atZone(zone).toLocalDate()
                YearMonth.from(d) == ym
            }
            MonthlyComparisonPoint(
                month = ym,
                label = ym.atDay(1).format(arabicMonthFormatter),
                income = monthTxs.filter { it.type == TransactionType.INCOME }.sumOf { it.amount.safeFinite().coerceAtLeast(0.0) },
                expense = monthTxs.filter { it.type == TransactionType.EXPENSE }.sumOf { it.amount.safeFinite().coerceAtLeast(0.0) },
            )
        }

        // #20 Monthly Spending Heatmap Calendar (current YearMonth)
        val ym = YearMonth.from(today)
        val allExpenseByDay = transactions.filter { it.type == TransactionType.EXPENSE }
            .groupBy { Instant.ofEpochMilli(it.timestamp).atZone(zone).toLocalDate() }
        val zeroEpochSet = zeroSpendDays.map { it.dateEpochDay }.toSet()
        val safeBaseline = if (dailySafeLimit > 0.0) dailySafeLimit else 150.0

        val heatmapCells = (1..ym.lengthOfMonth()).map { day ->
            val d = ym.atDay(day)
            val dayTxs = allExpenseByDay[d].orEmpty()
            val amt = dayTxs.sumOf { it.amount.safeFinite().coerceAtLeast(0.0) }
            val intensity = when {
                amt <= 0.0 && d.toEpochDay() in zeroEpochSet -> HeatmapIntensity.ZERO_SPEND
                amt <= 0.0 -> HeatmapIntensity.NONE
                amt <= safeBaseline * 0.65 -> HeatmapIntensity.LOW
                amt <= safeBaseline -> HeatmapIntensity.MEDIUM
                else -> HeatmapIntensity.HIGH
            }
            HeatmapDayCell(
                date = d,
                dayOfMonth = day,
                amount = amt,
                txCount = dayTxs.size,
                intensity = intensity,
            )
        }

        // #21 Small Leaks Detector (expenses <= 50 EGP in current cycle/timeframe)
        val smallTxs = expenses.filter { it.amount > 0.0 && it.amount <= 50.0 }
        val smallTopCat = smallTxs.groupBy { it.categoryId }
            .maxByOrNull { (_, list) -> list.sumOf { it.amount } }
            ?.key
            ?.let { categoryMap[it]?.name }
        val smallLeaks = SmallLeaksSummary(
            count = smallTxs.size,
            totalAmount = smallTxs.sumOf { it.amount.safeFinite().coerceAtLeast(0.0) },
            topCategoryName = smallTopCat,
        )

        // #28 Per-Category Monthly Budgets (current budget cycle spending)
        val cycleExpensesByCat = transactions.asSequence()
            .filter { it.type == TransactionType.EXPENSE }
            .filter { tx ->
                val d = Instant.ofEpochMilli(tx.timestamp).atZone(zone).toLocalDate()
                !d.isBefore(cycleStart) && !d.isAfter(today)
            }
            .groupBy { it.categoryId }

        val categoryBudgets = categories
            .filter { it.type == TransactionType.EXPENSE && (it.monthlyBudget ?: 0.0) > 0.0 }
            .map { cat ->
                val budget = (cat.monthlyBudget ?: 0.0).coerceAtLeast(1.0)
                val spent = cycleExpensesByCat[cat.id].orEmpty().sumOf { it.amount.safeFinite().coerceAtLeast(0.0) }
                CategoryBudgetProgress(
                    category = cat,
                    spent = spent,
                    budget = budget,
                    ratio = (spent / budget).toFloat().safeFinite().coerceAtLeast(0f),
                )
            }

        val insights = buildArabicInsights(
            allTransactions = transactions,
            periodExpenses = expenses,
            slices = slices,
            totalExpense = totalExpense,
            timeframe = timeframe,
            dailySafeLimit = dailySafeLimit,
            today = today,
            zone = zone,
        )

        return AnalyticsSnapshot(
            totalExpense = totalExpense,
            totalIncome = totalIncome,
            categorySlices = slices,
            dailyBars = bars,
            monthlyComparisons = monthlyComparisons,
            heatmapCells = heatmapCells,
            smallLeaks = smallLeaks,
            categoryBudgets = categoryBudgets,
            insights = insights,
        )
    }

    private fun buildArabicInsights(
        allTransactions: List<TransactionEntity>,
        periodExpenses: List<TransactionEntity>,
        slices: List<CategorySlice>,
        totalExpense: Double,
        timeframe: AnalyticsTimeframe,
        dailySafeLimit: Double,
        today: LocalDate,
        zone: ZoneId,
    ): List<String> {
        if (allTransactions.none { it.type == TransactionType.EXPENSE }) {
            return listOf(
                "لسه مفيش مصاريف مسجلة — ابدأ بتسجيل أول معاملة من زر + عشان الرادار يشتغل.",
                "استخدم ميزة الأظرف المحجوزة لعزل التزاماتك الثابتة زي الباقة والجمعية بدري.",
                "جرب تحدي «بدون صرف» يوم واحد في الأسبوع وهتلاحظ فرق كبير في رصيدك الحر.",
            )
        }

        val insight1 = if (slices.isNotEmpty() && totalExpense > 0.0) {
            val top = slices.first()
            "أكبر بند صرف (${timeframe.label}) هو «${top.name}» بنسبة ${top.percentage.roundToInt()}% بإجمالي ${Formatters.formatEgp(top.amount)}."
        } else {
            "مفيش مصاريف مسجلة في الفترة المختارة (${timeframe.label}) — ممتاز!"
        }

        val thisWeekStart = today.minusDays(6)
        val lastWeekStart = today.minusDays(13)
        val lastWeekEnd = today.minusDays(7)
        val thisWeekSum = allTransactions.asSequence()
            .filter { it.type == TransactionType.EXPENSE }
            .filter {
                val d = Instant.ofEpochMilli(it.timestamp).atZone(zone).toLocalDate()
                !d.isBefore(thisWeekStart) && !d.isAfter(today)
            }
            .sumOf { it.amount.safeFinite().coerceAtLeast(0.0) }
        val lastWeekSum = allTransactions.asSequence()
            .filter { it.type == TransactionType.EXPENSE }
            .filter {
                val d = Instant.ofEpochMilli(it.timestamp).atZone(zone).toLocalDate()
                !d.isBefore(lastWeekStart) && !d.isAfter(lastWeekEnd)
            }
            .sumOf { it.amount.safeFinite().coerceAtLeast(0.0) }

        val insight2 = when {
            lastWeekSum > 0.0 -> {
                val diffPct = (((thisWeekSum - lastWeekSum) / lastWeekSum) * 100.0).roundToInt()
                when {
                    diffPct < -5 -> "مصاريفك الأسبوع ده أقل بـ ${abs(diffPct)}% عن الأسبوع اللي فات — أداء ممتاز!"
                    diffPct > 5 -> "تنبيه: مصاريفك الأسبوع ده زادت بنسبة $diffPct% مقارنة بالأسبوع اللي فات."
                    else -> "معدل صرفك الأسبوع ده متوازن وقريب جداً من الأسبوع اللي فات."
                }
            }
            thisWeekSum > 0.0 -> "صرفت ${Formatters.formatEgp(thisWeekSum)} خلال آخر 7 أيام — استمر في المتابعة لظهور المقارنة الأسبوعية."
            else -> "مفيش مصاريف في آخر 7 أيام — التزام رائع بالميزانية!"
        }

        val distinctDays = periodExpenses
            .map { Instant.ofEpochMilli(it.timestamp).atZone(zone).toLocalDate() }
            .distinct()
            .size
            .coerceAtLeast(1)
        val avgDaily = (totalExpense / distinctDays.toDouble()).safeFinite()
        val insight3 = if (dailySafeLimit > 0.0) {
            if (avgDaily <= dailySafeLimit) {
                "متوسط صرفك اليومي ${Formatters.formatEgp(avgDaily)}، وده جوه الحد الآمن (${Formatters.formatEgp(dailySafeLimit)})."
            } else {
                "متوسط صرفك اليومي ${Formatters.formatEgp(avgDaily)} متجاوز الحد الآمن (${Formatters.formatEgp(dailySafeLimit)}) — حاول تهدي الصرف شوية."
            }
        } else {
            "متوسط صرفك في أيام الصرف هو ${Formatters.formatEgp(avgDaily)} يومياً."
        }

        return listOf(insight1, insight2, insight3)
    }

    fun calculateZeroBasedBudget(
        transactions: List<TransactionEntity>,
        envelopes: List<EnvelopeEntity>,
        categories: List<CategoryEntity>,
        gameyas: List<GameyaEntity>,
        installments: List<InstallmentEntity>,
        cycleStartDay: Int,
        cycleSavingsAmount: Double,
        cycleSavingsKey: String,
        today: LocalDate = LocalDate.now(),
    ): ZeroBasedBudgetSummary {
        val zone = ZoneId.systemDefault()
        val clampedStartDay = cycleStartDay.coerceIn(1, 28)
        val cycleStart = if (today.dayOfMonth >= clampedStartDay) {
            today.withDayOfMonth(clampedStartDay)
        } else {
            today.minusMonths(1).withDayOfMonth(clampedStartDay)
        }
        val monthlyIncome = transactions.asSequence()
            .filter { it.type == TransactionType.INCOME }
            .filter { tx ->
                val d = Instant.ofEpochMilli(tx.timestamp).atZone(zone).toLocalDate()
                !d.isBefore(cycleStart) && !d.isAfter(today)
            }
            .sumOf { it.amount.safeFinite().coerceAtLeast(0.0) }

        val envelopesTotal = envelopes.sumOf { it.reservedAmount.safeFinite().coerceAtLeast(0.0) }
        val categoryBudgetsTotal = categories
            .filter { it.type == TransactionType.EXPENSE }
            .sumOf { (it.monthlyBudget ?: 0.0).safeFinite().coerceAtLeast(0.0) }
        val gameyaReserve = gameyas
            .filter { needsCurrentCycleInstallmentReserve(it, today) }
            .sumOf { it.monthlyInstallment.safeFinite().coerceAtLeast(0.0) }
        val installmentReserve = installments
            .filter { needsCurrentCycleInstallmentReserve(it, today) }
            .sumOf { it.monthlyAmount.safeFinite().coerceAtLeast(0.0) }
        val commitmentsTotal = gameyaReserve + installmentReserve

        val currentKey = currentGameyaCycleKey(today)
        val savingsAssigned = if (cycleSavingsKey == currentKey) {
            cycleSavingsAmount.safeFinite().coerceAtLeast(0.0)
        } else {
            0.0
        }
        val totalAllocated = envelopesTotal + categoryBudgetsTotal + savingsAssigned + commitmentsTotal
        val unallocatedBalance = (monthlyIncome - totalAllocated).safeFinite()

        return ZeroBasedBudgetSummary(
            monthlyIncome = monthlyIncome,
            envelopesTotal = envelopesTotal,
            categoryBudgetsTotal = categoryBudgetsTotal,
            savingsAssigned = savingsAssigned,
            commitmentsTotal = commitmentsTotal,
            totalAllocated = totalAllocated,
            unallocatedBalance = unallocatedBalance,
        )
    }

    fun calculateEmergencyFundTarget(
        transactions: List<TransactionEntity>,
        categories: List<CategoryEntity>,
        today: LocalDate = LocalDate.now(),
    ): Double {
        val zone = ZoneId.systemDefault()
        val essentialKeywords = listOf("أكل", "شرب", "فواتير", "باقات", "مواصلات", "صحة", "صيدلية", "سكن", "إيجار", "تعليم")
        val essentialCatIds = categories
            .filter { cat ->
                cat.type == TransactionType.EXPENSE &&
                    essentialKeywords.any { kw -> cat.name.contains(kw, ignoreCase = true) }
            }
            .map { it.id }
            .toSet()

        val cutoff = today.minusMonths(3)
        val recentExpenses = transactions.filter { tx ->
            if (tx.type != TransactionType.EXPENSE || tx.tripEventId != null) return@filter false
            val d = Instant.ofEpochMilli(tx.timestamp).atZone(zone).toLocalDate()
            !d.isBefore(cutoff) && !d.isAfter(today)
        }
        if (recentExpenses.isEmpty()) return 3000.0

        val essentialExpenses = if (essentialCatIds.isNotEmpty()) {
            recentExpenses.filter { it.categoryId in essentialCatIds }.ifEmpty { recentExpenses }
        } else {
            recentExpenses
        }
        val distinctMonths = essentialExpenses
            .map { YearMonth.from(Instant.ofEpochMilli(it.timestamp).atZone(zone).toLocalDate()) }
            .distinct()
            .size
            .coerceIn(1, 3)
        val totalEssential = essentialExpenses.sumOf { it.amount.safeFinite().coerceAtLeast(0.0) }
        val monthlyAvg = totalEssential / distinctMonths.toDouble()
        return (monthlyAvg * 3.0).coerceAtLeast(3000.0).safeFinite()
    }

    fun calculateInflationAlerts(
        transactions: List<TransactionEntity>,
        categories: List<CategoryEntity>,
        today: LocalDate = LocalDate.now(),
    ): List<InflationSpikeAlert> {
        val zone = ZoneId.systemDefault()
        val currentYm = YearMonth.from(today)
        val categoryMap = categories.associateBy { it.id }

        val regularExpenses = transactions.filter {
            it.type == TransactionType.EXPENSE && it.tripEventId == null
        }
        if (regularExpenses.isEmpty()) return emptyList()

        val byCatAndMonth = regularExpenses.groupBy { it.categoryId }
        val alerts = mutableListOf<InflationSpikeAlert>()

        byCatAndMonth.forEach { (catId, txs) ->
            val monthTotals = txs.groupBy {
                YearMonth.from(Instant.ofEpochMilli(it.timestamp).atZone(zone).toLocalDate())
            }.mapValues { (_, list) ->
                list.sumOf { it.amount.safeFinite().coerceAtLeast(0.0) }
            }

            val currentSpend = monthTotals[currentYm] ?: 0.0
            if (currentSpend <= 0.0) return@forEach

            val historicalMonths = monthTotals.filterKeys { it.isBefore(currentYm) }.values.filter { it > 0.0 }
            if (historicalMonths.isEmpty()) return@forEach

            val historicalAvg = historicalMonths.sum() / historicalMonths.size.toDouble()
            if (historicalAvg <= 10.0) return@forEach

            val increaseRatio = (currentSpend - historicalAvg) / historicalAvg
            if (increaseRatio > 0.15) {
                val pct = (increaseRatio * 100.0).roundToInt()
                alerts.add(
                    InflationSpikeAlert(
                        categoryId = catId,
                        categoryName = catId?.let { categoryMap[it]?.name } ?: "أخرى",
                        currentMonthSpend = currentSpend,
                        historicalMonthlyAvg = historicalAvg,
                        increasePercent = pct,
                    ),
                )
            }
        }

        return alerts.sortedByDescending { it.increasePercent }
    }

    fun calculateFinancialHealthScore(
        transactions: List<TransactionEntity>,
        budgetSnapshot: BudgetSnapshot,
        debts: List<DebtEntity>,
        cycleStartDay: Int,
        today: LocalDate = LocalDate.now(),
    ): FinancialHealthScore {
        val zone = ZoneId.systemDefault()
        val clampedStartDay = cycleStartDay.coerceIn(1, 28)
        val cycleStart = if (today.dayOfMonth >= clampedStartDay) {
            today.withDayOfMonth(clampedStartDay)
        } else {
            today.minusMonths(1).withDayOfMonth(clampedStartDay)
        }

        val cycleTxs = transactions.filter { tx ->
            val d = Instant.ofEpochMilli(tx.timestamp).atZone(zone).toLocalDate()
            !d.isBefore(cycleStart) && !d.isAfter(today)
        }
        val cycleIncome = cycleTxs.filter { it.type == TransactionType.INCOME }
            .sumOf { it.amount.safeFinite().coerceAtLeast(0.0) }
        val cycleExpense = cycleTxs.filter { it.type == TransactionType.EXPENSE && it.tripEventId == null }
            .sumOf { it.amount.safeFinite().coerceAtLeast(0.0) }

        // 1. Savings Rate Component (0..25)
        val savingsScore = when {
            cycleIncome > 0.0 -> {
                val rate = ((cycleIncome - cycleExpense) / cycleIncome).coerceIn(-0.2, 0.4)
                (((rate.coerceAtLeast(0.0)) / 0.25) * 25.0).roundToInt().coerceIn(0, 25)
            }
            budgetSnapshot.freeBalance > 0.0 -> 15
            else -> 8
        }

        // 2. Daily Limit Adherence Component (0..25)
        val dailyScore = when {
            budgetSnapshot.dailySafeLimit <= 0.0 && budgetSnapshot.todaySpent > 0.0 -> 4
            budgetSnapshot.dailySafeLimit <= 0.0 -> 12
            budgetSnapshot.todaySpendRatio <= 0.70f &&
                budgetSnapshot.currentCycleAvgDailySpend <= budgetSnapshot.dailySafeLimit -> 25
            budgetSnapshot.todaySpendRatio <= 1.0f -> 18
            else -> 8
        }

        // 3. Zero-Spend Streak Component (0..25)
        val streakScore = ((budgetSnapshot.zeroSpendStreak.coerceIn(0, 7) / 7.0) * 25.0)
            .roundToInt()
            .coerceIn(0, 25)

        // 4. Debt Ratio Component (0..25)
        val activeDebts = debts.filter { !it.isSettled }
        val iOwe = activeDebts.filter { it.type == DebtType.I_OWE }
            .sumOf { it.amount.safeFinite().coerceAtLeast(0.0) }
        val assetsBase = (budgetSnapshot.totalLiquidity +
            activeDebts.filter { it.type == DebtType.OWED_TO_ME }.sumOf { it.amount.safeFinite().coerceAtLeast(0.0) })
            .coerceAtLeast(1.0)
        val debtScore = if (iOwe <= 0.0) {
            25
        } else {
            val ratio = (iOwe / assetsBase).coerceIn(0.0, 1.0)
            ((1.0 - ratio) * 25.0).roundToInt().coerceIn(2, 24)
        }

        val totalScore = (savingsScore + dailyScore + streakScore + debtScore).coerceIn(0, 100)
        val label = when {
            totalScore >= 80 -> "ممتاز — توازن مالي احترافي 🌟"
            totalScore >= 60 -> "جيد جداً — ماشي في الطريق الصح 👍"
            totalScore >= 40 -> "متوسط — محتاج شوية ضبط ⚖️"
            else -> "تحت الضغط — وقت إعادة التوازن 🛡️"
        }

        val tips = mutableListOf<String>()
        if (savingsScore < 18) {
            tips.add("خصّص 20% من أول دخل جاي مباشرة للحصالة أو صندوق الطوارئ قبل الصرف.")
        }
        if (dailyScore < 18) {
            tips.add("حاول تخلي صرفك اليومي تحت الحد الآمن (${Formatters.formatEgp(budgetSnapshot.dailySafeLimit)}) لآخر الدورة.")
        }
        if (streakScore < 15) {
            tips.add("اعمل تحدي «بدون صرف» يومين في الأسبوع — هيرفع مؤشرك ويزود رصيدك الحر فوراً.")
        }
        if (debtScore < 18 && iOwe > 0.0) {
            tips.add("احجز مبلغ جزء من الديون اللي عليك في ظرف مستقل لتسديدها بدون ضغط.")
        }
        if (tips.size < 2) {
            tips.add("استمر في متابعة الأظرف المحجوزة وتوزيع الميزانية الصفرية في بداية كل شهر.")
        }
        if (tips.size < 2) {
            tips.add("راقب التسريبات الصغيرة أقل من 50 ج.م وحوّل الفائض لهدفك الأساسي.")
        }

        return FinancialHealthScore(
            score = totalScore,
            label = label,
            savingsComponent = savingsScore,
            dailyLimitComponent = dailyScore,
            streakComponent = streakScore,
            debtComponent = debtScore,
            tips = tips.take(2),
        )
    }

    private fun Double.safeFinite(): Double = if (isNaN() || isInfinite()) 0.0 else this
    private fun Float.safeFinite(): Float = if (isNaN() || isInfinite()) 0f else this
}
