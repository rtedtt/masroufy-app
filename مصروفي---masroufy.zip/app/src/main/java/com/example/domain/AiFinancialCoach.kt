package com.example.domain

import android.graphics.Bitmap
import android.util.Base64
import com.example.data.local.AiChatMessageEntity
import com.example.data.local.CategoryEntity
import com.example.data.local.DebtEntity
import com.example.data.local.DebtType
import com.example.data.local.EnvelopeEntity
import com.example.data.local.GoalEntity
import com.example.data.local.InstallmentEntity
import com.example.data.local.TransactionEntity
import com.example.data.local.TransactionType
import com.example.data.local.WalletEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.time.Instant
import java.time.LocalDate
import java.time.YearMonth
import java.time.ZoneId
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.roundToInt

data class ScannedReceiptResult(
    val amount: Double?,
    val merchant: String,
    val suggestedCategoryId: Long?,
    val suggestedCategoryName: String?,
)

object ReceiptScannerHelper {
    fun bitmapToCompressedBase64(bitmap: Bitmap, maxDim: Int = 1024, quality: Int = 80): String {
        val w = bitmap.width.coerceAtLeast(1)
        val h = bitmap.height.coerceAtLeast(1)
        val largest = max(w, h)
        val scaled = if (largest > maxDim) {
            val scale = maxDim.toFloat() / largest.toFloat()
            val targetW = (w * scale).roundToInt().coerceAtLeast(1)
            val targetH = (h * scale).roundToInt().coerceAtLeast(1)
            Bitmap.createScaledBitmap(bitmap, targetW, targetH, true)
        } else {
            bitmap
        }
        val baos = ByteArrayOutputStream()
        scaled.compress(Bitmap.CompressFormat.JPEG, quality.coerceIn(50, 95), baos)
        if (scaled !== bitmap) {
            scaled.recycle()
        }
        return Base64.encodeToString(baos.toByteArray(), Base64.NO_WRAP)
    }
}

data class FinancialCoachSnapshot(
    val wallets: List<WalletEntity>,
    val categories: List<CategoryEntity>,
    val transactions: List<TransactionEntity>,
    val envelopes: List<EnvelopeEntity>,
    val goals: List<GoalEntity>,
    val debts: List<DebtEntity>,
    val budgetSnapshot: BudgetSnapshot,
    val analyticsSnapshot: AnalyticsSnapshot,
    val emergencyFundSaved: Double = 0.0,
    val installments: List<InstallmentEntity> = emptyList(),
)

object FinancialContextBuilder {

    fun buildSystemPrompt(snapshot: FinancialCoachSnapshot, today: LocalDate = LocalDate.now()): String {
        val zone = ZoneId.systemDefault()
        val currentYm = YearMonth.from(today)
        val categoryMap = snapshot.categories.associateBy { it.id }
        val walletMap = snapshot.wallets.associateBy { it.id }

        val monthTxs = snapshot.transactions.filter { tx ->
            YearMonth.from(Instant.ofEpochMilli(tx.timestamp).atZone(zone).toLocalDate()) == currentYm
        }
        val monthExpenses = monthTxs.filter { it.type == TransactionType.EXPENSE }
        val monthIncome = monthTxs.filter { it.type == TransactionType.INCOME }.sumOf { it.amount }
        val monthExpenseTotal = monthExpenses.sumOf { it.amount }

        val catBreakdown = monthExpenses
            .groupBy { it.categoryId }
            .entries
            .map { (catId, list) ->
                val sum = list.sumOf { it.amount }
                val pct = if (monthExpenseTotal > 0.0) ((sum / monthExpenseTotal) * 100.0).roundToInt() else 0
                val name = catId?.let { categoryMap[it]?.name } ?: "أخرى"
                Triple(name, sum, pct)
            }
            .sortedByDescending { it.second }

        val smallLeaks = monthExpenses.filter { it.amount in 0.01..50.0 }
        val smallLeaksTotal = smallLeaks.sumOf { it.amount }

        val activeGoals = snapshot.goals.filter { it.savedAmount < it.targetAmount }
        val activeDebts = snapshot.debts.filter { !it.isSettled }
        val owedToMe = activeDebts.filter { it.type == DebtType.OWED_TO_ME }
        val iOwe = activeDebts.filter { it.type == DebtType.I_OWE }

        val sb = StringBuilder()
        sb.appendLine("أنت «المستشار المالي الذكي» داخل تطبيق «مصروفي (Masroufy)».")
        sb.appendLine("تحدث دائماً باللهجة المصرية الودودة والعملية (مصري عامي)، وكن محدداً ومباشراً ومشجعاً.")
        sb.appendLine("اعتمد فقط على الأرقام الحقيقية التالية للمستخدم بعملة الجنيه المصري (ج.م)، ولا تخترع أي أرقام غير موجودة:")
        sb.appendLine()
        sb.appendLine("【ملخص الأرصدة اليوم ($today)】")
        sb.appendLine("- إجمالي السيولة: ${Formatters.formatCompactNumber(snapshot.budgetSnapshot.totalLiquidity)} ج.م")
        sb.appendLine("- الرصيد الحر المتاح للصرف: ${Formatters.formatCompactNumber(snapshot.budgetSnapshot.freeBalance)} ج.م")
        sb.appendLine("- الرصيد المحجوز للأظرف والالتزامات: ${Formatters.formatCompactNumber(snapshot.budgetSnapshot.reservedTotal)} ج.م (${snapshot.envelopes.size} أظرف)")
        sb.appendLine("- الحد اليومي الآمن للصرف: ${Formatters.formatCompactNumber(snapshot.budgetSnapshot.dailySafeLimit)} ج.م")
        sb.appendLine("- مصروف اليوم حتى الآن: ${Formatters.formatCompactNumber(snapshot.budgetSnapshot.todaySpent)} ج.م")
        sb.appendLine("- الأيام المتبقية في الدورة الشهرية: ${snapshot.budgetSnapshot.remainingDaysInCycle} يوم")
        sb.appendLine("- سلسلة تحدي بدون صرف: ${snapshot.budgetSnapshot.zeroSpendStreak} يوم")
        sb.appendLine("- الرصيد المتوقع نهاية الدورة: ${Formatters.formatCompactNumber(snapshot.budgetSnapshot.projectedEndOfCycleBalance)} ج.م")
        sb.appendLine("- صندوق الطوارئ المحمي: ${Formatters.formatCompactNumber(snapshot.emergencyFundSaved)} ج.م")
        snapshot.budgetSnapshot.activeTripSnapshot?.let { tripSnap ->
            sb.appendLine("- وضع رحلة/مناسبة نشط (${tripSnap.trip.title}): مصروف ${Formatters.formatCompactNumber(tripSnap.spent)} من ${Formatters.formatCompactNumber(tripSnap.trip.budget)} ج.م")
        }
        val activeInstallments = snapshot.installments.filter { it.isActive && it.paidMonths < it.totalMonths }
        if (activeInstallments.isNotEmpty()) {
            sb.appendLine("- أقساط شهرية نشطة (${activeInstallments.size}): إجمالي الشهر ${Formatters.formatCompactNumber(activeInstallments.sumOf { it.monthlyAmount })} ج.م")
        }
        sb.appendLine()
        sb.appendLine("【المحافظ】")
        if (snapshot.wallets.isEmpty()) {
            sb.appendLine("- لا توجد محافظ")
        } else {
            snapshot.wallets.forEach { w ->
                sb.appendLine("- ${w.name}: ${Formatters.formatCompactNumber(w.balance)} ج.م")
            }
        }
        sb.appendLine()
        sb.appendLine("【إحصائيات الشهر الحالي】")
        sb.appendLine("- إجمالي الدخل: ${Formatters.formatCompactNumber(monthIncome)} ج.م")
        sb.appendLine("- إجمالي المصاريف: ${Formatters.formatCompactNumber(monthExpenseTotal)} ج.م")
        if (catBreakdown.isNotEmpty()) {
            sb.appendLine("- توزيع المصاريف حسب التصنيف:")
            catBreakdown.forEach { (name, sum, pct) ->
                sb.appendLine("  • $name: ${Formatters.formatCompactNumber(sum)} ج.م ($pct%)")
            }
        }
        sb.appendLine("- التسريبات الصغيرة (مصاريف <= 50 ج.م): ${smallLeaks.size} معاملة بإجمالي ${Formatters.formatCompactNumber(smallLeaksTotal)} ج.م")
        sb.appendLine()
        sb.appendLine("【أهداف الحصالة النشطة】")
        if (activeGoals.isEmpty()) {
            sb.appendLine("- لا توجد أهداف ادخار نشطة حالياً")
        } else {
            activeGoals.forEach { g ->
                val pct = if (g.targetAmount > 0.0) ((g.savedAmount / g.targetAmount) * 100.0).roundToInt() else 0
                sb.appendLine("- ${g.title}: تم توفير ${Formatters.formatCompactNumber(g.savedAmount)} من ${Formatters.formatCompactNumber(g.targetAmount)} ج.م ($pct%)")
            }
        }
        sb.appendLine()
        sb.appendLine("【دفتر السُلف والديون】")
        sb.appendLine("- فلوس ليا بره: ${Formatters.formatCompactNumber(owedToMe.sumOf { it.amount })} ج.م (${owedToMe.size} أشخاص)")
        sb.appendLine("- فلوس عليك: ${Formatters.formatCompactNumber(iOwe.sumOf { it.amount })} ج.م (${iOwe.size} جهات)")
        activeDebts.take(5).forEach { d ->
            val dir = if (d.type == DebtType.OWED_TO_ME) "لي عند" else "عليا لـ"
            sb.appendLine("  • $dir ${d.personName}: ${Formatters.formatCompactNumber(d.amount)} ج.م")
        }
        sb.appendLine()
        sb.appendLine("【آخر 10 معاملات】")
        val recent = snapshot.transactions.take(10)
        if (recent.isEmpty()) {
            sb.appendLine("- لا توجد معاملات مسجلة بعد")
        } else {
            recent.forEach { tx ->
                val date = Formatters.formatDateOnly(tx.timestamp)
                val typeLabel = when (tx.type) {
                    TransactionType.EXPENSE -> "مصروف"
                    TransactionType.INCOME -> "دخل"
                    else -> "تحويل"
                }
                val catName = tx.categoryId?.let { categoryMap[it]?.name } ?: "تحويل"
                val wName = walletMap[tx.walletId]?.name ?: "محفظة"
                val notePart = if (tx.note.isNotBlank()) " - ${tx.note}" else ""
                sb.appendLine("- [$date] $typeLabel | $catName | $wName | ${Formatters.formatCompactNumber(tx.amount)} ج.م$notePart")
            }
        }
        sb.appendLine()
        sb.appendLine("أعطِ نصائح عملية مختصرة ومنظمة بنقاط واضحة، واكتشف أي مصاريف متكررة غير ضرورية أو تسريبات، واقترح خطط تحويش واقعية، وأجب عن أسئلة هل أستطيع شراء كذا بدقة بناءً على الرصيد الحر والحد اليومي.")
        return sb.toString()
    }
}

object GeminiRestClient {

    private const val MODEL_ENDPOINT =
        "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent"

    suspend fun verifyApiKey(apiKey: String): Result<Unit> = withContext(Dispatchers.IO) {
        val trimmed = apiKey.trim()
        if (trimmed.length < 20) {
            return@withContext Result.failure(IllegalArgumentException("صيغة المفتاح قصيرة جداً — تأكد من نسخ المفتاح كاملاً"))
        }

        val payload = JSONObject().apply {
            put(
                "contents",
                JSONArray().put(
                    JSONObject().apply {
                        put("role", "user")
                        put(
                            "parts",
                            JSONArray().put(JSONObject().put("text", "اكتب كلمة واحدة: جاهز")),
                        )
                    },
                ),
            )
            put(
                "generationConfig",
                JSONObject().apply {
                    put("maxOutputTokens", 16)
                    put("temperature", 0.1)
                },
            )
        }

        postGenerateContent(trimmed, payload).map { Unit }
    }

    suspend fun scanReceipt(
        apiKey: String,
        imageBase64: String,
        expenseCategories: List<CategoryEntity>,
    ): Result<ScannedReceiptResult> = withContext(Dispatchers.IO) {
        val trimmed = apiKey.trim()
        if (trimmed.isEmpty()) {
            return@withContext Result.failure(
                IllegalStateException("أضف مفتاح Gemini المجاني أولاً من الإعدادات أو شاشة المستشار لتفعيل مسح الفواتير"),
            )
        }

        val categoryNames = expenseCategories.map { it.name }.joinToString("، ")
        val prompt = """
            حلل صورة هذه الفاتورة أو الإيصال واستخرج البيانات التالية بصيغة JSON فقط بدون أي نص إضافي:
            {"amount": <الإجمالي النهائي كرقم عشري بدون عملة أو null لو غير واضح>, "merchant": "<اسم المتجر أو ملخص قصير بالعربي>", "category": "<أنسب تصنيف من هذه القائمة فقط: $categoryNames>"}
        """.trimIndent()

        val parts = JSONArray().apply {
            put(
                JSONObject().put(
                    "inline_data",
                    JSONObject().apply {
                        put("mime_type", "image/jpeg")
                        put("data", imageBase64)
                    },
                ),
            )
            put(JSONObject().put("text", prompt))
        }

        val payload = JSONObject().apply {
            put(
                "contents",
                JSONArray().put(
                    JSONObject().apply {
                        put("role", "user")
                        put("parts", parts)
                    },
                ),
            )
            put(
                "generationConfig",
                JSONObject().apply {
                    put("temperature", 0.15)
                    put("maxOutputTokens", 256)
                    put("responseMimeType", "application/json")
                },
            )
        }

        postGenerateContent(trimmed, payload).mapCatching { raw ->
            val cleaned = raw
                .removePrefix("```json")
                .removePrefix("```")
                .removeSuffix("```")
                .trim()
            val obj = JSONObject(cleaned)
            val rawAmount = obj.opt("amount")
            val parsedAmount = when (rawAmount) {
                is Number -> rawAmount.toDouble().takeIf { it > 0.0 && it.isFinite() }
                is String -> Formatters.parseSafeDouble(rawAmount)?.takeIf { it > 0.0 }
                else -> null
            }
            val merchant = obj.optString("merchant").orEmpty().trim()
            val catLabel = obj.optString("category").orEmpty().trim()
            val matchedCat = expenseCategories.firstOrNull {
                it.name.equals(catLabel, ignoreCase = true) ||
                    catLabel.contains(it.name, ignoreCase = true) ||
                    it.name.contains(catLabel, ignoreCase = true)
            }
            ScannedReceiptResult(
                amount = parsedAmount,
                merchant = merchant,
                suggestedCategoryId = matchedCat?.id,
                suggestedCategoryName = matchedCat?.name ?: catLabel.takeIf { it.isNotBlank() },
            )
        }
    }

    suspend fun generateCoachReply(
        apiKey: String,
        systemPrompt: String,
        history: List<AiChatMessageEntity>,
        userMessage: String,
    ): Result<String> = withContext(Dispatchers.IO) {
        val trimmed = apiKey.trim()
        if (trimmed.isEmpty()) {
            return@withContext Result.failure(IllegalStateException("لا يوجد مفتاح API محفوظ"))
        }

        val contentsArray = JSONArray()
        history.takeLast(12).forEach { msg ->
            contentsArray.put(
                JSONObject().apply {
                    put("role", if (msg.isUser) "user" else "model")
                    put("parts", JSONArray().put(JSONObject().put("text", msg.text)))
                },
            )
        }
        contentsArray.put(
            JSONObject().apply {
                put("role", "user")
                put("parts", JSONArray().put(JSONObject().put("text", userMessage)))
            },
        )

        val payload = JSONObject().apply {
            put(
                "systemInstruction",
                JSONObject().put(
                    "parts",
                    JSONArray().put(JSONObject().put("text", systemPrompt)),
                ),
            )
            put("contents", contentsArray)
            put(
                "generationConfig",
                JSONObject().apply {
                    put("temperature", 0.7)
                    put("maxOutputTokens", 1024)
                },
            )
        }

        postGenerateContent(trimmed, payload)
    }

    private fun postGenerateContent(apiKey: String, payload: JSONObject): Result<String> {
        var connection: HttpURLConnection? = null
        return try {
            val encodedKey = URLEncoder.encode(apiKey, "UTF-8")
            val url = URL("$MODEL_ENDPOINT?key=$encodedKey")
            connection = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 15_000
                readTimeout = 25_000
                doOutput = true
                setRequestProperty("Content-Type", "application/json; charset=UTF-8")
            }

            connection.outputStream.use { out ->
                out.write(payload.toString().toByteArray(Charsets.UTF_8))
            }

            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val bodyText = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()

            if (code in 200..299) {
                val json = JSONObject(bodyText)
                val candidates = json.optJSONArray("candidates")
                val first = candidates?.optJSONObject(0)
                val content = first?.optJSONObject("content")
                val parts = content?.optJSONArray("parts")
                val reply = buildString {
                    if (parts != null) {
                        for (i in 0 until parts.length()) {
                            append(parts.optJSONObject(i)?.optString("text").orEmpty())
                        }
                    }
                }.trim()
                if (reply.isBlank()) {
                    Result.failure(IOException("لم يصل رد نصي من Gemini — جرب سؤالاً آخر"))
                } else {
                    Result.success(reply)
                }
            } else {
                val apiErrorMessage = runCatching {
                    JSONObject(bodyText).optJSONObject("error")?.optString("message").orEmpty()
                }.getOrDefault("")
                val friendlyError = when {
                    code == 400 || code == 401 || code == 403 ||
                        apiErrorMessage.contains("API key", ignoreCase = true) ->
                        "مفتاح الـ API غير صحيح أو غير مفعّل — تأكد من نسخه بالكامل من Google AI Studio"
                    code == 429 ->
                        "تم تجاوز حد الطلبات المجاني مؤقتاً — انتظر دقيقة وجرب تاني"
                    else ->
                        "تعذر الاتصال بـ Gemini (كود $code)"
                }
                Result.failure(IOException(friendlyError))
            }
        } catch (_: IOException) {
            Result.failure(IOException("تعذر الاتصال بالإنترنت — تم التحويل للوضع الأوفلاين الذكي"))
        } catch (e: Exception) {
            Result.failure(e)
        } finally {
            connection?.disconnect()
        }
    }
}

object OfflineFinancialBrain {

    private val numberRegex = Regex("""\d+(?:[.,]\d+)?""")

    fun analyzeAndReply(
        question: String,
        snapshot: FinancialCoachSnapshot,
        today: LocalDate = LocalDate.now(),
    ): String {
        val normalizedQ = Formatters.normalizeArabicDigits(question).lowercase()
        val zone = ZoneId.systemDefault()
        val currentYm = YearMonth.from(today)
        val categoryMap = snapshot.categories.associateBy { it.id }

        val monthTxs = snapshot.transactions.filter { tx ->
            YearMonth.from(Instant.ofEpochMilli(tx.timestamp).atZone(zone).toLocalDate()) == currentYm
        }
        val monthExpenses = monthTxs.filter { it.type == TransactionType.EXPENSE }
        val monthIncome = monthTxs.filter { it.type == TransactionType.INCOME }.sumOf { it.amount }
        val monthExpenseTotal = monthExpenses.sumOf { it.amount }

        val topCategories = monthExpenses
            .groupBy { it.categoryId }
            .entries
            .map { (catId, list) ->
                val sum = list.sumOf { it.amount }
                val pct = if (monthExpenseTotal > 0.0) ((sum / monthExpenseTotal) * 100.0).roundToInt() else 0
                val name = catId?.let { categoryMap[it]?.name } ?: "أخرى"
                Triple(name, sum, pct)
            }
            .sortedByDescending { it.second }

        val smallLeaks = monthExpenses.filter { it.amount in 0.01..50.0 }
        val smallLeaksTotal = smallLeaks.sumOf { it.amount }
        val budget = snapshot.budgetSnapshot

        // 1. Affordability question (e.g., "ينفع أشتري سماعة ب 600 جنيه؟")
        val mentionedAmount = extractTargetAmount(normalizedQ)
        val isAffordabilityIntent = mentionedAmount != null && (
            normalizedQ.contains("اشتري") ||
                normalizedQ.contains("أشتري") ||
                normalizedQ.contains("ينفع") ||
                normalizedQ.contains("اقدر") ||
                normalizedQ.contains("أقدر") ||
                normalizedQ.contains("اجيب") ||
                normalizedQ.contains("أجيب") ||
                normalizedQ.contains("اصرف") ||
                normalizedQ.contains("أصرف") ||
                normalizedQ.contains("سعر") ||
                normalizedQ.contains("تكفي") ||
                normalizedQ.contains("مبلغ") ||
                normalizedQ.contains("بكام")
            )

        if (isAffordabilityIntent && mentionedAmount != null && mentionedAmount > 0.0) {
            return buildAffordabilityReply(mentionedAmount, budget)
        }

        // 2. Unnecessary spending / Leaks intent
        if (normalizedQ.contains("لازمة") ||
            normalizedQ.contains("ملهاش") ||
            normalizedQ.contains("تسريب") ||
            normalizedQ.contains("بيطير") ||
            normalizedQ.contains("فين الفلوس") ||
            normalizedQ.contains("هدر") ||
            normalizedQ.contains("زيادة")
        ) {
            return buildLeaksAndWasteReply(
                monthExpenseTotal = monthExpenseTotal,
                topCategories = topCategories,
                smallLeaksCount = smallLeaks.size,
                smallLeaksTotal = smallLeaksTotal,
                budget = budget,
            )
        }

        // 3. Savings plan / daily saving intent
        if (normalizedQ.contains("تحويش") ||
            normalizedQ.contains("أحوش") ||
            normalizedQ.contains("احوش") ||
            normalizedQ.contains("خطة") ||
            normalizedQ.contains("اوفر") ||
            normalizedQ.contains("أوفر") ||
            normalizedQ.contains("هدف") ||
            normalizedQ.contains("حصالة") ||
            normalizedQ.contains("اليومية")
        ) {
            return buildSavingsPlanReply(
                goals = snapshot.goals,
                budget = budget,
                topCategory = topCategories.firstOrNull(),
                smallLeaksTotal = smallLeaksTotal,
            )
        }

        // 4. Financial health evaluation / monthly report
        if (normalizedQ.contains("تقييم") ||
            normalizedQ.contains("قيم") ||
            normalizedQ.contains("وضعي") ||
            normalizedQ.contains("الشهر") ||
            normalizedQ.contains("ملخص") ||
            normalizedQ.contains("أخبار") ||
            normalizedQ.contains("اخبار") ||
            normalizedQ.contains("تقرير")
        ) {
            return buildStatusEvaluationReply(
                snapshot = snapshot,
                monthIncome = monthIncome,
                monthExpenseTotal = monthExpenseTotal,
                topCategory = topCategories.firstOrNull(),
            )
        }

        // 5. Debts intent
        if (normalizedQ.contains("سلف") ||
            normalizedQ.contains("سُلف") ||
            normalizedQ.contains("ديون") ||
            normalizedQ.contains("عليا") ||
            normalizedQ.contains("ليا")
        ) {
            val activeDebts = snapshot.debts.filter { !it.isSettled }
            val owedToMe = activeDebts.filter { it.type == DebtType.OWED_TO_ME }.sumOf { it.amount }
            val iOwe = activeDebts.filter { it.type == DebtType.I_OWE }.sumOf { it.amount }
            return buildString {
                appendLine("📋 ملخص دفتر السُلف والديون عندك:")
                appendLine("• فلوس ليك بره: ${Formatters.formatEgp(owedToMe)}")
                appendLine("• فلوس عليك: ${Formatters.formatEgp(iOwe)}")
                val net = owedToMe - iOwe
                if (net >= 0) {
                    appendLine("✅ صافي السُلف لصالحك بـ ${Formatters.formatEgp(net)}.")
                } else {
                    appendLine("⚠️ عليك صافي التزامات ${Formatters.formatEgp(-net)} — يفضل تحجز جزء منهم في ظرف عشان متتفاجئش.")
                }
            }.trim()
        }

        // 6. General fallback with live snapshot summary + helpful prompt hints
        return buildString {
            appendLine("أهلاً بك! أنا معاك في الوضع الأوفلاين الذكي وحسبتلك وضعك دلوقتي:")
            appendLine("💰 رصيدك الحر المتاح: ${Formatters.formatEgp(budget.freeBalance)} (محجوز للأظرف: ${Formatters.formatEgp(budget.reservedTotal)})")
            appendLine("🛡️ حدك اليومي الآمن: ${Formatters.formatEgp(budget.dailySafeLimit)} • باقي ${budget.remainingDaysInCycle} يوم في الدورة.")
            if (topCategories.isNotEmpty()) {
                val top = topCategories.first()
                appendLine("📊 أعلى بند صرف الشهر ده: «${top.first}» بـ ${Formatters.formatEgp(top.second)} (${top.third}%).")
            }
            appendLine()
            append("تقدر تسألني مثلاً: «ينفع أشتري حاجة بـ 300 جنيه؟» أو تضغط على أي سؤال سريع تحت!")
        }.trim()
    }

    private fun extractTargetAmount(normalizedText: String): Double? {
        val matches = numberRegex.findAll(normalizedText)
            .mapNotNull { Formatters.parseSafeDouble(it.value) }
            .filter { it > 0.0 }
            .toList()
        return matches.maxOrNull()
    }

    private fun buildAffordabilityReply(amount: Double, budget: BudgetSnapshot): String {
        val freeAfter = budget.freeBalance - amount
        val daysEquivalent = if (budget.dailySafeLimit > 0.0) {
            ceil(amount / budget.dailySafeLimit).toInt()
        } else {
            0
        }
        val newDailyLimit = if (budget.remainingDaysInCycle > 0) {
            (freeAfter.coerceAtLeast(0.0) / budget.remainingDaysInCycle)
        } else {
            0.0
        }

        return buildString {
            when {
                budget.freeBalance <= 0.0 -> {
                    appendLine("🚫 بصراحة، رصيدك الحر حالياً ${Formatters.formatEgp(budget.freeBalance)}، وأي مبلغ صافي موجود محجوز للأظرف والالتزامات.")
                    append("الأفضل تأجل الشراء بمبلغ ${Formatters.formatEgp(amount)} للدورة الجاية أو بعد ما يدخلك دخل جديد.")
                }
                amount > budget.freeBalance -> {
                    val shortage = amount - budget.freeBalance
                    appendLine("⚠️ المبلغ (${Formatters.formatEgp(amount)}) أكبر من رصيدك الحر المتاح (${Formatters.formatEgp(budget.freeBalance)}) بفرق ${Formatters.formatEgp(shortage)}.")
                    appendLine("ده معناه إنك هتضطر تسحب من الأظرف المحجوزة لالتزاماتك (${Formatters.formatEgp(budget.reservedTotal)}).")
                    append("💡 نصيحتي: لو مش ضروري النهارده، استنى أو جمّع الفرق خلال الأيام الجاية.")
                }
                amount > budget.freeBalance * 0.35 -> {
                    appendLine("🟡 ينفع تشتريه من رصيدك الحر، لكن خد بالك إنه هيسحب ${((amount / budget.freeBalance) * 100.0).roundToInt()}% من المتاح معاك!")
                    appendLine("• يعادل تقريباً مصروف $daysEquivalent يوم من حدك الآمن.")
                    appendLine("• هيتبقى معاك رصيد حر ${Formatters.formatEgp(freeAfter)} (يعني حدك اليومي الجديد هيبقى ${Formatters.formatEgp(newDailyLimit)}).")
                    append("لو الحاجة دي مهمة فعلاً توكل على الله، ولو كمالية طبّق قاعدة الـ 48 ساعة الأول.")
                }
                else -> {
                    appendLine("✅ أيوة، تقدر تشتريه بأمان من رصيدك الحر بدون ما تأثر على التزامات الأظرف!")
                    appendLine("• هيتبقى معاك رصيد حر ${Formatters.formatEgp(freeAfter)} لباقي ${budget.remainingDaysInCycle} يوم.")
                    append("• حدك اليومي الآمن بعد الشراء هيكون ${Formatters.formatEgp(newDailyLimit)} في اليوم.")
                }
            }
        }.trim()
    }

    private fun buildLeaksAndWasteReply(
        monthExpenseTotal: Double,
        topCategories: List<Triple<String, Double, Int>>,
        smallLeaksCount: Int,
        smallLeaksTotal: Double,
        budget: BudgetSnapshot,
    ): String {
        if (monthExpenseTotal <= 0.0) {
            return "👏 ممتاز! لسه مفيش أي مصاريف متسجلة الشهر ده — كمل كده وسجل أي مصروف أول بأول عشان أقدر أكتشفلك التسريبات."
        }
        return buildString {
            appendLine("🔍 فحصتلك مصاريف الشهر ده (${Formatters.formatEgp(monthExpenseTotal)}):")
            if (topCategories.isNotEmpty()) {
                val top = topCategories.first()
                appendLine("1️⃣ أكبر بند ساحب فلوسك هو «${top.first}» بإجمالي ${Formatters.formatEgp(top.second)} (${top.third}% من مصاريفك).")
                if (topCategories.size > 1) {
                    val second = topCategories[1]
                    appendLine("2️⃣ بعده «${second.first}» بـ ${Formatters.formatEgp(second.second)} (${second.third}%).")
                }
            }
            if (smallLeaksCount > 0) {
                val potentialSave = smallLeaksTotal * 0.4
                appendLine("💸 كاشف التسريبات الصغيرة (≤ 50 ج.م): عملت $smallLeaksCount معاملة صغيرة سحبوا لوحدهم ${Formatters.formatEgp(smallLeaksTotal)}!")
                appendLine("💡 لو قللت التسريبات الصغيرة دي بنسبة 40% بس، هتوفر حوالي ${Formatters.formatEgp(potentialSave)} زيادة في جيبك.")
            } else {
                appendLine("✅ حلو جداً! مفيش تسريبات صغيرة (≤ 50 ج.م) ملحوظة الشهر ده.")
            }
            if (budget.todaySpent > budget.dailySafeLimit && budget.dailySafeLimit > 0.0) {
                append("⚠️ مصروف النهارده (${Formatters.formatEgp(budget.todaySpent)}) عدى الحد الآمن (${Formatters.formatEgp(budget.dailySafeLimit)}) — حاول تقفل صرف باقي اليوم.")
            }
        }.trim()
    }

    private fun buildSavingsPlanReply(
        goals: List<GoalEntity>,
        budget: BudgetSnapshot,
        topCategory: Triple<String, Double, Int>?,
        smallLeaksTotal: Double,
    ): String {
        val remainingDays = budget.remainingDaysInCycle.coerceAtLeast(1)
        val suggestedDailySave = (budget.dailySafeLimit * 0.20).coerceAtLeast(15.0)
        val projectedMonthlySaved = suggestedDailySave * remainingDays
        val activeGoals = goals.filter { it.savedAmount < it.targetAmount }

        return buildString {
            appendLine("🎯 خطة التحويش العملية ليك لباقي الدورة ($remainingDays يوم):")
            appendLine("• رصيدك الحر الحالي: ${Formatters.formatEgp(budget.freeBalance)} — وحدك اليومي الآمن: ${Formatters.formatEgp(budget.dailySafeLimit)}.")
            appendLine("• لو خصصت يومياً ${Formatters.formatEgp(suggestedDailySave)} فقط (20% من الحد اليومي)، هتحوّش ${Formatters.formatEgp(projectedMonthlySaved)} قبل نهاية الشهر!")
            if (activeGoals.isNotEmpty()) {
                val g = activeGoals.first()
                val left = (g.targetAmount - g.savedAmount).coerceAtLeast(0.0)
                val dailyForGoal = left / 30.0
                appendLine("🐷 لهدفك «${g.title}» (باقي عليه ${Formatters.formatEgp(left)}): لو حطيت فيه ${Formatters.formatEgp(dailyForGoal)} يومياً هتكمله خلال شهر.")
            }
            if (topCategory != null) {
                appendLine("✂️ ركز على تقليل بند «${topCategory.first}» بنسبة 15% + اعمل يومين في الأسبوع «بدون صرف» وهتلاحظ فرق فوري.")
            } else if (smallLeaksTotal > 0.0) {
                appendLine("✂️ تقليل التسريبات الصغيرة هيوفرلك مبلغ ممتاز مباشرة في الحصالة.")
            }
        }.trim()
    }

    private fun buildStatusEvaluationReply(
        snapshot: FinancialCoachSnapshot,
        monthIncome: Double,
        monthExpenseTotal: Double,
        topCategory: Triple<String, Double, Int>?,
    ): String {
        val budget = snapshot.budgetSnapshot
        val netFlow = monthIncome - monthExpenseTotal
        val statusText = when (budget.safeSpendStatus) {
            SafeSpendStatus.SAFE -> "🟢 ممتاز ومستقر"
            SafeSpendStatus.CAUTION -> "🟡 محتاج حذر في الصرف"
            SafeSpendStatus.DANGER -> "🔴 ضغط عالي — لازم تهدي الصرف"
        }

        return buildString {
            appendLine("📊 تقييم وضعك المالي الشهر ده: $statusText")
            appendLine("• إجمالي السيولة: ${Formatters.formatEgp(budget.totalLiquidity)} (حر: ${Formatters.formatEgp(budget.freeBalance)} | محجوز: ${Formatters.formatEgp(budget.reservedTotal)})")
            appendLine("• دخل الشهر: ${Formatters.formatEgp(monthIncome)} | مصاريف الشهر: ${Formatters.formatEgp(monthExpenseTotal)}")
            if (monthIncome > 0.0) {
                val label = if (netFlow >= 0) "فائض" else "عجز"
                appendLine("• الصافي الشهري: $label ${Formatters.formatEgp(kotlin.math.abs(netFlow))}")
            }
            appendLine("• توقع الرصيد آخر الدورة: ${Formatters.formatEgp(budget.projectedEndOfCycleBalance)}")
            if (topCategory != null) {
                appendLine("• أعلى تصنيف صرف: «${topCategory.first}» (${topCategory.third}%).")
            }
            append("• تحدي بدون صرف: ${budget.zeroSpendStreak} يوم متواصل — استمر!")
        }.trim()
    }
}
