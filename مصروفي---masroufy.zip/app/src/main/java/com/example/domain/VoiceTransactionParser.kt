package com.example.domain

import com.example.data.local.CategoryEntity
import com.example.data.local.TransactionType
import com.example.data.local.WalletEntity
import com.example.data.local.WalletType
import java.util.Locale

data class VoiceParsedDraft(
    val amount: Double,
    val type: String,
    val categoryId: Long?,
    val walletId: Long?,
    val note: String,
    val categoryLabel: String,
    val walletLabel: String,
)

object VoiceTransactionParser {

    private val numberWordMap: Map<String, Double> = mapOf(
        "صفر" to 0.0,
        "واحد" to 1.0, "واحدة" to 1.0, "جنيه" to 1.0,
        "اتنين" to 2.0, "اثنين" to 2.0, "جنيهين" to 2.0,
        "تلاتة" to 3.0, "ثلاثة" to 3.0, "تلات" to 3.0,
        "أربعة" to 4.0, "اربعة" to 4.0, "أربع" to 4.0, "اربع" to 4.0,
        "خمسة" to 5.0, "خمس" to 5.0,
        "ستة" to 6.0, "ست" to 6.0,
        "سبعة" to 7.0, "سبع" to 7.0,
        "تمانية" to 8.0, "ثمانية" to 8.0, "تمان" to 8.0,
        "تسعة" to 9.0, "تسع" to 9.0,
        "عشرة" to 10.0, "عشر" to 10.0,
        "حداشر" to 11.0, "احد عشر" to 11.0,
        "اتناشر" to 12.0, "اثنا عشر" to 12.0,
        "تلتاشر" to 13.0, "ثلاثة عشر" to 13.0,
        "اربعتاشر" to 14.0, "أربعتاشر" to 14.0,
        "خمستاشر" to 15.0, "خمسة عشر" to 15.0,
        "ستاشر" to 16.0, "سبعتاشر" to 17.0, "تمنتاشر" to 18.0, "تسعتاشر" to 19.0,
        "عشرين" to 20.0, "عشرون" to 20.0,
        "تلاتين" to 30.0, "ثلاثين" to 30.0,
        "أربعين" to 40.0, "اربعين" to 40.0,
        "خمسين" to 50.0,
        "ستين" to 60.0,
        "سبعين" to 70.0,
        "تمانين" to 80.0, "ثمانين" to 80.0,
        "تسعين" to 90.0,
        "مية" to 100.0, "ميه" to 100.0, "مائة" to 100.0,
        "ميتين" to 200.0, "مائتين" to 200.0,
        "تلتمية" to 300.0, "ثلاثمائة" to 300.0,
        "ربعمية" to 400.0, "أربعمائة" to 400.0,
        "خمسمية" to 500.0, "خمسمائة" to 500.0,
        "ستمية" to 600.0, "ستمائة" to 600.0,
        "سبعمية" to 700.0, "سبعمائة" to 700.0,
        "تمنمية" to 800.0, "ثمانمائة" to 800.0,
        "تسعمية" to 900.0, "تسعمائة" to 900.0,
        "ألف" to 1000.0, "الف" to 1000.0,
        "ألفين" to 2000.0, "الفين" to 2000.0,
    )

    private val incomeHints = listOf(
        "قبضت", "استلمت", "جالي", "وصلني", "تحويل لي", "مرتب", "راتب", "مكافأة", "بونص", "دخل", "ايراد", "إيراد",
    )

    private val walletCashHints = listOf("كاش", "نقدي", "جيبي", "المحفظة العادية")
    private val walletBankHints = listOf("انستا", "إنستا", "انستاباي", "بنك", "فيزا", "حساب", "بطاقة", "كارت", "ماستر")
    private val walletMobileHints = listOf("فودافون", "اتصالات", "اورانج", "أورانج", "وي باي", "محفظة إلكترونية", "محفظة الكترونية", "فون كاش")

    private val numericRegex = Regex("""\d+(?:\.\d{1,2})?""")

    fun parse(
        spokenText: String,
        wallets: List<WalletEntity>,
        categories: List<CategoryEntity>,
    ): List<VoiceParsedDraft> {
        val normalized = Formatters.normalizeArabicDigits(spokenText)
            .replace("،", " ")
            .replace(Regex("""\s+"""), " ")
            .trim()
        if (normalized.isBlank()) return emptyList()

        // Global defaults if user mentions wallet/type once across compound sentence
        val globalWallet = detectWallet(normalized, wallets)
        val globalType = detectType(normalized)

        val clauses = splitCompoundClauses(normalized)
        val results = mutableListOf<VoiceParsedDraft>()

        for (clause in clauses) {
            val amount = extractAmountFromClause(clause) ?: continue
            if (amount <= 0.0) continue

            val type = if (incomeHints.any { clause.contains(it) }) TransactionType.INCOME else globalType
            val wallet = detectWallet(clause, wallets) ?: globalWallet ?: wallets.firstOrNull { it.type == WalletType.CASH } ?: wallets.firstOrNull()
            val targetCats = categories.filter { it.type == type }
            val category = detectCategory(clause, type, targetCats) ?: targetCats.lastOrNull()
            val cleanedNote = cleanClauseToNote(clause)

            results.add(
                VoiceParsedDraft(
                    amount = amount,
                    type = type,
                    categoryId = category?.id,
                    walletId = wallet?.id,
                    note = cleanedNote.ifBlank { category?.name ?: "إدخال صوتي" },
                    categoryLabel = category?.name ?: "أخرى",
                    walletLabel = wallet?.name ?: "كاش",
                ),
            )
        }
        return results
    }

    private fun splitCompoundClauses(text: String): List<String> {
        // Split on " و " or standalone " و" followed by digits/number words, without splitting compound numbers like "مية وخمسين" or "خمسة وعشرين"
        val tokens = text.split(" ").filter { it.isNotBlank() }
        if (tokens.size < 3) return listOf(text)

        val clauses = mutableListOf<String>()
        val current = mutableListOf<String>()

        var i = 0
        while (i < tokens.size) {
            val tok = tokens[i]
            val isStandaloneWaw = tok == "و"
            val startsWithWawAndDigit = tok.length > 1 && tok.startsWith("و") && (tok[1].isDigit() || isNumberWord(tok.substring(1)))

            if ((isStandaloneWaw || startsWithWawAndDigit) && current.isNotEmpty()) {
                val nextToken = if (isStandaloneWaw) tokens.getOrNull(i + 1).orEmpty() else tok.substring(1)
                val prevHasNumber = current.any { numericRegex.containsMatchIn(it) || isNumberWord(it) }
                val prevHasDescriptiveWord = current.any { !numericRegex.matches(it) && !isNumberWord(it) && it !in listOf("جنيه", "جم", "ج.م", "من", "على", "في", "دفعت", "صرفت", "اشتريت", "بـ", "ب") }
                val nextStartsNewAmount = numericRegex.containsMatchIn(nextToken) || isNumberWord(nextToken)

                if (prevHasNumber && prevHasDescriptiveWord && nextStartsNewAmount) {
                    clauses.add(current.joinToString(" "))
                    current.clear()
                    if (!isStandaloneWaw) {
                        current.add(tok.substring(1))
                    }
                    i++
                    continue
                }
            }
            current.add(tok)
            i++
        }
        if (current.isNotEmpty()) {
            clauses.add(current.joinToString(" "))
        }
        return clauses.ifEmpty { listOf(text) }
    }

    private fun isNumberWord(token: String): Boolean {
        val stripped = token.removePrefix("ب").removePrefix("بـ").removePrefix("و")
        return numberWordMap.containsKey(stripped) || numberWordMap.containsKey(token)
    }

    private fun extractAmountFromClause(clause: String): Double? {
        // Prefer numeric digits first
        val digitMatch = numericRegex.find(clause)
        var baseAmount = digitMatch?.value?.toDoubleOrNull()

        if (baseAmount == null) {
            // Try summing Arabic number words (e.g., "مية وخمسين" -> 150, "خمسين" -> 50, "ألف وميتين" -> 1200)
            var sum = 0.0
            var foundWord = false
            val tokens = clause.split(" ")
            for (rawTok in tokens) {
                val tok = rawTok.trim()
                    .removePrefix("بـ")
                    .removePrefix("ب")
                val candidate = if (tok.startsWith("و") && tok.length > 1 && numberWordMap.containsKey(tok.substring(1))) {
                    tok.substring(1)
                } else {
                    tok
                }
                val valNum = numberWordMap[candidate]
                if (valNum != null) {
                    sum += valNum
                    foundWord = true
                }
            }
            if (foundWord && sum > 0.0) {
                baseAmount = sum
            }
        }

        if (baseAmount != null) {
            if (clause.contains("ونص") || clause.contains("و نص")) {
                baseAmount += if (baseAmount >= 100 && baseAmount % 100.0 == 0.0 && baseAmount == 100.0) 50.0 else 0.5
            }
        }
        return baseAmount
    }

    private fun detectType(text: String): String {
        val lower = text.lowercase(Locale.ROOT)
        return if (incomeHints.any { lower.contains(it) }) {
            TransactionType.INCOME
        } else {
            TransactionType.EXPENSE
        }
    }

    private fun detectWallet(text: String, wallets: List<WalletEntity>): WalletEntity? {
        val lower = text.lowercase(Locale.ROOT)
        return when {
            walletMobileHints.any { lower.contains(it) } ->
                wallets.firstOrNull { it.type == WalletType.MOBILE_WALLET }
                    ?: wallets.firstOrNull { it.name.contains("محفظة") }
            walletBankHints.any { lower.contains(it) } ->
                wallets.firstOrNull { it.type == WalletType.BANK }
                    ?: wallets.firstOrNull { it.name.contains("بنك") || it.name.contains("إنستا") }
            walletCashHints.any { lower.contains(it) } ->
                wallets.firstOrNull { it.type == WalletType.CASH }
            else -> wallets.firstOrNull { lower.contains(it.name.lowercase(Locale.ROOT)) }
        }
    }

    private fun detectCategory(
        clause: String,
        txType: String,
        categories: List<CategoryEntity>,
    ): CategoryEntity? {
        val lower = clause.lowercase(Locale.ROOT)
        if (txType == TransactionType.INCOME) {
            return when {
                lower.contains("راتب") || lower.contains("مرتب") || lower.contains("قبضت") ->
                    categories.firstOrNull { it.name.contains("راتب") }
                lower.contains("فريلانس") || lower.contains("شغل") || lower.contains("عميل") ->
                    categories.firstOrNull { it.name.contains("حر") }
                lower.contains("هدية") || lower.contains("مصروف") ->
                    categories.firstOrNull { it.name.contains("مصروف") || it.name.contains("هدية") }
                else -> categories.firstOrNull()
            }
        }

        val hintName = when {
            listOf("مواصلات", "اوبر", "أوبر", "كريم", "اندرايف", "إن درايف", "مترو", "ميكروباص", "تاكسي", "توكتوك", "بنزين", "سفر", "أجرة", "اجرة")
                .any { lower.contains(it) } -> "مواصلات"

            listOf("غدا", "غداء", "فطار", "عشا", "عشاء", "اكل", "أكل", "شرب", "قهوة", "شاي", "عصير", "مطعم", "طلبات", "سوبرماركت", "بقالة", "فول", "طعمية", "كشري", "شاورما", "عيش", "لبن")
                .any { lower.contains(it) } -> "أكل وشرب"

            listOf("باقة", "نت", "انترنت", "إنترنت", "شحن", "رصيد", "فاتورة", "كهربا", "ميه", "غاز")
                .any { lower.contains(it) } -> "باقة وإنترنت"

            listOf("كورس", "دراسة", "كتاب", "ملازم", "جامعة", "كلية", "مدرسة", "امتحان")
                .any { lower.contains(it) } -> "دراسة وكورسات"

            listOf("خروجة", "خروجات", "كافيه", "سينما", "فسحة", "تذكرة", "بلايستيشن")
                .any { lower.contains(it) } -> "خروجات"

            listOf("دوا", "دواء", "صيدلية", "دكتور", "كشف", "علاج", "تحليل", "مستشفى")
                .any { lower.contains(it) } -> "صحة"

            listOf("لبس", "هدوم", "تسوق", "شوبنج", "امازون", "أمازون", "نون", "حذاء", "شنطة")
                .any { lower.contains(it) } -> "تسوق"

            else -> null
        }

        return if (hintName != null) {
            categories.firstOrNull { it.name.contains(hintName) } ?: categories.firstOrNull()
        } else {
            categories.firstOrNull { lower.contains(it.name.lowercase(Locale.ROOT)) }
        }
    }

    private fun cleanClauseToNote(clause: String): String {
        val stopWords = setOf(
            "دفعت", "صرفت", "اشتريت", "حولت", "قبضت", "استلمت", "جالي",
            "جنيه", "جنيهات", "جم", "ج.م", "من", "على", "في", "الى", "إلى",
            "الكاش", "كاش", "المحفظة", "انستا", "إنستا", "باي", "فودافون", "اتصالات",
        )
        val cleaned = clause
            .replace(numericRegex, " ")
            .split(" ")
            .map { it.trim() }
            .filter { tok ->
                tok.isNotBlank() &&
                    tok !in stopWords &&
                    !numberWordMap.containsKey(tok)
            }
            .joinToString(" ")
            .trim()
        return cleaned.ifBlank { clause.take(40) }
    }
}
