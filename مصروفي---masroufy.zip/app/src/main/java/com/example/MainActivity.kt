package com.example

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AccountBalanceWallet
import androidx.compose.material.icons.outlined.Analytics
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.rounded.AccountBalanceWallet
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Analytics
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.FloatingActionButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.SnackbarResult
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavDestination.Companion.hasRoute
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.toRoute
import com.example.data.local.ThemeMode
import com.example.data.local.TransactionEntity
import com.example.data.local.TransactionType
import com.example.navigation.AiAdvisorRoute
import com.example.navigation.AnalyticsRoute
import com.example.navigation.HomeRoute
import com.example.navigation.PlanningRoute
import com.example.navigation.SettingsRoute
import com.example.navigation.WalletStatementRoute
import com.example.notifications.NotificationHelper
import com.example.ui.components.QuickLogBottomSheet
import com.example.ui.components.QuickLogPrefill
import com.example.ui.components.StartupPermissionsHandler
import com.example.ui.components.ThemesGallerySheet
import com.example.ui.screens.AiAdvisorScreen
import com.example.ui.screens.AnalyticsScreen
import com.example.ui.screens.AnimatedSplashScreen
import com.example.ui.screens.AppLockScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.MasroufyWebViewScreen
import com.example.ui.screens.OnboardingScreen
import com.example.ui.screens.PlanningScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.WalletStatementScreen
import com.example.ui.theme.LocalMasroufyColors
import com.example.ui.theme.MasroufyTheme
import com.example.viewmodel.MasroufyUiEvent
import com.example.viewmodel.MasroufyViewModel
import kotlinx.coroutines.launch

private const val SHORTCUT_QUICK_EXPENSE = "com.example.SHORTCUT_QUICK_EXPENSE"
private const val SHORTCUT_VOICE_LOG = "com.example.SHORTCUT_VOICE_LOG"
private const val SHORTCUT_AI_COACH = "com.example.SHORTCUT_AI_COACH"

class MainActivity : FragmentActivity() {

    private var openQuickLogTrigger by mutableStateOf(false)
    private var openQuickLogVoiceTrigger by mutableStateOf(false)
    private var openAiCoachTrigger by mutableStateOf(false)
    private var externalQuickLogPrefill by mutableStateOf<QuickLogPrefill?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        handleIncomingIntent(intent)
        setContent {
            MasroufyTheme(darkTheme = true) {
                MasroufyWebViewScreen()
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIncomingIntent(intent)
    }

    private fun handleIncomingIntent(intent: Intent?) {
        when (intent?.action) {
            SHORTCUT_QUICK_EXPENSE -> {
                externalQuickLogPrefill = null
                openQuickLogVoiceTrigger = false
                openQuickLogTrigger = true
                return
            }
            SHORTCUT_VOICE_LOG -> {
                externalQuickLogPrefill = null
                openQuickLogVoiceTrigger = true
                openQuickLogTrigger = true
                return
            }
            SHORTCUT_AI_COACH -> {
                openAiCoachTrigger = true
                return
            }
        }
        val (shouldOpen, prefill) = extractQuickLogPrefill(intent)
        if (shouldOpen) {
            externalQuickLogPrefill = prefill
            openQuickLogVoiceTrigger = false
            openQuickLogTrigger = true
        }
    }
}

private fun extractQuickLogPrefill(intent: Intent?): Pair<Boolean, QuickLogPrefill?> {
    if (intent == null) return false to null
    val shouldOpen = intent.getBooleanExtra(NotificationHelper.EXTRA_OPEN_QUICK_LOG, false)
    if (!shouldOpen) return false to null

    val amount = if (intent.hasExtra(NotificationHelper.EXTRA_PREFILL_AMOUNT)) {
        intent.getDoubleExtra(NotificationHelper.EXTRA_PREFILL_AMOUNT, 0.0).takeIf { it > 0.0 }
    } else {
        null
    }
    val type = intent.getStringExtra(NotificationHelper.EXTRA_PREFILL_TYPE) ?: TransactionType.EXPENSE
    val walletId = intent.getLongExtra(NotificationHelper.EXTRA_PREFILL_WALLET_ID, -1L).takeIf { it > 0L }
    val categoryId = intent.getLongExtra(NotificationHelper.EXTRA_PREFILL_CATEGORY_ID, -1L).takeIf { it > 0L }
    val note = intent.getStringExtra(NotificationHelper.EXTRA_PREFILL_NOTE).orEmpty()

    val prefill = if (amount != null || walletId != null || categoryId != null || note.isNotBlank()) {
        QuickLogPrefill(
            amount = amount,
            type = type,
            walletId = walletId,
            categoryId = categoryId,
            note = note,
        )
    } else {
        null
    }
    return true to prefill
}

private data class NavDestinationItem(
    val route: Any,
    val label: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val testTag: String,
)

@Composable
private fun MasroufyAppShell(
    viewModel: MasroufyViewModel,
    externalOpenQuickLog: Boolean,
    externalAutoVoice: Boolean,
    externalOpenAiCoach: Boolean,
    externalPrefill: QuickLogPrefill?,
    onExternalQuickLogConsumed: () -> Unit,
    onExternalAiCoachConsumed: () -> Unit,
    onCheckAllPermissions: () -> Unit,
) {
    val context = LocalContext.current
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentDestination = navBackStackEntry?.destination
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    var showQuickLogSheet by remember { mutableStateOf(false) }
    var showThemesGallerySheet by remember { mutableStateOf(false) }
    var quickLogInitialMode by remember { mutableStateOf(TransactionType.EXPENSE) }
    var quickLogInitialWalletId by remember { mutableStateOf<Long?>(null) }
    var quickLogPrefill by remember { mutableStateOf<QuickLogPrefill?>(null) }
    var quickLogAutoLaunchVoice by remember { mutableStateOf(false) }
    var editingTransaction by remember { mutableStateOf<TransactionEntity?>(null) }
    var lastBackPressAt by remember { mutableLongStateOf(0L) }

    LaunchedEffect(externalOpenQuickLog, externalAutoVoice, externalPrefill) {
        if (externalOpenQuickLog) {
            quickLogPrefill = externalPrefill
            quickLogInitialMode = externalPrefill?.type ?: TransactionType.EXPENSE
            quickLogInitialWalletId = externalPrefill?.walletId
            quickLogAutoLaunchVoice = externalAutoVoice
            editingTransaction = null
            showQuickLogSheet = true
            onExternalQuickLogConsumed()
        }
    }

    LaunchedEffect(externalOpenAiCoach) {
        if (externalOpenAiCoach) {
            navController.navigate(AiAdvisorRoute) {
                launchSingleTop = true
            }
            onExternalAiCoachConsumed()
        }
    }

    LaunchedEffect(Unit) {
        viewModel.events.collect { event ->
            scope.launch {
                snackbarHostState.currentSnackbarData?.dismiss()
                when (event) {
                    is MasroufyUiEvent.Message -> {
                        snackbarHostState.showSnackbar(event.text)
                    }
                    is MasroufyUiEvent.UndoDelete -> {
                        val result = snackbarHostState.showSnackbar(
                            message = event.text,
                            actionLabel = "تراجع",
                            duration = SnackbarDuration.Short,
                        )
                        if (result == SnackbarResult.ActionPerformed) {
                            viewModel.restoreDeletedTransactions(event.deletedTransactions)
                        }
                    }
                }
            }
        }
    }

    val isOnHome = currentDestination?.hasRoute<HomeRoute>() == true
    val isFullScreenSubRoute = currentDestination?.hasRoute<WalletStatementRoute>() == true ||
        currentDestination?.hasRoute<AiAdvisorRoute>() == true

    // Double-back-to-exit on Home screen when QuickLog sheet is closed
    BackHandler(enabled = isOnHome && !showQuickLogSheet) {
        val now = System.currentTimeMillis()
        if (now - lastBackPressAt < 2000L) {
            (context as? Activity)?.finish()
        } else {
            lastBackPressAt = now
            Toast.makeText(context, "اضغط مرة أخرى للخروج", Toast.LENGTH_SHORT).show()
        }
    }

    val destinations = remember {
        listOf(
            NavDestinationItem(
                route = HomeRoute,
                label = "الرئيسية",
                selectedIcon = Icons.Rounded.Home,
                unselectedIcon = Icons.Outlined.Home,
                testTag = "nav_home",
            ),
            NavDestinationItem(
                route = PlanningRoute,
                label = "التخطيط",
                selectedIcon = Icons.Rounded.AccountBalanceWallet,
                unselectedIcon = Icons.Outlined.AccountBalanceWallet,
                testTag = "nav_planning",
            ),
            NavDestinationItem(
                route = AnalyticsRoute,
                label = "التحليلات",
                selectedIcon = Icons.Rounded.Analytics,
                unselectedIcon = Icons.Outlined.Analytics,
                testTag = "nav_analytics",
            ),
            NavDestinationItem(
                route = SettingsRoute,
                label = "الإعدادات",
                selectedIcon = Icons.Rounded.Settings,
                unselectedIcon = Icons.Outlined.Settings,
                testTag = "nav_settings",
            ),
        )
    }

    fun navigateTo(route: Any) {
        navController.navigate(route) {
            popUpTo(navController.graph.findStartDestination().id) {
                saveState = true
            }
            launchSingleTop = true
            restoreState = true
        }
    }

    fun isRouteSelected(route: Any): Boolean = when (route) {
        is HomeRoute -> currentDestination?.hasRoute<HomeRoute>() == true
        is PlanningRoute -> currentDestination?.hasRoute<PlanningRoute>() == true
        is AnalyticsRoute -> currentDestination?.hasRoute<AnalyticsRoute>() == true
        is SettingsRoute -> currentDestination?.hasRoute<SettingsRoute>() == true
        else -> false
    }

    fun openQuickLog(mode: String = TransactionType.EXPENSE, walletId: Long? = null, editing: TransactionEntity? = null) {
        quickLogPrefill = null
        quickLogInitialMode = mode
        quickLogInitialWalletId = walletId
        quickLogAutoLaunchVoice = false
        editingTransaction = editing
        showQuickLogSheet = true
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val useNavigationRail = maxWidth >= 600.dp

        Scaffold(
            modifier = Modifier.fillMaxSize(),
            containerColor = MaterialTheme.colorScheme.background,
            contentWindowInsets = WindowInsets.safeDrawing,
            snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
            bottomBar = {
                if (!useNavigationRail && !isFullScreenSubRoute) {
                    MasroufyBottomBarWithCenterFab(
                        destinations = destinations,
                        isSelected = ::isRouteSelected,
                        onNavigate = ::navigateTo,
                        onFabClick = { openQuickLog(TransactionType.EXPENSE, null, null) },
                    )
                }
            },
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding),
            ) {
                if (useNavigationRail && !isFullScreenSubRoute) {
                    NavigationRail(
                        modifier = Modifier
                            .fillMaxHeight()
                            .statusBarsPadding()
                            .padding(vertical = 12.dp),
                        containerColor = MaterialTheme.colorScheme.surface,
                        header = {
                            FloatingActionButton(
                                onClick = { openQuickLog(TransactionType.EXPENSE, null, null) },
                                containerColor = MaterialTheme.colorScheme.primary,
                                contentColor = MaterialTheme.colorScheme.onPrimary,
                                shape = CircleShape,
                                modifier = Modifier.testTag("center_add_fab"),
                            ) {
                                Icon(Icons.Rounded.Add, contentDescription = "تسجيل معاملة جديدة")
                            }
                        },
                    ) {
                        Spacer(modifier = Modifier.height(16.dp))
                        destinations.forEach { item ->
                            val selected = isRouteSelected(item.route)
                            NavigationRailItem(
                                selected = selected,
                                onClick = { navigateTo(item.route) },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) item.selectedIcon else item.unselectedIcon,
                                        contentDescription = item.label,
                                    )
                                },
                                label = { Text(item.label) },
                                modifier = Modifier.testTag(item.testTag),
                            )
                        }
                    }
                }

                NavHost(
                    navController = navController,
                    startDestination = HomeRoute,
                    modifier = Modifier.weight(1f),
                ) {
                    composable<HomeRoute> {
                        HomeScreen(
                            state = state,
                            onOpenQuickLog = { mode, walletId ->
                                openQuickLog(mode = mode, walletId = walletId, editing = null)
                            },
                            onOpenWalletStatement = { walletId ->
                                navController.navigate(WalletStatementRoute(walletId))
                            },
                            onEditTransaction = { tx ->
                                openQuickLog(mode = tx.type, walletId = tx.walletId, editing = tx)
                            },
                            onDeleteTransaction = { tx -> viewModel.deleteTransaction(tx) },
                            onDuplicateTransaction = { tx -> viewModel.duplicateTransaction(tx) },
                            onBulkDeleteTransactions = { ids -> viewModel.bulkDeleteTransactions(ids) },
                            onBulkMoveTransactions = { ids, targetId -> viewModel.bulkMoveTransactions(ids, targetId) },
                            onToggleZeroSpend = { viewModel.toggleTodayZeroSpend() },
                            onTogglePrivacyMode = { viewModel.togglePrivacyMode() },
                            onLogQuickTemplate = { template -> viewModel.logFromQuickTemplate(template) },
                            onSaveQuickTemplate = { title, amt, type, catId, wId, note ->
                                viewModel.saveQuickTemplate(title, amt, type, catId, wId, note)
                            },
                            onDeleteQuickTemplate = { id -> viewModel.deleteQuickTemplate(id) },
                            onConfirmRecurringDue = { item -> viewModel.confirmRecurringDue(item) },
                            onOpenAiAdvisor = { navController.navigate(AiAdvisorRoute) },
                            onOpenThemesGallery = { showThemesGallerySheet = true },
                        )
                    }
                    composable<AiAdvisorRoute> {
                        AiAdvisorScreen(
                            state = state,
                            onBack = { navController.popBackStack() },
                            onSendMessage = { msg -> viewModel.sendAiCoachMessage(msg) },
                            onClearChat = { viewModel.clearAiChat() },
                            onTestAndSaveApiKey = { key -> viewModel.testAndSaveGeminiApiKey(key) },
                            onClearApiKey = { viewModel.clearGeminiApiKey() },
                            onShowMessage = { msg -> viewModel.showMessage(msg) },
                        )
                    }
                    composable<WalletStatementRoute> { entry ->
                        val route = entry.toRoute<WalletStatementRoute>()
                        WalletStatementScreen(
                            walletId = route.walletId,
                            state = state,
                            onBack = { navController.popBackStack() },
                            onReconcileBalance = { wId, actual -> viewModel.reconcileWalletBalance(wId, actual) },
                            onEditTransaction = { tx ->
                                openQuickLog(mode = tx.type, walletId = tx.walletId, editing = tx)
                            },
                            onAddTransactionForWallet = { wId ->
                                openQuickLog(mode = TransactionType.EXPENSE, walletId = wId, editing = null)
                            },
                        )
                    }
                    composable<PlanningRoute> {
                        PlanningScreen(
                            state = state,
                            onSaveEnvelope = { id, title, target, reserved, dueDay ->
                                viewModel.saveEnvelope(id, title, target, reserved, dueDay)
                            },
                            onDeleteEnvelope = { viewModel.deleteEnvelope(it) },
                            onTopUpEnvelope = { id, amt -> viewModel.topUpEnvelope(id, amt) },
                            onSpendFromEnvelope = { envId, wId, amt, catId, note ->
                                viewModel.spendFromEnvelope(envId, wId, amt, catId, note)
                            },
                            onSaveGoal = { id, title, target, saved, iconKey, colorHex ->
                                viewModel.saveGoal(id, title, target, saved, iconKey, colorHex)
                            },
                            onDeleteGoal = { viewModel.deleteGoal(it) },
                            onContributeToGoal = { goalId, wId, amt, onComplete ->
                                viewModel.contributeToGoal(goalId, wId, amt, onComplete)
                            },
                            onSaveDebt = { id, name, amt, type, note, dueMillis ->
                                viewModel.saveDebt(id, name, amt, type, note, dueMillis)
                            },
                            onDeleteDebt = { viewModel.deleteDebt(it) },
                            onSettleDebt = { debtId, wId -> viewModel.settleDebt(debtId, wId) },
                            onSaveRecurring = { id, title, amt, type, catId, wId, freq, nextEpoch, autoPost, note ->
                                viewModel.saveRecurring(id, title, amt, type, catId, wId, freq, nextEpoch, autoPost, note)
                            },
                            onDeleteRecurring = { viewModel.deleteRecurring(it) },
                            onConfirmRecurringDue = { viewModel.confirmRecurringDue(it) },
                            onSaveGameya = { id, title, monthly, members, turn, startYm, wId ->
                                viewModel.saveGameya(id, title, monthly, members, turn, startYm, wId)
                            },
                            onDeleteGameya = { viewModel.deleteGameya(it) },
                            onPayGameyaInstallment = { gId, wId -> viewModel.payGameyaInstallment(gId, wId) },
                            onReceiveGameyaPayout = { gId, wId -> viewModel.receiveGameyaPayout(gId, wId) },
                            onSaveSubscription = { id, title, amt, cycle, epoch, wId, catId, note ->
                                viewModel.saveSubscription(id, title, amt, cycle, epoch, wId, catId, note)
                            },
                            onDeleteSubscription = { viewModel.deleteSubscription(it) },
                            onToggleSubscriptionActive = { id, active -> viewModel.toggleSubscriptionActive(id, active) },
                            onRenewSubscriptionNow = { viewModel.renewSubscriptionNow(it) },
                            onApply503020 = { amt, wId, toEmergency, targetGoalId ->
                                viewModel.apply503020Allocation(amt, wId, toEmergency, targetGoalId)
                            },
                            onRebalanceEnvelopes = { fromId, toId, amt ->
                                viewModel.rebalanceEnvelopes(fromId, toId, amt)
                            },
                            onContributeEmergency = { wId, amt ->
                                viewModel.contributeToEmergencyFund(wId, amt)
                            },
                            onWithdrawEmergency = { wId, amt ->
                                viewModel.withdrawFromEmergencyFund(wId, amt)
                            },
                            onSaveTrip = { id, title, budget, isActive ->
                                viewModel.saveTripEvent(id, title, budget, isActive)
                            },
                            onToggleTripActive = { id, active ->
                                viewModel.toggleTripEventActive(id, active)
                            },
                            onDeleteTrip = { viewModel.deleteTripEvent(it) },
                            onSaveInstallment = { id, itemName, monthlyAmt, paidMonths, totalMonths, dueDay, wId ->
                                viewModel.saveInstallment(id, itemName, monthlyAmt, paidMonths, totalMonths, dueDay, wId)
                            },
                            onDeleteInstallment = { viewModel.deleteInstallment(it) },
                            onPayInstallmentMonth = { id, wId -> viewModel.payInstallmentMonth(id, wId) },
                        )
                    }
                    composable<AnalyticsRoute> {
                        AnalyticsScreen(
                            state = state,
                            onSelectTimeframe = { viewModel.setAnalyticsTimeframe(it) },
                            onRebalanceCategoryBudgets = { fromId, toId, amt ->
                                viewModel.rebalanceCategoryBudgets(fromId, toId, amt)
                            },
                            onShowMessage = { viewModel.showMessage(it) },
                        )
                    }
                    composable<SettingsRoute> {
                        SettingsScreen(
                            state = state,
                            onSetThemeMode = { viewModel.setThemeMode(it) },
                            onTogglePrivacyMode = { viewModel.togglePrivacyMode() },
                            onSetCycleStartDay = { viewModel.setBudgetCycleStartDay(it) },
                            onSetDailyRolloverMode = { viewModel.setDailyRolloverMode(it) },
                            onSetDailyReminder = { enabled, hr, min -> viewModel.setDailyReminder(enabled, hr, min) },
                            onSetPersistentQuickLog = { viewModel.setPersistentQuickLogEnabled(it) },
                            onSetWeeklyAutoBackup = { viewModel.setWeeklyAutoBackupEnabled(it) },
                            onEnablePin = { viewModel.enablePin(it) },
                            onDisablePin = { viewModel.disablePin() },
                            onToggleBiometric = { viewModel.setBiometricEnabled(it) },
                            onSaveWallet = { id, name, bal, type, icon, color, isDef, threshold, order ->
                                viewModel.saveWallet(id, name, bal, type, icon, color, isDef, threshold, order)
                            },
                            onDeleteWallet = { viewModel.deleteWallet(it) },
                            onMoveWalletOrder = { id, up -> viewModel.moveWalletOrder(id, up) },
                            onReconcileWallet = { wId, actual -> viewModel.reconcileWalletBalance(wId, actual) },
                            onSaveCategory = { id, name, type, icon, color, isDef, budget, order ->
                                viewModel.saveCategory(id, name, type, icon, color, isDef, budget, order)
                            },
                            onDeleteCategory = { viewModel.deleteCategory(it) },
                            onMoveCategoryOrder = { id, up -> viewModel.moveCategoryOrder(id, up) },
                            onBuildBackupJson = { viewModel.buildBackupJson() },
                            onRestoreBackupJson = { viewModel.restoreBackupJson(it) },
                            onResetAllData = { viewModel.resetAllData() },
                            onTestAndSaveGeminiApiKey = { key -> viewModel.testAndSaveGeminiApiKey(key) },
                            onClearGeminiApiKey = { viewModel.clearGeminiApiKey() },
                            onOpenThemesGallery = { showThemesGallerySheet = true },
                            onSetAutoNotificationCapture = { viewModel.setAutoNotificationCaptureEnabled(it) },
                            onCheckAllPermissions = onCheckAllPermissions,
                            onShowMessage = { viewModel.showMessage(it) },
                        )
                    }
                }
            }
        }
    }

    if (showQuickLogSheet) {
        QuickLogBottomSheet(
            wallets = state.wallets,
            categories = state.categories,
            budgetSnapshot = state.budgetSnapshot,
            initialMode = quickLogInitialMode,
            initialWalletId = quickLogInitialWalletId,
            editingTransaction = editingTransaction,
            prefill = quickLogPrefill,
            activeTrip = state.budgetSnapshot.activeTripSnapshot?.trip,
            autoLaunchVoice = quickLogAutoLaunchVoice,
            onParseSms = { raw -> viewModel.parseClipboardSms(raw) },
            onParseVoice = { transcript -> viewModel.parseVoiceTranscript(transcript) },
            onSaveVoiceBatch = { drafts ->
                viewModel.saveVoiceTransactions(drafts)
                showQuickLogSheet = false
                quickLogAutoLaunchVoice = false
                editingTransaction = null
                quickLogPrefill = null
            },
            onScanReceipt = { bmp, cb -> viewModel.scanReceiptBitmap(bmp, cb) },
            onSave = { existingId, amount, type, catId, wId, toWId, note, ts, saveAsTemplate, cashbackAmt, tripEventId, apply503020 ->
                viewModel.saveTransaction(
                    existingId = existingId,
                    amount = amount,
                    type = type,
                    categoryId = catId,
                    walletId = wId,
                    toWalletId = toWId,
                    note = note,
                    timestamp = ts,
                    saveAsTemplate = saveAsTemplate,
                    cashbackAmount = cashbackAmt,
                    tripEventId = tripEventId,
                    apply503020OnSave = apply503020,
                )
                showQuickLogSheet = false
                quickLogAutoLaunchVoice = false
                editingTransaction = null
                quickLogPrefill = null
            },
            onSaveSplitBill = { total, friendsCount, friendNames, catId, wId, note ->
                viewModel.saveSplitBill(total, friendsCount, friendNames, catId, wId, note)
                showQuickLogSheet = false
                quickLogAutoLaunchVoice = false
                editingTransaction = null
                quickLogPrefill = null
            },
            onDismiss = {
                showQuickLogSheet = false
                quickLogAutoLaunchVoice = false
                editingTransaction = null
                quickLogPrefill = null
            },
        )
    }

    if (showThemesGallerySheet) {
        val totalIncome = state.analyticsSnapshot.totalIncome
        val savingsRate = if (totalIncome > 0.0) {
            (((totalIncome - state.analyticsSnapshot.totalExpense).coerceAtLeast(0.0) / totalIncome) * 100.0)
                .toInt()
                .coerceIn(0, 100)
        } else {
            0
        }
        ThemesGallerySheet(
            gamification = state.gamification,
            selectedThemeId = state.settings.selectedThemeId,
            zeroSpendStreak = state.budgetSnapshot.zeroSpendStreak,
            savingsRatePercent = savingsRate,
            healthScore = state.financialHealthScore.score,
            onShowMessage = { viewModel.showMessage(it) },
            onSelectTheme = { viewModel.setSelectedThemeId(it) },
            onDismiss = { showThemesGallerySheet = false },
        )
    }
}

@Composable
private fun MasroufyBottomBarWithCenterFab(
    destinations: List<NavDestinationItem>,
    isSelected: (Any) -> Boolean,
    onNavigate: (Any) -> Unit,
    onFabClick: () -> Unit,
) {
    val semantic = LocalMasroufyColors.current
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .navigationBarsPadding(),
        contentAlignment = Alignment.BottomCenter,
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            shape = RoundedCornerShape(24.dp),
            color = MaterialTheme.colorScheme.surface,
            border = BorderStroke(1.dp, semantic.cardBorder),
            tonalElevation = 4.dp,
            shadowElevation = 8.dp,
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(68.dp)
                    .padding(horizontal = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceAround,
            ) {
                destinations.take(2).forEach { item ->
                    BottomNavTabItem(
                        item = item,
                        selected = isSelected(item.route),
                        onClick = { onNavigate(item.route) },
                        modifier = Modifier.weight(1f),
                    )
                }

                Spacer(modifier = Modifier.size(64.dp))

                destinations.drop(2).forEach { item ->
                    BottomNavTabItem(
                        item = item,
                        selected = isSelected(item.route),
                        onClick = { onNavigate(item.route) },
                        modifier = Modifier.weight(1f),
                    )
                }
            }
        }

        FloatingActionButton(
            onClick = onFabClick,
            shape = CircleShape,
            containerColor = MaterialTheme.colorScheme.primary,
            contentColor = MaterialTheme.colorScheme.onPrimary,
            elevation = FloatingActionButtonDefaults.elevation(defaultElevation = 8.dp),
            modifier = Modifier
                .offset(y = (-24).dp)
                .size(60.dp)
                .testTag("center_add_fab"),
        ) {
            Icon(
                imageVector = Icons.Rounded.Add,
                contentDescription = "تسجيل معاملة جديدة",
                modifier = Modifier.size(30.dp),
            )
        }
    }
}

@Composable
private fun BottomNavTabItem(
    item: NavDestinationItem,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 6.dp)
            .testTag(item.testTag),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(12.dp))
                .background(if (selected) color.copy(alpha = 0.16f) else Color.Transparent)
                .padding(horizontal = 12.dp, vertical = 4.dp),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                imageVector = if (selected) item.selectedIcon else item.unselectedIcon,
                contentDescription = item.label,
                tint = color,
                modifier = Modifier.size(22.dp),
            )
        }
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = item.label,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
            color = color,
            maxLines = 1,
        )
    }
}
