package com.example.viewmodel

import android.app.Application
import android.graphics.Bitmap
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AiChatMessageEntity
import com.example.data.local.CategoryEntity
import com.example.data.local.DebtEntity
import com.example.data.local.EnvelopeEntity
import com.example.data.local.GameyaEntity
import com.example.data.local.GoalEntity
import com.example.data.local.InstallmentEntity
import com.example.data.local.MasroufyDatabase
import com.example.data.local.QuickTemplateEntity
import com.example.data.local.RecurringTransactionEntity
import com.example.data.local.SettingsDataStore
import com.example.data.local.SubscriptionEntity
import com.example.data.local.TransactionEntity
import com.example.data.local.TransactionType
import com.example.data.local.TripEventEntity
import com.example.data.local.UserSettings
import com.example.data.local.WalletEntity
import com.example.data.local.ZeroSpendDayEntity
import com.example.data.repository.MasroufyRepository
import com.example.domain.AnalyticsSnapshot
import com.example.domain.AnalyticsTimeframe
import com.example.domain.BudgetSnapshot
import com.example.domain.FinanceCalculator
import com.example.domain.FinancialCoachSnapshot
import com.example.domain.FinancialContextBuilder
import com.example.domain.FinancialHealthScore
import com.example.domain.Formatters
import com.example.domain.GamificationEngine
import com.example.domain.GamificationSnapshot
import com.example.domain.GeminiRestClient
import com.example.domain.HashtagParser
import com.example.domain.InflationSpikeAlert
import com.example.domain.MasroufyThemePack
import com.example.domain.OfflineFinancialBrain
import com.example.domain.ParsedSmsResult
import com.example.domain.ReceiptScannerHelper
import com.example.domain.ScannedReceiptResult
import com.example.domain.SmsTransactionParser
import com.example.domain.SubscriptionsSummary
import com.example.domain.TagSpendSummary
import com.example.domain.VoiceParsedDraft
import com.example.domain.VoiceTransactionParser
import com.example.domain.XpAwards
import com.example.domain.ZeroBasedBudgetSummary
import com.example.notifications.NotificationHelper
import com.example.widget.MasroufyAppWidget
import com.example.workers.WorkScheduler
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.drop
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.LocalDate

sealed interface MasroufyUiEvent {
    data class Message(val text: String) : MasroufyUiEvent
    data class UndoDelete(
        val text: String,
        val deletedTransactions: List<TransactionEntity>,
    ) : MasroufyUiEvent
}

data class MasroufyUiState(
    val isLoaded: Boolean = false,
    val wallets: List<WalletEntity> = emptyList(),
    val categories: List<CategoryEntity> = emptyList(),
    val transactions: List<TransactionEntity> = emptyList(),
    val envelopes: List<EnvelopeEntity> = emptyList(),
    val goals: List<GoalEntity> = emptyList(),
    val debts: List<DebtEntity> = emptyList(),
    val zeroSpendDays: List<ZeroSpendDayEntity> = emptyList(),
    val quickTemplates: List<QuickTemplateEntity> = emptyList(),
    val recurringTransactions: List<RecurringTransactionEntity> = emptyList(),
    val settings: UserSettings = UserSettings(),
    val budgetSnapshot: BudgetSnapshot = FinanceCalculator.calculateBudgetSnapshot(
        wallets = emptyList(),
        envelopes = emptyList(),
        transactions = emptyList(),
        zeroSpendDays = emptyList(),
        cycleStartDay = 1,
    ),
    val selectedTimeframe: AnalyticsTimeframe = AnalyticsTimeframe.MONTH,
    val analyticsSnapshot: AnalyticsSnapshot = AnalyticsSnapshot(
        totalExpense = 0.0,
        totalIncome = 0.0,
        categorySlices = emptyList(),
        dailyBars = emptyList(),
        monthlyComparisons = emptyList(),
        heatmapCells = emptyList(),
        smallLeaks = com.example.domain.SmallLeaksSummary(0, 0.0, null),
        categoryBudgets = emptyList(),
        insights = emptyList(),
    ),
    val isAppLocked: Boolean = false,
    val aiChatMessages: List<AiChatMessageEntity> = emptyList(),
    val isAiThinking: Boolean = false,
    val gameyas: List<GameyaEntity> = emptyList(),
    val subscriptions: List<SubscriptionEntity> = emptyList(),
    val subscriptionsSummary: SubscriptionsSummary = SubscriptionsSummary(0, 0.0, 0.0, 0),
    val gamification: GamificationSnapshot = GamificationEngine.computeSnapshot(0, MasroufyThemePack.EMERALD_CLASSIC.id),
    val tripEvents: List<TripEventEntity> = emptyList(),
    val installments: List<InstallmentEntity> = emptyList(),
    val zeroBasedBudget: ZeroBasedBudgetSummary = ZeroBasedBudgetSummary(0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0),
    val emergencyFundTarget: Double = 3000.0,
    val inflationAlerts: List<InflationSpikeAlert> = emptyList(),
    val financialHealthScore: FinancialHealthScore = FinancialHealthScore(
        score = 50,
        label = "جيد — ابدأ التتبع",
        savingsComponent = 15,
        dailyLimitComponent = 15,
        streakComponent = 0,
        debtComponent = 20,
        tips = emptyList(),
    ),
    val hashtagSummaries: List<TagSpendSummary> = emptyList(),
)

class MasroufyViewModel(application: Application) : AndroidViewModel(application) {

    private val appContext = application.applicationContext
    private val database = MasroufyDatabase.getInstance(application)
    private val settingsDataStore = SettingsDataStore(application)
    private val repository = MasroufyRepository(database, settingsDataStore)

    private val selectedTimeframe = MutableStateFlow(AnalyticsTimeframe.MONTH)
    private val unlockedInSession = MutableStateFlow(false)
    private val isAiThinkingFlow = MutableStateFlow(false)

    private val _events = MutableSharedFlow<MasroufyUiEvent>(extraBufferCapacity = 16)
    val events = _events.asSharedFlow()

    private data class CoreRecords(
        val wallets: List<WalletEntity>,
        val categories: List<CategoryEntity>,
        val transactions: List<TransactionEntity>,
        val envelopes: List<EnvelopeEntity>,
    )

    private data class PlanningRecords(
        val goals: List<GoalEntity>,
        val debts: List<DebtEntity>,
        val zeroSpendDays: List<ZeroSpendDayEntity>,
        val quickTemplates: List<QuickTemplateEntity>,
        val recurring: List<RecurringTransactionEntity>,
    )

    private val coreFlow = combine(
        repository.walletsFlow,
        repository.categoriesFlow,
        repository.transactionsFlow,
        repository.envelopesFlow,
    ) { wallets, categories, transactions, envelopes ->
        CoreRecords(wallets, categories, transactions, envelopes)
    }

    private val planningFlow = combine(
        repository.goalsFlow,
        repository.debtsFlow,
        repository.zeroSpendDaysFlow,
        repository.quickTemplatesFlow,
        repository.recurringFlow,
    ) { goals, debts, zeroDays, templates, recurring ->
        PlanningRecords(goals, debts, zeroDays, templates, recurring)
    }

    private data class UiMetaState(
        val settings: UserSettings,
        val timeframe: AnalyticsTimeframe,
        val unlocked: Boolean,
        val aiMessages: List<AiChatMessageEntity>,
        val isAiThinking: Boolean,
    )

    private val metaFlow = combine(
        repository.settingsFlow,
        selectedTimeframe,
        unlockedInSession,
        repository.aiChatMessagesFlow,
        isAiThinkingFlow,
    ) { settings, timeframe, unlocked, aiMessages, aiThinking ->
        UiMetaState(settings, timeframe, unlocked, aiMessages, aiThinking)
    }

    private data class V2V3PlanningRecords(
        val gameyas: List<GameyaEntity>,
        val subscriptions: List<SubscriptionEntity>,
        val trips: List<TripEventEntity>,
        val installments: List<InstallmentEntity>,
    )

    private val v2PlanningFlow = combine(
        repository.gameyasFlow,
        repository.subscriptionsFlow,
        repository.tripEventsFlow,
        repository.installmentsFlow,
    ) { gameyas, subscriptions, trips, installments ->
        V2V3PlanningRecords(gameyas, subscriptions, trips, installments)
    }

    val uiState: StateFlow<MasroufyUiState> = combine(
        coreFlow,
        planningFlow,
        metaFlow,
        v2PlanningFlow,
    ) { core, planning, meta, extra ->
        val budget = FinanceCalculator.calculateBudgetSnapshot(
            wallets = core.wallets,
            envelopes = core.envelopes,
            transactions = core.transactions,
            zeroSpendDays = planning.zeroSpendDays,
            cycleStartDay = meta.settings.budgetCycleStartDay,
            gameyas = extra.gameyas,
            installments = extra.installments,
            trips = extra.trips,
            dailyRolloverMode = meta.settings.dailyRolloverMode,
        )
        val analytics = FinanceCalculator.calculateAnalytics(
            transactions = core.transactions,
            categories = core.categories,
            zeroSpendDays = planning.zeroSpendDays,
            timeframe = meta.timeframe,
            cycleStartDay = meta.settings.budgetCycleStartDay,
            dailySafeLimit = budget.dailySafeLimit,
        )
        val subscriptionsSummary = FinanceCalculator.calculateSubscriptionsSummary(extra.subscriptions)
        val gamification = GamificationEngine.computeSnapshot(
            xp = meta.settings.xpPoints,
            selectedThemeId = meta.settings.selectedThemeId,
        )
        val zeroBased = FinanceCalculator.calculateZeroBasedBudget(
            transactions = core.transactions,
            envelopes = core.envelopes,
            categories = core.categories,
            gameyas = extra.gameyas,
            installments = extra.installments,
            cycleStartDay = meta.settings.budgetCycleStartDay,
            cycleSavingsAmount = meta.settings.cycleSavingsAmount,
            cycleSavingsKey = meta.settings.cycleSavingsKey,
        )
        val emergencyTarget = FinanceCalculator.calculateEmergencyFundTarget(
            transactions = core.transactions,
            categories = core.categories,
        )
        val inflationAlerts = FinanceCalculator.calculateInflationAlerts(
            transactions = core.transactions,
            categories = core.categories,
        )
        val healthScore = FinanceCalculator.calculateFinancialHealthScore(
            transactions = core.transactions,
            budgetSnapshot = budget,
            debts = planning.debts,
            cycleStartDay = meta.settings.budgetCycleStartDay,
        )
        val hashtagSummaries = HashtagParser.summarizeTagSpend(core.transactions)
        val locked = meta.settings.isPinEnabled && !meta.unlocked
        MasroufyUiState(
            isLoaded = true,
            wallets = core.wallets,
            categories = core.categories,
            transactions = core.transactions,
            envelopes = core.envelopes,
            goals = planning.goals,
            debts = planning.debts,
            zeroSpendDays = planning.zeroSpendDays,
            quickTemplates = planning.quickTemplates,
            recurringTransactions = planning.recurring,
            settings = meta.settings,
            budgetSnapshot = budget,
            selectedTimeframe = meta.timeframe,
            analyticsSnapshot = analytics,
            isAppLocked = locked,
            aiChatMessages = meta.aiMessages,
            isAiThinking = meta.isAiThinking,
            gameyas = extra.gameyas,
            subscriptions = extra.subscriptions,
            subscriptionsSummary = subscriptionsSummary,
            gamification = gamification,
            tripEvents = extra.trips,
            installments = extra.installments,
            zeroBasedBudget = zeroBased,
            emergencyFundTarget = emergencyTarget,
            inflationAlerts = inflationAlerts,
            financialHealthScore = healthScore,
            hashtagSummaries = hashtagSummaries,
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = MasroufyUiState(),
    )

    init {
        viewModelScope.launch {
            repository.ensureSeeded()
            val postedRecurring = repository.processAutoDueRecurring()
            if (postedRecurring > 0) {
                _events.tryEmit(MasroufyUiEvent.Message("تم تسجيل $postedRecurring معاملة متكررة تلقائياً"))
            }
            val initialSettings = repository.settingsFlow.first()
            if (!initialSettings.isPinEnabled) {
                unlockedInSession.value = true
            }
            NotificationHelper.createChannels(appContext)
            NotificationHelper.updatePersistentQuickLogNotification(
                appContext,
                initialSettings.persistentQuickLogEnabled,
            )
            WorkScheduler.scheduleDailyCheck(
                appContext,
                initialSettings.dailyReminderHour,
                initialSettings.dailyReminderMinute,
            )
            WorkScheduler.scheduleWeeklyBackup(appContext, initialSettings.weeklyAutoBackupEnabled)
        }
        viewModelScope.launch {
            uiState
                .map { Triple(it.budgetSnapshot.freeBalance, it.budgetSnapshot.dailySafeLimit, it.settings.isPrivacyMode) }
                .distinctUntilChanged()
                .drop(1)
                .collect {
                    MasroufyAppWidget.requestUpdate(appContext)
                }
        }
    }

    // --- Onboarding (#30) ---

    fun completeOnboarding(walletBalances: Map<Long, Double>, cycleStartDay: Int) {
        viewModelScope.launch {
            repository.completeOnboarding(walletBalances, cycleStartDay)
            _events.tryEmit(MasroufyUiEvent.Message("أهلاً بك في مصروفي! تم إعداد محافظك"))
        }
    }

    fun skipOnboarding() {
        viewModelScope.launch {
            repository.skipOnboarding()
        }
    }

    // --- Quick Log & SMS Parsing ---

    fun parseClipboardSms(rawText: String): ParsedSmsResult? {
        val state = uiState.value
        return SmsTransactionParser.parse(
            rawText = rawText,
            wallets = state.wallets,
            categories = state.categories,
        )
    }

    fun parseVoiceTranscript(spokenText: String): List<VoiceParsedDraft> {
        val state = uiState.value
        return VoiceTransactionParser.parse(
            spokenText = spokenText,
            wallets = state.wallets,
            categories = state.categories,
        )
    }

    private suspend fun grantXp(delta: Int) {
        val levelUp = repository.awardXp(delta)
        if (levelUp != null) {
            _events.tryEmit(
                MasroufyUiEvent.Message("مبروك الترقية! وصلت إلى ${levelUp.title} — تم فتح سمة جديدة!"),
            )
        }
    }

    fun saveVoiceTransactions(drafts: List<VoiceParsedDraft>) {
        if (drafts.isEmpty()) return
        viewModelScope.launch {
            val state = uiState.value
            val fallbackWalletId = state.wallets.firstOrNull()?.id ?: return@launch
            var savedCount = 0
            drafts.forEach { draft ->
                val targetWallet = draft.walletId ?: fallbackWalletId
                repository.addTransaction(
                    TransactionEntity(
                        amount = draft.amount,
                        type = draft.type,
                        categoryId = draft.categoryId,
                        walletId = targetWallet,
                        note = draft.note,
                        timestamp = System.currentTimeMillis(),
                    ),
                )
                savedCount++
            }
            _events.tryEmit(MasroufyUiEvent.Message("تم حفظ $savedCount معاملة من الإدخال الصوتي"))
            grantXp(XpAwards.TRANSACTION * savedCount)
        }
    }

    fun saveTransaction(
        existingId: Long?,
        amount: Double,
        type: String,
        categoryId: Long?,
        walletId: Long,
        toWalletId: Long?,
        note: String,
        timestamp: Long = System.currentTimeMillis(),
        saveAsTemplate: Boolean = false,
        templateTitle: String = "",
        cashbackAmount: Double = 0.0,
        tripEventId: Long? = null,
        apply503020OnSave: Boolean = false,
    ) {
        viewModelScope.launch {
            val prevSnapshot = uiState.value.budgetSnapshot
            val tx = TransactionEntity(
                id = existingId ?: 0L,
                amount = amount,
                type = type,
                categoryId = categoryId,
                walletId = walletId,
                toWalletId = toWalletId,
                note = note.trim(),
                timestamp = timestamp,
                tripEventId = if (type == TransactionType.EXPENSE) tripEventId else null,
            )
            if (existingId == null || existingId == 0L) {
                repository.addTransaction(tx, cashbackAmount = cashbackAmount)
                if (apply503020OnSave && type == TransactionType.INCOME) {
                    repository.applyIncome503020Allocation(
                        amount = amount,
                        sourceWalletId = walletId,
                        putSavingsInEmergencyFund = true,
                        targetGoalId = null,
                    )
                }
                if (saveAsTemplate && type != TransactionType.TRANSFER) {
                    val catName = uiState.value.categories.firstOrNull { it.id == categoryId }?.name ?: "معاملة"
                    val title = templateTitle.trim().ifBlank {
                        note.trim().ifBlank { catName }
                    }
                    repository.saveQuickTemplate(
                        QuickTemplateEntity(
                            title = title,
                            amount = amount,
                            type = type,
                            categoryId = categoryId,
                            walletId = walletId,
                            note = note.trim(),
                        ),
                    )
                }
                val msg = when {
                    apply503020OnSave && type == TransactionType.INCOME -> "تم تسجيل الدخل وتوزيعه تلقائياً 50/30/20 ✅"
                    cashbackAmount > 0.0 && type == TransactionType.EXPENSE ->
                        "تم تسجيل المصروف وإضافة كاش باك ${Formatters.formatEgp(cashbackAmount)} لمحفظتك 🎁"
                    else -> "تم تسجيل المعاملة بنجاح"
                }
                _events.tryEmit(MasroufyUiEvent.Message(msg))
                grantXp(XpAwards.TRANSACTION)
            } else {
                repository.updateTransaction(tx)
                _events.tryEmit(MasroufyUiEvent.Message("تم تحديث المعاملة بنجاح"))
            }

            if (type == TransactionType.EXPENSE && tripEventId == null) {
                checkPostExpenseAlerts(prevSnapshot, amount, walletId)
            }
        }
    }

    fun saveSplitBill(
        totalAmount: Double,
        friendsCount: Int,
        friendNames: List<String>,
        categoryId: Long?,
        walletId: Long,
        note: String,
    ) {
        viewModelScope.launch {
            val prevSnapshot = uiState.value.budgetSnapshot
            repository.addSplitBillTransaction(
                totalAmount = totalAmount,
                friendsCount = friendsCount,
                friendNames = friendNames,
                categoryId = categoryId,
                walletId = walletId,
                note = note,
            )
            val userShare = totalAmount / (friendsCount + 1).coerceAtLeast(2)
            _events.tryEmit(
                MasroufyUiEvent.Message(
                    "تم خصم حصتك (${Formatters.formatEgp(userShare)}) وإضافة ${friendsCount} سلفة في دفتر السُلف",
                ),
            )
            grantXp(XpAwards.TRANSACTION)
            checkPostExpenseAlerts(prevSnapshot, userShare, walletId)
        }
    }

    private fun checkPostExpenseAlerts(prevSnapshot: BudgetSnapshot, addedExpense: Double, walletId: Long) {
        // Daily limit exceeded check (#8)
        val newTodaySpent = prevSnapshot.todaySpent + addedExpense
        if (prevSnapshot.dailySafeLimit > 0.0 &&
            prevSnapshot.todaySpent <= prevSnapshot.dailySafeLimit &&
            newTodaySpent > prevSnapshot.dailySafeLimit
        ) {
            NotificationHelper.showDailyLimitExceededAlert(
                context = appContext,
                spentText = Formatters.formatEgp(newTodaySpent),
                limitText = Formatters.formatEgp(prevSnapshot.dailySafeLimit),
            )
        }
        // Low wallet balance check (#9)
        val wallet = uiState.value.wallets.firstOrNull { it.id == walletId }
        if (wallet != null && wallet.minBalanceThreshold > 0.0) {
            val projectedBalance = wallet.balance - addedExpense
            if (wallet.balance >= wallet.minBalanceThreshold && projectedBalance < wallet.minBalanceThreshold) {
                NotificationHelper.showLowWalletBalanceAlert(
                    context = appContext,
                    walletName = wallet.name,
                    balanceText = Formatters.formatEgp(projectedBalance),
                )
            }
        }
    }

    fun deleteTransaction(tx: TransactionEntity) {
        viewModelScope.launch {
            val deleted = repository.deleteTransaction(tx)
            if (deleted != null) {
                _events.tryEmit(
                    MasroufyUiEvent.UndoDelete(
                        text = "تم حذف المعاملة وتحديث الرصيد",
                        deletedTransactions = listOf(deleted),
                    ),
                )
            }
        }
    }

    fun restoreDeletedTransactions(transactions: List<TransactionEntity>) {
        viewModelScope.launch {
            repository.restoreTransactions(transactions)
            _events.tryEmit(MasroufyUiEvent.Message("تم التراجع واستعادة المعاملات"))
        }
    }

    fun duplicateTransaction(tx: TransactionEntity) {
        viewModelScope.launch {
            repository.duplicateTransaction(tx)
            _events.tryEmit(MasroufyUiEvent.Message("تم تكرار المعاملة بتاريخ اليوم"))
        }
    }

    fun bulkDeleteTransactions(ids: Set<Long>) {
        viewModelScope.launch {
            val deleted = repository.bulkDeleteTransactions(ids)
            if (deleted.isNotEmpty()) {
                _events.tryEmit(
                    MasroufyUiEvent.UndoDelete(
                        text = "تم حذف ${deleted.size} معاملة",
                        deletedTransactions = deleted,
                    ),
                )
            }
        }
    }

    fun bulkMoveTransactions(ids: Set<Long>, targetWalletId: Long) {
        viewModelScope.launch {
            repository.bulkMoveTransactions(ids, targetWalletId)
            _events.tryEmit(MasroufyUiEvent.Message("تم نقل المعاملات للمحفظة المختارة"))
        }
    }

    fun reconcileWalletBalance(walletId: Long, actualBalance: Double) {
        viewModelScope.launch {
            val diff = repository.reconcileWalletBalance(walletId, actualBalance)
            if (kotlin.math.abs(diff) < 0.01) {
                _events.tryEmit(MasroufyUiEvent.Message("رصيد المحفظة مطابق بالفعل"))
            } else {
                _events.tryEmit(MasroufyUiEvent.Message("تم تعديل الرصيد الفعلي وتسجيل فرق الجرد"))
            }
        }
    }

    // --- Quick Templates (#3) ---

    fun saveQuickTemplate(
        title: String,
        amount: Double,
        type: String,
        categoryId: Long?,
        walletId: Long,
        note: String,
    ) {
        viewModelScope.launch {
            repository.saveQuickTemplate(
                QuickTemplateEntity(
                    title = title.trim(),
                    amount = amount,
                    type = type,
                    categoryId = categoryId,
                    walletId = walletId,
                    note = note.trim(),
                ),
            )
            _events.tryEmit(MasroufyUiEvent.Message("تم حفظ القالب السريع"))
        }
    }

    fun deleteQuickTemplate(id: Long) {
        viewModelScope.launch {
            repository.deleteQuickTemplate(id)
            _events.tryEmit(MasroufyUiEvent.Message("تم حذف القالب"))
        }
    }

    fun logFromQuickTemplate(template: QuickTemplateEntity) {
        viewModelScope.launch {
            val prevSnapshot = uiState.value.budgetSnapshot
            repository.logFromQuickTemplate(template)
            _events.tryEmit(MasroufyUiEvent.Message("تم تسجيل «${template.title}» (${Formatters.formatEgp(template.amount)})"))
            grantXp(XpAwards.TRANSACTION)
            if (template.type == TransactionType.EXPENSE) {
                checkPostExpenseAlerts(prevSnapshot, template.amount, template.walletId)
            }
        }
    }

    // --- Recurring Transactions (#4) ---

    fun saveRecurring(
        id: Long = 0L,
        title: String,
        amount: Double,
        type: String,
        categoryId: Long?,
        walletId: Long,
        frequency: String,
        nextDueEpochDay: Long,
        autoPost: Boolean,
        note: String,
    ) {
        viewModelScope.launch {
            repository.saveRecurring(
                RecurringTransactionEntity(
                    id = id,
                    title = title.trim(),
                    amount = amount,
                    type = type,
                    categoryId = categoryId,
                    walletId = walletId,
                    frequency = frequency,
                    nextDueEpochDay = nextDueEpochDay,
                    autoPost = autoPost,
                    isActive = true,
                    note = note.trim(),
                ),
            )
            _events.tryEmit(MasroufyUiEvent.Message("تم حفظ المعاملة المتكررة"))
        }
    }

    fun deleteRecurring(id: Long) {
        viewModelScope.launch {
            repository.deleteRecurring(id)
            _events.tryEmit(MasroufyUiEvent.Message("تم حذف التكرار"))
        }
    }

    fun confirmRecurringDue(item: RecurringTransactionEntity) {
        viewModelScope.launch {
            repository.confirmRecurringDue(item, LocalDate.now())
            _events.tryEmit(MasroufyUiEvent.Message("تم تسجيل «${item.title}» وجدولة الموعد القادم"))
        }
    }

    // --- Zero-Spend Streak ---

    fun toggleTodayZeroSpend() {
        viewModelScope.launch {
            val snap = uiState.value.budgetSnapshot
            if (snap.todaySpent > 0.0) {
                _events.tryEmit(MasroufyUiEvent.Message("تم تسجيل مصروف اليوم بالفعل — جرب تاني بكرة!"))
                return@launch
            }
            if (snap.isTodayZeroSpendConfirmed) {
                repository.unmarkTodayZeroSpend()
                _events.tryEmit(MasroufyUiEvent.Message("تم إلغاء تأكيد اليوم"))
            } else {
                repository.markTodayZeroSpend()
                _events.tryEmit(MasroufyUiEvent.Message("عاش! تم تسجيل اليوم ضمن تحدي بدون صرف (+50 XP)"))
                grantXp(XpAwards.ZERO_SPEND_DAY)
            }
        }
    }

    // --- Envelopes ---

    fun saveEnvelope(id: Long = 0L, title: String, targetAmount: Double, reservedAmount: Double, dueDay: Int?, iconKey: String = "envelope") {
        viewModelScope.launch {
            repository.saveEnvelope(
                EnvelopeEntity(
                    id = id,
                    title = title.trim(),
                    reservedAmount = reservedAmount,
                    targetAmount = targetAmount.coerceAtLeast(reservedAmount),
                    dueDay = dueDay,
                    iconKey = iconKey,
                ),
            )
            _events.tryEmit(MasroufyUiEvent.Message(if (id == 0L) "تم إنشاء الظرف بنجاح" else "تم تحديث الظرف"))
        }
    }

    fun deleteEnvelope(id: Long) {
        viewModelScope.launch {
            repository.deleteEnvelope(id)
            _events.tryEmit(MasroufyUiEvent.Message("تم حذف الظرف وفك الحجز"))
        }
    }

    fun topUpEnvelope(envelopeId: Long, amount: Double) {
        viewModelScope.launch {
            repository.topUpEnvelope(envelopeId, amount)
            _events.tryEmit(MasroufyUiEvent.Message("تم حجز مبلغ إضافي في الظرف"))
        }
    }

    fun spendFromEnvelope(envelopeId: Long, walletId: Long, amount: Double, categoryId: Long?, note: String) {
        viewModelScope.launch {
            repository.spendFromEnvelope(envelopeId, walletId, amount, categoryId, note)
            _events.tryEmit(MasroufyUiEvent.Message("تم الصرف من الظرف وتسجيل المصروف"))
        }
    }

    // --- Goals ---

    fun saveGoal(id: Long = 0L, title: String, targetAmount: Double, savedAmount: Double = 0.0, iconKey: String = "savings", colorHex: Long = 0xFF10B981) {
        viewModelScope.launch {
            repository.saveGoal(
                GoalEntity(
                    id = id,
                    title = title.trim(),
                    targetAmount = targetAmount,
                    savedAmount = savedAmount,
                    iconKey = iconKey,
                    colorHex = colorHex,
                ),
            )
            _events.tryEmit(MasroufyUiEvent.Message(if (id == 0L) "تم إضافة الهدف للحصالة" else "تم تحديث الهدف"))
        }
    }

    fun deleteGoal(id: Long) {
        viewModelScope.launch {
            repository.deleteGoal(id)
            _events.tryEmit(MasroufyUiEvent.Message("تم حذف الهدف"))
        }
    }

    fun contributeToGoal(goalId: Long, walletId: Long, amount: Double, onGoalCompleted: () -> Unit = {}) {
        viewModelScope.launch {
            val completed = repository.contributeToGoal(goalId, walletId, amount)
            if (completed) {
                onGoalCompleted()
                _events.tryEmit(MasroufyUiEvent.Message("مبروك! حققت هدف التحويش بالكامل 🎉 (+230 XP)"))
                grantXp(XpAwards.GOAL_DEPOSIT + XpAwards.GOAL_COMPLETED)
            } else {
                _events.tryEmit(MasroufyUiEvent.Message("تم تحويل المبلغ للحصالة بنجاح (+30 XP)"))
                grantXp(XpAwards.GOAL_DEPOSIT)
            }
        }
    }

    // --- Debts ---

    fun saveDebt(id: Long = 0L, personName: String, amount: Double, type: String, note: String, dueDateMillis: Long? = null) {
        viewModelScope.launch {
            repository.saveDebt(
                DebtEntity(
                    id = id,
                    personName = personName.trim(),
                    amount = amount,
                    type = type,
                    note = note.trim(),
                    dueDateMillis = dueDateMillis,
                ),
            )
            _events.tryEmit(MasroufyUiEvent.Message("تم حفظ السُلفة بنجاح"))
        }
    }

    fun deleteDebt(id: Long) {
        viewModelScope.launch {
            repository.deleteDebt(id)
            _events.tryEmit(MasroufyUiEvent.Message("تم حذف السجل"))
        }
    }

    fun settleDebt(debtId: Long, walletId: Long) {
        viewModelScope.launch {
            repository.settleDebt(debtId, walletId)
            _events.tryEmit(MasroufyUiEvent.Message("تم السداد وتحديث رصيد المحفظة (+25 XP)"))
            grantXp(XpAwards.GAMEYA_OR_DEBT)
        }
    }

    // --- Gam'eya Manager ---

    fun saveGameya(
        id: Long = 0L,
        title: String,
        monthlyInstallment: Double,
        totalMembers: Int,
        payoutTurnMonth: Int,
        startYearMonth: String,
        walletId: Long,
    ) {
        viewModelScope.launch {
            val existing = uiState.value.gameyas.firstOrNull { it.id == id }
            repository.saveGameya(
                GameyaEntity(
                    id = id,
                    title = title.trim(),
                    monthlyInstallment = monthlyInstallment,
                    totalMembers = totalMembers.coerceAtLeast(2),
                    payoutTurnMonth = payoutTurnMonth.coerceIn(1, totalMembers.coerceAtLeast(2)),
                    startYearMonth = startYearMonth,
                    walletId = walletId,
                    paidMonthsCount = existing?.paidMonthsCount ?: 0,
                    isPayoutReceived = existing?.isPayoutReceived ?: false,
                    lastPaidCycleKey = existing?.lastPaidCycleKey.orEmpty(),
                    isActive = existing?.isActive ?: true,
                ),
            )
            _events.tryEmit(MasroufyUiEvent.Message(if (id == 0L) "تمت إضافة الجمعية بنجاح" else "تم تحديث الجمعية"))
        }
    }

    fun deleteGameya(id: Long) {
        viewModelScope.launch {
            repository.deleteGameya(id)
            _events.tryEmit(MasroufyUiEvent.Message("تم حذف الجمعية"))
        }
    }

    fun payGameyaInstallment(gameyaId: Long, walletId: Long) {
        viewModelScope.launch {
            if (repository.payGameyaInstallment(gameyaId, walletId)) {
                _events.tryEmit(MasroufyUiEvent.Message("تم دفع قسط الشهر وتسجيل المصروف (+25 XP)"))
                grantXp(XpAwards.GAMEYA_OR_DEBT)
            }
        }
    }

    fun receiveGameyaPayout(gameyaId: Long, walletId: Long) {
        viewModelScope.launch {
            val payout = repository.receiveGameyaPayout(gameyaId, walletId)
            if (payout != null) {
                _events.tryEmit(MasroufyUiEvent.Message("مبروك القبض! تم إضافة ${Formatters.formatEgp(payout)} لمحفظتك 🎉"))
                grantXp(XpAwards.GAMEYA_OR_DEBT)
            }
        }
    }

    // --- Subscriptions & Fixed Bills Radar ---

    fun saveSubscription(
        id: Long = 0L,
        title: String,
        amount: Double,
        billingCycle: String,
        nextRenewalEpochDay: Long,
        walletId: Long,
        categoryId: Long?,
        note: String,
    ) {
        viewModelScope.launch {
            val existing = uiState.value.subscriptions.firstOrNull { it.id == id }
            repository.saveSubscription(
                SubscriptionEntity(
                    id = id,
                    title = title.trim(),
                    amount = amount,
                    billingCycle = billingCycle,
                    nextRenewalEpochDay = nextRenewalEpochDay,
                    walletId = walletId,
                    categoryId = categoryId,
                    isActive = existing?.isActive ?: true,
                    note = note.trim(),
                ),
            )
            _events.tryEmit(MasroufyUiEvent.Message(if (id == 0L) "تمت إضافة الاشتراك للرادار" else "تم تحديث الاشتراك"))
        }
    }

    fun deleteSubscription(id: Long) {
        viewModelScope.launch {
            repository.deleteSubscription(id)
            _events.tryEmit(MasroufyUiEvent.Message("تم حذف الاشتراك"))
        }
    }

    fun toggleSubscriptionActive(id: Long, active: Boolean) {
        viewModelScope.launch {
            repository.toggleSubscriptionActive(id, active)
        }
    }

    fun renewSubscriptionNow(id: Long) {
        viewModelScope.launch {
            if (repository.renewSubscriptionNow(id)) {
                _events.tryEmit(MasroufyUiEvent.Message("تم تسجيل التجديد وتحديث الموعد القادم"))
                grantXp(XpAwards.TRANSACTION)
            }
        }
    }

    // --- Themes, Auto-Capture & Startup Permissions ---

    fun setSelectedThemeId(themeId: String) {
        viewModelScope.launch {
            val pack = MasroufyThemePack.fromId(themeId)
            val currentLevel = uiState.value.gamification.rank.level
            if (currentLevel < pack.unlockLevel) {
                _events.tryEmit(
                    MasroufyUiEvent.Message("تُفتح سمة «${pack.arabicName}» عند الوصول للمستوى ${pack.unlockLevel}"),
                )
                return@launch
            }
            repository.setSelectedThemeId(pack.id)
            _events.tryEmit(MasroufyUiEvent.Message("تم تفعيل سمة «${pack.arabicName}»"))
        }
    }

    fun setAutoNotificationCaptureEnabled(enabled: Boolean) {
        viewModelScope.launch {
            repository.setAutoNotificationCaptureEnabled(enabled)
            _events.tryEmit(
                MasroufyUiEvent.Message(
                    if (enabled) "تم تفعيل الرصد التلقائي لإشعارات الدفع" else "تم إيقاف الرصد التلقائي",
                ),
            )
        }
    }

    fun markStartupPermissionsPrompted() {
        viewModelScope.launch {
            repository.setHasPromptedStartupPermissions(true)
        }
    }

    // --- Analytics ---

    fun setAnalyticsTimeframe(timeframe: AnalyticsTimeframe) {
        selectedTimeframe.value = timeframe
    }

    // --- Wallets & Categories Management & Reordering ---

    fun saveWallet(
        id: Long = 0L,
        name: String,
        balance: Double,
        type: String,
        iconKey: String,
        colorHex: Long,
        isDefault: Boolean = false,
        minBalanceThreshold: Double = 100.0,
        sortOrder: Int = 0,
    ) {
        viewModelScope.launch {
            repository.saveWallet(
                WalletEntity(
                    id = id,
                    name = name.trim(),
                    type = type,
                    balance = balance,
                    iconKey = iconKey,
                    colorHex = colorHex,
                    isDefault = isDefault,
                    minBalanceThreshold = minBalanceThreshold.coerceAtLeast(0.0),
                    sortOrder = sortOrder,
                ),
            )
            _events.tryEmit(MasroufyUiEvent.Message(if (id == 0L) "تم إضافة المحفظة" else "تم تحديث المحفظة"))
        }
    }

    fun deleteWallet(id: Long) {
        viewModelScope.launch {
            if (uiState.value.wallets.size <= 1) {
                _events.tryEmit(MasroufyUiEvent.Message("مينفعش تحذف كل المحافظ — لازم تبقى محفظة واحدة على الأقل"))
                return@launch
            }
            repository.deleteWallet(id)
            _events.tryEmit(MasroufyUiEvent.Message("تم حذف المحفظة"))
        }
    }

    fun moveWalletOrder(id: Long, moveUp: Boolean) {
        viewModelScope.launch { repository.moveWalletOrder(id, moveUp) }
    }

    fun saveCategory(
        id: Long = 0L,
        name: String,
        type: String,
        iconKey: String,
        colorHex: Long,
        isDefault: Boolean = false,
        monthlyBudget: Double? = null,
        sortOrder: Int = 0,
    ) {
        viewModelScope.launch {
            repository.saveCategory(
                CategoryEntity(
                    id = id,
                    name = name.trim(),
                    type = type,
                    iconKey = iconKey,
                    colorHex = colorHex,
                    isDefault = isDefault,
                    monthlyBudget = monthlyBudget?.takeIf { it > 0.0 },
                    sortOrder = sortOrder,
                ),
            )
            _events.tryEmit(MasroufyUiEvent.Message(if (id == 0L) "تم إضافة التصنيف" else "تم تحديث التصنيف"))
        }
    }

    fun deleteCategory(id: Long) {
        viewModelScope.launch {
            repository.deleteCategory(id)
            _events.tryEmit(MasroufyUiEvent.Message("تم حذف التصنيف"))
        }
    }

    fun moveCategoryOrder(id: Long, moveUp: Boolean) {
        viewModelScope.launch { repository.moveCategoryOrder(id, moveUp) }
    }

    // --- Settings, Notifications & Security ---

    fun setThemeMode(mode: String) {
        viewModelScope.launch { repository.setThemeMode(mode) }
    }

    fun togglePrivacyMode() {
        viewModelScope.launch {
            val next = !uiState.value.settings.isPrivacyMode
            repository.setPrivacyMode(next)
        }
    }

    fun setBudgetCycleStartDay(day: Int) {
        viewModelScope.launch {
            repository.setBudgetCycleStartDay(day)
            _events.tryEmit(MasroufyUiEvent.Message("تم تحديث يوم بداية الدورة الشهرية ليوم $day"))
        }
    }

    fun setDailyReminder(enabled: Boolean, hour: Int, minute: Int) {
        viewModelScope.launch {
            repository.setDailyReminder(enabled, hour, minute)
            WorkScheduler.scheduleDailyCheck(appContext, hour, minute)
            _events.tryEmit(
                MasroufyUiEvent.Message(
                    if (enabled) "تم تفعيل التذكير المسائي يومياً" else "تم إيقاف التذكير المسائي",
                ),
            )
        }
    }

    fun setPersistentQuickLogEnabled(enabled: Boolean) {
        viewModelScope.launch {
            repository.setPersistentQuickLogEnabled(enabled)
            NotificationHelper.updatePersistentQuickLogNotification(appContext, enabled)
            _events.tryEmit(
                MasroufyUiEvent.Message(
                    if (enabled) "تم تفعيل إشعار التسجيل السريع" else "تم إيقاف إشعار التسجيل السريع",
                ),
            )
        }
    }

    fun setWeeklyAutoBackupEnabled(enabled: Boolean) {
        viewModelScope.launch {
            repository.setWeeklyAutoBackupEnabled(enabled)
            WorkScheduler.scheduleWeeklyBackup(appContext, enabled)
            _events.tryEmit(
                MasroufyUiEvent.Message(
                    if (enabled) "تم تفعيل النسخ الاحتياطي التلقائي الأسبوعي" else "تم إيقاف النسخ التلقائي",
                ),
            )
        }
    }

    fun enablePin(pin: String) {
        viewModelScope.launch {
            repository.setPin(pin)
            unlockedInSession.value = true
            _events.tryEmit(MasroufyUiEvent.Message("تم تفعيل قفل التطبيق برمز PIN"))
        }
    }

    fun disablePin() {
        viewModelScope.launch {
            repository.disablePin()
            unlockedInSession.value = true
            _events.tryEmit(MasroufyUiEvent.Message("تم إلغاء قفل التطبيق"))
        }
    }

    fun setBiometricEnabled(enabled: Boolean) {
        viewModelScope.launch {
            repository.setBiometricEnabled(enabled)
            _events.tryEmit(MasroufyUiEvent.Message(if (enabled) "تم تفعيل فتح البصمة" else "تم إيقاف فتح البصمة"))
        }
    }

    suspend fun verifyPinAndUnlock(pin: String): Boolean {
        val ok = repository.verifyPin(pin)
        if (ok) {
            unlockedInSession.value = true
        }
        return ok
    }

    fun unlockWithBiometric() {
        unlockedInSession.value = true
    }

    fun lockAppOnBackground() {
        if (uiState.value.settings.isPinEnabled) {
            unlockedInSession.value = false
        }
    }

    // --- V3 Pro: Financial Balancing, Rollover, Emergency Fund, Trips, Installments & Receipt Scanner ---

    fun setDailyRolloverMode(mode: String) {
        viewModelScope.launch {
            repository.setDailyRolloverMode(mode)
            _events.tryEmit(MasroufyUiEvent.Message("تم تحديث وضع ترحيل الفائض اليومي"))
        }
    }

    fun apply503020Allocation(
        amount: Double,
        sourceWalletId: Long,
        putSavingsInEmergencyFund: Boolean,
        targetGoalId: Long?,
    ) {
        viewModelScope.launch {
            repository.applyIncome503020Allocation(
                amount = amount,
                sourceWalletId = sourceWalletId,
                putSavingsInEmergencyFund = putSavingsInEmergencyFund,
                targetGoalId = targetGoalId,
            )
            _events.tryEmit(MasroufyUiEvent.Message("تم توزيع المبلغ بنجاح حسب قاعدة 50 / 30 / 20 ✅"))
            grantXp(XpAwards.GOAL_DEPOSIT)
        }
    }

    fun rebalanceEnvelopes(fromEnvelopeId: Long, toEnvelopeId: Long, amount: Double) {
        viewModelScope.launch {
            if (repository.rebalanceEnvelopes(fromEnvelopeId, toEnvelopeId, amount)) {
                _events.tryEmit(MasroufyUiEvent.Message("تم نقل ${Formatters.formatEgp(amount)} لتغطية العجز بين الأظرف"))
            } else {
                _events.tryEmit(MasroufyUiEvent.Message("تعذر التحويل — تأكد من الرصيد المتاح في الظرف المصدر"))
            }
        }
    }

    fun rebalanceCategoryBudgets(fromCategoryId: Long, toCategoryId: Long, amount: Double) {
        viewModelScope.launch {
            if (repository.rebalanceCategoryBudgets(fromCategoryId, toCategoryId, amount)) {
                _events.tryEmit(MasroufyUiEvent.Message("تمت موازنة ميزانيات التصنيفات بنجاح"))
            } else {
                _events.tryEmit(MasroufyUiEvent.Message("تعذر تعديل الميزانية — تأكد من قيمة الميزانية المتاحة"))
            }
        }
    }

    fun contributeToEmergencyFund(walletId: Long, amount: Double) {
        viewModelScope.launch {
            repository.contributeToEmergencyFund(walletId, amount)
            _events.tryEmit(MasroufyUiEvent.Message("تم إضافة ${Formatters.formatEgp(amount)} إلى صندوق الطوارئ 🛡️ (+30 XP)"))
            grantXp(XpAwards.GOAL_DEPOSIT)
        }
    }

    fun withdrawFromEmergencyFund(walletId: Long, amount: Double) {
        viewModelScope.launch {
            repository.withdrawFromEmergencyFund(walletId, amount)
            _events.tryEmit(MasroufyUiEvent.Message("تم السحب من صندوق الطوارئ إلى المحفظة"))
        }
    }

    fun saveTripEvent(id: Long = 0L, title: String, budget: Double, isActive: Boolean = true) {
        viewModelScope.launch {
            val existing = uiState.value.tripEvents.firstOrNull { it.id == id }
            repository.saveTripEvent(
                TripEventEntity(
                    id = id,
                    title = title.trim(),
                    budget = budget,
                    isActive = isActive,
                    createdAt = existing?.createdAt ?: System.currentTimeMillis(),
                ),
            )
            _events.tryEmit(MasroufyUiEvent.Message(if (id == 0L) "تم تشغيل وضع الرحلة/المناسبة 🏖️" else "تم تحديث الرحلة"))
        }
    }

    fun toggleTripEventActive(tripId: Long, active: Boolean) {
        viewModelScope.launch {
            repository.toggleTripEventActive(tripId, active)
            _events.tryEmit(
                MasroufyUiEvent.Message(
                    if (active) "تم تفعيل وضع الرحلة الحالية 🏖️" else "تم إيقاف وضع الرحلة والعودة للوضع الطبيعي",
                ),
            )
        }
    }

    fun deleteTripEvent(tripId: Long) {
        viewModelScope.launch {
            repository.deleteTripEvent(tripId)
            _events.tryEmit(MasroufyUiEvent.Message("تم حذف سجل الرحلة"))
        }
    }

    fun saveInstallment(
        id: Long = 0L,
        itemName: String,
        monthlyAmount: Double,
        paidMonths: Int,
        totalMonths: Int,
        dueDay: Int,
        walletId: Long,
    ) {
        viewModelScope.launch {
            val existing = uiState.value.installments.firstOrNull { it.id == id }
            repository.saveInstallment(
                InstallmentEntity(
                    id = id,
                    itemName = itemName.trim(),
                    monthlyAmount = monthlyAmount,
                    paidMonths = paidMonths.coerceIn(0, totalMonths.coerceAtLeast(1)),
                    totalMonths = totalMonths.coerceAtLeast(1),
                    dueDay = dueDay.coerceIn(1, 28),
                    walletId = walletId,
                    lastPaidCycleKey = existing?.lastPaidCycleKey.orEmpty(),
                    isActive = paidMonths < totalMonths,
                    createdAt = existing?.createdAt ?: System.currentTimeMillis(),
                ),
            )
            _events.tryEmit(MasroufyUiEvent.Message(if (id == 0L) "تمت إضافة القسط الشهري" else "تم تحديث القسط"))
        }
    }

    fun deleteInstallment(id: Long) {
        viewModelScope.launch {
            repository.deleteInstallment(id)
            _events.tryEmit(MasroufyUiEvent.Message("تم حذف القسط"))
        }
    }

    fun payInstallmentMonth(installmentId: Long, walletId: Long) {
        viewModelScope.launch {
            if (repository.payInstallmentMonth(installmentId, walletId)) {
                _events.tryEmit(MasroufyUiEvent.Message("تم سداد قسط الشهر وحجز المتبقي بنجاح (+25 XP)"))
                grantXp(XpAwards.GAMEYA_OR_DEBT)
            }
        }
    }

    fun scanReceiptBitmap(bitmap: Bitmap, onResult: (ScannedReceiptResult?, String?) -> Unit) {
        viewModelScope.launch {
            val state = uiState.value
            val apiKey = state.settings.geminiApiKey.trim()
            if (apiKey.isEmpty()) {
                onResult(null, "أضف مفتاح Gemini المجاني من الإعدادات لتفعيل قراءة الفواتير بالذكاء الاصطناعي")
                return@launch
            }
            val expenseCategories = state.categories.filter { it.type == TransactionType.EXPENSE }
            val result = withContext(Dispatchers.Default) {
                val base64 = ReceiptScannerHelper.bitmapToCompressedBase64(bitmap)
                GeminiRestClient.scanReceipt(
                    apiKey = apiKey,
                    imageBase64 = base64,
                    expenseCategories = expenseCategories,
                )
            }
            result
                .onSuccess { scanned -> onResult(scanned, null) }
                .onFailure { err -> onResult(null, err.message ?: "تعذر قراءة الفاتورة") }
        }
    }

    // --- Backup & Restore ---

    suspend fun buildBackupJson(): String = repository.exportBackupJson()

    fun restoreBackupJson(jsonText: String) {
        viewModelScope.launch {
            repository.importBackupJson(jsonText)
                .onSuccess { _events.tryEmit(MasroufyUiEvent.Message("تم استعادة النسخة الاحتياطية بنجاح")) }
                .onFailure { _events.tryEmit(MasroufyUiEvent.Message("ملف النسخة الاحتياطية غير صالح أو تالف")) }
        }
    }

    fun resetAllData() {
        viewModelScope.launch {
            repository.resetAllData()
            unlockedInSession.value = true
            _events.tryEmit(MasroufyUiEvent.Message("تم مسح جميع البيانات وإعادة الضبط"))
        }
    }

    fun showMessage(message: String) {
        _events.tryEmit(MasroufyUiEvent.Message(message))
    }

    // --- AI Financial Coach & BYOK Gemini Setup ---

    suspend fun testAndSaveGeminiApiKey(rawKey: String): Result<Unit> {
        val result = GeminiRestClient.verifyApiKey(rawKey)
        if (result.isSuccess) {
            repository.setGeminiApiKey(rawKey)
            _events.tryEmit(MasroufyUiEvent.Message("تم تفعيل المستشار الذكي بنجاح! ✅"))
        }
        return result
    }

    fun clearGeminiApiKey() {
        viewModelScope.launch {
            repository.setGeminiApiKey("")
            _events.tryEmit(MasroufyUiEvent.Message("تم إزالة مفتاح Gemini والعودة للوضع الأوفلاين الذكي"))
        }
    }

    fun clearAiChat() {
        viewModelScope.launch {
            repository.clearAiChat()
            _events.tryEmit(MasroufyUiEvent.Message("تم مسح المحادثة"))
        }
    }

    fun sendAiCoachMessage(rawText: String) {
        val trimmed = rawText.trim()
        if (trimmed.isEmpty() || isAiThinkingFlow.value) return

        viewModelScope.launch {
            isAiThinkingFlow.value = true
            try {
                val priorHistory = repository.getAiChatHistory()
                repository.insertAiChatMessage(
                    AiChatMessageEntity(
                        text = trimmed,
                        isUser = true,
                        timestamp = System.currentTimeMillis(),
                        isOfflineEngine = false,
                    ),
                )

                val state = uiState.value
                val coachSnapshot = FinancialCoachSnapshot(
                    wallets = state.wallets,
                    categories = state.categories,
                    transactions = state.transactions,
                    envelopes = state.envelopes,
                    goals = state.goals,
                    debts = state.debts,
                    budgetSnapshot = state.budgetSnapshot,
                    analyticsSnapshot = state.analyticsSnapshot,
                    emergencyFundSaved = state.settings.emergencyFundSaved,
                    installments = state.installments,
                )

                val apiKey = state.settings.geminiApiKey.trim()
                val (replyText, usedOffline) = if (apiKey.isNotBlank()) {
                    val systemPrompt = FinancialContextBuilder.buildSystemPrompt(coachSnapshot)
                    val onlineResult = GeminiRestClient.generateCoachReply(
                        apiKey = apiKey,
                        systemPrompt = systemPrompt,
                        history = priorHistory,
                        userMessage = trimmed,
                    )
                    if (onlineResult.isSuccess) {
                        onlineResult.getOrThrow() to false
                    } else {
                        val offlineReply = OfflineFinancialBrain.analyzeAndReply(trimmed, coachSnapshot)
                        val reason = onlineResult.exceptionOrNull()?.message ?: "تعذر الاتصال بـ Gemini"
                        "⚡ ($reason — تم الرد بالوضع الأوفلاين الذكي)\n\n$offlineReply" to true
                    }
                } else {
                    OfflineFinancialBrain.analyzeAndReply(trimmed, coachSnapshot) to true
                }

                repository.insertAiChatMessage(
                    AiChatMessageEntity(
                        text = replyText,
                        isUser = false,
                        timestamp = System.currentTimeMillis(),
                        isOfflineEngine = usedOffline,
                    ),
                )
            } finally {
                isAiThinkingFlow.value = false
            }
        }
    }
}
