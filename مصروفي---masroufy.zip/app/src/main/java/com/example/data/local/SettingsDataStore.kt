package com.example.data.local

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.doublePreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.Base64

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "masroufy_settings")

data class UserSettings(
    val themeMode: String = ThemeMode.DARK,
    val budgetCycleStartDay: Int = 1,
    val isPinEnabled: Boolean = false,
    val isBiometricEnabled: Boolean = false,
    val hasPinConfigured: Boolean = false,
    val isPrivacyMode: Boolean = false,
    val hasCompletedOnboarding: Boolean = false,
    val dailyReminderEnabled: Boolean = false,
    val dailyReminderHour: Int = 22,
    val dailyReminderMinute: Int = 0,
    val persistentQuickLogEnabled: Boolean = false,
    val weeklyAutoBackupEnabled: Boolean = true,
    val lastWeeklyBackupAt: Long = 0L,
    val geminiApiKey: String = "",
    val xpPoints: Int = 0,
    val selectedThemeId: String = "EMERALD_CLASSIC",
    val autoNotificationCaptureEnabled: Boolean = true,
    val hasPromptedStartupPermissions: Boolean = false,
    val dailyRolloverMode: String = RolloverMode.NONE,
    val emergencyFundSaved: Double = 0.0,
    val cycleSavingsAmount: Double = 0.0,
    val cycleSavingsKey: String = "",
) {
    // Backwards-compatible helper for backup/preview consumers
    val isDarkTheme: Boolean
        get() = themeMode != ThemeMode.LIGHT

    val hasGeminiApiKey: Boolean
        get() = geminiApiKey.isNotBlank()
}

class SettingsDataStore(private val context: Context) {

    private object Keys {
        val THEME_MODE = stringPreferencesKey("theme_mode")
        val IS_DARK_THEME_LEGACY = booleanPreferencesKey("is_dark_theme")
        val CYCLE_START_DAY = intPreferencesKey("budget_cycle_start_day")
        val IS_PIN_ENABLED = booleanPreferencesKey("is_pin_enabled")
        val IS_BIOMETRIC_ENABLED = booleanPreferencesKey("is_biometric_enabled")
        val PIN_HASH = stringPreferencesKey("pin_hash")
        val PIN_SALT = stringPreferencesKey("pin_salt")
        val IS_PRIVACY_MODE = booleanPreferencesKey("is_privacy_mode")
        val HAS_COMPLETED_ONBOARDING = booleanPreferencesKey("has_completed_onboarding")
        val DAILY_REMINDER_ENABLED = booleanPreferencesKey("daily_reminder_enabled")
        val DAILY_REMINDER_HOUR = intPreferencesKey("daily_reminder_hour")
        val DAILY_REMINDER_MINUTE = intPreferencesKey("daily_reminder_minute")
        val PERSISTENT_QUICK_LOG_ENABLED = booleanPreferencesKey("persistent_quick_log_enabled")
        val WEEKLY_AUTO_BACKUP_ENABLED = booleanPreferencesKey("weekly_auto_backup_enabled")
        val LAST_WEEKLY_BACKUP_AT = longPreferencesKey("last_weekly_backup_at")
        val GEMINI_API_KEY = stringPreferencesKey("gemini_api_key")
        val XP_POINTS = intPreferencesKey("xp_points")
        val SELECTED_THEME_ID = stringPreferencesKey("selected_theme_id")
        val AUTO_NOTIFICATION_CAPTURE = booleanPreferencesKey("auto_notification_capture")
        val HAS_PROMPTED_STARTUP_PERMISSIONS = booleanPreferencesKey("has_prompted_startup_permissions")
        val DAILY_ROLLOVER_MODE = stringPreferencesKey("daily_rollover_mode")
        val EMERGENCY_FUND_SAVED = doublePreferencesKey("emergency_fund_saved")
        val CYCLE_SAVINGS_AMOUNT = doublePreferencesKey("cycle_savings_amount")
        val CYCLE_SAVINGS_KEY = stringPreferencesKey("cycle_savings_key")
    }

    val settingsFlow: Flow<UserSettings> = context.dataStore.data.map { prefs ->
        val pinHash = prefs[Keys.PIN_HASH]
        val legacyDark = prefs[Keys.IS_DARK_THEME_LEGACY]
        val mode = prefs[Keys.THEME_MODE] ?: if (legacyDark == false) ThemeMode.LIGHT else ThemeMode.DARK
        UserSettings(
            themeMode = mode,
            budgetCycleStartDay = (prefs[Keys.CYCLE_START_DAY] ?: 1).coerceIn(1, 28),
            isPinEnabled = (prefs[Keys.IS_PIN_ENABLED] ?: false) && !pinHash.isNullOrEmpty(),
            isBiometricEnabled = prefs[Keys.IS_BIOMETRIC_ENABLED] ?: false,
            hasPinConfigured = !pinHash.isNullOrEmpty(),
            isPrivacyMode = prefs[Keys.IS_PRIVACY_MODE] ?: false,
            hasCompletedOnboarding = prefs[Keys.HAS_COMPLETED_ONBOARDING] ?: false,
            dailyReminderEnabled = prefs[Keys.DAILY_REMINDER_ENABLED] ?: false,
            dailyReminderHour = (prefs[Keys.DAILY_REMINDER_HOUR] ?: 22).coerceIn(0, 23),
            dailyReminderMinute = (prefs[Keys.DAILY_REMINDER_MINUTE] ?: 0).coerceIn(0, 59),
            persistentQuickLogEnabled = prefs[Keys.PERSISTENT_QUICK_LOG_ENABLED] ?: false,
            weeklyAutoBackupEnabled = prefs[Keys.WEEKLY_AUTO_BACKUP_ENABLED] ?: true,
            lastWeeklyBackupAt = prefs[Keys.LAST_WEEKLY_BACKUP_AT] ?: 0L,
            geminiApiKey = prefs[Keys.GEMINI_API_KEY].orEmpty(),
            xpPoints = (prefs[Keys.XP_POINTS] ?: 0).coerceAtLeast(0),
            selectedThemeId = prefs[Keys.SELECTED_THEME_ID] ?: "EMERALD_CLASSIC",
            autoNotificationCaptureEnabled = prefs[Keys.AUTO_NOTIFICATION_CAPTURE] ?: true,
            hasPromptedStartupPermissions = prefs[Keys.HAS_PROMPTED_STARTUP_PERMISSIONS] ?: false,
            dailyRolloverMode = prefs[Keys.DAILY_ROLLOVER_MODE] ?: RolloverMode.NONE,
            emergencyFundSaved = (prefs[Keys.EMERGENCY_FUND_SAVED] ?: 0.0).coerceAtLeast(0.0),
            cycleSavingsAmount = (prefs[Keys.CYCLE_SAVINGS_AMOUNT] ?: 0.0).coerceAtLeast(0.0),
            cycleSavingsKey = prefs[Keys.CYCLE_SAVINGS_KEY].orEmpty(),
        )
    }

    suspend fun setThemeMode(mode: String) {
        context.dataStore.edit { prefs ->
            prefs[Keys.THEME_MODE] = mode
            prefs[Keys.IS_DARK_THEME_LEGACY] = mode != ThemeMode.LIGHT
        }
    }

    suspend fun setSelectedThemeId(themeId: String) {
        context.dataStore.edit { prefs ->
            prefs[Keys.SELECTED_THEME_ID] = themeId
        }
    }

    suspend fun addXp(delta: Int): Pair<Int, Int> {
        if (delta <= 0) {
            val current = getCurrentSettings().xpPoints
            return current to current
        }
        var oldXp = 0
        var newXp = 0
        context.dataStore.edit { prefs ->
            oldXp = (prefs[Keys.XP_POINTS] ?: 0).coerceAtLeast(0)
            newXp = oldXp + delta
            prefs[Keys.XP_POINTS] = newXp
        }
        return oldXp to newXp
    }

    suspend fun setXpPoints(xp: Int) {
        context.dataStore.edit { prefs ->
            prefs[Keys.XP_POINTS] = xp.coerceAtLeast(0)
        }
    }

    suspend fun setAutoNotificationCaptureEnabled(enabled: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[Keys.AUTO_NOTIFICATION_CAPTURE] = enabled
        }
    }

    suspend fun setHasPromptedStartupPermissions(prompted: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[Keys.HAS_PROMPTED_STARTUP_PERMISSIONS] = prompted
        }
    }

    suspend fun setDailyRolloverMode(mode: String) {
        context.dataStore.edit { prefs ->
            prefs[Keys.DAILY_ROLLOVER_MODE] = mode
        }
    }

    suspend fun adjustEmergencyFund(delta: Double): Double {
        var updated = 0.0
        context.dataStore.edit { prefs ->
            val current = (prefs[Keys.EMERGENCY_FUND_SAVED] ?: 0.0).coerceAtLeast(0.0)
            updated = (current + delta).coerceAtLeast(0.0)
            prefs[Keys.EMERGENCY_FUND_SAVED] = updated
        }
        return updated
    }

    suspend fun setEmergencyFundSaved(amount: Double) {
        context.dataStore.edit { prefs ->
            prefs[Keys.EMERGENCY_FUND_SAVED] = amount.coerceAtLeast(0.0)
        }
    }

    suspend fun recordCycleSavings(cycleKey: String, addedAmount: Double) {
        if (addedAmount <= 0.0) return
        context.dataStore.edit { prefs ->
            val prevKey = prefs[Keys.CYCLE_SAVINGS_KEY].orEmpty()
            val prevAmount = if (prevKey == cycleKey) (prefs[Keys.CYCLE_SAVINGS_AMOUNT] ?: 0.0).coerceAtLeast(0.0) else 0.0
            prefs[Keys.CYCLE_SAVINGS_KEY] = cycleKey
            prefs[Keys.CYCLE_SAVINGS_AMOUNT] = prevAmount + addedAmount
        }
    }

    suspend fun setBudgetCycleStartDay(day: Int) {
        context.dataStore.edit { prefs ->
            prefs[Keys.CYCLE_START_DAY] = day.coerceIn(1, 28)
        }
    }

    suspend fun setPrivacyMode(enabled: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[Keys.IS_PRIVACY_MODE] = enabled
        }
    }

    suspend fun setHasCompletedOnboarding(completed: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[Keys.HAS_COMPLETED_ONBOARDING] = completed
        }
    }

    suspend fun setDailyReminder(enabled: Boolean, hour: Int, minute: Int) {
        context.dataStore.edit { prefs ->
            prefs[Keys.DAILY_REMINDER_ENABLED] = enabled
            prefs[Keys.DAILY_REMINDER_HOUR] = hour.coerceIn(0, 23)
            prefs[Keys.DAILY_REMINDER_MINUTE] = minute.coerceIn(0, 59)
        }
    }

    suspend fun setPersistentQuickLogEnabled(enabled: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[Keys.PERSISTENT_QUICK_LOG_ENABLED] = enabled
        }
    }

    suspend fun setWeeklyAutoBackupEnabled(enabled: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[Keys.WEEKLY_AUTO_BACKUP_ENABLED] = enabled
        }
    }

    suspend fun setLastWeeklyBackupAt(timestamp: Long) {
        context.dataStore.edit { prefs ->
            prefs[Keys.LAST_WEEKLY_BACKUP_AT] = timestamp
        }
    }

    suspend fun setGeminiApiKey(apiKey: String) {
        val trimmed = apiKey.trim()
        context.dataStore.edit { prefs ->
            if (trimmed.isEmpty()) {
                prefs.remove(Keys.GEMINI_API_KEY)
            } else {
                prefs[Keys.GEMINI_API_KEY] = trimmed
            }
        }
    }

    suspend fun setPin(pin: String) {
        val saltBytes = ByteArray(16).also { SecureRandom().nextBytes(it) }
        val salt = Base64.getEncoder().encodeToString(saltBytes)
        val hash = hashPin(pin, salt)
        context.dataStore.edit { prefs ->
            prefs[Keys.PIN_SALT] = salt
            prefs[Keys.PIN_HASH] = hash
            prefs[Keys.IS_PIN_ENABLED] = true
        }
    }

    suspend fun verifyPin(pin: String): Boolean {
        val prefs = context.dataStore.data.first()
        val storedHash = prefs[Keys.PIN_HASH] ?: return false
        val storedSalt = prefs[Keys.PIN_SALT] ?: return false
        return hashPin(pin, storedSalt) == storedHash
    }

    suspend fun disablePin() {
        context.dataStore.edit { prefs ->
            prefs[Keys.IS_PIN_ENABLED] = false
            prefs[Keys.IS_BIOMETRIC_ENABLED] = false
            prefs.remove(Keys.PIN_HASH)
            prefs.remove(Keys.PIN_SALT)
        }
    }

    suspend fun setBiometricEnabled(enabled: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[Keys.IS_BIOMETRIC_ENABLED] = enabled
        }
    }

    suspend fun getCurrentSettings(): UserSettings = settingsFlow.first()

    suspend fun resetSettings() {
        context.dataStore.edit { prefs ->
            prefs[Keys.THEME_MODE] = ThemeMode.DARK
            prefs[Keys.IS_DARK_THEME_LEGACY] = true
            prefs[Keys.CYCLE_START_DAY] = 1
            prefs[Keys.IS_PIN_ENABLED] = false
            prefs[Keys.IS_BIOMETRIC_ENABLED] = false
            prefs[Keys.IS_PRIVACY_MODE] = false
            prefs[Keys.HAS_COMPLETED_ONBOARDING] = false
            prefs[Keys.DAILY_REMINDER_ENABLED] = false
            prefs[Keys.DAILY_REMINDER_HOUR] = 22
            prefs[Keys.DAILY_REMINDER_MINUTE] = 0
            prefs[Keys.PERSISTENT_QUICK_LOG_ENABLED] = false
            prefs[Keys.WEEKLY_AUTO_BACKUP_ENABLED] = true
            prefs[Keys.XP_POINTS] = 0
            prefs[Keys.SELECTED_THEME_ID] = "EMERALD_CLASSIC"
            prefs[Keys.AUTO_NOTIFICATION_CAPTURE] = true
            prefs[Keys.DAILY_ROLLOVER_MODE] = RolloverMode.NONE
            prefs[Keys.EMERGENCY_FUND_SAVED] = 0.0
            prefs[Keys.CYCLE_SAVINGS_AMOUNT] = 0.0
            prefs[Keys.CYCLE_SAVINGS_KEY] = ""
            prefs.remove(Keys.PIN_HASH)
            prefs.remove(Keys.PIN_SALT)
            prefs.remove(Keys.GEMINI_API_KEY)
        }
    }

    private fun hashPin(pin: String, salt: String): String {
        val digest = MessageDigest.getInstance("SHA-256")
        val bytes = digest.digest("$salt:$pin".toByteArray(Charsets.UTF_8))
        return bytes.joinToString("") { "%02x".format(it) }
    }
}
