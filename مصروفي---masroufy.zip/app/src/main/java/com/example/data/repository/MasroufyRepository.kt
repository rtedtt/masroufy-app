package com.example.data.repository

import androidx.room.withTransaction
import com.example.data.local.AiChatMessageEntity
import com.example.data.local.BillingCycle
import com.example.data.local.CategoryEntity
import com.example.data.local.DebtEntity
import com.example.data.local.DebtType
import com.example.data.local.DefaultSeedData
import com.example.data.local.EnvelopeEntity
import com.example.data.local.GameyaEntity
import com.example.data.local.GoalEntity
import com.example.data.local.InstallmentEntity
import com.example.data.local.MasroufyBackup
import com.example.data.local.MasroufyDatabase
import com.example.data.local.QuickTemplateEntity
import com.example.data.local.RecurringFrequency
import com.example.data.local.RecurringTransactionEntity
import com.example.data.local.SettingsDataStore
import com.example.data.local.SubscriptionEntity
import com.example.data.local.ThemeMode
import com.example.data.local.TransactionEntity
import com.example.data.local.TransactionType
import com.example.data.local.TripEventEntity
import com.example.data.local.UserSettings
import com.example.data.local.WalletEntity
import com.example.data.local.ZeroSpendDayEntity
import com.example.domain.ArabicRank
import com.example.domain.FinanceCalculator
import com.example.domain.GamificationEngine
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.serialization.json.Json
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import kotlin.math.abs

class MasroufyRepository(
    private val db: MasroufyDatabase,
    private val settingsDataStore: SettingsDataStore,
) {
    private val walletDao = db.walletDao()
    private val categoryDao = db.categoryDao()
    private val transactionDao = db.transactionDao()
    private val envelopeDao = db.envelopeDao()
    private val goalDao = db.goalDao()
    private val debtDao = db.debtDao()
    private val zeroSpendDao = db.zeroSpendDao()
    private val quickTemplateDao = db.quickTemplateDao()
    private val recurringDao = db.recurringTransactionDao()
    private val aiChatDao = db.aiChatMessageDao()
    private val gameyaDao = db.gameyaDao()
    private val subscriptionDao = db.subscriptionDao()
    private val tripEventDao = db.tripEventDao()
    private val installmentDao = db.installmentDao()

    private val seedMutex = Mutex()
    private val backupJson = Json {
        prettyPrint = true
        ignoreUnknownKeys = true
        encodeDefaults = true
    }

    val walletsFlow: Flow<List<WalletEntity>> = walletDao.observeAll()
    val categoriesFlow: Flow<List<CategoryEntity>> = categoryDao.observeAll()
    val transactionsFlow: Flow<List<TransactionEntity>> = transactionDao.observeAll()
    val envelopesFlow: Flow<List<EnvelopeEntity>> = envelopeDao.observeAll()
    val goalsFlow: Flow<List<GoalEntity>> = goalDao.observeAll()
    val debtsFlow: Flow<List<DebtEntity>> = debtDao.observeAll()
    val zeroSpendDaysFlow: Flow<List<ZeroSpendDayEntity>> = zeroSpendDao.observeAll()
    val quickTemplatesFlow: Flow<List<QuickTemplateEntity>> = quickTemplateDao.observeAll()
    val recurringFlow: Flow<List<RecurringTransactionEntity>> = recurringDao.observeAll()
    val aiChatMessagesFlow: Flow<List<AiChatMessageEntity>> = aiChatDao.observeAll()
    val gameyasFlow: Flow<List<GameyaEntity>> = gameyaDao.observeAll()
    val subscriptionsFlow: Flow<List<SubscriptionEntity>> = subscriptionDao.observeAll()
    val tripEventsFlow: Flow<List<TripEventEntity>> = tripEventDao.observeAll()
    val installmentsFlow: Flow<List<InstallmentEntity>> = installmentDao.observeAll()
    val settingsFlow: Flow<UserSettings> = settingsDataStore.settingsFlow

    suspend fun ensureSeeded() {
        seedMutex.withLock {
            db.withTransaction {
                if (walletDao.count() == 0) {
                    walletDao.insertAll(DefaultSeedData.defaultWallets())
                }
                if (categoryDao.count() == 0) {
                    categoryDao.insertAll(DefaultSeedData.defaultCategories())
                }
            }
        }
    }

    // --- Onboarding ---

    suspend fun completeOnboarding(walletBalances: Map<Long, Double>, cycleStartDay: Int) {
        db.withTransaction {
            val wallets = walletDao.getAll()
            wallets.forEach { w ->
                val newBal = walletBalances[w.id]
                if (newBal != null) {
                    walletDao.update(w.copy(balance = newBal.coerceAtLeast(0.0)))
                }
            }
        }
        settingsDataStore.setBudgetCycleStartDay(cycleStartDay)
        settingsDataStore.setHasCompletedOnboarding(true)
    }

    suspend fun skipOnboarding() {
        settingsDataStore.setHasCompletedOnboarding(true)
    }

    // --- Transactions ---

    suspend fun addTransaction(transaction: TransactionEntity, cashbackAmount: Double = 0.0): Long {
        val insertedId = db.withTransaction {
            val id = transactionDao.insert(transaction)
            applyTransactionBalanceEffect(transaction, sign = 1)
            clearZeroSpendIfExpense(transaction)
            if (transaction.type == TransactionType.EXPENSE && cashbackAmount > 0.0) {
                val incomeCatId = categoryDao.getAll().lastOrNull { it.type == TransactionType.INCOME }?.id
                val cashbackNote = if (transaction.note.isNotBlank()) {
                    "كاش باك مسترد: ${transaction.note}"
                } else {
                    "كاش باك مسترد"
                }
                val cashbackTx = TransactionEntity(
                    amount = cashbackAmount,
                    type = TransactionType.INCOME,
                    categoryId = incomeCatId,
                    walletId = transaction.walletId,
                    note = cashbackNote,
                    timestamp = transaction.timestamp + 1L,
                )
                transactionDao.insert(cashbackTx)
                applyTransactionBalanceEffect(cashbackTx, sign = 1)
            }
            id
        }
        return insertedId
    }

    suspend fun addSplitBillTransaction(
        totalAmount: Double,
        friendsCount: Int,
        friendNames: List<String>,
        categoryId: Long?,
        walletId: Long,
        note: String,
    ) {
        val totalPeople = (friendsCount + 1).coerceAtLeast(2)
        val perPersonShare = totalAmount / totalPeople
        val now = System.currentTimeMillis()
        val expenseNote = buildString {
            append("حصة تقسيم فاتورة")
            if (note.isNotBlank()) append(" ($note)")
        }

        db.withTransaction {
            val tx = TransactionEntity(
                amount = perPersonShare,
                type = TransactionType.EXPENSE,
                categoryId = categoryId,
                walletId = walletId,
                note = expenseNote,
                timestamp = now,
            )
            transactionDao.insert(tx)
            applyTransactionBalanceEffect(tx, sign = 1)
            clearZeroSpendIfExpense(tx)

            for (i in 0 until friendsCount) {
                val friendName = friendNames.getOrNull(i)?.trim().orEmpty().ifBlank { "صديق ${i + 1}" }
                debtDao.insert(
                    DebtEntity(
                        personName = friendName,
                        amount = perPersonShare,
                        type = DebtType.OWED_TO_ME,
                        note = if (note.isNotBlank()) "تقسيم فاتورة: $note" else "تقسيم فاتورة",
                        dateMillis = now,
                    ),
                )
            }
        }
    }

    suspend fun updateTransaction(newTransaction: TransactionEntity) {
        db.withTransaction {
            val old = transactionDao.getById(newTransaction.id)
            if (old != null) {
                applyTransactionBalanceEffect(old, sign = -1)
            }
            transactionDao.update(newTransaction)
            applyTransactionBalanceEffect(newTransaction, sign = 1)
            clearZeroSpendIfExpense(newTransaction)
        }
    }

    suspend fun deleteTransaction(transaction: TransactionEntity): TransactionEntity? {
        return db.withTransaction {
            val existing = transactionDao.getById(transaction.id) ?: return@withTransaction null
            applyTransactionBalanceEffect(existing, sign = -1)
            transactionDao.deleteById(existing.id)
            existing
        }
    }

    suspend fun restoreTransactions(transactions: List<TransactionEntity>) {
        db.withTransaction {
            transactions.forEach { tx ->
                transactionDao.insert(tx)
                applyTransactionBalanceEffect(tx, sign = 1)
            }
        }
    }

    suspend fun duplicateTransaction(tx: TransactionEntity) {
        val copy = tx.copy(
            id = 0L,
            timestamp = System.currentTimeMillis(),
        )
        addTransaction(copy)
    }

    suspend fun bulkDeleteTransactions(ids: Set<Long>): List<TransactionEntity> {
        return db.withTransaction {
            val removed = mutableListOf<TransactionEntity>()
            ids.forEach { id ->
                val existing = transactionDao.getById(id)
                if (existing != null) {
                    applyTransactionBalanceEffect(existing, sign = -1)
                    transactionDao.deleteById(id)
                    removed.add(existing)
                }
            }
            removed
        }
    }

    suspend fun bulkMoveTransactions(ids: Set<Long>, targetWalletId: Long) {
        db.withTransaction {
            ids.forEach { id ->
                val existing = transactionDao.getById(id) ?: return@forEach
                if (existing.walletId == targetWalletId) return@forEach
                applyTransactionBalanceEffect(existing, sign = -1)
                val updated = existing.copy(walletId = targetWalletId)
                transactionDao.update(updated)
                applyTransactionBalanceEffect(updated, sign = 1)
            }
        }
    }

    suspend fun reconcileWalletBalance(walletId: Long, actualBalance: Double): Double {
        return db.withTransaction {
            val wallet = walletDao.getById(walletId) ?: return@withTransaction 0.0
            val diff = actualBalance - wallet.balance
            if (abs(diff) < 0.01) return@withTransaction 0.0

            val categories = categoryDao.getAll()
            val txType = if (diff > 0) TransactionType.INCOME else TransactionType.EXPENSE
            val catId = if (txType == TransactionType.INCOME) {
                categories.lastOrNull { it.type == TransactionType.INCOME }?.id
            } else {
                categories.lastOrNull { it.type == TransactionType.EXPENSE }?.id
            }
            val tx = TransactionEntity(
                amount = abs(diff),
                type = txType,
                categoryId = catId,
                walletId = walletId,
                note = "فرق جرد الرصيد الفعلي",
                timestamp = System.currentTimeMillis(),
            )
            transactionDao.insert(tx)
            walletDao.adjustBalance(walletId, diff)
            diff
        }
    }

    private suspend fun clearZeroSpendIfExpense(transaction: TransactionEntity) {
        if (transaction.type == TransactionType.EXPENSE) {
            val txDay = Instant.ofEpochMilli(transaction.timestamp)
                .atZone(ZoneId.systemDefault())
                .toLocalDate()
                .toEpochDay()
            zeroSpendDao.deleteByDay(txDay)
        }
    }

    private suspend fun applyTransactionBalanceEffect(tx: TransactionEntity, sign: Int) {
        when (tx.type) {
            TransactionType.EXPENSE -> {
                walletDao.adjustBalance(tx.walletId, -tx.amount * sign)
            }
            TransactionType.INCOME -> {
                walletDao.adjustBalance(tx.walletId, tx.amount * sign)
            }
            TransactionType.TRANSFER -> {
                walletDao.adjustBalance(tx.walletId, -tx.amount * sign)
                tx.toWalletId?.let { targetId ->
                    walletDao.adjustBalance(targetId, tx.amount * sign)
                }
            }
        }
    }

    // --- Quick Templates ---

    suspend fun saveQuickTemplate(template: QuickTemplateEntity) {
        if (template.id == 0L) quickTemplateDao.insert(template) else quickTemplateDao.update(template)
    }

    suspend fun deleteQuickTemplate(id: Long) {
        quickTemplateDao.deleteById(id)
    }

    suspend fun logFromQuickTemplate(template: QuickTemplateEntity) {
        addTransaction(
            TransactionEntity(
                amount = template.amount,
                type = template.type,
                categoryId = template.categoryId,
                walletId = template.walletId,
                note = template.note.ifBlank { template.title },
                timestamp = System.currentTimeMillis(),
            ),
        )
    }

    // --- Recurring Transactions ---

    suspend fun saveRecurring(recurring: RecurringTransactionEntity) {
        if (recurring.id == 0L) recurringDao.insert(recurring) else recurringDao.update(recurring)
    }

    suspend fun deleteRecurring(id: Long) {
        recurringDao.deleteById(id)
    }

    suspend fun processAutoDueRecurring(today: LocalDate = LocalDate.now()): Int {
        val todayEpoch = today.toEpochDay()
        var postedCount = 0
        db.withTransaction {
            val all = recurringDao.getAll().filter { it.isActive && it.autoPost && it.nextDueEpochDay <= todayEpoch }
            all.forEach { item ->
                val tx = TransactionEntity(
                    amount = item.amount,
                    type = item.type,
                    categoryId = item.categoryId,
                    walletId = item.walletId,
                    note = item.note.ifBlank { "تكرار تلقائي: ${item.title}" },
                    timestamp = System.currentTimeMillis(),
                )
                transactionDao.insert(tx)
                applyTransactionBalanceEffect(tx, sign = 1)
                clearZeroSpendIfExpense(tx)
                val nextDue = computeNextDueEpochDay(item.nextDueEpochDay, item.frequency, todayEpoch)
                recurringDao.update(item.copy(nextDueEpochDay = nextDue))
                postedCount++
            }
        }
        return postedCount
    }

    suspend fun confirmRecurringDue(item: RecurringTransactionEntity, today: LocalDate = LocalDate.now()) {
        val todayEpoch = today.toEpochDay()
        db.withTransaction {
            val tx = TransactionEntity(
                amount = item.amount,
                type = item.type,
                categoryId = item.categoryId,
                walletId = item.walletId,
                note = item.note.ifBlank { item.title },
                timestamp = System.currentTimeMillis(),
            )
            transactionDao.insert(tx)
            applyTransactionBalanceEffect(tx, sign = 1)
            clearZeroSpendIfExpense(tx)
            val nextDue = computeNextDueEpochDay(item.nextDueEpochDay, item.frequency, todayEpoch)
            recurringDao.update(item.copy(nextDueEpochDay = nextDue))
        }
    }

    private fun computeNextDueEpochDay(currentDueEpoch: Long, frequency: String, todayEpoch: Long): Long {
        var date = LocalDate.ofEpochDay(currentDueEpoch)
        val todayDate = LocalDate.ofEpochDay(todayEpoch)
        do {
            date = when (frequency) {
                RecurringFrequency.DAILY -> date.plusDays(1)
                RecurringFrequency.WEEKLY -> date.plusWeeks(1)
                else -> date.plusMonths(1)
            }
        } while (!date.isAfter(todayDate))
        return date.toEpochDay()
    }

    // --- Zero-Spend Streak ---

    suspend fun markTodayZeroSpend() {
        val today = LocalDate.now().toEpochDay()
        zeroSpendDao.insert(ZeroSpendDayEntity(dateEpochDay = today))
    }

    suspend fun unmarkTodayZeroSpend() {
        val today = LocalDate.now().toEpochDay()
        zeroSpendDao.deleteByDay(today)
    }

    // --- Envelopes ---

    suspend fun saveEnvelope(envelope: EnvelopeEntity) {
        if (envelope.id == 0L) envelopeDao.insert(envelope) else envelopeDao.update(envelope)
    }

    suspend fun deleteEnvelope(id: Long) {
        envelopeDao.deleteById(id)
    }

    suspend fun topUpEnvelope(envelopeId: Long, addedAmount: Double) {
        if (addedAmount <= 0.0) return
        db.withTransaction {
            val env = envelopeDao.getById(envelopeId) ?: return@withTransaction
            val newReserved = env.reservedAmount + addedAmount
            val newTarget = maxOf(env.targetAmount, newReserved)
            envelopeDao.update(env.copy(reservedAmount = newReserved, targetAmount = newTarget))
        }
    }

    suspend fun spendFromEnvelope(
        envelopeId: Long,
        walletId: Long,
        amount: Double,
        categoryId: Long?,
        note: String,
    ) {
        if (amount <= 0.0) return
        db.withTransaction {
            val env = envelopeDao.getById(envelopeId) ?: return@withTransaction
            val updatedReserved = (env.reservedAmount - amount).coerceAtLeast(0.0)
            envelopeDao.update(env.copy(reservedAmount = updatedReserved))

            val txNote = note.ifBlank { "صرف من ظرف: ${env.title}" }
            val tx = TransactionEntity(
                amount = amount,
                type = TransactionType.EXPENSE,
                categoryId = categoryId,
                walletId = walletId,
                note = txNote,
                envelopeId = envelopeId,
            )
            transactionDao.insert(tx)
            walletDao.adjustBalance(walletId, -amount)

            val todayEpoch = LocalDate.now().toEpochDay()
            zeroSpendDao.deleteByDay(todayEpoch)
        }
    }

    // --- Savings Goals ---

    suspend fun saveGoal(goal: GoalEntity) {
        if (goal.id == 0L) goalDao.insert(goal) else goalDao.update(goal)
    }

    suspend fun deleteGoal(id: Long) {
        goalDao.deleteById(id)
    }

    suspend fun contributeToGoal(goalId: Long, walletId: Long, amount: Double): Boolean {
        if (amount <= 0.0) return false
        var justCompleted = false
        db.withTransaction {
            val goal = goalDao.getById(goalId) ?: return@withTransaction
            val newSaved = goal.savedAmount + amount
            justCompleted = goal.savedAmount < goal.targetAmount && newSaved >= goal.targetAmount
            walletDao.adjustBalance(walletId, -amount)
            goalDao.update(goal.copy(savedAmount = newSaved))
        }
        settingsDataStore.recordCycleSavings(FinanceCalculator.currentGameyaCycleKey(), amount)
        return justCompleted
    }

    // --- Debts & Loans ---

    suspend fun saveDebt(debt: DebtEntity) {
        if (debt.id == 0L) debtDao.insert(debt) else debtDao.update(debt)
    }

    suspend fun deleteDebt(id: Long) {
        debtDao.deleteById(id)
    }

    suspend fun settleDebt(debtId: Long, walletId: Long) {
        db.withTransaction {
            val debt = debtDao.getById(debtId) ?: return@withTransaction
            if (debt.isSettled) return@withTransaction

            val now = System.currentTimeMillis()
            debtDao.update(
                debt.copy(
                    isSettled = true,
                    settledWalletId = walletId,
                    settledAt = now,
                ),
            )

            val categories = categoryDao.getAll()
            if (debt.type == DebtType.OWED_TO_ME) {
                val incomeCatId = categories.firstOrNull { it.type == TransactionType.INCOME }?.id
                walletDao.adjustBalance(walletId, debt.amount)
                transactionDao.insert(
                    TransactionEntity(
                        amount = debt.amount,
                        type = TransactionType.INCOME,
                        categoryId = incomeCatId,
                        walletId = walletId,
                        note = "تحصيل سلفة من ${debt.personName}",
                        timestamp = now,
                    ),
                )
            } else {
                val expenseCatId = categories.lastOrNull { it.type == TransactionType.EXPENSE }?.id
                walletDao.adjustBalance(walletId, -debt.amount)
                transactionDao.insert(
                    TransactionEntity(
                        amount = debt.amount,
                        type = TransactionType.EXPENSE,
                        categoryId = expenseCatId,
                        walletId = walletId,
                        note = "سداد دين لـ ${debt.personName}",
                        timestamp = now,
                    ),
                )
            }
        }
    }

    // --- Wallets & Categories Management & Reordering ---

    suspend fun saveWallet(wallet: WalletEntity) {
        if (wallet.id == 0L) {
            val maxOrder = (walletDao.getAll().maxOfOrNull { it.sortOrder } ?: -1) + 1
            walletDao.insert(wallet.copy(sortOrder = maxOrder))
        } else {
            walletDao.update(wallet)
        }
    }

    suspend fun deleteWallet(id: Long) {
        walletDao.deleteById(id)
    }

    suspend fun moveWalletOrder(walletId: Long, moveUp: Boolean) {
        db.withTransaction {
            val sorted = walletDao.getAll().mapIndexed { index, w -> w.copy(sortOrder = index) }.toMutableList()
            val idx = sorted.indexOfFirst { it.id == walletId }
            if (idx == -1) return@withTransaction
            val targetIdx = if (moveUp) idx - 1 else idx + 1
            if (targetIdx !in sorted.indices) return@withTransaction
            val temp = sorted[idx]
            sorted[idx] = sorted[targetIdx].copy(sortOrder = idx)
            sorted[targetIdx] = temp.copy(sortOrder = targetIdx)
            walletDao.insertAll(sorted)
        }
    }

    suspend fun saveCategory(category: CategoryEntity) {
        if (category.id == 0L) {
            val maxOrder = (categoryDao.getAll().maxOfOrNull { it.sortOrder } ?: -1) + 1
            categoryDao.insert(category.copy(sortOrder = maxOrder))
        } else {
            categoryDao.update(category)
        }
    }

    suspend fun deleteCategory(id: Long) {
        categoryDao.deleteById(id)
    }

    suspend fun moveCategoryOrder(categoryId: Long, moveUp: Boolean) {
        db.withTransaction {
            val sorted = categoryDao.getAll().mapIndexed { index, c -> c.copy(sortOrder = index) }.toMutableList()
            val idx = sorted.indexOfFirst { it.id == categoryId }
            if (idx == -1) return@withTransaction
            val targetIdx = if (moveUp) idx - 1 else idx + 1
            if (targetIdx !in sorted.indices) return@withTransaction
            val temp = sorted[idx]
            sorted[idx] = sorted[targetIdx].copy(sortOrder = idx)
            sorted[targetIdx] = temp.copy(sortOrder = targetIdx)
            categoryDao.insertAll(sorted)
        }
    }

    // --- Settings & Security ---

    suspend fun setThemeMode(mode: String) = settingsDataStore.setThemeMode(mode)
    suspend fun setBudgetCycleStartDay(day: Int) = settingsDataStore.setBudgetCycleStartDay(day)
    suspend fun setPrivacyMode(enabled: Boolean) = settingsDataStore.setPrivacyMode(enabled)
    suspend fun setDailyReminder(enabled: Boolean, hour: Int, minute: Int) =
        settingsDataStore.setDailyReminder(enabled, hour, minute)
    suspend fun setPersistentQuickLogEnabled(enabled: Boolean) =
        settingsDataStore.setPersistentQuickLogEnabled(enabled)
    suspend fun setWeeklyAutoBackupEnabled(enabled: Boolean) =
        settingsDataStore.setWeeklyAutoBackupEnabled(enabled)
    suspend fun setLastWeeklyBackupAt(ts: Long) = settingsDataStore.setLastWeeklyBackupAt(ts)
    suspend fun setGeminiApiKey(apiKey: String) = settingsDataStore.setGeminiApiKey(apiKey)

    // --- AI Financial Coach Chat ---

    suspend fun getAiChatHistory(): List<AiChatMessageEntity> = aiChatDao.getAll()
    suspend fun insertAiChatMessage(message: AiChatMessageEntity): Long = aiChatDao.insert(message)
    suspend fun clearAiChat() = aiChatDao.deleteAll()

    suspend fun setPin(pin: String) = settingsDataStore.setPin(pin)
    suspend fun verifyPin(pin: String): Boolean = settingsDataStore.verifyPin(pin)
    suspend fun disablePin() = settingsDataStore.disablePin()
    suspend fun setBiometricEnabled(enabled: Boolean) = settingsDataStore.setBiometricEnabled(enabled)
    suspend fun setSelectedThemeId(themeId: String) = settingsDataStore.setSelectedThemeId(themeId)
    suspend fun setAutoNotificationCaptureEnabled(enabled: Boolean) =
        settingsDataStore.setAutoNotificationCaptureEnabled(enabled)
    suspend fun setHasPromptedStartupPermissions(prompted: Boolean) =
        settingsDataStore.setHasPromptedStartupPermissions(prompted)

    suspend fun awardXp(delta: Int): ArabicRank? {
        val (oldXp, newXp) = settingsDataStore.addXp(delta)
        return GamificationEngine.detectLevelUp(oldXp, newXp)
    }

    // --- Gam'eya Manager ---

    suspend fun saveGameya(gameya: GameyaEntity) {
        if (gameya.id == 0L) gameyaDao.insert(gameya) else gameyaDao.update(gameya)
    }

    suspend fun deleteGameya(id: Long) {
        gameyaDao.deleteById(id)
    }

    suspend fun payGameyaInstallment(gameyaId: Long, walletId: Long): Boolean {
        val today = LocalDate.now()
        val cycleKey = FinanceCalculator.currentGameyaCycleKey(today)
        var paid = false
        db.withTransaction {
            val g = gameyaDao.getById(gameyaId) ?: return@withTransaction
            if (g.paidMonthsCount >= g.totalMembers) return@withTransaction

            val categories = categoryDao.getAll()
            val expenseCatId = categories.lastOrNull { it.type == TransactionType.EXPENSE }?.id
            val nextCount = (g.paidMonthsCount + 1).coerceAtMost(g.totalMembers)
            val tx = TransactionEntity(
                amount = g.monthlyInstallment,
                type = TransactionType.EXPENSE,
                categoryId = expenseCatId,
                walletId = walletId,
                note = "قسط جمعية: ${g.title} ($nextCount/${g.totalMembers})",
                timestamp = System.currentTimeMillis(),
            )
            transactionDao.insert(tx)
            applyTransactionBalanceEffect(tx, sign = 1)
            clearZeroSpendIfExpense(tx)

            val finishedAll = nextCount >= g.totalMembers && g.isPayoutReceived
            gameyaDao.update(
                g.copy(
                    paidMonthsCount = nextCount,
                    lastPaidCycleKey = cycleKey,
                    isActive = !finishedAll,
                ),
            )
            paid = true
        }
        return paid
    }

    suspend fun receiveGameyaPayout(gameyaId: Long, walletId: Long): Double? {
        var payoutAmount: Double? = null
        db.withTransaction {
            val g = gameyaDao.getById(gameyaId) ?: return@withTransaction
            if (g.isPayoutReceived) return@withTransaction

            val totalPayout = g.monthlyInstallment * g.totalMembers
            val categories = categoryDao.getAll()
            val incomeCatId = categories.lastOrNull { it.type == TransactionType.INCOME }?.id
            val tx = TransactionEntity(
                amount = totalPayout,
                type = TransactionType.INCOME,
                categoryId = incomeCatId,
                walletId = walletId,
                note = "قبض جمعية: ${g.title}",
                timestamp = System.currentTimeMillis(),
            )
            transactionDao.insert(tx)
            applyTransactionBalanceEffect(tx, sign = 1)

            val finishedAll = g.paidMonthsCount >= g.totalMembers
            gameyaDao.update(
                g.copy(
                    isPayoutReceived = true,
                    isActive = !finishedAll,
                ),
            )
            payoutAmount = totalPayout
        }
        return payoutAmount
    }

    // --- Subscriptions & Fixed Bills Radar ---

    suspend fun saveSubscription(subscription: SubscriptionEntity) {
        if (subscription.id == 0L) subscriptionDao.insert(subscription) else subscriptionDao.update(subscription)
    }

    suspend fun deleteSubscription(id: Long) {
        subscriptionDao.deleteById(id)
    }

    suspend fun toggleSubscriptionActive(id: Long, active: Boolean) {
        val sub = subscriptionDao.getById(id) ?: return
        subscriptionDao.update(sub.copy(isActive = active))
    }

    suspend fun renewSubscriptionNow(subscriptionId: Long, today: LocalDate = LocalDate.now()): Boolean {
        var renewed = false
        db.withTransaction {
            val sub = subscriptionDao.getById(subscriptionId) ?: return@withTransaction
            val tx = TransactionEntity(
                amount = sub.amount,
                type = TransactionType.EXPENSE,
                categoryId = sub.categoryId,
                walletId = sub.walletId,
                note = sub.note.ifBlank { "تجديد اشتراك: ${sub.title}" },
                timestamp = System.currentTimeMillis(),
            )
            transactionDao.insert(tx)
            applyTransactionBalanceEffect(tx, sign = 1)
            clearZeroSpendIfExpense(tx)

            var nextRenewal = LocalDate.ofEpochDay(sub.nextRenewalEpochDay)
            if (!nextRenewal.isAfter(today)) {
                nextRenewal = today
            }
            nextRenewal = if (sub.billingCycle == BillingCycle.YEARLY) {
                nextRenewal.plusYears(1)
            } else {
                nextRenewal.plusMonths(1)
            }
            subscriptionDao.update(sub.copy(nextRenewalEpochDay = nextRenewal.toEpochDay()))
            renewed = true
        }
        return renewed
    }

    // --- V3 Pro: Rollover, Emergency Fund, Rebalancing, 50/30/20, Trips & Installments ---

    suspend fun setDailyRolloverMode(mode: String) = settingsDataStore.setDailyRolloverMode(mode)

    suspend fun contributeToEmergencyFund(walletId: Long, amount: Double) {
        if (amount <= 0.0) return
        db.withTransaction {
            walletDao.adjustBalance(walletId, -amount)
        }
        settingsDataStore.adjustEmergencyFund(amount)
        settingsDataStore.recordCycleSavings(FinanceCalculator.currentGameyaCycleKey(), amount)
    }

    suspend fun withdrawFromEmergencyFund(walletId: Long, amount: Double) {
        if (amount <= 0.0) return
        val currentSaved = settingsDataStore.getCurrentSettings().emergencyFundSaved
        val actualWithdraw = amount.coerceAtMost(currentSaved)
        if (actualWithdraw <= 0.0) return
        db.withTransaction {
            walletDao.adjustBalance(walletId, actualWithdraw)
        }
        settingsDataStore.adjustEmergencyFund(-actualWithdraw)
    }

    suspend fun rebalanceEnvelopes(fromEnvelopeId: Long, toEnvelopeId: Long, amount: Double): Boolean {
        if (amount <= 0.0 || fromEnvelopeId == toEnvelopeId) return false
        var success = false
        db.withTransaction {
            val fromEnv = envelopeDao.getById(fromEnvelopeId) ?: return@withTransaction
            val toEnv = envelopeDao.getById(toEnvelopeId) ?: return@withTransaction
            val transferable = amount.coerceAtMost(fromEnv.reservedAmount)
            if (transferable <= 0.0) return@withTransaction
            envelopeDao.update(fromEnv.copy(reservedAmount = (fromEnv.reservedAmount - transferable).coerceAtLeast(0.0)))
            val newToReserved = toEnv.reservedAmount + transferable
            envelopeDao.update(
                toEnv.copy(
                    reservedAmount = newToReserved,
                    targetAmount = maxOf(toEnv.targetAmount, newToReserved),
                ),
            )
            success = true
        }
        return success
    }

    suspend fun rebalanceCategoryBudgets(fromCategoryId: Long, toCategoryId: Long, amount: Double): Boolean {
        if (amount <= 0.0 || fromCategoryId == toCategoryId) return false
        var success = false
        db.withTransaction {
            val fromCat = categoryDao.getById(fromCategoryId) ?: return@withTransaction
            val toCat = categoryDao.getById(toCategoryId) ?: return@withTransaction
            val fromBudget = (fromCat.monthlyBudget ?: 0.0).coerceAtLeast(0.0)
            val transferable = amount.coerceAtMost(fromBudget)
            if (transferable <= 0.0) return@withTransaction
            val remainingFrom = (fromBudget - transferable).takeIf { it > 0.0 }
            val newToBudget = (toCat.monthlyBudget ?: 0.0) + transferable
            categoryDao.update(fromCat.copy(monthlyBudget = remainingFrom))
            categoryDao.update(toCat.copy(monthlyBudget = newToBudget))
            success = true
        }
        return success
    }

    suspend fun applyIncome503020Allocation(
        amount: Double,
        sourceWalletId: Long,
        putSavingsInEmergencyFund: Boolean,
        targetGoalId: Long?,
    ) {
        if (amount <= 0.0) return
        val essentials50 = (amount * 0.50).let { kotlin.math.round(it * 100.0) / 100.0 }
        val savings20 = (amount * 0.20).let { kotlin.math.round(it * 100.0) / 100.0 }

        db.withTransaction {
            val existingEnv = envelopeDao.getAll().firstOrNull {
                it.title.contains("الأساسيات") || it.title.contains("50%")
            }
            if (existingEnv != null) {
                val newRes = existingEnv.reservedAmount + essentials50
                envelopeDao.update(
                    existingEnv.copy(
                        reservedAmount = newRes,
                        targetAmount = maxOf(existingEnv.targetAmount, newRes),
                    ),
                )
            } else {
                envelopeDao.insert(
                    EnvelopeEntity(
                        title = "الأساسيات والالتزامات (50%)",
                        reservedAmount = essentials50,
                        targetAmount = essentials50,
                        iconKey = "envelope",
                    ),
                )
            }

            if (putSavingsInEmergencyFund || targetGoalId == null) {
                walletDao.adjustBalance(sourceWalletId, -savings20)
            } else {
                val goal = goalDao.getById(targetGoalId)
                if (goal != null) {
                    walletDao.adjustBalance(sourceWalletId, -savings20)
                    goalDao.update(goal.copy(savedAmount = goal.savedAmount + savings20))
                } else {
                    walletDao.adjustBalance(sourceWalletId, -savings20)
                }
            }
        }
        if (putSavingsInEmergencyFund || targetGoalId == null) {
            settingsDataStore.adjustEmergencyFund(savings20)
        }
        settingsDataStore.recordCycleSavings(FinanceCalculator.currentGameyaCycleKey(), savings20)
    }

    // --- Trip & Event Mode ---

    suspend fun saveTripEvent(trip: TripEventEntity): Long {
        return db.withTransaction {
            if (trip.isActive) {
                tripEventDao.deactivateAll()
            }
            if (trip.id == 0L) {
                tripEventDao.insert(trip)
            } else {
                tripEventDao.update(trip)
                trip.id
            }
        }
    }

    suspend fun toggleTripEventActive(tripId: Long, active: Boolean) {
        db.withTransaction {
            val existing = tripEventDao.getById(tripId) ?: return@withTransaction
            if (active) {
                tripEventDao.deactivateAll()
            }
            tripEventDao.update(existing.copy(isActive = active))
        }
    }

    suspend fun deleteTripEvent(tripId: Long) {
        tripEventDao.deleteById(tripId)
    }

    // --- Installments Tracker ---

    suspend fun saveInstallment(installment: InstallmentEntity) {
        if (installment.id == 0L) installmentDao.insert(installment) else installmentDao.update(installment)
    }

    suspend fun deleteInstallment(id: Long) {
        installmentDao.deleteById(id)
    }

    suspend fun payInstallmentMonth(installmentId: Long, walletId: Long): Boolean {
        val cycleKey = FinanceCalculator.currentGameyaCycleKey(LocalDate.now())
        var paid = false
        db.withTransaction {
            val inst = installmentDao.getById(installmentId) ?: return@withTransaction
            if (inst.paidMonths >= inst.totalMonths) return@withTransaction

            val categories = categoryDao.getAll()
            val expenseCatId = categories.firstOrNull {
                it.type == TransactionType.EXPENSE && it.name.contains("أقساط")
            }?.id ?: categories.lastOrNull { it.type == TransactionType.EXPENSE }?.id

            val nextPaid = (inst.paidMonths + 1).coerceAtMost(inst.totalMonths)
            val tx = TransactionEntity(
                amount = inst.monthlyAmount,
                type = TransactionType.EXPENSE,
                categoryId = expenseCatId,
                walletId = walletId,
                note = "قسط شهري: ${inst.itemName} ($nextPaid/${inst.totalMonths})",
                timestamp = System.currentTimeMillis(),
            )
            transactionDao.insert(tx)
            applyTransactionBalanceEffect(tx, sign = 1)
            clearZeroSpendIfExpense(tx)

            installmentDao.update(
                inst.copy(
                    paidMonths = nextPaid,
                    lastPaidCycleKey = cycleKey,
                    isActive = nextPaid < inst.totalMonths,
                ),
            )
            paid = true
        }
        return paid
    }

    // --- Backup, Restore & Reset ---

    suspend fun exportBackupJson(): String {
        val settings = settingsDataStore.getCurrentSettings()
        val backup = MasroufyBackup(
            version = 4,
            exportedAt = System.currentTimeMillis(),
            isDarkTheme = settings.isDarkTheme,
            themeMode = settings.themeMode,
            budgetCycleStartDay = settings.budgetCycleStartDay,
            xpPoints = settings.xpPoints,
            selectedThemeId = settings.selectedThemeId,
            dailyRolloverMode = settings.dailyRolloverMode,
            emergencyFundSaved = settings.emergencyFundSaved,
            wallets = walletDao.getAll(),
            categories = categoryDao.getAll(),
            transactions = transactionDao.getAll(),
            envelopes = envelopeDao.getAll(),
            goals = goalDao.getAll(),
            debts = debtDao.getAll(),
            zeroSpendDays = zeroSpendDao.getAll(),
            quickTemplates = quickTemplateDao.getAll(),
            recurringTransactions = recurringDao.getAll(),
            gameyas = gameyaDao.getAll(),
            subscriptions = subscriptionDao.getAll(),
            tripEvents = tripEventDao.getAll(),
            installments = installmentDao.getAll(),
        )
        return backupJson.encodeToString(MasroufyBackup.serializer(), backup)
    }

    suspend fun importBackupJson(jsonText: String): Result<Unit> = runCatching {
        val backup = backupJson.decodeFromString(MasroufyBackup.serializer(), jsonText)
        db.withTransaction {
            transactionDao.deleteAll()
            envelopeDao.deleteAll()
            goalDao.deleteAll()
            debtDao.deleteAll()
            zeroSpendDao.deleteAll()
            quickTemplateDao.deleteAll()
            recurringDao.deleteAll()
            gameyaDao.deleteAll()
            subscriptionDao.deleteAll()
            tripEventDao.deleteAll()
            installmentDao.deleteAll()
            categoryDao.deleteAll()
            walletDao.deleteAll()

            val wallets = backup.wallets.ifEmpty { DefaultSeedData.defaultWallets() }
            val categories = backup.categories.ifEmpty { DefaultSeedData.defaultCategories() }

            walletDao.insertAll(wallets)
            categoryDao.insertAll(categories)
            transactionDao.insertAll(backup.transactions)
            envelopeDao.insertAll(backup.envelopes)
            goalDao.insertAll(backup.goals)
            debtDao.insertAll(backup.debts)
            zeroSpendDao.insertAll(backup.zeroSpendDays)
            quickTemplateDao.insertAll(backup.quickTemplates)
            recurringDao.insertAll(backup.recurringTransactions)
            gameyaDao.insertAll(backup.gameyas)
            subscriptionDao.insertAll(backup.subscriptions)
            tripEventDao.insertAll(backup.tripEvents)
            installmentDao.insertAll(backup.installments)
        }
        val restoredTheme = if (backup.themeMode in listOf(ThemeMode.DARK, ThemeMode.LIGHT, ThemeMode.SYSTEM)) {
            backup.themeMode
        } else if (backup.isDarkTheme) {
            ThemeMode.DARK
        } else {
            ThemeMode.LIGHT
        }
        settingsDataStore.setThemeMode(restoredTheme)
        settingsDataStore.setBudgetCycleStartDay(backup.budgetCycleStartDay)
        settingsDataStore.setXpPoints(backup.xpPoints)
        settingsDataStore.setSelectedThemeId(backup.selectedThemeId)
        settingsDataStore.setDailyRolloverMode(backup.dailyRolloverMode)
        settingsDataStore.setEmergencyFundSaved(backup.emergencyFundSaved)
    }

    suspend fun resetAllData() {
        db.withTransaction {
            transactionDao.deleteAll()
            envelopeDao.deleteAll()
            goalDao.deleteAll()
            debtDao.deleteAll()
            zeroSpendDao.deleteAll()
            quickTemplateDao.deleteAll()
            recurringDao.deleteAll()
            gameyaDao.deleteAll()
            subscriptionDao.deleteAll()
            tripEventDao.deleteAll()
            installmentDao.deleteAll()
            aiChatDao.deleteAll()
            categoryDao.deleteAll()
            walletDao.deleteAll()

            walletDao.insertAll(DefaultSeedData.defaultWallets())
            categoryDao.insertAll(DefaultSeedData.defaultCategories())
        }
        settingsDataStore.resetSettings()
    }
}
