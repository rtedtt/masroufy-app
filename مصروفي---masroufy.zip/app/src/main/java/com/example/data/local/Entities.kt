package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.serialization.Serializable

object WalletType {
    const val CASH = "CASH"
    const val BANK = "BANK"
    const val MOBILE_WALLET = "MOBILE_WALLET"
    const val CUSTOM = "CUSTOM"
}

object TransactionType {
    const val EXPENSE = "EXPENSE"
    const val INCOME = "INCOME"
    const val TRANSFER = "TRANSFER"
}

object DebtType {
    const val OWED_TO_ME = "OWED_TO_ME"
    const val I_OWE = "I_OWE"
}

object RecurringFrequency {
    const val DAILY = "DAILY"
    const val WEEKLY = "WEEKLY"
    const val MONTHLY = "MONTHLY"

    fun label(freq: String): String = when (freq) {
        DAILY -> "يومياً"
        WEEKLY -> "أسبوعياً"
        MONTHLY -> "شهرياً"
        else -> freq
    }
}

object ThemeMode {
    const val DARK = "DARK"
    const val LIGHT = "LIGHT"
    const val SYSTEM = "SYSTEM"
}

object RolloverMode {
    const val NONE = "NONE"
    const val TODAY_BONUS = "TODAY_BONUS"
    const val SPREAD_REMAINING = "SPREAD_REMAINING"

    fun label(mode: String): String = when (mode) {
        TODAY_BONUS -> "مكافأة اليوم من فائض الأمس"
        SPREAD_REMAINING -> "توزيع تلقائي على باقي الأيام"
        else -> "إيقاف (حساب ثابت يومياً)"
    }
}

@Serializable
@Entity(tableName = "wallets")
data class WalletEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val type: String,
    val balance: Double,
    val iconKey: String,
    val colorHex: Long,
    val isDefault: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    val minBalanceThreshold: Double = 100.0,
    val sortOrder: Int = 0,
)

@Serializable
@Entity(tableName = "categories")
data class CategoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val type: String,
    val iconKey: String,
    val colorHex: Long,
    val isDefault: Boolean = false,
    val monthlyBudget: Double? = null,
    val sortOrder: Int = 0,
)

@Serializable
@Entity(tableName = "transactions")
data class TransactionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val amount: Double,
    val type: String,
    val categoryId: Long? = null,
    val walletId: Long,
    val toWalletId: Long? = null,
    val note: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    val envelopeId: Long? = null,
    val tripEventId: Long? = null,
)

@Serializable
@Entity(tableName = "envelopes")
data class EnvelopeEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val reservedAmount: Double,
    val targetAmount: Double,
    val iconKey: String = "envelope",
    val dueDay: Int? = null,
    val createdAt: Long = System.currentTimeMillis(),
)

@Serializable
@Entity(tableName = "goals")
data class GoalEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val targetAmount: Double,
    val savedAmount: Double = 0.0,
    val iconKey: String = "savings",
    val colorHex: Long = 0xFF10B981,
    val createdAt: Long = System.currentTimeMillis(),
)

@Serializable
@Entity(tableName = "debts")
data class DebtEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val personName: String,
    val amount: Double,
    val type: String,
    val note: String = "",
    val dateMillis: Long = System.currentTimeMillis(),
    val dueDateMillis: Long? = null,
    val isSettled: Boolean = false,
    val settledWalletId: Long? = null,
    val settledAt: Long? = null,
)

@Serializable
@Entity(tableName = "zero_spend_days")
data class ZeroSpendDayEntity(
    @PrimaryKey val dateEpochDay: Long,
    val confirmedAt: Long = System.currentTimeMillis(),
)

@Serializable
@Entity(tableName = "quick_templates")
data class QuickTemplateEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val amount: Double,
    val type: String = TransactionType.EXPENSE,
    val categoryId: Long? = null,
    val walletId: Long,
    val note: String = "",
    val sortOrder: Int = 0,
)

@Serializable
@Entity(tableName = "recurring_transactions")
data class RecurringTransactionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val amount: Double,
    val type: String = TransactionType.EXPENSE,
    val categoryId: Long? = null,
    val walletId: Long,
    val frequency: String = RecurringFrequency.MONTHLY,
    val nextDueEpochDay: Long,
    val autoPost: Boolean = false,
    val isActive: Boolean = true,
    val note: String = "",
)

@Serializable
@Entity(tableName = "ai_chat_messages")
data class AiChatMessageEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val text: String,
    val isUser: Boolean,
    val timestamp: Long = System.currentTimeMillis(),
    val isOfflineEngine: Boolean = false,
)

object BillingCycle {
    const val MONTHLY = "MONTHLY"
    const val YEARLY = "YEARLY"

    fun label(cycle: String): String = when (cycle) {
        YEARLY -> "سنوي"
        else -> "شهري"
    }
}

@Serializable
@Entity(tableName = "gameyas")
data class GameyaEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val monthlyInstallment: Double,
    val totalMembers: Int,
    val payoutTurnMonth: Int,
    val startYearMonth: String,
    val walletId: Long,
    val paidMonthsCount: Int = 0,
    val isPayoutReceived: Boolean = false,
    val lastPaidCycleKey: String = "",
    val isActive: Boolean = true,
    val createdAt: Long = System.currentTimeMillis(),
)

@Serializable
@Entity(tableName = "subscriptions")
data class SubscriptionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val amount: Double,
    val billingCycle: String = BillingCycle.MONTHLY,
    val nextRenewalEpochDay: Long,
    val walletId: Long,
    val categoryId: Long? = null,
    val isActive: Boolean = true,
    val note: String = "",
)

@Serializable
@Entity(tableName = "trip_events")
data class TripEventEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val budget: Double,
    val isActive: Boolean = true,
    val createdAt: Long = System.currentTimeMillis(),
)

@Serializable
@Entity(tableName = "installments")
data class InstallmentEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val itemName: String,
    val monthlyAmount: Double,
    val paidMonths: Int = 0,
    val totalMonths: Int,
    val dueDay: Int = 1,
    val walletId: Long,
    val lastPaidCycleKey: String = "",
    val isActive: Boolean = true,
    val createdAt: Long = System.currentTimeMillis(),
)

