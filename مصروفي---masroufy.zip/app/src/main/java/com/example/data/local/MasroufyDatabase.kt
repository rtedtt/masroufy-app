package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        WalletEntity::class,
        CategoryEntity::class,
        TransactionEntity::class,
        EnvelopeEntity::class,
        GoalEntity::class,
        DebtEntity::class,
        ZeroSpendDayEntity::class,
        QuickTemplateEntity::class,
        RecurringTransactionEntity::class,
        AiChatMessageEntity::class,
        GameyaEntity::class,
        SubscriptionEntity::class,
        TripEventEntity::class,
        InstallmentEntity::class,
    ],
    version = 5,
    exportSchema = false,
)
abstract class MasroufyDatabase : RoomDatabase() {
    abstract fun walletDao(): WalletDao
    abstract fun categoryDao(): CategoryDao
    abstract fun transactionDao(): TransactionDao
    abstract fun envelopeDao(): EnvelopeDao
    abstract fun goalDao(): GoalDao
    abstract fun debtDao(): DebtDao
    abstract fun zeroSpendDao(): ZeroSpendDao
    abstract fun quickTemplateDao(): QuickTemplateDao
    abstract fun recurringTransactionDao(): RecurringTransactionDao
    abstract fun aiChatMessageDao(): AiChatMessageDao
    abstract fun gameyaDao(): GameyaDao
    abstract fun subscriptionDao(): SubscriptionDao
    abstract fun tripEventDao(): TripEventDao
    abstract fun installmentDao(): InstallmentDao

    companion object {
        @Volatile
        private var INSTANCE: MasroufyDatabase? = null

        fun getInstance(context: Context): MasroufyDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    MasroufyDatabase::class.java,
                    "masroufy_offline.db",
                )
                    .fallbackToDestructiveMigration(dropAllTables = true)
                    .build()
                    .also { INSTANCE = it }
            }
        }
    }
}

object DefaultSeedData {
    fun defaultWallets(): List<WalletEntity> = listOf(
        WalletEntity(
            name = "كاش",
            type = WalletType.CASH,
            balance = 0.0,
            iconKey = "cash",
            colorHex = 0xFF10B981,
            isDefault = true,
            minBalanceThreshold = 100.0,
            sortOrder = 0,
        ),
        WalletEntity(
            name = "حساب بنكي / إنستا باي",
            type = WalletType.BANK,
            balance = 0.0,
            iconKey = "bank",
            colorHex = 0xFF38BDF8,
            isDefault = true,
            minBalanceThreshold = 100.0,
            sortOrder = 1,
        ),
        WalletEntity(
            name = "محفظة إلكترونية",
            type = WalletType.MOBILE_WALLET,
            balance = 0.0,
            iconKey = "mobile_wallet",
            colorHex = 0xFFF59E0B,
            isDefault = true,
            minBalanceThreshold = 100.0,
            sortOrder = 2,
        ),
    )

    fun defaultCategories(): List<CategoryEntity> = listOf(
        // Expense Categories
        CategoryEntity(
            name = "مواصلات",
            type = TransactionType.EXPENSE,
            iconKey = "transport",
            colorHex = 0xFF38BDF8,
            isDefault = true,
            sortOrder = 0,
        ),
        CategoryEntity(
            name = "أكل وشرب",
            type = TransactionType.EXPENSE,
            iconKey = "food",
            colorHex = 0xFFF97316,
            isDefault = true,
            sortOrder = 1,
        ),
        CategoryEntity(
            name = "باقة وإنترنت",
            type = TransactionType.EXPENSE,
            iconKey = "internet",
            colorHex = 0xFF8B5CF6,
            isDefault = true,
            sortOrder = 2,
        ),
        CategoryEntity(
            name = "دراسة وكورسات",
            type = TransactionType.EXPENSE,
            iconKey = "study",
            colorHex = 0xFF3B82F6,
            isDefault = true,
            sortOrder = 3,
        ),
        CategoryEntity(
            name = "خروجات",
            type = TransactionType.EXPENSE,
            iconKey = "outing",
            colorHex = 0xFFEC4899,
            isDefault = true,
            sortOrder = 4,
        ),
        CategoryEntity(
            name = "صحة",
            type = TransactionType.EXPENSE,
            iconKey = "health",
            colorHex = 0xFFEF4444,
            isDefault = true,
            sortOrder = 5,
        ),
        CategoryEntity(
            name = "تسوق",
            type = TransactionType.EXPENSE,
            iconKey = "shopping",
            colorHex = 0xFFF59E0B,
            isDefault = true,
            sortOrder = 6,
        ),
        CategoryEntity(
            name = "أخرى",
            type = TransactionType.EXPENSE,
            iconKey = "other",
            colorHex = 0xFF64748B,
            isDefault = true,
            sortOrder = 7,
        ),
        // Income Categories
        CategoryEntity(
            name = "راتب",
            type = TransactionType.INCOME,
            iconKey = "salary",
            colorHex = 0xFF10B981,
            isDefault = true,
            sortOrder = 8,
        ),
        CategoryEntity(
            name = "عمل حر",
            type = TransactionType.INCOME,
            iconKey = "freelance",
            colorHex = 0xFF06B6D4,
            isDefault = true,
            sortOrder = 9,
        ),
        CategoryEntity(
            name = "مصروف / هدية",
            type = TransactionType.INCOME,
            iconKey = 0xFFF59E0B.let { "gift" },
            colorHex = 0xFFF59E0B,
            isDefault = true,
            sortOrder = 10,
        ),
        CategoryEntity(
            name = "دخل آخر",
            type = TransactionType.INCOME,
            iconKey = "income_other",
            colorHex = 0xFF64748B,
            isDefault = true,
            sortOrder = 11,
        ),
    )
}
