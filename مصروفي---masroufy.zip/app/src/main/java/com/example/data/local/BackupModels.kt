package com.example.data.local

import kotlinx.serialization.Serializable

@Serializable
data class MasroufyBackup(
    val version: Int = 4,
    val exportedAt: Long = System.currentTimeMillis(),
    val isDarkTheme: Boolean = true,
    val themeMode: String = ThemeMode.DARK,
    val budgetCycleStartDay: Int = 1,
    val xpPoints: Int = 0,
    val selectedThemeId: String = "EMERALD_CLASSIC",
    val dailyRolloverMode: String = RolloverMode.NONE,
    val emergencyFundSaved: Double = 0.0,
    val wallets: List<WalletEntity> = emptyList(),
    val categories: List<CategoryEntity> = emptyList(),
    val transactions: List<TransactionEntity> = emptyList(),
    val envelopes: List<EnvelopeEntity> = emptyList(),
    val goals: List<GoalEntity> = emptyList(),
    val debts: List<DebtEntity> = emptyList(),
    val zeroSpendDays: List<ZeroSpendDayEntity> = emptyList(),
    val quickTemplates: List<QuickTemplateEntity> = emptyList(),
    val recurringTransactions: List<RecurringTransactionEntity> = emptyList(),
    val gameyas: List<GameyaEntity> = emptyList(),
    val subscriptions: List<SubscriptionEntity> = emptyList(),
    val tripEvents: List<TripEventEntity> = emptyList(),
    val installments: List<InstallmentEntity> = emptyList(),
)
