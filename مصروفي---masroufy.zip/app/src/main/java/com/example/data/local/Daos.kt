package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface WalletDao {
    @Query("SELECT * FROM wallets ORDER BY sortOrder ASC, isDefault DESC, id ASC")
    fun observeAll(): Flow<List<WalletEntity>>

    @Query("SELECT * FROM wallets ORDER BY sortOrder ASC, isDefault DESC, id ASC")
    suspend fun getAll(): List<WalletEntity>

    @Query("SELECT * FROM wallets WHERE id = :id")
    suspend fun getById(id: Long): WalletEntity?

    @Query("SELECT COUNT(*) FROM wallets")
    suspend fun count(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(wallet: WalletEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(wallets: List<WalletEntity>)

    @Update
    suspend fun update(wallet: WalletEntity)

    @Query("UPDATE wallets SET balance = balance + :delta WHERE id = :walletId")
    suspend fun adjustBalance(walletId: Long, delta: Double)

    @Query("DELETE FROM wallets WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM wallets")
    suspend fun deleteAll()
}

@Dao
interface CategoryDao {
    @Query("SELECT * FROM categories ORDER BY sortOrder ASC, isDefault DESC, id ASC")
    fun observeAll(): Flow<List<CategoryEntity>>

    @Query("SELECT * FROM categories ORDER BY sortOrder ASC, isDefault DESC, id ASC")
    suspend fun getAll(): List<CategoryEntity>

    @Query("SELECT * FROM categories WHERE id = :id")
    suspend fun getById(id: Long): CategoryEntity?

    @Query("SELECT COUNT(*) FROM categories")
    suspend fun count(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(category: CategoryEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(categories: List<CategoryEntity>)

    @Update
    suspend fun update(category: CategoryEntity)

    @Query("DELETE FROM categories WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM categories")
    suspend fun deleteAll()
}

@Dao
interface TransactionDao {
    @Query("SELECT * FROM transactions ORDER BY timestamp DESC, id DESC")
    fun observeAll(): Flow<List<TransactionEntity>>

    @Query("SELECT * FROM transactions ORDER BY timestamp DESC, id DESC")
    suspend fun getAll(): List<TransactionEntity>

    @Query("SELECT * FROM transactions WHERE id = :id")
    suspend fun getById(id: Long): TransactionEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(transaction: TransactionEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(transactions: List<TransactionEntity>)

    @Update
    suspend fun update(transaction: TransactionEntity)

    @Delete
    suspend fun delete(transaction: TransactionEntity)

    @Query("DELETE FROM transactions WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM transactions")
    suspend fun deleteAll()
}

@Dao
interface EnvelopeDao {
    @Query("SELECT * FROM envelopes ORDER BY id DESC")
    fun observeAll(): Flow<List<EnvelopeEntity>>

    @Query("SELECT * FROM envelopes ORDER BY id DESC")
    suspend fun getAll(): List<EnvelopeEntity>

    @Query("SELECT * FROM envelopes WHERE id = :id")
    suspend fun getById(id: Long): EnvelopeEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(envelope: EnvelopeEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(envelopes: List<EnvelopeEntity>)

    @Update
    suspend fun update(envelope: EnvelopeEntity)

    @Query("DELETE FROM envelopes WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM envelopes")
    suspend fun deleteAll()
}

@Dao
interface GoalDao {
    @Query("SELECT * FROM goals ORDER BY id DESC")
    fun observeAll(): Flow<List<GoalEntity>>

    @Query("SELECT * FROM goals ORDER BY id DESC")
    suspend fun getAll(): List<GoalEntity>

    @Query("SELECT * FROM goals WHERE id = :id")
    suspend fun getById(id: Long): GoalEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(goal: GoalEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(goals: List<GoalEntity>)

    @Update
    suspend fun update(goal: GoalEntity)

    @Query("DELETE FROM goals WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM goals")
    suspend fun deleteAll()
}

@Dao
interface DebtDao {
    @Query("SELECT * FROM debts ORDER BY isSettled ASC, dateMillis DESC, id DESC")
    fun observeAll(): Flow<List<DebtEntity>>

    @Query("SELECT * FROM debts ORDER BY isSettled ASC, dateMillis DESC, id DESC")
    suspend fun getAll(): List<DebtEntity>

    @Query("SELECT * FROM debts WHERE id = :id")
    suspend fun getById(id: Long): DebtEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(debt: DebtEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(debts: List<DebtEntity>)

    @Update
    suspend fun update(debt: DebtEntity)

    @Query("DELETE FROM debts WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM debts")
    suspend fun deleteAll()
}

@Dao
interface ZeroSpendDao {
    @Query("SELECT * FROM zero_spend_days ORDER BY dateEpochDay DESC")
    fun observeAll(): Flow<List<ZeroSpendDayEntity>>

    @Query("SELECT * FROM zero_spend_days ORDER BY dateEpochDay DESC")
    suspend fun getAll(): List<ZeroSpendDayEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(day: ZeroSpendDayEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(days: List<ZeroSpendDayEntity>)

    @Query("DELETE FROM zero_spend_days WHERE dateEpochDay = :epochDay")
    suspend fun deleteByDay(epochDay: Long)

    @Query("DELETE FROM zero_spend_days")
    suspend fun deleteAll()
}

@Dao
interface QuickTemplateDao {
    @Query("SELECT * FROM quick_templates ORDER BY sortOrder ASC, id ASC")
    fun observeAll(): Flow<List<QuickTemplateEntity>>

    @Query("SELECT * FROM quick_templates ORDER BY sortOrder ASC, id ASC")
    suspend fun getAll(): List<QuickTemplateEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(template: QuickTemplateEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(templates: List<QuickTemplateEntity>)

    @Update
    suspend fun update(template: QuickTemplateEntity)

    @Query("DELETE FROM quick_templates WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM quick_templates")
    suspend fun deleteAll()
}

@Dao
interface RecurringTransactionDao {
    @Query("SELECT * FROM recurring_transactions ORDER BY isActive DESC, nextDueEpochDay ASC, id DESC")
    fun observeAll(): Flow<List<RecurringTransactionEntity>>

    @Query("SELECT * FROM recurring_transactions ORDER BY isActive DESC, nextDueEpochDay ASC, id DESC")
    suspend fun getAll(): List<RecurringTransactionEntity>

    @Query("SELECT * FROM recurring_transactions WHERE id = :id")
    suspend fun getById(id: Long): RecurringTransactionEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(recurring: RecurringTransactionEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(items: List<RecurringTransactionEntity>)

    @Update
    suspend fun update(recurring: RecurringTransactionEntity)

    @Query("DELETE FROM recurring_transactions WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM recurring_transactions")
    suspend fun deleteAll()
}

@Dao
interface AiChatMessageDao {
    @Query("SELECT * FROM ai_chat_messages ORDER BY timestamp ASC, id ASC")
    fun observeAll(): Flow<List<AiChatMessageEntity>>

    @Query("SELECT * FROM ai_chat_messages ORDER BY timestamp ASC, id ASC")
    suspend fun getAll(): List<AiChatMessageEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(message: AiChatMessageEntity): Long

    @Query("DELETE FROM ai_chat_messages")
    suspend fun deleteAll()
}

@Dao
interface GameyaDao {
    @Query("SELECT * FROM gameyas ORDER BY isActive DESC, createdAt DESC, id DESC")
    fun observeAll(): Flow<List<GameyaEntity>>

    @Query("SELECT * FROM gameyas ORDER BY isActive DESC, createdAt DESC, id DESC")
    suspend fun getAll(): List<GameyaEntity>

    @Query("SELECT * FROM gameyas WHERE id = :id")
    suspend fun getById(id: Long): GameyaEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(gameya: GameyaEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(gameyas: List<GameyaEntity>)

    @Update
    suspend fun update(gameya: GameyaEntity)

    @Query("DELETE FROM gameyas WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM gameyas")
    suspend fun deleteAll()
}

@Dao
interface SubscriptionDao {
    @Query("SELECT * FROM subscriptions ORDER BY isActive DESC, nextRenewalEpochDay ASC, id DESC")
    fun observeAll(): Flow<List<SubscriptionEntity>>

    @Query("SELECT * FROM subscriptions ORDER BY isActive DESC, nextRenewalEpochDay ASC, id DESC")
    suspend fun getAll(): List<SubscriptionEntity>

    @Query("SELECT * FROM subscriptions WHERE id = :id")
    suspend fun getById(id: Long): SubscriptionEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(sub: SubscriptionEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(subs: List<SubscriptionEntity>)

    @Update
    suspend fun update(sub: SubscriptionEntity)

    @Query("DELETE FROM subscriptions WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM subscriptions")
    suspend fun deleteAll()
}

@Dao
interface TripEventDao {
    @Query("SELECT * FROM trip_events ORDER BY isActive DESC, createdAt DESC, id DESC")
    fun observeAll(): Flow<List<TripEventEntity>>

    @Query("SELECT * FROM trip_events ORDER BY isActive DESC, createdAt DESC, id DESC")
    suspend fun getAll(): List<TripEventEntity>

    @Query("SELECT * FROM trip_events WHERE id = :id")
    suspend fun getById(id: Long): TripEventEntity?

    @Query("SELECT * FROM trip_events WHERE isActive = 1 ORDER BY createdAt DESC LIMIT 1")
    suspend fun getActive(): TripEventEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(trip: TripEventEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(trips: List<TripEventEntity>)

    @Update
    suspend fun update(trip: TripEventEntity)

    @Query("UPDATE trip_events SET isActive = 0")
    suspend fun deactivateAll()

    @Query("DELETE FROM trip_events WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM trip_events")
    suspend fun deleteAll()
}

@Dao
interface InstallmentDao {
    @Query("SELECT * FROM installments ORDER BY isActive DESC, dueDay ASC, id DESC")
    fun observeAll(): Flow<List<InstallmentEntity>>

    @Query("SELECT * FROM installments ORDER BY isActive DESC, dueDay ASC, id DESC")
    suspend fun getAll(): List<InstallmentEntity>

    @Query("SELECT * FROM installments WHERE id = :id")
    suspend fun getById(id: Long): InstallmentEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(installment: InstallmentEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(installments: List<InstallmentEntity>)

    @Update
    suspend fun update(installment: InstallmentEntity)

    @Query("DELETE FROM installments WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM installments")
    suspend fun deleteAll()
}

