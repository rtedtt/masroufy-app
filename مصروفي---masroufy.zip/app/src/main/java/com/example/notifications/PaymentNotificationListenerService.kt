package com.example.notifications

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import com.example.data.local.MasroufyDatabase
import com.example.data.local.SettingsDataStore
import com.example.domain.SmsTransactionParser
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import java.util.Locale

class PaymentNotificationListenerService : NotificationListenerService() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    @Volatile
    private var lastSignature: String = ""

    @Volatile
    private var lastSignatureTimeMs: Long = 0L

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn == null) return
        val pkg = sbn.packageName.orEmpty()
        if (pkg.isBlank() || pkg == packageName) return

        val extras = sbn.notification?.extras ?: return
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty().trim()
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty().trim()
        val bigText = extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString().orEmpty().trim()
        val body = bigText.ifBlank { text }
        if (title.isBlank() && body.isBlank()) return

        val combined = "$title $body".trim()
        val lowerCombined = combined.lowercase(Locale.ROOT)
        val lowerPkg = pkg.lowercase(Locale.ROOT)

        val senderHint = detectSenderHint(lowerPkg, lowerCombined) ?: return

        val now = System.currentTimeMillis()
        val signature = "$pkg|$title|$body"
        if (signature == lastSignature && (now - lastSignatureTimeMs) < 20_000L) {
            return
        }
        lastSignature = signature
        lastSignatureTimeMs = now

        serviceScope.launch {
            val settings = SettingsDataStore(applicationContext).getCurrentSettings()
            if (!settings.autoNotificationCaptureEnabled) return@launch

            val db = MasroufyDatabase.getInstance(applicationContext)
            val wallets = db.walletDao().getAll()
            val categories = db.categoryDao().getAll()

            val parseInput = "$senderHint $combined"
            val parsed = SmsTransactionParser.parse(
                rawText = parseInput,
                wallets = wallets,
                categories = categories,
            )

            if (parsed?.amount != null && parsed.amount > 0.0) {
                NotificationHelper.showDetectedPaymentNotification(
                    context = applicationContext,
                    parsed = parsed,
                    sourceTitle = "رصد معاملة ($senderHint)",
                )
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        serviceScope.cancel()
    }

    companion object {
        private val financialKeywords = listOf(
            "instapay", "إنستا باي", "انستا باي", "انستاباي",
            "vodafone cash", "فودافون كاش", "أنا فودافون", "ana vodafone",
            "etisalat cash", "اتصالات كاش", "my e&", "e& money",
            "orange cash", "اورانج كاش", "أورانج كاش",
            "we pay", "وي باي",
            "nbe", "البنك الأهلي", "الأهلي المصري",
            "cib", "التجاري الدولي",
            "banque misr", "بنك مصر", "bm online",
            "mashreq", "المشرق", "qnb", "alexbank", "بنك الإسكندرية",
        )

        private val amountHintKeywords = listOf(
            "egp", "جنيه", "ج.م", "جم", "خصم", "دفع", "استلام", "تحويل", "إيداع", "ايداع",
            "debited", "credited", "received", "transfer", "paid", "payment",
        )

        fun detectSenderHint(lowerPkg: String, lowerText: String): String? {
            return when {
                lowerPkg.contains("instapay") || lowerText.contains("instapay") || lowerText.contains("إنستا باي") || lowerText.contains("انستا باي") ->
                    "إنستا باي"
                lowerPkg.contains("vodafone") || lowerText.contains("vodafone cash") || lowerText.contains("فودافون كاش") ->
                    "فودافون كاش"
                lowerPkg.contains("etisalat") || lowerPkg.contains("mye") || lowerText.contains("etisalat cash") || lowerText.contains("اتصالات كاش") || lowerText.contains("my e&") ->
                    "اتصالات كاش"
                lowerPkg.contains("orange") || lowerText.contains("orange cash") || lowerText.contains("اورانج كاش") || lowerText.contains("أورانج كاش") ->
                    "أورانج كاش"
                lowerPkg.contains("wepay") || lowerText.contains("we pay") || lowerText.contains("وي باي") ->
                    "وي باي"
                lowerPkg.contains("nbe") || lowerText.contains("nbe") || lowerText.contains("البنك الأهلي") ->
                    "البنك الأهلي"
                lowerPkg.contains("cib") || lowerText.contains("cib") || lowerText.contains("التجاري الدولي") ->
                    "بنك CIB"
                lowerPkg.contains("banquemisr") || lowerText.contains("banque misr") || lowerText.contains("بنك مصر") ->
                    "بنك مصر"
                lowerPkg.contains("mashreq") || lowerText.contains("mashreq") || lowerText.contains("المشرق") ->
                    "بنك المشرق"
                financialKeywords.any { lowerText.contains(it) } && amountHintKeywords.any { lowerText.contains(it) } ->
                    "إشعار بنكي"
                else -> null
            }
        }
    }
}
