package com.example.notifications

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.example.MainActivity
import com.example.R
import com.example.domain.Formatters
import com.example.domain.ParsedSmsResult

object NotificationHelper {

    const val CHANNEL_REMINDERS = "masroufy_reminders"
    const val CHANNEL_QUICK_LOG = "masroufy_quick_log"
    const val CHANNEL_AUTO_CAPTURE = "masroufy_auto_capture"

    const val EXTRA_OPEN_QUICK_LOG = "extra_open_quick_log"
    const val EXTRA_PREFILL_AMOUNT = "extra_prefill_amount"
    const val EXTRA_PREFILL_TYPE = "extra_prefill_type"
    const val EXTRA_PREFILL_WALLET_ID = "extra_prefill_wallet_id"
    const val EXTRA_PREFILL_CATEGORY_ID = "extra_prefill_category_id"
    const val EXTRA_PREFILL_NOTE = "extra_prefill_note"

    private const val ID_DAILY_REMINDER = 1001
    private const val ID_LIMIT_ALERT = 1002
    private const val ID_LOW_WALLET = 1003
    private const val ID_DEBT_DUE = 1004
    private const val ID_PERSISTENT_QUICK_LOG = 1005
    private const val ID_SUBSCRIPTION_RENEWAL = 1006
    private const val ID_AUTO_PAYMENT_BASE = 4000

    fun createChannels(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val remindersChannel = NotificationChannel(
                CHANNEL_REMINDERS,
                "تذكيرات وتنبيهات مصروفي",
                NotificationManager.IMPORTANCE_DEFAULT,
            ).apply {
                description = "تذكير مسائي، تنبيه الحد اليومي، تنبيه انخفاض المحفظة، الاشتراكات، ومواعيد السُلف"
            }
            val quickLogChannel = NotificationChannel(
                CHANNEL_QUICK_LOG,
                "التسجيل السريع المستمر",
                NotificationManager.IMPORTANCE_LOW,
            ).apply {
                description = "إشعار دائم لفتح شاشة تسجيل المصاريف بسرعة"
            }
            val autoCaptureChannel = NotificationChannel(
                CHANNEL_AUTO_CAPTURE,
                "رصد المعاملات التلقائي",
                NotificationManager.IMPORTANCE_HIGH,
            ).apply {
                description = "تنبيهات فورية عند رصد معاملة من إنستا باي أو المحافظ والبنوك"
            }
            manager.createNotificationChannel(remindersChannel)
            manager.createNotificationChannel(quickLogChannel)
            manager.createNotificationChannel(autoCaptureChannel)
        }
    }

    fun hasNotificationPermission(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS,
            ) == PackageManager.PERMISSION_GRANTED
        } else {
            true
        }
    }

    fun isNotificationListenerEnabled(context: Context): Boolean {
        return NotificationManagerCompat.getEnabledListenerPackages(context)
            .contains(context.packageName)
    }

    fun openNotificationListenerSettings(context: Context) {
        val intent = Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        runCatching { context.startActivity(intent) }
    }

    fun showDailyEveningReminder(context: Context) {
        if (!hasNotificationPermission(context)) return
        createChannels(context)
        val openQuickLogIntent = quickLogPendingIntent(context, 2001)
        val notification = NotificationCompat.Builder(context, CHANNEL_REMINDERS)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle("لسه مسجلتش مصاريف النهارده")
            .setContentText("خُد 10 ثواني وسجّل مصاريفك في مصروفي عشان تحافظ على دقة ميزانيتك.")
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .setContentIntent(openQuickLogIntent)
            .addAction(0, "+ تسجيل مصروف", openQuickLogIntent)
            .build()
        notifySafe(context, ID_DAILY_REMINDER, notification)
    }

    fun showDailyLimitExceededAlert(context: Context, spentText: String, limitText: String) {
        if (!hasNotificationPermission(context)) return
        createChannels(context)
        val notification = NotificationCompat.Builder(context, CHANNEL_REMINDERS)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle("تنبيه: تجاوزت الحد الآمن اليومي")
            .setContentText("إجمالي صرفك اليوم $spentText وتخطيت الحد الآمن ($limitText).")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(launchAppPendingIntent(context, 2002))
            .build()
        notifySafe(context, ID_LIMIT_ALERT, notification)
    }

    fun showLowWalletBalanceAlert(context: Context, walletName: String, balanceText: String) {
        if (!hasNotificationPermission(context)) return
        createChannels(context)
        val notification = NotificationCompat.Builder(context, CHANNEL_REMINDERS)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle("انخفاض رصيد محفظة $walletName")
            .setContentText("الرصيد الحالي $balanceText أقل من الحد الأدنى المحدد.")
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .setContentIntent(launchAppPendingIntent(context, 2003))
            .build()
        notifySafe(context, ID_LOW_WALLET, notification)
    }

    fun showDebtDueReminder(context: Context, count: Int, firstPerson: String) {
        if (!hasNotificationPermission(context)) return
        createChannels(context)
        val text = if (count == 1) {
            "موعد سداد سُلفة «$firstPerson» حان اليوم."
        } else {
            "عندك $count سُلف مستحقة اليوم (أولها: $firstPerson)."
        }
        val notification = NotificationCompat.Builder(context, CHANNEL_REMINDERS)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle("تذكير بموعد سداد سُلفة")
            .setContentText(text)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .setContentIntent(launchAppPendingIntent(context, 2004))
            .build()
        notifySafe(context, ID_DEBT_DUE, notification)
    }

    fun showSubscriptionRenewalAlert(
        context: Context,
        title: String,
        amountText: String,
        daysRemaining: Long,
    ) {
        if (!hasNotificationPermission(context)) return
        createChannels(context)
        val whenText = when {
            daysRemaining <= 0L -> "اليوم"
            daysRemaining == 1L -> "بكرة"
            else -> "خلال $daysRemaining أيام"
        }
        val notification = NotificationCompat.Builder(context, CHANNEL_REMINDERS)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle("تنبيه تجديد اشتراك: $title")
            .setContentText("موعد التجديد $whenText بقيمة $amountText — تأكد من توفر الرصيد.")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(launchAppPendingIntent(context, 2006))
            .build()
        notifySafe(context, ID_SUBSCRIPTION_RENEWAL, notification)
    }

    fun showDetectedPaymentNotification(
        context: Context,
        parsed: ParsedSmsResult,
        sourceTitle: String,
    ) {
        if (!hasNotificationPermission(context)) return
        val amount = parsed.amount ?: return
        createChannels(context)

        val requestCode = ID_AUTO_PAYMENT_BASE + ((System.currentTimeMillis() / 1000L) % 500).toInt()
        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra(EXTRA_OPEN_QUICK_LOG, true)
            putExtra(EXTRA_PREFILL_AMOUNT, amount)
            putExtra(EXTRA_PREFILL_TYPE, parsed.transactionType)
            parsed.suggestedWalletId?.let { putExtra(EXTRA_PREFILL_WALLET_ID, it) }
            parsed.suggestedCategoryId?.let { putExtra(EXTRA_PREFILL_CATEGORY_ID, it) }
            putExtra(EXTRA_PREFILL_NOTE, parsed.extractedNote)
        }
        val pendingIntent = PendingIntent.getActivity(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )

        val amountFormatted = Formatters.formatEgp(amount)
        val bodyText = "تم رصد معاملة بقيمة $amountFormatted — اضغط للتسجيل"
        val notification = NotificationCompat.Builder(context, CHANNEL_AUTO_CAPTURE)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(sourceTitle.ifBlank { "رصد معاملة مالية جديدة" })
            .setContentText(bodyText)
            .setStyle(NotificationCompat.BigTextStyle().bigText(bodyText))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .addAction(0, "تسجيل الآن", pendingIntent)
            .build()
        notifySafe(context, requestCode, notification)
    }

    fun updatePersistentQuickLogNotification(context: Context, enabled: Boolean) {
        val manager = NotificationManagerCompat.from(context)
        if (!enabled || !hasNotificationPermission(context)) {
            manager.cancel(ID_PERSISTENT_QUICK_LOG)
            return
        }
        createChannels(context)
        val quickIntent = quickLogPendingIntent(context, 2005)
        val notification = NotificationCompat.Builder(context, CHANNEL_QUICK_LOG)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle("مصروفي • التسجيل السريع")
            .setContentText("اضغط لتسجيل مصروف أو دخل جديد فوراً")
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setContentIntent(quickIntent)
            .addAction(0, "+ تسجيل مصروف", quickIntent)
            .build()
        notifySafe(context, ID_PERSISTENT_QUICK_LOG, notification)
    }

    private fun quickLogPendingIntent(context: Context, requestCode: Int): PendingIntent {
        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra(EXTRA_OPEN_QUICK_LOG, true)
        }
        return PendingIntent.getActivity(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
    }

    private fun launchAppPendingIntent(context: Context, requestCode: Int): PendingIntent {
        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        return PendingIntent.getActivity(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
    }

    private fun notifySafe(context: Context, id: Int, notification: android.app.Notification) {
        try {
            NotificationManagerCompat.from(context).notify(id, notification)
        } catch (_: SecurityException) {
            // Permission revoked at runtime
        }
    }
}
