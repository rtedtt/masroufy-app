package com.example.navigation

import kotlinx.serialization.Serializable

@Serializable
object HomeRoute

@Serializable
object PlanningRoute

@Serializable
object AnalyticsRoute

@Serializable
object SettingsRoute

@Serializable
data class WalletStatementRoute(val walletId: Long)

@Serializable
object AiAdvisorRoute
