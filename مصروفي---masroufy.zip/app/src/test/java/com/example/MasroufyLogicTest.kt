package com.example

import com.example.data.local.BillingCycle
import com.example.data.local.DebtEntity
import com.example.data.local.DebtType
import com.example.data.local.DefaultSeedData
import com.example.data.local.EnvelopeEntity
import com.example.data.local.GameyaEntity
import com.example.data.local.GoalEntity
import com.example.data.local.InstallmentEntity
import com.example.data.local.RolloverMode
import com.example.data.local.SubscriptionEntity
import com.example.data.local.TransactionEntity
import com.example.data.local.TransactionType
import com.example.data.local.TripEventEntity
import com.example.data.local.WalletType
import com.example.data.local.ZeroSpendDayEntity
import com.example.domain.AnalyticsTimeframe
import com.example.domain.FinanceCalculator
import com.example.domain.FinancialCoachSnapshot
import com.example.domain.FinancialContextBuilder
import com.example.domain.Formatters
import com.example.domain.GamificationEngine
import com.example.domain.HashtagParser
import com.example.domain.MasroufyThemePack
import com.example.domain.MathExpressionEvaluator
import com.example.domain.OfflineFinancialBrain
import com.example.domain.SafeSpendStatus
import com.example.domain.SmsTransactionParser
import com.example.domain.VoiceTransactionParser
import com.example.notifications.PaymentNotificationListenerService
import com.example.ui.components.DeveloperProfile
import com.example.ui.components.QrMatrixHelper
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate
import java.time.YearMonth
import java.time.ZoneId

class MasroufyLogicTest {

    private val wallets = DefaultSeedData.defaultWallets().mapIndexed { idx, w -> w.copy(id = (idx + 1).toLong()) }
    private val categories = DefaultSeedData.defaultCategories().mapIndexed { idx, c -> c.copy(id = (idx + 1).toLong()) }

    @Test
    fun `parse Arabic InstaPay expense SMS accurately`() {
        val sms = "تم خصم مبلغ 450.50 جنيه من حسابك عبر إنستا باي لمطعم طلبات"
        val parsed = SmsTransactionParser.parse(sms, wallets, categories)
        assertNotNull(parsed)
        assertEquals(450.50, parsed!!.amount!!, 0.01)
        assertEquals(TransactionType.EXPENSE, parsed.transactionType)
        val bankWallet = wallets.first { it.type == WalletType.BANK }
        assertEquals(bankWallet.id, parsed.suggestedWalletId)
    }

    @Test
    fun `parse English Vodafone Cash income SMS accurately`() {
        val sms = "You have received 1,200 EGP on Vodafone Cash from 01012345678"
        val parsed = SmsTransactionParser.parse(sms, wallets, categories)
        assertNotNull(parsed)
        assertEquals(1200.0, parsed!!.amount!!, 0.01)
        assertEquals(TransactionType.INCOME, parsed.transactionType)
        val mobileWallet = wallets.first { it.type == WalletType.MOBILE_WALLET }
        assertEquals(mobileWallet.id, parsed.suggestedWalletId)
    }

    @Test
    fun `parse Arabic numerals in bank SMS`() {
        val sms = "تم إيداع مبلغ ٣٥٠ جنيه في حسابك البنك الأهلي"
        val parsed = SmsTransactionParser.parse(sms, wallets, categories)
        assertNotNull(parsed)
        assertEquals(350.0, parsed!!.amount!!, 0.01)
        assertEquals(TransactionType.INCOME, parsed.transactionType)
    }

    @Test
    fun `budget snapshot splits liquidity, reserved envelopes, and daily safe limit`() {
        val today = LocalDate.of(2026, 11, 20)
        val todayMillis = today.atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli() + 3600_000L

        val testWallets = listOf(
            wallets[0].copy(balance = 1000.0),
            wallets[1].copy(balance = 4000.0),
        )
        val envelopes = listOf(
            EnvelopeEntity(id = 1, title = "باقة النت", reservedAmount = 500.0, targetAmount = 500.0),
        )
        val txs = listOf(
            TransactionEntity(
                id = 1,
                amount = 100.0,
                type = TransactionType.EXPENSE,
                walletId = 1,
                timestamp = todayMillis,
            ),
        )
        val zeroDays = listOf(
            ZeroSpendDayEntity(dateEpochDay = today.minusDays(1).toEpochDay()),
            ZeroSpendDayEntity(dateEpochDay = today.minusDays(2).toEpochDay()),
        )

        val snap = FinanceCalculator.calculateBudgetSnapshot(
            wallets = testWallets,
            envelopes = envelopes,
            transactions = txs,
            zeroSpendDays = zeroDays,
            cycleStartDay = 1,
            today = today,
        )

        assertEquals(5000.0, snap.totalLiquidity, 0.01)
        assertEquals(500.0, snap.reservedTotal, 0.01)
        assertEquals(4500.0, snap.freeBalance, 0.01)
        assertEquals(11, snap.remainingDaysInCycle) // Nov 20 to Dec 1 = 11 days
        assertEquals(100.0, snap.todaySpent, 0.01)
        assertEquals(2, snap.zeroSpendStreak)
        assertEquals(SafeSpendStatus.SAFE, snap.safeSpendStatus)
        assertTrue(snap.projectedEndOfCycleBalance.isFinite())
    }

    @Test
    fun `impulse purchase shield triggers when exceeding 20 percent of free balance`() {
        val days = FinanceCalculator.calculateImpulseShieldDays(
            enteredAmount = 1200.0,
            freeBalance = 4000.0,
            dailySafeLimit = 200.0,
        )
        assertNotNull(days)
        assertEquals(6, days)

        val safe = FinanceCalculator.calculateImpulseShieldDays(
            enteredAmount = 50.0,
            freeBalance = 4000.0,
            dailySafeLimit = 200.0,
        )
        assertNull(safe)
    }

    @Test
    fun `math expression evaluator handles Arabic digits and operator precedence`() {
        assertEquals(105.0, MathExpressionEvaluator.evaluate("50+35+20")!!, 0.001)
        assertEquals(250.0, MathExpressionEvaluator.evaluate("٥٠+١٠٠*٢")!!, 0.001)
        assertEquals(75.5, MathExpressionEvaluator.evaluate("(١٠٠ + ٥١) ÷ ٢")!!, 0.001)
        assertNull(MathExpressionEvaluator.evaluate("100/0"))
        assertNull(MathExpressionEvaluator.evaluate(""))
    }

    @Test
    fun `arabic numerals and commas normalize safely and RTL sign isolates format cleanly`() {
        assertEquals(125.5, Formatters.parseSafeDouble("١٢٥٫٥")!!, 0.001)
        assertEquals(45.75, Formatters.parseSafeDouble("٤٥,٧٥")!!, 0.001)
        assertEquals(1200.0, Formatters.parseSafeDouble("1,200")!!, 0.001)

        val masked = Formatters.formatEgp(500.0, isMasked = true)
        assertTrue(masked.contains("****"))

        val signedPos = Formatters.formatEgp(150.0, showPositiveSign = true)
        assertTrue(signedPos.startsWith("\u2066+ 150\u2069"))
    }

    @Test
    fun `analytics calculates small leaks and zero spend heatmap safely`() {
        val today = LocalDate.of(2026, 11, 20)
        val todayMillis = today.atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli() + 3600_000L
        val foodCatId = categories.first().id

        val txs = listOf(
            TransactionEntity(id = 1, amount = 35.0, type = TransactionType.EXPENSE, categoryId = foodCatId, walletId = 1, timestamp = todayMillis),
            TransactionEntity(id = 2, amount = 45.0, type = TransactionType.EXPENSE, categoryId = foodCatId, walletId = 1, timestamp = todayMillis),
            TransactionEntity(id = 3, amount = 250.0, type = TransactionType.EXPENSE, categoryId = foodCatId, walletId = 1, timestamp = todayMillis),
        )
        val zeroDays = listOf(ZeroSpendDayEntity(dateEpochDay = today.minusDays(1).toEpochDay()))

        val analytics = FinanceCalculator.calculateAnalytics(
            transactions = txs,
            categories = categories,
            zeroSpendDays = zeroDays,
            timeframe = AnalyticsTimeframe.MONTH,
            cycleStartDay = 1,
            dailySafeLimit = 200.0,
            today = today,
        )

        assertEquals(330.0, analytics.totalExpense, 0.01)
        assertEquals(2, analytics.smallLeaks.count)
        assertEquals(80.0, analytics.smallLeaks.totalAmount, 0.01)
        assertTrue(analytics.heatmapCells.isNotEmpty())
        assertEquals(5, analytics.monthlyComparisons.size)
    }

    @Test
    fun `ai financial context builder and offline brain use live data accurately`() {
        val today = LocalDate.of(2026, 11, 20)
        val todayMillis = today.atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli() + 3600_000L
        val testWallets = listOf(wallets[0].copy(balance = 1500.0), wallets[1].copy(balance = 2500.0))
        val envelopes = listOf(EnvelopeEntity(id = 1, title = "إيجار", reservedAmount = 1000.0, targetAmount = 1000.0))
        val goals = listOf(GoalEntity(id = 1, title = "لابتوب", targetAmount = 10000.0, savedAmount = 2000.0))
        val debts = listOf(DebtEntity(id = 1, personName = "أحمد", amount = 300.0, type = DebtType.OWED_TO_ME))
        val txs = listOf(
            TransactionEntity(id = 1, amount = 40.0, type = TransactionType.EXPENSE, categoryId = categories.first().id, walletId = 1, note = "قهوة", timestamp = todayMillis),
        )
        val budget = FinanceCalculator.calculateBudgetSnapshot(testWallets, envelopes, txs, emptyList(), 1, today)
        val analytics = FinanceCalculator.calculateAnalytics(txs, categories, emptyList(), AnalyticsTimeframe.MONTH, 1, budget.dailySafeLimit, today)

        val coachSnapshot = FinancialCoachSnapshot(
            wallets = testWallets,
            categories = categories,
            transactions = txs,
            envelopes = envelopes,
            goals = goals,
            debts = debts,
            budgetSnapshot = budget,
            analyticsSnapshot = analytics,
        )

        val prompt = FinancialContextBuilder.buildSystemPrompt(coachSnapshot, today)
        assertTrue(prompt.contains("3,000")) // Free balance 4000 - 1000
        assertTrue(prompt.contains("لابتوب"))
        assertTrue(prompt.contains("أحمد"))
        assertTrue(prompt.contains("قهوة"))

        val affordYes = OfflineFinancialBrain.analyzeAndReply("ينفع أشتري كتاب بـ 200 جنيه؟", coachSnapshot, today)
        assertTrue(affordYes.contains("تقدر تشتريه"))

        val affordNo = OfflineFinancialBrain.analyzeAndReply("ينفع أشتري موبايل بـ ٥٠٠٠ جنيه؟", coachSnapshot, today)
        assertTrue(affordNo.contains("أكبر من رصيدك الحر"))

        val leaksReply = OfflineFinancialBrain.analyzeAndReply("إيه المصاريف اللي ملهاش لازمة؟", coachSnapshot, today)
        assertTrue(leaksReply.contains("التسريبات الصغيرة"))
    }

    @Test
    fun `developer vCard QR matrix generates valid square matrix with ErrorCorrectionLevel H`() {
        val matrix = QrMatrixHelper.generateMatrix(DeveloperProfile.VCARD_PAYLOAD)
        assertTrue(matrix.width >= 33)
        assertEquals(matrix.width, matrix.height)
    }

    @Test
    fun `gamification engine resolves rank thresholds, level ups, and locked theme fallback`() {
        assertEquals(1, GamificationEngine.rankForXp(0).level)
        assertEquals(2, GamificationEngine.rankForXp(200).level)
        assertEquals(3, GamificationEngine.rankForXp(600).level)
        assertEquals(4, GamificationEngine.rankForXp(1500).level)
        assertEquals(5, GamificationEngine.rankForXp(3000).level)

        val levelUp = GamificationEngine.detectLevelUp(190, 210)
        assertNotNull(levelUp)
        assertEquals(2, levelUp!!.level)
        assertNull(GamificationEngine.detectLevelUp(210, 250))

        // Level 1 user requesting Level 4 theme falls back to EMERALD_CLASSIC
        val lockedSnap = GamificationEngine.computeSnapshot(xp = 50, selectedThemeId = MasroufyThemePack.FIERY_RUBY.id)
        assertEquals(MasroufyThemePack.EMERALD_CLASSIC, lockedSnap.activeThemePack)

        // Level 4 user requesting Level 4 theme activates FIERY_RUBY
        val unlockedSnap = GamificationEngine.computeSnapshot(xp = 1550, selectedThemeId = MasroufyThemePack.FIERY_RUBY.id)
        assertEquals(MasroufyThemePack.FIERY_RUBY, unlockedSnap.activeThemePack)
    }

    @Test
    fun `voice transaction parser handles compound sentences, Arabic number words, and income`() {
        val compound = VoiceTransactionParser.parse(
            spokenText = "دفعت 35 مواصلات و 90 غدا من الكاش",
            wallets = wallets,
            categories = categories,
        )
        assertEquals(2, compound.size)
        assertEquals(35.0, compound[0].amount, 0.01)
        assertEquals(90.0, compound[1].amount, 0.01)
        assertEquals(TransactionType.EXPENSE, compound[0].type)
        val cashId = wallets.first { it.type == WalletType.CASH }.id
        assertEquals(cashId, compound[0].walletId)
        assertEquals(cashId, compound[1].walletId)

        val wordAmount = VoiceTransactionParser.parse(
            spokenText = "صرفت مية وخمسين نت",
            wallets = wallets,
            categories = categories,
        )
        assertEquals(1, wordAmount.size)
        assertEquals(150.0, wordAmount[0].amount, 0.01)

        val income = VoiceTransactionParser.parse(
            spokenText = "قبضت 5000 مرتب انستا باي",
            wallets = wallets,
            categories = categories,
        )
        assertEquals(1, income.size)
        assertEquals(5000.0, income[0].amount, 0.01)
        assertEquals(TransactionType.INCOME, income[0].type)
        val bankId = wallets.first { it.type == WalletType.BANK }.id
        assertEquals(bankId, income[0].walletId)
    }

    @Test
    fun `gameya reserve deducts unpaid installment from free balance and detects payout readiness`() {
        val today = LocalDate.of(2026, 11, 20)
        val startYm = YearMonth.from(today).minusMonths(2).toString() // Month 3 of 5
        val gameya = GameyaEntity(
            id = 1,
            title = "جمعية الشغل",
            monthlyInstallment = 1000.0,
            totalMembers = 5,
            payoutTurnMonth = 3,
            startYearMonth = startYm,
            walletId = 1,
            paidMonthsCount = 2,
            lastPaidCycleKey = YearMonth.from(today).minusMonths(1).toString(),
            isPayoutReceived = false,
            isActive = true,
        )

        val testWallets = listOf(wallets[0].copy(balance = 5000.0))
        val snap = FinanceCalculator.calculateBudgetSnapshot(
            wallets = testWallets,
            envelopes = emptyList(),
            transactions = emptyList(),
            zeroSpendDays = emptyList(),
            cycleStartDay = 1,
            today = today,
            gameyas = listOf(gameya),
        )
        assertEquals(1000.0, snap.reservedGameyaTotal, 0.01)
        assertEquals(4000.0, snap.freeBalance, 0.01)
        assertTrue(FinanceCalculator.isGameyaPayoutReady(gameya, today))

        val paidGameya = gameya.copy(
            lastPaidCycleKey = FinanceCalculator.currentGameyaCycleKey(today),
            isPayoutReceived = true,
        )
        assertFalse(FinanceCalculator.needsCurrentCycleInstallmentReserve(paidGameya, today))
        assertFalse(FinanceCalculator.isGameyaPayoutReady(paidGameya, today))
    }

    @Test
    fun `subscriptions summary computes monthly, annualized, and 48h due alerts`() {
        val today = LocalDate.of(2026, 11, 20)
        val subs = listOf(
            SubscriptionEntity(
                id = 1,
                title = "نتفليكس",
                amount = 200.0,
                billingCycle = BillingCycle.MONTHLY,
                nextRenewalEpochDay = today.plusDays(1).toEpochDay(),
                walletId = 2,
                isActive = true,
            ),
            SubscriptionEntity(
                id = 2,
                title = "تخزين سحابي",
                amount = 1200.0,
                billingCycle = BillingCycle.YEARLY,
                nextRenewalEpochDay = today.plusDays(20).toEpochDay(),
                walletId = 2,
                isActive = true,
            ),
            SubscriptionEntity(
                id = 3,
                title = "اشتراك متوقف",
                amount = 100.0,
                billingCycle = BillingCycle.MONTHLY,
                nextRenewalEpochDay = today.toEpochDay(),
                walletId = 1,
                isActive = false,
            ),
        )

        val summary = FinanceCalculator.calculateSubscriptionsSummary(subs, today)
        assertEquals(2, summary.activeCount)
        assertEquals(300.0, summary.monthlyCommitment, 0.01)
        assertEquals(3600.0, summary.annualizedTotal, 0.01)
        assertEquals(1, summary.dueWithin48HoursCount)
    }

    @Test
    fun `notification listener detects Egyptian payment providers and ignores non-financial apps`() {
        assertEquals(
            "إنستا باي",
            PaymentNotificationListenerService.detectSenderHint("com.egyptianbanks.instapay", "تم تحويل 250 جنيه"),
        )
        assertEquals(
            "فودافون كاش",
            PaymentNotificationListenerService.detectSenderHint("com.vodafone.anavodafone", "تم استلام 400 جنيه فودافون كاش"),
        )
        assertNull(
            PaymentNotificationListenerService.detectSenderHint("com.whatsapp", "أهلاً عامل إيه النهاردة"),
        )
    }

    @Test
    fun `hashtag parser extracts Arabic and English tags and summarizes spend`() {
        val tags = HashtagParser.extractTags("قهوة الصبح #كافيه مع الشباب #Work #كافيه")
        assertEquals(listOf("#كافيه", "#Work"), tags)
        assertTrue(HashtagParser.matchesTag("طلبية #Work", "#work"))
        assertFalse(HashtagParser.matchesTag("طلبية بدون وسم", "#work"))

        val todayMillis = LocalDate.of(2026, 11, 20)
            .atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli() + 3600_000L
        val txs = listOf(
            TransactionEntity(id = 1, amount = 120.0, type = TransactionType.EXPENSE, walletId = 1, note = "قهوة #كافيه #خروجة", timestamp = todayMillis),
            TransactionEntity(id = 2, amount = 280.0, type = TransactionType.EXPENSE, walletId = 1, note = "عشاء #خروجة", timestamp = todayMillis),
            TransactionEntity(id = 3, amount = 500.0, type = TransactionType.INCOME, walletId = 1, note = "بونص #Work", timestamp = todayMillis),
        )
        val summaries = HashtagParser.summarizeTagSpend(txs)
        assertEquals(3, summaries.size)
        assertEquals("#خروجة", summaries.first().tag)
        assertEquals(400.0, summaries.first().totalExpense, 0.01)
        assertEquals(2, summaries.first().count)
        val workSummary = summaries.first { it.tag == "#Work" }
        assertEquals(500.0, workSummary.totalIncome, 0.01)
    }

    @Test
    fun `rollover mode TODAY_BONUS adds yesterday surplus while NONE and SPREAD_REMAINING do not`() {
        val today = LocalDate.of(2026, 11, 20)
        val yesterdayMillis = today.minusDays(1).atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli() + 3600_000L
        val testWallets = listOf(wallets[0].copy(balance = 1150.0))
        val txs = listOf(
            TransactionEntity(id = 1, amount = 50.0, type = TransactionType.EXPENSE, walletId = 1, timestamp = yesterdayMillis),
        )

        val bonusSnap = FinanceCalculator.calculateBudgetSnapshot(
            wallets = testWallets,
            envelopes = emptyList(),
            transactions = txs,
            zeroSpendDays = emptyList(),
            cycleStartDay = 1,
            today = today,
            dailyRolloverMode = RolloverMode.TODAY_BONUS,
        )
        val spreadSnap = FinanceCalculator.calculateBudgetSnapshot(
            wallets = testWallets,
            envelopes = emptyList(),
            transactions = txs,
            zeroSpendDays = emptyList(),
            cycleStartDay = 1,
            today = today,
            dailyRolloverMode = RolloverMode.SPREAD_REMAINING,
        )
        val noneSnap = FinanceCalculator.calculateBudgetSnapshot(
            wallets = testWallets,
            envelopes = emptyList(),
            transactions = txs,
            zeroSpendDays = emptyList(),
            cycleStartDay = 1,
            today = today,
            dailyRolloverMode = RolloverMode.NONE,
        )

        assertTrue(bonusSnap.yesterdaySurplusBonus > 0.0)
        assertTrue(bonusSnap.dailySafeLimit > spreadSnap.dailySafeLimit)
        assertEquals(0.0, spreadSnap.yesterdaySurplusBonus, 0.01)
        assertEquals(0.0, noneSnap.yesterdaySurplusBonus, 0.01)
    }

    @Test
    fun `trip event isolates trip expenses from today regular daily spend`() {
        val today = LocalDate.of(2026, 11, 20)
        val todayMillis = today.atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli() + 3600_000L
        val trip = TripEventEntity(id = 7, title = "سفريات الساحل", budget = 2000.0, isActive = true)
        val txs = listOf(
            TransactionEntity(id = 1, amount = 60.0, type = TransactionType.EXPENSE, walletId = 1, timestamp = todayMillis, tripEventId = null),
            TransactionEntity(id = 2, amount = 750.0, type = TransactionType.EXPENSE, walletId = 1, timestamp = todayMillis, tripEventId = 7),
        )

        val snap = FinanceCalculator.calculateBudgetSnapshot(
            wallets = listOf(wallets[0].copy(balance = 5000.0)),
            envelopes = emptyList(),
            transactions = txs,
            zeroSpendDays = emptyList(),
            cycleStartDay = 1,
            today = today,
            trips = listOf(trip),
        )

        assertEquals(60.0, snap.todaySpent, 0.01)
        assertNotNull(snap.activeTripSnapshot)
        assertEquals(750.0, snap.activeTripSnapshot!!.spent, 0.01)
        assertEquals(1250.0, snap.activeTripSnapshot!!.remaining, 0.01)
    }

    @Test
    fun `installments reserve current unpaid cycle and release after cycle payment`() {
        val today = LocalDate.of(2026, 11, 20)
        val unpaid = InstallmentEntity(
            id = 1,
            itemName = "لاب توب فاليو",
            monthlyAmount = 800.0,
            paidMonths = 2,
            totalMonths = 12,
            dueDay = 25,
            walletId = 1,
            lastPaidCycleKey = YearMonth.from(today).minusMonths(1).toString(),
            isActive = true,
        )
        val paidThisMonth = unpaid.copy(
            id = 2,
            itemName = "تكييف",
            monthlyAmount = 500.0,
            lastPaidCycleKey = FinanceCalculator.currentGameyaCycleKey(today),
        )

        val snap = FinanceCalculator.calculateBudgetSnapshot(
            wallets = listOf(wallets[0].copy(balance = 3000.0)),
            envelopes = emptyList(),
            transactions = emptyList(),
            zeroSpendDays = emptyList(),
            cycleStartDay = 1,
            today = today,
            installments = listOf(unpaid, paidThisMonth),
        )

        assertEquals(800.0, snap.reservedInstallmentsTotal, 0.01)
        assertEquals(2200.0, snap.freeBalance, 0.01)
        assertTrue(FinanceCalculator.needsCurrentCycleInstallmentReserve(unpaid, today))
        assertFalse(FinanceCalculator.needsCurrentCycleInstallmentReserve(paidThisMonth, today))
    }

    @Test
    fun `zero based budget, emergency target, inflation radar, and health score compute accurately`() {
        val today = LocalDate.of(2026, 11, 20)
        val zone = ZoneId.systemDefault()
        val nowMillis = today.atStartOfDay(zone).toInstant().toEpochMilli() + 3600_000L
        val lastMonthMillis = today.minusMonths(1).atStartOfDay(zone).toInstant().toEpochMilli() + 3600_000L
        val twoMonthsAgoMillis = today.minusMonths(2).atStartOfDay(zone).toInstant().toEpochMilli() + 3600_000L
        val foodCatId = categories.first { it.type == TransactionType.EXPENSE }.id

        val testCategories = categories.map {
            if (it.id == foodCatId) it.copy(monthlyBudget = 2000.0) else it.copy(monthlyBudget = null)
        }
        val envelopes = listOf(EnvelopeEntity(id = 1, title = "إيجار", reservedAmount = 3000.0, targetAmount = 3000.0))
        val txs = listOf(
            TransactionEntity(id = 1, amount = 10000.0, type = TransactionType.INCOME, walletId = 1, timestamp = nowMillis),
            TransactionEntity(id = 2, amount = 1000.0, type = TransactionType.EXPENSE, categoryId = foodCatId, walletId = 1, timestamp = twoMonthsAgoMillis),
            TransactionEntity(id = 3, amount = 1000.0, type = TransactionType.EXPENSE, categoryId = foodCatId, walletId = 1, timestamp = lastMonthMillis),
            TransactionEntity(id = 4, amount = 1500.0, type = TransactionType.EXPENSE, categoryId = foodCatId, walletId = 1, timestamp = nowMillis),
        )
        val cycleKey = FinanceCalculator.currentGameyaCycleKey(today)

        val zbb = FinanceCalculator.calculateZeroBasedBudget(
            transactions = txs,
            envelopes = envelopes,
            categories = testCategories,
            gameyas = emptyList(),
            installments = emptyList(),
            cycleStartDay = 1,
            cycleSavingsAmount = 2000.0,
            cycleSavingsKey = cycleKey,
            today = today,
        )
        assertEquals(10000.0, zbb.monthlyIncome, 0.01)
        assertEquals(7000.0, zbb.totalAllocated, 0.01)
        assertEquals(3000.0, zbb.unallocatedBalance, 0.01)

        val emergencyTarget = FinanceCalculator.calculateEmergencyFundTarget(txs, testCategories, today)
        assertTrue(emergencyTarget >= 3000.0)

        val alerts = FinanceCalculator.calculateInflationAlerts(txs, testCategories, today)
        assertEquals(1, alerts.size)
        assertEquals(50, alerts.first().increasePercent)

        val budget = FinanceCalculator.calculateBudgetSnapshot(
            wallets = listOf(wallets[0].copy(balance = 10000.0)),
            envelopes = envelopes,
            transactions = txs,
            zeroSpendDays = listOf(ZeroSpendDayEntity(today.minusDays(1).toEpochDay())),
            cycleStartDay = 1,
            today = today,
        )
        val health = FinanceCalculator.calculateFinancialHealthScore(
            transactions = txs,
            budgetSnapshot = budget,
            debts = emptyList(),
            cycleStartDay = 1,
            today = today,
        )
        assertTrue(health.score in 0..100)
        assertTrue(health.tips.isNotEmpty())
    }
}
